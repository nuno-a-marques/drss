package QTable;
import simulator.SimulationStatus;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

import org.apache.commons.math3.util.Precision;

import main.GlobalParameters;

public class QTable {
    //public double[][][] table = {{{0.3719336827610949, 0.3923395721172606, 0.2357267451216443},{-0.684036939731058, 0.1654393585595976, -0.1505237017093443},{-0.3438253241541886, 0.3073448659298766, 0.3488298099159348},{0.3022675370078187, 0.533443927795815, 0.1642885351963663},{-0.4105521057571363, 0.4555993831039987, -0.1338485111388649},{-0.1772764930081281, -0.4084296626021168, 0.4142938443897551},{0.3772596654446654, -0.5043782696937431, -0.1183620648615915},{-0.3035454724958062, -0.0555024275373259, 0.6409520999668677},{-0.0837418638654674, 0.1260250055409532, 0.7902331305935794},{0.4225994818894552, 0.5549652038777803, -0.0224353142327646}},{{0.3758046540763923, 0.4019047654977942, 0.2222905804258134},{0.3325445811520111, 0.3343038669187477, 0.3331515519292413},{0.3333333577955255, 0.3333332907840059, 0.3333333514204686},{0.3333152013246888, 0.333345345743612, 0.3333394529316992},{0.3333336368634135, 0.3333069708488181, 0.3333593922877683},{0.3347502196372795, 0.328421234325109, 0.3368285460376113},{0.3571317786896831, 0.3014481550117998, 0.3414200662985171},{0.393601624008783, 0.2746192962155367, 0.3317790797756802},{0.3932233409550371, 0.3137810112034104, 0.2929956478415523},{0.3523157460065135, 0.3429861250703492, 0.3046981289231373}},{{0.31506277703475, 0.2893960322545237, 0.3955411907107262},{0.3201981190149732, 0.3383691653570657, 0.3414327156279612},{0.3333333668039444, 0.3333333202151092, 0.3333333129809462},{0.3333333333333331, 0.3333333333333331, 0.3333333333333337},{0.3333333333333333, 0.3333333333333333, 0.3333333333333332},{0.3333333333333333, 0.3333333333333333, 0.3333333333333333},{0.3333333333333333, 0.3333333333333333, 0.3333333333333333},{0.3333333333333333, 0.3333333333333333, 0.3333333333333333},{0.3333333333333333, 0.3333333333333333, 0.3333333333333333},{0.3333333333333333, 0.3333333333333333, 0.3333333333333333}},{{0.4478095860686574, 0.3089435897443186, 0.2432468241870241},{0.3336858118785226, 0.3339371732823284, 0.332377014839149},{0.3333576425966263, 0.3333275547799414, 0.3333148026234322},{0.3333332755100859, 0.3333333353491025, 0.3333333891408115},{0.3333333333486767, 0.333333333302647, 0.3333333333486763},{0.3332162368322852, 0.3333918815838573, 0.3333918815838573},{0.3333333333333333, 0.3333333333333333, 0.3333333333333333},{0.3333333333333333, 0.3333333333333333, 0.3333333333333333},{0.3333333333333333, 0.3333333333333333, 0.3333333333333333},{0.3333333333333333, 0.3333333333333333, 0.3333333333333333}},{{0.2348406256990019, 0.4269367496560485, 0.3382226246449495},{0.3332066975494552, 0.3333938734906962, 0.3333994289598486},{0.3333355730895654, 0.3333355733358989, 0.3333288535745355},{0.333333333334707, 0.3333333333332391, 0.3333333333320538},{0.3333333333892833, 0.3333333333877059, 0.3333333332230108},{0.3333333333354196, 0.3333333333354195, 0.333333333329161},{0.3333333332550726, 0.3333333333724636, 0.3333333333724638},{0.3333333333333333, 0.3333333333333333, 0.3333333333333333},{0.3333333333333333, 0.3333333333333333, 0.3333333333333333},{0.3333333333333333, 0.3333333333333333, 0.3333333333333333}},{{-0.2089774856147145, 0.6844575252981479, -0.1065649890871375},{0.345875491028768, 0.3074113197020623, 0.3467131892691697},{0.3333333850217019, 0.3333335039026631, 0.3333331110756349},{0.3333333333906834, 0.3333333332186867, 0.3333333333906298},{0.333333562191159, 0.3333335621911562, 0.3333328756176847},{0.333333333333335, 0.333333333333335, 0.33333333333333},{0.3333333333333333, 0.3333333333333333, 0.3333333333333333},{0.3333333333333333, 0.3333333333333333, 0.3333333333333333},{0.3333333333333333, 0.3333333333333333, 0.3333333333333333},{0.3333333333333333, 0.3333333333333333, 0.3333333333333333}},{{-0.0365174306762611, 0.5309559688535432, -0.4325266004701956},{0.333370894418501, 0.3333715844353443, 0.3332575211461547},{0.3333333332797009, 0.3333333335264831, 0.333333333193816},{0.3333333333860374, 0.3333333332102323, 0.3333333334037303},{0.3333333337001528, 0.3333333337001101, 0.3333333325997371},{0.3333333333333333, 0.3333333333333333, 0.3333333333333333},{0.3333333333333207, 0.3333333333333396, 0.3333333333333396},{0.3333333333333333, 0.3333333333333333, 0.3333333333333333},{0.3333333333333333, 0.3333333333333333, 0.3333333333333333},{0.3333333333333333, 0.3333333333333333, 0.3333333333333333}},{{0.1893348288226383, 0.1305524981563154, 0.6801126730210462},{0.333902551335215, 0.3321965519337918, 0.3339008967309932},{0.3333333505273134, 0.3333333504357109, 0.3333332990369757},{0.3333298666757122, 0.3333350666376038, 0.3333350666866838},{0.3333333333333286, 0.3333333333333355, 0.3333333333333359},{0.3333333333892463, 0.333333333221507, 0.3333333333892466},{0.3333333333333336, 0.3333333333333326, 0.3333333333333336},{0.3333333333333333, 0.3333333333333333, 0.3333333333333333},{0.3333333333333333, 0.3333333333333333, 0.3333333333333333},{0.3333333333333333, 0.3333333333333333, 0.3333333333333333}},{{-0.660494878381834, 0.2141862164845371, 0.1253189051336289},{0.3519098048424404, 0.3519015703179124, 0.2961886248396472},{0.3333333294448818, 0.3333333351013023, 0.3333333354538158},{0.3333333333552062, 0.3333333333523538, 0.3333333332924401},{0.3333333335216111, 0.3333333335245591, 0.3333333329538298},{0.3333333333333333, 0.3333333333333338, 0.3333333333333329},{0.3333333333333333, 0.3333333333333333, 0.3333333333333333},{0.3333333333333333, 0.3333333333333333, 0.3333333333333333},{0.3333333333333333, 0.3333333333333333, 0.3333333333333333},{0.3333333333333333, 0.3333333333333333, 0.3333333333333333}},{{0.333330068951758, 0.3333419230439987, 0.3333280080042431},{0.3333333309756085, 0.3333333355148026, 0.3333333335095888},{0.3333333352585053, 0.3333333302396711, 0.3333333345018235},{0.3333333333382638, 0.3333333333234722, 0.3333333333382638},{0.3333333333333333, 0.3333333333333333, 0.3333333333333333},{0.3333333333333333, 0.3333333333333333, 0.3333333333333333},{0.3333333333333333, 0.3333333333333333, 0.3333333333333333},{0.3333333333333333, 0.3333333333333333, 0.3333333333333333},{0.3333333333333333, 0.3333333333333333, 0.3333333333333333},{0.3333333333333333, 0.3333333333333333, 0.3333333333333333}}} ;
    //public double[][][][] table = new double[10][10][10][3];                             // UPDT
    public double[][][]   tableSmall = new double[5][5][3];                                          // UPDT
    public double[][][][] tableLarge = new double[5][5][5][3];                                       // UPDT
    //public int numberOfWeights = 375 ;          // HARD CODED                               // UPDT,    75, 375,  300, 3000

    public QTable(){  
        // atualizar os pesos da Qtable

        double [] readWeights = readQTableWeights();                     // HC, hard coded
        
        if ( GlobalParameters.rtrsSS.equals("ss-1") ){
            setupTableSmall(readWeights);
        }
        else if ( GlobalParameters.rtrsSS.equals("ss-2") ){
            setupTableSmall(readWeights);
        }
        else if ( GlobalParameters.rtrsSS.equals("ss-3") ){
            setupTableLarge(readWeights);
        }
    }

    public QTable(int a ){  
        
    }

    public void setupTableSmall(double [] readWeights){
        // transfer dos pesos para a neural net
        int controlo   = 0 ;
        int x_controlo = 0 ;
        int y_controlo = 0 ;
        int q_controlo = 0 ;

        // weight transfer 3000 params                                                                          UPDT
        for(int i = 0; i < readWeights.length; i++){
            tableSmall [x_controlo] [y_controlo] [q_controlo] = readWeights[controlo];                               // UPDT

            controlo = controlo + 1 ;
            q_controlo = q_controlo + 1;
            if (q_controlo == 3) {
                q_controlo = 0;
                y_controlo = y_controlo + 1;
            }
            if (y_controlo == 5) {                                                                            // UPDT    5, 10 or 3000 params
                y_controlo = 0;
                x_controlo = x_controlo + 1;
            }
        }
    }

    public void setupTableLarge(double [] readWeights){
        
        // transfer dos pesos para a neural net
        int controlo   = 0 ;
        int x_controlo = 0 ;
        int y_controlo = 0 ;
        int z_controlo = 0 ;
        int q_controlo = 0 ;

        // weight transfer 3000 params                                                                          UPDT
        for(int i = 0; i < readWeights.length; i++){
            tableLarge [x_controlo] [y_controlo] [z_controlo] [q_controlo] = readWeights[controlo];                               // UPDT

            controlo = controlo + 1 ;
            q_controlo = q_controlo + 1;
            if (q_controlo == 3) {
                q_controlo = 0;
                z_controlo = z_controlo + 1;
            }
            if (z_controlo == 5) {                                                                            // UPDT    5, 10 or 3000 params
                z_controlo = 0;
                y_controlo = y_controlo + 1;
            }
            if (y_controlo == 5) {                                                                            // UPDT    5, 10 or 3000 params
                y_controlo = 0;
                x_controlo = x_controlo + 1;
            }
        }
    }

    public double[] readQTableWeights(){
        int numWeights =   0;
        int tokenPos   =   0;

        if (      GlobalParameters.rtrsSS.equals("ss-1") ){
            numWeights =  75;
            tokenPos   =   3;
        }
        else if ( GlobalParameters.rtrsSS.equals("ss-2") ){
            numWeights =  75;
            tokenPos   =   3;            
        }
        else if ( GlobalParameters.rtrsSS.equals("ss-3") ){
            numWeights = 375;
            tokenPos   =   4;            
        }

        String fileName = "";        
        fileName = "q_table_" + GlobalParameters.NNSETUP + ".txt";
        double [] readWeights = new double[numWeights];                                    // HC, hard coded    UPDT       75,  300, 3000
        int controlo=0;
        try{
            File myObj = new File(fileName);
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                // System.out.println(data);                                        // only in VERBOSE
                String[] tokens = data.split(",");                
                double   x = Double.parseDouble(tokens[tokenPos]);                         // HC hardcoded      UPDT          3, 4
                readWeights[controlo] = x; 
                controlo = controlo + 1 ;  
        }
        myReader.close();
        }
        catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            int randomVar = 1000/0;
            e.printStackTrace();
        }

        return  readWeights;
    }

    public int convertVar3(double val){
        int temp = (int) Math.floor(val/18000);
        temp = Math.max(temp, 0);
        temp = Math.min(temp, 9);
        return temp;
    }

    public int convertVar3_log(double val){
        val  = Math.log(val+1.0);
        val  = val-8.0;
        int temp = (int) Math.floor(val/0.8);                           // UPDT  0.4    0.8
        temp = Math.max(temp, 0);
        temp = Math.min(temp, 4);                                    // UPDT  9   4
        return temp;
    }

    public int convertVar1(double val){
        int temp = (int) Math.floor(val/500);
        temp = Math.max(temp, 0);
        temp = Math.min(temp, 9);
        return temp;
    }

    public int convertVar1_log(double val){
        val  = Math.log(val+1.0);
        val  = val-6.5;
        int temp = (int) Math.floor(val/0.5);   	                               // UPDT     0.3  0.6   0.5
        temp = Math.max(temp, 0);
        temp = Math.min(temp, 4);                                               // UPDT      9 4
        return temp;
    }

    public int convertVar2_log(double val){
        val         = Math.log(val+1.0);
        //val  = val-6;
        int temp = (int) Math.floor(val/2.6);                                   // UPDT    1.3    2.6
        temp = Math.max(temp, 0);
        temp = Math.min(temp, 4);                                             // UPDT    9   4
        return temp;
    }

    public int convertVar2(double val){
        int temp = (int) Math.floor(val/300);
        temp = Math.max(temp, 0);
        temp = Math.min(temp, 9);
        return temp;
    }

    public int getAgentSuggestion(double var, double var2, double var3, SimulationStatus status){
        //double[] jsState = status.getAgentStatus();
        int x1 = convertVar1_log(var);          // wip                                    // UPDT
        int x2 = convertVar2_log(var2);         // tard                                   // UPDT
        int x3 = convertVar3_log(var3);         // earl                                   // UPDT

        double maxQ = - Double.MAX_VALUE;
        int out = 508;
        int[] rules = {18, 214,  508};

        for (int i = 0; i < 3; i++) {
            double q_val = 0;
            if (      GlobalParameters.rtrsSS.equals("ss-1") ){
                q_val = Precision.round ( tableSmall [x1][x2][i], 5 );                    // UPDT
            }
            else if ( GlobalParameters.rtrsSS.equals("ss-2") ){
                q_val = Precision.round ( tableSmall [x1][x3][i], 5 );          
            }
            else if ( GlobalParameters.rtrsSS.equals("ss-3") ){
                q_val = Precision.round ( tableLarge [x1][x2][x3][i], 5 );           
            }

            if (q_val >= maxQ) {
                maxQ = q_val;
                out = rules[i]; // ir ao vetor das regras
            }
            // System.out.println( String.valueOf(var) + ", " + x1 + ", " + String.valueOf(var2) + ", " + x2 + ", " + String.valueOf(var3) + ", " + x3+ ", "+ String.valueOf(q_val));
        }
        /* System.out.println(out);
        if (out == 214) {
            System.out.println("alto");
        } */
        
        return out;
    }

    public void getPlotDecisions(){
        // obter suggestions

        int[] var1 = new int[10000];
        int[] var2 = new int[10000];
        int[] resu = new int[10000];

        int contador = 0;
        
        for (int i = 0; i <= 8000; i+= 100) {
            for (int j = 0; j <= 8000; j+= 100) {
                int result = getAgentSuggestion(i, j, 0, null);
                //System.out.println(i + ", " + j + ", " + result);
                var1[contador] = i;
                var2[contador] = j;
                resu[contador] = result;
                contador = contador + 1;
            }
        }
        contador = 0;
        PrintWriter writer;
        try {
            writer = new PrintWriter("dataForPlots-" + GlobalParameters.NNSETUP + ".txt", "UTF-8");
            for (int i = 0; i <= 8000; i+= 100) {
                for (int j = 0; j <= 8000; j+= 100) {
                    writer.println(var1[contador] + ", " + var2[contador] + ", " + resu[contador]);
                    contador = contador + 1;
                }
            }
            writer.close();
        } catch (FileNotFoundException | UnsupportedEncodingException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        int breakpoint = 10000/0;
    }

// weight transfer 3000 params                                                                          UPDT
/* for(int i = 0; i < numberOfWeights; i++){
    table [x_controlo] [y_controlo] [z_controlo] [q_controlo] = readWeights[controlo];

    controlo = controlo + 1 ;
    q_controlo = q_controlo + 1;
    if (q_controlo == 3) {
        q_controlo = 0;
        z_controlo = z_controlo + 1;
    }
    if (z_controlo == 10) {
        z_controlo = 0;
        y_controlo = y_controlo + 1;
    }
    if (y_controlo == 10) {
        y_controlo = 0;
        x_controlo = x_controlo + 1;
    }
} */

}
