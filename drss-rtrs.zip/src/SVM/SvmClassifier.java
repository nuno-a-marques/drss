package SVM;

import org.jpmml.evaluator.Evaluator;
import org.jpmml.evaluator.LoadingModelEvaluatorBuilder;
import org.jpmml.evaluator.support_vector_machine.VoteProbabilityDistribution;
import org.xml.sax.SAXException;
import jakarta.xml.bind.JAXBException;
import main.GlobalParameters;

import java.io.File;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.xml.parsers.ParserConfigurationException;
import org.jpmml.evaluator.ProbabilityDistribution;

public class SvmClassifier {
    // https://openscoring.io/blog/2014/05/15/jpmml_evaluator_api_prepare_evaluate/
    // https://metana.io/blog/how-to-use-sklearn-in-java-scikit-learn/~

    Evaluator evaluator;
    int remainder;

    public SvmClassifier() {

        // tipo de inputs necessarios
        setRemainder();

        try {
            // Load the PMML model
            evaluator = new LoadingModelEvaluatorBuilder().load(new File("svm_" + GlobalParameters.NNSETUP + ".pmml")).build();            
        } catch (IOException | ParserConfigurationException | SAXException | JAXBException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    public SvmClassifier(int a) {

    }

    public void setRemainder(){
        String configStr = String.valueOf(GlobalParameters.NNSETUP);
        configStr = configStr.substring(3,4);
        int configIDX = Integer.parseInt(configStr);
        remainder = configIDX;
    }

    public int getSvmSuggestion(double x1, double x2, double x3, double x4){
        // x1     x2       x3       x4
        // WIP   eTrad    eEarl    eLat

        Map<String, Double> arguments = new LinkedHashMap<>();
        if (remainder == 1) { 
            arguments.put("x1", x1);
            arguments.put("x2", x2);
        }
        else if (remainder == 2) { 
            arguments.put("x1", x1);
            arguments.put("x2", x3);
        }
        else if (remainder == 3) { 
            arguments.put("x1", x1);
            arguments.put("x2", x4);
        }
        else if (remainder == 4) { 
            arguments.put("x1", x1);
            arguments.put("x2", x2);
            arguments.put("x3", x3);
        }
        else if (remainder == 5) { 
            arguments.put("x1", x1);
            arguments.put("x2", x3);
            arguments.put("x3", x4);
        }
        else if (remainder == 6) { 
            arguments.put("x1", x1);
            arguments.put("x2", x2);
            arguments.put("x3", x3);
            arguments.put("x4", x4);
        }
        
        Map<String, ?> results = evaluator.evaluate(arguments);
        Object targetValue = results.get("y");
        
        //extrair o resultado
        String result = targetValue.toString();
        result = result.substring(35);
        int label = 508;
        if      (  result.charAt(7) == ",".charAt(0) )        {       label = 508 ;   }
        else if (  result.charAt(5) == ",".charAt(0) )        {       label = 214 ;   }
        else if (  result.charAt(2) == ",".charAt(0) )        {       label =  18 ;   }
        else    {
                    System.out.println("erro no output do modelo");
                    int a = 1000/0;   
        }
        //System.out.println(label);

        return label;
    }

}