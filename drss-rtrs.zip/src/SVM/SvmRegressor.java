package SVM;

import org.jpmml.evaluator.Evaluator;
import org.jpmml.evaluator.LoadingModelEvaluatorBuilder;
import org.xml.sax.SAXException;

import jakarta.xml.bind.JAXBException;
import main.GlobalParameters;

import java.io.File;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

public class SvmRegressor {

    Evaluator evaluator_18 ;
    Evaluator evaluator_214;
    Evaluator evaluator_508;
    int remainder;

    public SvmRegressor() {
        // obter o remainder
        setRemainder();

        try {
            // Load the PMML model
            evaluator_18  = new LoadingModelEvaluatorBuilder().load(new File("svm_" + GlobalParameters.NNSETUP + "_18.pmml")).build( );
            evaluator_214 = new LoadingModelEvaluatorBuilder().load(new File("svm_" + GlobalParameters.NNSETUP + "_214.pmml")).build();
            evaluator_508 = new LoadingModelEvaluatorBuilder().load(new File("svm_" + GlobalParameters.NNSETUP + "_508.pmml")).build();            
        } catch (IOException | ParserConfigurationException | SAXException | JAXBException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        // debugModel();

    }

    public SvmRegressor(int a) {

    }

    public void setRemainder(){
        String configStr = String.valueOf(GlobalParameters.NNSETUP);
        configStr = configStr.substring(3,4);
        int configIDX = Integer.parseInt(configStr);
        remainder = configIDX;
    }

    public void debugModel(){
        double x1 = 2000.0;
        double x2 =  150.0;

        Map<String, Double> arguments = new LinkedHashMap<>();
        if (remainder == 1) { 
            arguments.put("var19", x1);
            arguments.put("var24", x2);
        }

        Map<String, ?> results = evaluator_18.evaluate(arguments);
        Object targetValue = results.get("y");
        // double out = (double) targetValue;
        
        //extrair o resultado
        String result = targetValue.toString();
        
        System.out.println(result);

    }

    public int getSvmSuggestion(double x1, double x2, double x3, double x4){
        // x1     x2       x3       x4
        // WIP   eTrad    eEarl    eLat
        // v19   v24      v25      v26

        int label = 14;                                                                     // init da variavel

        Map<String, Double> arguments = new LinkedHashMap<>();
        if (remainder == 1) { 
            arguments.put("var19", x1);                                                    // os nomes das variaveis originais
            arguments.put("var24", x2);
        }
        else if (remainder == 2) { 
            arguments.put("var19", x1);
            arguments.put("var25", x3);
        }
        else if (remainder == 3) { 
            arguments.put("var19", x1);
            arguments.put("var26", x4);
        }
        else if (remainder == 4) { 
            arguments.put("var19", x1);
            arguments.put("var24", x2);
            arguments.put("var25", x3);
        }
        else if (remainder == 5) { 
            arguments.put("var19", x1);
            arguments.put("var25", x3);
            arguments.put("var26", x4);
        }
        else if (remainder == 6) { 
            arguments.put("var19", x1);
            arguments.put("var24", x2);
            arguments.put("var25", x3);
            arguments.put("var26", x4);
        }
        
        Map<String, ?> result_18 = evaluator_18.evaluate(arguments);
        Object targetValue_18   = result_18.get("y");
        double pred_18          = (double) targetValue_18;

        Map<String, ?> result_214 = evaluator_214.evaluate(arguments);
        Object targetValue_214 = result_214.get("y");
        double pred_214          = (double) targetValue_214;

        Map<String, ?> result_508 = evaluator_508.evaluate(arguments);
        Object targetValue_508 = result_508.get("y");
        double pred_508          = (double) targetValue_508;
        
        if ( (pred_18 < pred_214 ) & (pred_18 < pred_508) ){
            label = 18;
        }
        else{
            if (pred_214 < pred_508){
                label = 214;
            }
            else {
                label = 508;
            }
        }

        return label;
    }
    
}
