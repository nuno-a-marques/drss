package utils;

import java.util.Map;
import java.util.Random;

import javax.lang.model.util.ElementScanner6;

import org.apache.commons.math3.distribution.ExponentialDistribution;
import org.apache.commons.math3.distribution.GammaDistribution;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.random.Well19937c;

import input.Instance;
import main.GlobalParameters;
import simulator.BenchmarkResult;


public class Utils {

	private static ExponentialDistribution expDistribution;
	private static Random randomNumber;
	private static Random disruptionGenerator;
	private static RandomGenerator randomGenerator;
	private static Map<Integer,Map<Integer,Map<Double,Map<Integer, BenchmarkResult> > > > benchmarkResults;

	public static enum ProblemType {
		JOBSHOP {
		      public String toString() {
		          return "js";
		      }
		  },

		  FLEXIBLE_JOBSHOP {
		      public String toString() {
		          return "fjs";
		      }
		  },
		  PARALLEL_MACHINE {
		      public String toString() {
		          return "pm";
		      }
		  }		  
		}
	
	public static enum EvaluationType {
		NORMAL,
		SMALL,
		SIMPLIFIED		  
		}	
	
	public static void setBenchmarkResults(Map<Integer,Map<Integer,Map<Double,Map<Integer,BenchmarkResult> > > > results){
		benchmarkResults = results;
	}
	public static void initializeExpDistributions(Instance instance, double utilization){
		
		double meanInterval = getMeanArrivalInterval(instance, utilization);
		//expDistribution = new ExponentialDistribution(meanInterval);

		expDistribution = new ExponentialDistribution(randomGenerator, meanInterval);
		
		//expDistribution = new ExponentialDistribution(utilization);		
	}

	public static double getBestResultTardiness(Instance instance, double allowanceFactor, double utilizationLevel, double cv){
		
		Integer instanceName= Integer.valueOf(instance.getName());
		int cvInteger = (int)Math.round(100*cv);
		int uInteger = (int)Math.round(100*utilizationLevel);
		
		return benchmarkResults.get(instanceName).get(cvInteger).get(allowanceFactor).get(uInteger).getTardiness();	
	}
	
	public static double getBestResultFlowtime(Instance instance, double allowanceFactor, double utilizationLevel, double cv){
		
		Integer instanceName= Integer.valueOf(instance.getName());
		int cvInteger = (int)Math.round(100*cv);
		int uInteger = (int)Math.round(100*utilizationLevel);
		
		return benchmarkResults.get(instanceName).get(cvInteger).get(allowanceFactor).get(uInteger).getFlowtime();
	}
	
	public static double getBestResultTardyJobs(Instance instance, double allowanceFactor, double utilizationLevel, double cv){
		
		Integer instanceName= Integer.valueOf(instance.getName());
		int cvInteger = (int)Math.round(100*cv);
		int uInteger = (int)Math.round(100*utilizationLevel);
		
		return benchmarkResults.get(instanceName).get(cvInteger).get(allowanceFactor).get(uInteger).getPercentageTardyJobs();			
	}	
	
	public static BenchmarkResult getBenchmarkResult(Instance instance, double allowanceFactor, double utilizationLevel, double cv){
		
		Integer instanceName= Integer.valueOf(instance.getName());
			
		int cvInteger = (int)Math.round(100*cv);
		int uInteger = (int)Math.round(100*utilizationLevel);
		
		Map<Integer,Map<Double,Map<Integer,BenchmarkResult> > > bestByCV = benchmarkResults.get(instanceName);		
		if(bestByCV != null){
			Map<Double,Map<Integer,BenchmarkResult> > bestByAllowance = bestByCV.get(cvInteger);
			if(bestByAllowance != null){
				Map<Integer,BenchmarkResult> bestByUtilization =bestByAllowance.get(allowanceFactor);
				
				if(bestByUtilization !=null)
					return bestByUtilization.get(uInteger);		
				else 
					return null;
			}
			else
				return null;
		}
		else
			return null;
	}
	
	public static void initializeData(){
		
		randomNumber = new Random();
		randomGenerator=new Well19937c();
		disruptionGenerator = new Random();
		
	}
	
	public static void setDistributionsSeed(long seed, double cv){
		//System.out.println("Setting Distributions seed: " + seed);
		expDistribution.reseedRandomGenerator(seed);
		randomNumber.setSeed(seed);
		randomGenerator.setSeed(seed);
		disruptionGenerator.setSeed(seed);
		//System.out.println("Test Random Number: " + String.valueOf(getRandomNumber(1.0, 2.0)));
		//System.out.println("Test Random Number: " + String.valueOf(getRandomNumber(1.0, 2.0)));
		//System.out.println("Test Random ExpDist: " + String.valueOf(getArrivalTimeSample()));
		//System.out.println("Test Random ExpDist: " + String.valueOf(getArrivalTimeSample()));			
	}

	public static void setExpDistributionsSeed(long seed, double cv){
		//System.out.println("Setting expDist seed: " + seed);
		expDistribution.reseedRandomGenerator(seed);
		//System.out.println("Test Random ExpDist: " + String.valueOf(getArrivalTimeSample()));
		//System.out.println("Test Random ExpDist: " + String.valueOf(getArrivalTimeSample()));		
	}
	
	public static double getRandomNumber(double min, double max){
		return randomNumber.nextDouble()*(max-min)+min;
	}

	public static double getGaussianRandomNumber(){
		return Math.max(randomNumber.nextGaussian()*5+50,1);
	}
	
	public static double getRoundedRandomNumber(int min, int max){
		
		double sample1 = randomNumber.nextDouble();
		double sample2 = sample1*(max-min);				
		return (int) (min+sample2);
	}
	
	public static int getRandomInt(int min, int max){
		int sample = min+randomNumber.nextInt(max-min+1);
		return sample;
	}
	
	public static double getOperationTimeSample(double operationTime, double cv){	
		// only used with CV uncertainty		
		if(cv < 0.0001)
			return operationTime;
		
		double variance = Math.pow(operationTime*cv, 2.0);
		double exp2 = Math.pow(operationTime, 2.0);
		double alpha = exp2 / variance;
		double beta = variance / operationTime;		
		GammaDistribution dist = new GammaDistribution(alpha, beta);	
		dist.reseedRandomGenerator(0);
		double sample = dist.sample();
						
		return sample;
	}
	
	public static double getIndividualSizePenalty(int maxGenerations, int currGeneration){	
		if(GlobalParameters.FIXED_PENALTY)
			return GlobalParameters.SIZE_PENALTY;
		else
			return currGeneration*GlobalParameters.SIZE_PENALTY;
	}
	
	public static double getArrivalTimeSample(){
		//long a = 1;
		//expDistribution.reseedRandomGenerator(a);	
		return (int) expDistribution.sample();
	}	
		
	public static double getMeanArrivalInterval(Instance instance, double utilization){
		double resultado=0.0;		
		//double nMachines = ((double)instance.getNumMachines())*instance.getOpFlexibility();
		double nMachines = ((double)instance.getNumMachines());	
		
		double avgOpTime = (double)(instance.getMaxProcessingTime() + instance.getMinProcessingTime())/2.0;				
		double jobProcessingTime = ((double)(instance.getMaxNumOperations()+instance.getMinNumOperations())*
				avgOpTime)/2.0;
		//double fc=Math.pow(utilization,instance.getOpFlexibility()*((double)instance.getNumMachines()));
		//double fc=3.4815*Math.pow(instance.getOpFlexibility(),2)-1.4222*instance.getOpFlexibility()+0.1074;

		double serviceTime = jobProcessingTime/nMachines;
		resultado = serviceTime/utilization;

		//double k=0.5;
		//resultado=resultado*(k/Math.sqrt(instance.getOpFlexibility()));

		// double k=0.9;
		// resultado=resultado*k;

		//System.out.println("O InterArrivalTime é:    "+ String.valueOf(resultado));
		
		return resultado;
	}

	// LOGIC FOR DISRUTION SAMPLES	
	public static double getDisruptionTimestepSample(int min, int max){
		// THE NAME IS TIMESTEP BUT NUMJOBS IS USED
		double sample1 = disruptionGenerator.nextDouble();
		double sample2 = sample1*(max-min);				
		return (int) (min+sample2);
	}

	public static double getAllowanceDisruption(){
		double out = 0.0;
		int rand_int1 = disruptionGenerator.nextInt(5);				//HC hard coded
		
		if			(rand_int1 == 0) { out = 2 ;}
		else if 	(rand_int1 == 1) { out = 3 ;}
		else if 	(rand_int1 == 2) { out = 4 ;}
		else if 	(rand_int1 == 3) { out = 6 ;}
		else 						 { out = 8 ;}
		return out;
	}

	public static double getUtilisationDisruption(){
		double out = 0.0;
		int rand_int1 = disruptionGenerator.nextInt(5);				//HC hard coded
		
		if			(rand_int1 == 0) { out = 0.80 ;}
		else if 	(rand_int1 == 1) { out = 0.85 ;}
		else if 	(rand_int1 == 2) { out = 0.90 ;}
		else if 	(rand_int1 == 3) { out = 0.95 ;}
		else 						 { out = 0.97 ;}
		return out;
	}
	
	public static double getWeightedAverage(double performance, int w1, double lastPerformance, int w2){
		
		return (performance*((double)w1) + lastPerformance*((double) w2))/
				(double)(w1+w2);
	}
	
	public static String getExpressionsFileName(int iteration){
		
		//String fileName = GlobalParameters.OUTPUT_DIR + "/";
		String fileName = GlobalParameters.OUTPUTFILE_EXPRESSIONS;
		/* if(GlobalParameters.ITERATIONS > 1)
			fileName += iteration; */
		fileName += iteration;
		fileName += ".txt";
		
		return fileName;
	}
	
	public static String getBestRuleFileName(int iteration){
		
		String fileName = GlobalParameters.BEST_RULE_FILE;
		if(GlobalParameters.ITERATIONS > 1)
			fileName += iteration;
		fileName += ".txt";
		
		return fileName;
	}
	
	public static String getRulesFileName(int iteration){
		
		String fileName = GlobalParameters.OUTPUTFILE_RULES;
		if(GlobalParameters.ITERATIONS > 1)
			fileName += iteration;
		fileName += ".csv";
		
		return fileName;
	}

	public static int argmax (double [] elems)
    {
      int bestIdx = -1;
      double max = Double.NEGATIVE_INFINITY;
      for (int i = 0; i < elems.length; i++) {
        double elem = elems[i];
        if (elem > max) {
          max = elem;
          bestIdx = i;
        }
      }
      return bestIdx;
    }

	public static void checkRTRStype( String modelid ){
		String[] result = modelid.split("-", 2);
		GlobalParameters.rtrsTYPE =  result[0] ;
		GlobalParameters.rtrsSS   =  result[1] ;

	}

}
