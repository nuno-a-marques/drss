package DQN;

import org.neuroph.core.Weight;
import org.neuroph.core.transfer.Linear;
import org.neuroph.nnet.MultiLayerPerceptron;
import org.neuroph.util.TransferFunctionType;

public class Dqn {
    
    private MultiLayerPerceptron neuralNet;
    int myArr [] = {45, 55, 95, 105};
    private double nnWeightList [] = {-0.303307246325532,0.157046912180062,-0.461633012072686,-0.0259619347135253,-0.35288567403159,-0.0718578119595419,-0.295569310665428,0.348502723734079,-0.0989853228808839,-0.173943907581867,-0.108664606931987,-0.218351913511972,-0.0551153404544718,-0.0644468633346335,-0.252507198211139,-0.323388050908783,0.0495531126619647,0.410454787525638,0.135355058040599,-0.0550952194638894,0.183249115672781,-0.147884280803721,-0.0731152412010599,-0.359239266908817,-0.142821519077526,0.0691547840723771,0.116127908715486,-0.0413242693802347,0.296435589237387,-0.352428478332688,0.395949551274521,-0.132584759484747,-0.134724782191597,0.120766165309019,-0.0436972078154155,0.140176097292125,0.0746121638025918,0.245807139885943,-0.0323801119164439,0.294389596232278,-0.414337324000807,0.371121557647908,-0.455251217748808,0.177372610300039,-0.269575910212224,0.00234680852881686,0.215708668258768,0.449470020638503,-0.461392624084812,0.440925226183857,0.441898252895246,-0.431870968545511,0.34203051801849,-0.0226506322410048,0.37971558740472,-0.0711381485062617,0.00628381170613834,0.343726579607147,0.338487915764354,0.440572665123628,0.303403259847873,0.466456151266787,-0.343668098132044,0.0728696852854905,0.00465673085700202,0.304091138950643,0.465760451430394,-0.0764302874623043,0.2422421453118,0.331714651012364,0.230961920238894,0.0940037472442098,0.286212945059343,-0.287029744884593,0.208434232284955,0.298913487082593,-0.233005805142884,-0.276602760186636,-0.189520452115509    };
    
    public Dqn(){
        neuralNet = new MultiLayerPerceptron(TransferFunctionType.RECTIFIED, 5, 4, 4, 4, 3);
        
        Linear ln0=new Linear();
        neuralNet.getLayerAt(4).getNeuronAt(0).setTransferFunction(ln0);
        Linear ln1=new Linear();
        neuralNet.getLayerAt(4).getNeuronAt(1).setTransferFunction(ln1);
        Linear ln2=new Linear();
        neuralNet.getLayerAt(4).getNeuronAt(0).setTransferFunction(ln2);

    }

    public MultiLayerPerceptron getNetwork(){
        return neuralNet;
    }

    public void setWeights(){
        int controlo=0;
        int nLayers=neuralNet.getLayersCount();
        for(int l = 1; l < nLayers; l++){
            int nNeurons=neuralNet.getLayerAt(l).getNeuronsCount();
            for(int n = 0; n < nNeurons; n++){
                Weight[] weightList=neuralNet.getLayerAt(l).getNeuronAt(n).getWeights();                 //Pesos da Layer
                for(int w=0;w<weightList.length;w++){
                    Weight weightTemp=weightList[w];                                                     //Peso Individual
                    weightTemp.setValue(nnWeightList[controlo]);
                    controlo=controlo+1;                    
                }
            }
        }
    }

    public static double[] makePrediction(MultiLayerPerceptron nn, double var1, double var2, double var3, double var4, double var5){
        //nn.setInput(var1, var2, var3, var4, var5);
        nn.setInput(var1/10000, var2/1000, var3/100, var4/10000, var5);
        nn.calculate();
        double[] output1 = new double[]{nn.getOutput()[0]};
        double[] output2 = new double[]{nn.getOutput()[1]};
        double[] output3 = new double[]{nn.getOutput()[2]};

        double output [] = {output1[0], output2[0], output3[0]};
        return output;
    }

    // pre trained Q functions
    public static int preQf3LR(double meanSlackinQueue, double meanEstLateness, double queueSize, double meanEstTardiness, double machineUtilisation){
        int ruleCode = -1;
        double min = Double.MAX_VALUE;              // min is preferred
        double val = 0.0;

        // model  18, rr
        val = meanSlackinQueue * -255.50696913267308 + meanEstLateness * 12484.929501089475 + queueSize * 3252.4303546506976 + meanEstTardiness * 704.2560365532427 +  machineUtilisation * -990613.6630554879 + 1558338.8259356918; // colocar aqui o modelo
        if (val <= min) {
            ruleCode = 18;
            min = val;
        }

        // model 214, rr
        val = meanSlackinQueue * -647.4673503589596 + meanEstLateness * 16162.756930147325 + queueSize * -14398.317663355116 + meanEstTardiness * 199.99134095339286 +  machineUtilisation * -1615671.0995118548 + 3003815.17993094; // colocar aqui o modelo
        if (val <= min) {
            ruleCode = 214;
            min = val;
        }

        // model 508, rr
        val = meanSlackinQueue * -243.51607828540875 + meanEstLateness * 15573.59980007617 + queueSize * 15504.780528585396 + meanEstTardiness * 24.24858941257662 +  machineUtilisation * -906528.7424886136 + 1520795.0253099264; // colocar aqui o modelo
        if (val <= min) {
            ruleCode = 508;
            min = val;
        }
        
        return ruleCode;
    }

    public static int preNN(MultiLayerPerceptron nn, double meanSlackinQueue, double meanEstLateness, double queueSize, double meanEstTardiness, double machineUtilisation){
        int ruleCode = -1;
        double min = Double.MAX_VALUE;              // min is preferred
        double val = 0.0;

        double pre [] = makePrediction(nn, meanSlackinQueue, meanEstLateness, queueSize, meanEstTardiness, machineUtilisation);

        // model  18, rr
        val = pre[0];
        if (val <= min) {
            ruleCode = 18;
            min = val;
        }

        // model 214, rr
        val = pre[1];
        if (val <= min) {
            ruleCode = 214;
            min = val;
        }

        // model 508, rr
        val = pre[2];
        if (val <= min) {
            ruleCode = 508;
            min = val;
        }
        
        return ruleCode;
    }
    
}
