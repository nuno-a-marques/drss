package RFregressor;

public class RandomForestRegressor {

public static int numRules = 3;
public static int nTrees   = 1;
public static int[] nPaths_18 = {  52, 53, 47, 50, 51, 51, 45, 55, 54, 45  };
public static int[] nPaths_214 = {  29, 41, 37, 43, 43, 35, 42, 39, 33, 29  };
public static int[] nPaths_508 = {  54, 47, 43, 49, 53, 51, 52, 46, 47, 44  };
public static int[] nPaths = {  52, 29, 54  };

public static double checkDT18Tree0Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 522.0) && (wipJS > 2236.5) && (eTardJS > 1065.5) && (eTardJS > 3135.0) && (eTardJS <= 166365.0))  { ruleCode = 0.147 ; }
    return ruleCode; }
public static double checkDT18Tree0Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3275.0) && (wipJS <= 1572.5) && (wipJS <= 1451.0) && (wipJS <= 1391.0) && (wipJS <= 835.0))  { ruleCode = 27.691 ; }
    return ruleCode; }
public static double checkDT18Tree0Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 522.0) && (wipJS > 2236.5) && (eTardJS > 1065.5) && (eTardJS <= 3135.0) && (eTardJS <= 3091.0))  { ruleCode = 0.3 ; }
    return ruleCode; }
public static double checkDT18Tree0Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 522.0) && (wipJS <= 2236.5) && (wipJS <= 2235.5) && (eTardJS > 833.5) && (eTardJS > 1211.75))  { ruleCode = 0.14 ; }
    return ruleCode; }
public static double checkDT18Tree0Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3275.0) && (wipJS > 1572.5) && (wipJS > 1574.0) && (wipJS > 1959.5) && (wipJS <= 2684.0))  { ruleCode = 15.233 ; }
    return ruleCode; }
public static double checkDT18Tree0Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 522.0) && (eTardJS > 21.5) && (eTardJS > 208.75) && (wipJS > 1182.5) && (eTardJS <= 442.25))  { ruleCode = 0.634 ; }
    return ruleCode; }
public static double checkDT18Tree0Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 522.0) && (eTardJS > 21.5) && (eTardJS <= 208.75) && (eTardJS <= 184.25) && (wipJS <= 3524.0))  { ruleCode = 1.077 ; }
    return ruleCode; }
public static double checkDT18Tree0Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 522.0) && (wipJS > 2236.5) && (eTardJS <= 1065.5) && (eTardJS <= 1040.25) && (wipJS <= 5798.5))  { ruleCode = 0.636 ; }
    return ruleCode; }
public static double checkDT18Tree0Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 3275.0) && (wipJS > 3287.5) && (wipJS <= 4291.0) && (wipJS <= 4283.5) && (wipJS > 3534.5))  { ruleCode = 118.745 ; }
    return ruleCode; }
public static double checkDT18Tree0Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3275.0) && (wipJS > 1572.5) && (wipJS > 1574.0) && (wipJS > 1959.5) && (wipJS > 2684.0))  { ruleCode = 43.483 ; }
    return ruleCode; }
public static double checkDT18Tree0Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3275.0) && (wipJS > 1572.5) && (wipJS > 1574.0) && (wipJS <= 1959.5) && (wipJS <= 1951.5))  { ruleCode = 44.095 ; }
    return ruleCode; }
public static double checkDT18Tree0Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 522.0) && (wipJS > 2236.5) && (eTardJS > 1065.5) && (eTardJS > 3135.0) && (eTardJS > 166365.0))  { ruleCode = 0.356 ; }
    return ruleCode; }
public static double checkDT18Tree0Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 522.0) && (eTardJS > 21.5) && (eTardJS <= 208.75) && (eTardJS <= 184.25) && (wipJS > 3524.0))  { ruleCode = 1.937 ; }
    return ruleCode; }
public static double checkDT18Tree0Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 3275.0) && (wipJS > 3287.5) && (wipJS <= 4291.0) && (wipJS <= 4283.5) && (wipJS <= 3534.5))  { ruleCode = 40.28 ; }
    return ruleCode; }
public static double checkDT18Tree0Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 3275.0) && (wipJS > 3287.5) && (wipJS > 4291.0) && (wipJS > 4628.0) && (wipJS <= 5292.5))  { ruleCode = 9.81 ; }
    return ruleCode; }
public static double checkDT18Tree0Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 522.0) && (wipJS <= 2236.5) && (wipJS <= 2235.5) && (eTardJS <= 833.5) && (eTardJS <= 820.5))  { ruleCode = 0.109 ; }
    return ruleCode; }
public static double checkDT18Tree0Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 3275.0) && (wipJS > 3287.5) && (wipJS > 4291.0) && (wipJS <= 4628.0) && (wipJS <= 4544.0))  { ruleCode = 4.669 ; }
    return ruleCode; }
public static double checkDT18Tree0Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 522.0) && (eTardJS > 21.5) && (eTardJS > 208.75) && (wipJS > 1182.5) && (eTardJS > 442.25))  { ruleCode = 2.017 ; }
    return ruleCode; }
public static double checkDT18Tree0Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 3275.0) && (wipJS > 3287.5) && (wipJS > 4291.0) && (wipJS > 4628.0) && (wipJS > 5292.5))  { ruleCode = 1.549 ; }
    return ruleCode; }
public static double checkDT18Tree0Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3275.0) && (wipJS <= 1572.5) && (wipJS <= 1451.0) && (wipJS <= 1391.0) && (wipJS > 835.0))  { ruleCode = 10.759 ; }
    return ruleCode; }
public static double checkDT18Tree0Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 522.0) && (wipJS <= 2236.5) && (wipJS <= 2235.5) && (eTardJS > 833.5) && (eTardJS <= 1211.75))  { ruleCode = 2.086 ; }
    return ruleCode; }
public static double checkDT18Tree0Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3275.0) && (wipJS <= 1572.5) && (wipJS > 1451.0) && (wipJS <= 1565.5) && (wipJS <= 1524.5))  { ruleCode = 4.818 ; }
    return ruleCode; }
public static double checkDT18Tree0Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 522.0) && (eTardJS <= 21.5) && (eTardJS <= 14.75) && (eTardJS <= 5.5) && (wipJS <= 5169.0))  { ruleCode = 2.486 ; }
    return ruleCode; }
public static double checkDT18Tree0Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 522.0) && (eTardJS > 21.5) && (eTardJS <= 208.75) && (eTardJS > 184.25) && (eTardJS <= 201.5))  { ruleCode = 6.142 ; }
    return ruleCode; }
public static double checkDT18Tree0Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 522.0) && (eTardJS <= 21.5) && (eTardJS <= 14.75) && (eTardJS > 5.5) && (wipJS <= 3306.0))  { ruleCode = 2.276 ; }
    return ruleCode; }
public static double checkDT18Tree0Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 3275.0) && (wipJS > 3287.5) && (wipJS > 4291.0) && (wipJS <= 4628.0) && (wipJS > 4544.0))  { ruleCode = 53.619 ; }
    return ruleCode; }
public static double checkDT18Tree0Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 522.0) && (eTardJS <= 21.5) && (eTardJS <= 14.75) && (eTardJS > 5.5) && (wipJS > 3306.0))  { ruleCode = 0.436 ; }
    return ruleCode; }
public static double checkDT18Tree0Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3275.0) && (wipJS <= 1572.5) && (wipJS > 1451.0) && (wipJS <= 1565.5) && (wipJS > 1524.5))  { ruleCode = 1.765 ; }
    return ruleCode; }
public static double checkDT18Tree0Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3275.0) && (wipJS <= 1572.5) && (wipJS <= 1451.0) && (wipJS > 1391.0) && (wipJS > 1404.5))  { ruleCode = 20.279 ; }
    return ruleCode; }
public static double checkDT18Tree0Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 522.0) && (eTardJS <= 21.5) && (eTardJS > 14.75) && (wipJS <= 2372.0) && (eTardJS > 16.0))  { ruleCode = 6.256 ; }
    return ruleCode; }
public static double checkDT18Tree0Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 522.0) && (eTardJS > 21.5) && (eTardJS <= 208.75) && (eTardJS > 184.25) && (eTardJS > 201.5))  { ruleCode = 1.463 ; }
    return ruleCode; }
public static double checkDT18Tree0Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 522.0) && (wipJS > 2236.5) && (eTardJS > 1065.5) && (eTardJS <= 3135.0) && (eTardJS > 3091.0))  { ruleCode = 7.196 ; }
    return ruleCode; }
public static double checkDT18Tree0Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 522.0) && (wipJS > 2236.5) && (eTardJS <= 1065.5) && (eTardJS > 1040.25) && (eTardJS > 1050.0))  { ruleCode = 0.944 ; }
    return ruleCode; }
public static double checkDT18Tree0Path33(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 522.0) && (eTardJS <= 21.5) && (eTardJS > 14.75) && (wipJS > 2372.0) && (eTardJS <= 17.5))  { ruleCode = 0.822 ; }
    return ruleCode; }
public static double checkDT18Tree0Path34(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3275.0) && (wipJS <= 1572.5) && (wipJS > 1451.0) && (wipJS > 1565.5) && (wipJS > 1569.5))  { ruleCode = 6.701 ; }
    return ruleCode; }
public static double checkDT18Tree0Path35(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 522.0) && (wipJS > 2236.5) && (eTardJS <= 1065.5) && (eTardJS <= 1040.25) && (wipJS > 5798.5))  { ruleCode = 2.681 ; }
    return ruleCode; }
public static double checkDT18Tree0Path36(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 522.0) && (eTardJS <= 21.5) && (eTardJS > 14.75) && (wipJS > 2372.0) && (eTardJS > 17.5))  { ruleCode = 0.14 ; }
    return ruleCode; }
public static double checkDT18Tree0Path37(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 522.0) && (wipJS <= 2236.5) && (wipJS > 2235.5) && (eTardJS <= 1376.75) && (eTardJS > 806.5))  { ruleCode = 0.16 ; }
    return ruleCode; }
public static double checkDT18Tree0Path38(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 522.0) && (eTardJS > 21.5) && (eTardJS > 208.75) && (wipJS <= 1182.5) && (wipJS > 1102.5))  { ruleCode = 12.5 ; }
    return ruleCode; }
public static double checkDT18Tree0Path39(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 3275.0) && (wipJS <= 3287.5))  { ruleCode = 870.0 ; }
    return ruleCode; }
public static double checkDT18Tree0Path40(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 522.0) && (wipJS > 2236.5) && (eTardJS <= 1065.5) && (eTardJS > 1040.25) && (eTardJS <= 1050.0))  { ruleCode = 7.42 ; }
    return ruleCode; }
public static double checkDT18Tree0Path41(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 3275.0) && (wipJS > 3287.5) && (wipJS <= 4291.0) && (wipJS > 4283.5))  { ruleCode = 915.0 ; }
    return ruleCode; }
public static double checkDT18Tree0Path42(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3275.0) && (wipJS > 1572.5) && (wipJS > 1574.0) && (wipJS <= 1959.5) && (wipJS > 1951.5))  { ruleCode = 504.0 ; }
    return ruleCode; }
public static double checkDT18Tree0Path43(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 522.0) && (eTardJS > 21.5) && (eTardJS > 208.75) && (wipJS <= 1182.5) && (wipJS <= 1102.5))  { ruleCode = 0.42 ; }
    return ruleCode; }
public static double checkDT18Tree0Path44(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3275.0) && (wipJS > 1572.5) && (wipJS <= 1574.0))  { ruleCode = 1079.0 ; }
    return ruleCode; }
public static double checkDT18Tree0Path45(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 522.0) && (wipJS <= 2236.5) && (wipJS <= 2235.5) && (eTardJS <= 833.5) && (eTardJS > 820.5))  { ruleCode = -38.763 ; }
    return ruleCode; }
public static double checkDT18Tree0Path46(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3275.0) && (wipJS <= 1572.5) && (wipJS > 1451.0) && (wipJS > 1565.5) && (wipJS <= 1569.5))  { ruleCode = 15.0 ; }
    return ruleCode; }
public static double checkDT18Tree0Path47(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 522.0) && (eTardJS <= 21.5) && (eTardJS <= 14.75) && (eTardJS <= 5.5) && (wipJS > 5169.0))  { ruleCode = 11.29 ; }
    return ruleCode; }
public static double checkDT18Tree0Path48(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 522.0) && (wipJS <= 2236.5) && (wipJS > 2235.5) && (eTardJS > 1376.75))  { ruleCode = -197.24 ; }
    return ruleCode; }
public static double checkDT18Tree0Path49(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3275.0) && (wipJS <= 1572.5) && (wipJS <= 1451.0) && (wipJS > 1391.0) && (wipJS <= 1404.5))  { ruleCode = 462.0 ; }
    return ruleCode; }
public static double checkDT18Tree0Path50(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 522.0) && (wipJS <= 2236.5) && (wipJS > 2235.5) && (eTardJS <= 1376.75) && (eTardJS <= 806.5))  { ruleCode = 0.16 ; }
    return ruleCode; }
public static double checkDT18Tree0Path51(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 522.0) && (eTardJS <= 21.5) && (eTardJS > 14.75) && (wipJS <= 2372.0) && (eTardJS <= 16.0))  { ruleCode = 19.5 ; }
    return ruleCode; }
public static double checkDT18Tree1Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 125.25) && (eTardJS > 190.0) && (eTardJS > 202.5) && (eTardJS > 1211.75) && (eTardJS > 1815.25))  { ruleCode = 0.198 ; }
    return ruleCode; }
public static double checkDT18Tree1Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 4289.5) && (wipJS <= 4281.0) && (wipJS <= 1729.5) && (wipJS <= 1633.0) && (wipJS <= 1549.0))  { ruleCode = 28.973 ; }
    return ruleCode; }
public static double checkDT18Tree1Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 125.25) && (eTardJS > 190.0) && (eTardJS > 202.5) && (eTardJS <= 1211.75) && (eTardJS <= 1208.25))  { ruleCode = 0.889 ; }
    return ruleCode; }
public static double checkDT18Tree1Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 4289.5) && (wipJS <= 4281.0) && (wipJS > 1729.5) && (wipJS > 2032.5) && (wipJS > 2683.0))  { ruleCode = 58.431 ; }
    return ruleCode; }
public static double checkDT18Tree1Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 4289.5) && (wipJS <= 4281.0) && (wipJS > 1729.5) && (wipJS > 2032.5) && (wipJS <= 2683.0))  { ruleCode = 11.307 ; }
    return ruleCode; }
public static double checkDT18Tree1Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 125.25) && (eTardJS > 190.0) && (eTardJS > 202.5) && (eTardJS > 1211.75) && (eTardJS <= 1815.25))  { ruleCode = -1.155 ; }
    return ruleCode; }
public static double checkDT18Tree1Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 4289.5) && (wipJS <= 4281.0) && (wipJS > 1729.5) && (wipJS <= 2032.5) && (wipJS <= 2019.5))  { ruleCode = 87.031 ; }
    return ruleCode; }
public static double checkDT18Tree1Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 125.25) && (wipJS <= 4156.0) && (eTardJS > 20.5) && (wipJS > 1758.5) && (wipJS > 2003.5))  { ruleCode = 1.213 ; }
    return ruleCode; }
public static double checkDT18Tree1Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 4289.5) && (wipJS > 4726.5) && (wipJS <= 5914.0) && (wipJS <= 5695.5) && (wipJS <= 5328.0))  { ruleCode = 7.13 ; }
    return ruleCode; }
public static double checkDT18Tree1Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 125.25) && (wipJS <= 4156.0) && (eTardJS <= 20.5) && (eTardJS <= 14.75) && (wipJS <= 3810.0))  { ruleCode = 2.387 ; }
    return ruleCode; }
public static double checkDT18Tree1Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 125.25) && (eTardJS <= 190.0) && (eTardJS <= 182.5) && (wipJS > 2236.0) && (wipJS <= 3629.0))  { ruleCode = 2.027 ; }
    return ruleCode; }
public static double checkDT18Tree1Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 4289.5) && (wipJS <= 4726.5) && (wipJS <= 4592.5) && (wipJS > 4382.5) && (wipJS <= 4512.0))  { ruleCode = 11.989 ; }
    return ruleCode; }
public static double checkDT18Tree1Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 125.25) && (eTardJS <= 190.0) && (eTardJS <= 182.5) && (wipJS <= 2236.0) && (wipJS <= 1907.0))  { ruleCode = 0.502 ; }
    return ruleCode; }
public static double checkDT18Tree1Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 4289.5) && (wipJS <= 4281.0) && (wipJS <= 1729.5) && (wipJS <= 1633.0) && (wipJS > 1549.0))  { ruleCode = 71.076 ; }
    return ruleCode; }
public static double checkDT18Tree1Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 125.25) && (eTardJS <= 190.0) && (eTardJS <= 182.5) && (wipJS > 2236.0) && (wipJS > 3629.0))  { ruleCode = 0.716 ; }
    return ruleCode; }
public static double checkDT18Tree1Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 4289.5) && (wipJS > 4726.5) && (wipJS <= 5914.0) && (wipJS <= 5695.5) && (wipJS > 5328.0))  { ruleCode = 1.984 ; }
    return ruleCode; }
public static double checkDT18Tree1Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 4289.5) && (wipJS <= 4281.0) && (wipJS <= 1729.5) && (wipJS > 1633.0) && (wipJS <= 1719.5))  { ruleCode = 3.908 ; }
    return ruleCode; }
public static double checkDT18Tree1Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 125.25) && (wipJS > 4156.0) && (wipJS > 4273.5) && (eTardJS > 4.0) && (wipJS > 4931.0))  { ruleCode = 0.975 ; }
    return ruleCode; }
public static double checkDT18Tree1Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 4289.5) && (wipJS <= 4726.5) && (wipJS <= 4592.5) && (wipJS <= 4382.5) && (wipJS <= 4380.5))  { ruleCode = 4.297 ; }
    return ruleCode; }
public static double checkDT18Tree1Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 4289.5) && (wipJS <= 4726.5) && (wipJS <= 4592.5) && (wipJS > 4382.5) && (wipJS > 4512.0))  { ruleCode = 4.727 ; }
    return ruleCode; }
public static double checkDT18Tree1Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 125.25) && (wipJS <= 4156.0) && (eTardJS > 20.5) && (wipJS <= 1758.5) && (wipJS > 1226.5))  { ruleCode = 2.909 ; }
    return ruleCode; }
public static double checkDT18Tree1Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 125.25) && (wipJS > 4156.0) && (wipJS > 4273.5) && (eTardJS > 4.0) && (wipJS <= 4931.0))  { ruleCode = 3.138 ; }
    return ruleCode; }
public static double checkDT18Tree1Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 125.25) && (eTardJS <= 190.0) && (eTardJS > 182.5) && (eTardJS > 183.25) && (eTardJS <= 188.5))  { ruleCode = 2.978 ; }
    return ruleCode; }
public static double checkDT18Tree1Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 4289.5) && (wipJS <= 4726.5) && (wipJS > 4592.5) && (wipJS > 4623.0) && (wipJS <= 4718.0))  { ruleCode = 8.312 ; }
    return ruleCode; }
public static double checkDT18Tree1Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 125.25) && (wipJS <= 4156.0) && (eTardJS > 20.5) && (wipJS > 1758.5) && (wipJS <= 2003.5))  { ruleCode = -2.129 ; }
    return ruleCode; }
public static double checkDT18Tree1Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 125.25) && (eTardJS <= 190.0) && (eTardJS <= 182.5) && (wipJS <= 2236.0) && (wipJS > 1907.0))  { ruleCode = -1.43 ; }
    return ruleCode; }
public static double checkDT18Tree1Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 4289.5) && (wipJS > 4726.5) && (wipJS > 5914.0) && (wipJS <= 6435.5) && (wipJS <= 6276.0))  { ruleCode = 0.652 ; }
    return ruleCode; }
public static double checkDT18Tree1Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 125.25) && (wipJS <= 4156.0) && (eTardJS <= 20.5) && (eTardJS <= 14.75) && (wipJS > 3810.0))  { ruleCode = 0.633 ; }
    return ruleCode; }
public static double checkDT18Tree1Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 125.25) && (wipJS <= 4156.0) && (eTardJS <= 20.5) && (eTardJS > 14.75) && (eTardJS > 15.75))  { ruleCode = 2.439 ; }
    return ruleCode; }
public static double checkDT18Tree1Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 125.25) && (eTardJS > 190.0) && (eTardJS <= 202.5) && (wipJS <= 3766.0) && (wipJS <= 2884.0))  { ruleCode = 0.165 ; }
    return ruleCode; }
public static double checkDT18Tree1Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 4289.5) && (wipJS <= 4281.0) && (wipJS > 1729.5) && (wipJS <= 2032.5) && (wipJS > 2019.5))  { ruleCode = 495.957 ; }
    return ruleCode; }
public static double checkDT18Tree1Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 4289.5) && (wipJS > 4726.5) && (wipJS > 5914.0) && (wipJS > 6435.5) && (wipJS > 7177.0))  { ruleCode = 0.202 ; }
    return ruleCode; }
public static double checkDT18Tree1Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 125.25) && (wipJS <= 4156.0) && (eTardJS <= 20.5) && (eTardJS > 14.75) && (eTardJS <= 15.75))  { ruleCode = 10.101 ; }
    return ruleCode; }
public static double checkDT18Tree1Path33(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 125.25) && (wipJS <= 4156.0) && (eTardJS > 20.5) && (wipJS <= 1758.5) && (wipJS <= 1226.5))  { ruleCode = 0.031 ; }
    return ruleCode; }
public static double checkDT18Tree1Path34(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 4289.5) && (wipJS > 4726.5) && (wipJS > 5914.0) && (wipJS > 6435.5) && (wipJS <= 7177.0))  { ruleCode = 3.2 ; }
    return ruleCode; }
public static double checkDT18Tree1Path35(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 125.25) && (wipJS > 4156.0) && (wipJS > 4273.5) && (eTardJS <= 4.0) && (wipJS > 4987.0))  { ruleCode = 11.29 ; }
    return ruleCode; }
public static double checkDT18Tree1Path36(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 125.25) && (eTardJS > 190.0) && (eTardJS <= 202.5) && (wipJS > 3766.0))  { ruleCode = 20.974 ; }
    return ruleCode; }
public static double checkDT18Tree1Path37(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 125.25) && (eTardJS > 190.0) && (eTardJS <= 202.5) && (wipJS <= 3766.0) && (wipJS > 2884.0))  { ruleCode = 4.864 ; }
    return ruleCode; }
public static double checkDT18Tree1Path38(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 4289.5) && (wipJS <= 4281.0) && (wipJS <= 1729.5) && (wipJS > 1633.0) && (wipJS > 1719.5))  { ruleCode = 21.0 ; }
    return ruleCode; }
public static double checkDT18Tree1Path39(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 125.25) && (eTardJS <= 190.0) && (eTardJS > 182.5) && (eTardJS > 183.25) && (eTardJS > 188.5))  { ruleCode = -38.462 ; }
    return ruleCode; }
public static double checkDT18Tree1Path40(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 125.25) && (eTardJS <= 190.0) && (eTardJS > 182.5) && (eTardJS <= 183.25))  { ruleCode = -128.0 ; }
    return ruleCode; }
public static double checkDT18Tree1Path41(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 4289.5) && (wipJS > 4281.0))  { ruleCode = 915.0 ; }
    return ruleCode; }
public static double checkDT18Tree1Path42(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 125.25) && (wipJS > 4156.0) && (wipJS <= 4273.5) && (eTardJS > 83.5))  { ruleCode = 19.2 ; }
    return ruleCode; }
public static double checkDT18Tree1Path43(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 4289.5) && (wipJS <= 4726.5) && (wipJS <= 4592.5) && (wipJS <= 4382.5) && (wipJS > 4380.5))  { ruleCode = 1.358 ; }
    return ruleCode; }
public static double checkDT18Tree1Path44(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 125.25) && (wipJS > 4156.0) && (wipJS > 4273.5) && (eTardJS <= 4.0) && (wipJS <= 4987.0))  { ruleCode = 1.248 ; }
    return ruleCode; }
public static double checkDT18Tree1Path45(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 4289.5) && (wipJS <= 4726.5) && (wipJS > 4592.5) && (wipJS <= 4623.0) && (wipJS <= 4610.0))  { ruleCode = 34.5 ; }
    return ruleCode; }
public static double checkDT18Tree1Path46(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 4289.5) && (wipJS <= 4726.5) && (wipJS > 4592.5) && (wipJS <= 4623.0) && (wipJS > 4610.0))  { ruleCode = 169.778 ; }
    return ruleCode; }
public static double checkDT18Tree1Path47(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 125.25) && (wipJS > 4156.0) && (wipJS <= 4273.5) && (eTardJS <= 83.5))  { ruleCode = 5.403 ; }
    return ruleCode; }
public static double checkDT18Tree1Path48(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 4289.5) && (wipJS <= 4726.5) && (wipJS > 4592.5) && (wipJS > 4623.0) && (wipJS > 4718.0))  { ruleCode = 34.836 ; }
    return ruleCode; }
public static double checkDT18Tree1Path49(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 4289.5) && (wipJS > 4726.5) && (wipJS <= 5914.0) && (wipJS > 5695.5) && (wipJS <= 5823.5))  { ruleCode = 36.807 ; }
    return ruleCode; }
public static double checkDT18Tree1Path50(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 4289.5) && (wipJS > 4726.5) && (wipJS <= 5914.0) && (wipJS > 5695.5) && (wipJS > 5823.5))  { ruleCode = 12.783 ; }
    return ruleCode; }
public static double checkDT18Tree1Path51(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 4289.5) && (wipJS > 4726.5) && (wipJS > 5914.0) && (wipJS <= 6435.5) && (wipJS > 6276.0))  { ruleCode = 0.198 ; }
    return ruleCode; }
public static double checkDT18Tree1Path52(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 125.25) && (eTardJS > 190.0) && (eTardJS > 202.5) && (eTardJS <= 1211.75) && (eTardJS > 1208.25))  { ruleCode = 16.5 ; }
    return ruleCode; }
public static double checkDT18Tree2Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 168.5) && (eTardJS > 183.5) && (eTardJS > 1213.5) && (eTardJS > 1815.25) && (eTardJS > 1951.25))  { ruleCode = 0.156 ; }
    return ruleCode; }
public static double checkDT18Tree2Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3473.5) && (wipJS <= 2059.0) && (wipJS <= 2019.5) && (wipJS <= 1396.5) && (wipJS <= 1357.0))  { ruleCode = 24.878 ; }
    return ruleCode; }
public static double checkDT18Tree2Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 168.5) && (eTardJS > 183.5) && (eTardJS <= 1213.5) && (eTardJS <= 1200.5) && (eTardJS > 190.0))  { ruleCode = 1.03 ; }
    return ruleCode; }
public static double checkDT18Tree2Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3473.5) && (wipJS <= 2059.0) && (wipJS <= 2019.5) && (wipJS > 1396.5) && (wipJS > 1404.5))  { ruleCode = 54.474 ; }
    return ruleCode; }
public static double checkDT18Tree2Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 3473.5) && (wipJS > 3480.0) && (wipJS <= 4546.5) && (wipJS <= 4544.0) && (wipJS <= 4235.0))  { ruleCode = 87.248 ; }
    return ruleCode; }
public static double checkDT18Tree2Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 168.5) && (eTardJS > 183.5) && (eTardJS > 1213.5) && (eTardJS <= 1815.25) && (eTardJS <= 1810.0))  { ruleCode = 0.285 ; }
    return ruleCode; }
public static double checkDT18Tree2Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 168.5) && (eTardJS <= 165.75) && (wipJS <= 3524.0) && (eTardJS > 21.5) && (wipJS > 2007.0))  { ruleCode = 1.396 ; }
    return ruleCode; }
public static double checkDT18Tree2Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3473.5) && (wipJS > 2059.0) && (wipJS > 2699.5) && (wipJS > 2859.0) && (wipJS <= 3268.5))  { ruleCode = 13.304 ; }
    return ruleCode; }
public static double checkDT18Tree2Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3473.5) && (wipJS > 2059.0) && (wipJS <= 2699.5) && (wipJS > 2235.0) && (wipJS <= 2500.5))  { ruleCode = 9.708 ; }
    return ruleCode; }
public static double checkDT18Tree2Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 3473.5) && (wipJS > 3480.0) && (wipJS > 4546.5) && (wipJS <= 5328.0) && (wipJS <= 5242.0))  { ruleCode = 7.586 ; }
    return ruleCode; }
public static double checkDT18Tree2Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 168.5) && (eTardJS <= 165.75) && (wipJS <= 3524.0) && (eTardJS > 21.5) && (wipJS <= 2007.0))  { ruleCode = 0.245 ; }
    return ruleCode; }
public static double checkDT18Tree2Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 3473.5) && (wipJS > 3480.0) && (wipJS <= 4546.5) && (wipJS <= 4544.0) && (wipJS > 4235.0))  { ruleCode = 14.163 ; }
    return ruleCode; }
public static double checkDT18Tree2Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3473.5) && (wipJS > 2059.0) && (wipJS <= 2699.5) && (wipJS <= 2235.0) && (wipJS <= 2229.5))  { ruleCode = 10.519 ; }
    return ruleCode; }
public static double checkDT18Tree2Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3473.5) && (wipJS > 2059.0) && (wipJS > 2699.5) && (wipJS > 2859.0) && (wipJS > 3268.5))  { ruleCode = 28.35 ; }
    return ruleCode; }
public static double checkDT18Tree2Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3473.5) && (wipJS > 2059.0) && (wipJS <= 2699.5) && (wipJS > 2235.0) && (wipJS > 2500.5))  { ruleCode = 5.244 ; }
    return ruleCode; }
public static double checkDT18Tree2Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 168.5) && (eTardJS <= 165.75) && (wipJS > 3524.0) && (eTardJS > 6.0) && (eTardJS <= 80.5))  { ruleCode = 1.503 ; }
    return ruleCode; }
public static double checkDT18Tree2Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 168.5) && (eTardJS > 183.5) && (eTardJS > 1213.5) && (eTardJS > 1815.25) && (eTardJS <= 1951.25))  { ruleCode = 0.479 ; }
    return ruleCode; }
public static double checkDT18Tree2Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3473.5) && (wipJS > 2059.0) && (wipJS > 2699.5) && (wipJS <= 2859.0) && (wipJS <= 2849.0))  { ruleCode = 29.068 ; }
    return ruleCode; }
public static double checkDT18Tree2Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 3473.5) && (wipJS > 3480.0) && (wipJS > 4546.5) && (wipJS > 5328.0) && (wipJS <= 5914.0))  { ruleCode = 2.362 ; }
    return ruleCode; }
public static double checkDT18Tree2Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 168.5) && (eTardJS <= 165.75) && (wipJS > 3524.0) && (eTardJS > 6.0) && (eTardJS > 80.5))  { ruleCode = 3.421 ; }
    return ruleCode; }
public static double checkDT18Tree2Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 168.5) && (eTardJS <= 165.75) && (wipJS <= 3524.0) && (eTardJS <= 21.5) && (wipJS > 1901.0))  { ruleCode = 4.175 ; }
    return ruleCode; }
public static double checkDT18Tree2Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 3473.5) && (wipJS > 3480.0) && (wipJS > 4546.5) && (wipJS > 5328.0) && (wipJS > 5914.0))  { ruleCode = 0.668 ; }
    return ruleCode; }
public static double checkDT18Tree2Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 168.5) && (eTardJS <= 165.75) && (wipJS <= 3524.0) && (eTardJS <= 21.5) && (wipJS <= 1901.0))  { ruleCode = 1.121 ; }
    return ruleCode; }
public static double checkDT18Tree2Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 168.5) && (eTardJS <= 165.75) && (wipJS > 3524.0) && (eTardJS <= 6.0) && (wipJS <= 4987.0))  { ruleCode = 3.526 ; }
    return ruleCode; }
public static double checkDT18Tree2Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 168.5) && (eTardJS > 183.5) && (eTardJS <= 1213.5) && (eTardJS <= 1200.5) && (eTardJS <= 190.0))  { ruleCode = -3.725 ; }
    return ruleCode; }
public static double checkDT18Tree2Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 168.5) && (eTardJS <= 183.5) && (eTardJS <= 182.5) && (wipJS <= 3398.5) && (wipJS > 1822.5))  { ruleCode = 0.132 ; }
    return ruleCode; }
public static double checkDT18Tree2Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3473.5) && (wipJS <= 2059.0) && (wipJS > 2019.5) && (wipJS > 2023.5) && (wipJS > 2032.5))  { ruleCode = 145.049 ; }
    return ruleCode; }
public static double checkDT18Tree2Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3473.5) && (wipJS <= 2059.0) && (wipJS <= 2019.5) && (wipJS <= 1396.5) && (wipJS > 1357.0))  { ruleCode = 1.671 ; }
    return ruleCode; }
public static double checkDT18Tree2Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 3473.5) && (wipJS > 3480.0) && (wipJS > 4546.5) && (wipJS <= 5328.0) && (wipJS > 5242.0))  { ruleCode = 40.982 ; }
    return ruleCode; }
public static double checkDT18Tree2Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 168.5) && (eTardJS <= 183.5) && (eTardJS <= 182.5) && (wipJS <= 3398.5) && (wipJS <= 1822.5))  { ruleCode = 0.851 ; }
    return ruleCode; }
public static double checkDT18Tree2Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3473.5) && (wipJS <= 2059.0) && (wipJS > 2019.5) && (wipJS > 2023.5) && (wipJS <= 2032.5))  { ruleCode = 215.393 ; }
    return ruleCode; }
public static double checkDT18Tree2Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3473.5) && (wipJS > 2059.0) && (wipJS <= 2699.5) && (wipJS <= 2235.0) && (wipJS > 2229.5))  { ruleCode = 109.642 ; }
    return ruleCode; }
public static double checkDT18Tree2Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3473.5) && (wipJS <= 2059.0) && (wipJS <= 2019.5) && (wipJS > 1396.5) && (wipJS <= 1404.5))  { ruleCode = 462.0 ; }
    return ruleCode; }
public static double checkDT18Tree2Path33(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 168.5) && (eTardJS > 183.5) && (eTardJS <= 1213.5) && (eTardJS > 1200.5) && (wipJS > 2886.0))  { ruleCode = 6.386 ; }
    return ruleCode; }
public static double checkDT18Tree2Path34(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3473.5) && (wipJS <= 2059.0) && (wipJS > 2019.5) && (wipJS <= 2023.5))  { ruleCode = 810.0 ; }
    return ruleCode; }
public static double checkDT18Tree2Path35(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 168.5) && (eTardJS > 183.5) && (eTardJS <= 1213.5) && (eTardJS > 1200.5) && (wipJS <= 2886.0))  { ruleCode = 16.5 ; }
    return ruleCode; }
public static double checkDT18Tree2Path36(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 168.5) && (eTardJS <= 183.5) && (eTardJS > 182.5) && (wipJS <= 3178.5))  { ruleCode = 2.107 ; }
    return ruleCode; }
public static double checkDT18Tree2Path37(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 168.5) && (eTardJS <= 183.5) && (eTardJS > 182.5) && (wipJS > 3178.5))  { ruleCode = -128.0 ; }
    return ruleCode; }
public static double checkDT18Tree2Path38(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 168.5) && (eTardJS <= 165.75) && (wipJS > 3524.0) && (eTardJS <= 6.0) && (wipJS > 4987.0))  { ruleCode = 11.29 ; }
    return ruleCode; }
public static double checkDT18Tree2Path39(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3473.5) && (wipJS > 2059.0) && (wipJS > 2699.5) && (wipJS <= 2859.0) && (wipJS > 2849.0))  { ruleCode = 780.0 ; }
    return ruleCode; }
public static double checkDT18Tree2Path40(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 168.5) && (eTardJS <= 183.5) && (eTardJS <= 182.5) && (wipJS > 3398.5) && (wipJS > 4293.0))  { ruleCode = 0.685 ; }
    return ruleCode; }
public static double checkDT18Tree2Path41(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 168.5) && (eTardJS <= 183.5) && (eTardJS <= 182.5) && (wipJS > 3398.5) && (wipJS <= 4293.0))  { ruleCode = 1.064 ; }
    return ruleCode; }
public static double checkDT18Tree2Path42(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 3473.5) && (wipJS <= 3480.0))  { ruleCode = 1071.0 ; }
    return ruleCode; }
public static double checkDT18Tree2Path43(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 3473.5) && (wipJS > 3480.0) && (wipJS <= 4546.5) && (wipJS > 4544.0))  { ruleCode = 640.0 ; }
    return ruleCode; }
public static double checkDT18Tree2Path44(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 168.5) && (eTardJS > 165.75) && (eTardJS > 167.0))  { ruleCode = 1.241 ; }
    return ruleCode; }
public static double checkDT18Tree2Path45(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 168.5) && (eTardJS > 165.75) && (eTardJS <= 167.0))  { ruleCode = 8.93 ; }
    return ruleCode; }
public static double checkDT18Tree2Path46(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 168.5) && (eTardJS > 183.5) && (eTardJS > 1213.5) && (eTardJS <= 1815.25) && (eTardJS > 1810.0))  { ruleCode = -197.24 ; }
    return ruleCode; }
public static double checkDT18Tree3Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 811.5) && (wipJS > 2236.5) && (eTardJS > 3143.75) && (eTardJS <= 98193.5) && (eTardJS > 3344.5))  { ruleCode = 0.144 ; }
    return ruleCode; }
public static double checkDT18Tree3Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3312.5) && (wipJS <= 2857.5) && (wipJS <= 2845.5) && (wipJS <= 2704.5) && (wipJS <= 1977.0))  { ruleCode = 32.131 ; }
    return ruleCode; }
public static double checkDT18Tree3Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 811.5) && (wipJS > 2236.5) && (eTardJS <= 3143.75) && (eTardJS <= 3092.0) && (eTardJS > 1064.5))  { ruleCode = 0.261 ; }
    return ruleCode; }
public static double checkDT18Tree3Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 811.5) && (wipJS <= 2236.5) && (wipJS <= 2235.5) && (eTardJS > 833.5) && (eTardJS > 1211.75))  { ruleCode = 0.188 ; }
    return ruleCode; }
public static double checkDT18Tree3Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3312.5) && (wipJS <= 2857.5) && (wipJS <= 2845.5) && (wipJS <= 2704.5) && (wipJS > 1977.0))  { ruleCode = 15.689 ; }
    return ruleCode; }
public static double checkDT18Tree3Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 811.5) && (eTardJS > 141.5) && (eTardJS > 190.0) && (eTardJS > 202.0) && (wipJS <= 3595.5))  { ruleCode = 0.701 ; }
    return ruleCode; }
public static double checkDT18Tree3Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 811.5) && (wipJS > 2236.5) && (eTardJS > 3143.75) && (eTardJS > 98193.5) && (eTardJS <= 167167.25))  { ruleCode = 0.223 ; }
    return ruleCode; }
public static double checkDT18Tree3Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 3312.5) && (wipJS > 3314.0) && (wipJS <= 4289.5) && (wipJS <= 4283.5) && (wipJS > 3473.5))  { ruleCode = 111.154 ; }
    return ruleCode; }
public static double checkDT18Tree3Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 811.5) && (eTardJS > 141.5) && (eTardJS > 190.0) && (eTardJS > 202.0) && (wipJS > 3595.5))  { ruleCode = 1.585 ; }
    return ruleCode; }
public static double checkDT18Tree3Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 811.5) && (eTardJS <= 141.5) && (eTardJS > 21.5) && (wipJS > 2118.0) && (eTardJS <= 98.75))  { ruleCode = 1.249 ; }
    return ruleCode; }
public static double checkDT18Tree3Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 811.5) && (wipJS > 2236.5) && (eTardJS > 3143.75) && (eTardJS > 98193.5) && (eTardJS > 167167.25))  { ruleCode = 0.328 ; }
    return ruleCode; }
public static double checkDT18Tree3Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 3312.5) && (wipJS > 3314.0) && (wipJS > 4289.5) && (wipJS > 4623.0) && (wipJS <= 5914.0))  { ruleCode = 6.378 ; }
    return ruleCode; }
public static double checkDT18Tree3Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 811.5) && (wipJS > 2236.5) && (eTardJS <= 3143.75) && (eTardJS <= 3092.0) && (eTardJS <= 1064.5))  { ruleCode = 0.724 ; }
    return ruleCode; }
public static double checkDT18Tree3Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 811.5) && (eTardJS <= 141.5) && (eTardJS > 21.5) && (wipJS > 2118.0) && (eTardJS > 98.75))  { ruleCode = 2.294 ; }
    return ruleCode; }
public static double checkDT18Tree3Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 3312.5) && (wipJS > 3314.0) && (wipJS > 4289.5) && (wipJS <= 4623.0) && (wipJS <= 4540.0))  { ruleCode = 11.24 ; }
    return ruleCode; }
public static double checkDT18Tree3Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 811.5) && (eTardJS > 141.5) && (eTardJS <= 190.0) && (eTardJS <= 182.5) && (wipJS > 1649.5))  { ruleCode = 0.774 ; }
    return ruleCode; }
public static double checkDT18Tree3Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 811.5) && (wipJS <= 2236.5) && (wipJS <= 2235.5) && (eTardJS > 833.5) && (eTardJS <= 1211.75))  { ruleCode = 1.654 ; }
    return ruleCode; }
public static double checkDT18Tree3Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3312.5) && (wipJS > 2857.5) && (wipJS > 2935.5) && (wipJS > 3002.0) && (wipJS > 3102.0))  { ruleCode = 4.963 ; }
    return ruleCode; }
public static double checkDT18Tree3Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 811.5) && (eTardJS <= 141.5) && (eTardJS > 21.5) && (wipJS <= 2118.0) && (wipJS > 1693.0))  { ruleCode = -0.008 ; }
    return ruleCode; }
public static double checkDT18Tree3Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 3312.5) && (wipJS > 3314.0) && (wipJS <= 4289.5) && (wipJS <= 4283.5) && (wipJS <= 3473.5))  { ruleCode = 34.933 ; }
    return ruleCode; }
public static double checkDT18Tree3Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 811.5) && (wipJS > 2236.5) && (eTardJS > 3143.75) && (eTardJS <= 98193.5) && (eTardJS <= 3344.5))  { ruleCode = -0.037 ; }
    return ruleCode; }
public static double checkDT18Tree3Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 811.5) && (eTardJS <= 141.5) && (eTardJS <= 21.5) && (wipJS <= 2636.0) && (eTardJS > 2.75))  { ruleCode = 3.985 ; }
    return ruleCode; }
public static double checkDT18Tree3Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 811.5) && (eTardJS <= 141.5) && (eTardJS > 21.5) && (wipJS <= 2118.0) && (wipJS <= 1693.0))  { ruleCode = 1.536 ; }
    return ruleCode; }
public static double checkDT18Tree3Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3312.5) && (wipJS <= 2857.5) && (wipJS <= 2845.5) && (wipJS > 2704.5) && (wipJS > 2708.5))  { ruleCode = 59.556 ; }
    return ruleCode; }
public static double checkDT18Tree3Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3312.5) && (wipJS > 2857.5) && (wipJS <= 2935.5) && (wipJS <= 2916.0) && (wipJS > 2860.5))  { ruleCode = 3.787 ; }
    return ruleCode; }
public static double checkDT18Tree3Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3312.5) && (wipJS > 2857.5) && (wipJS > 2935.5) && (wipJS > 3002.0) && (wipJS <= 3102.0))  { ruleCode = 20.039 ; }
    return ruleCode; }
public static double checkDT18Tree3Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3312.5) && (wipJS > 2857.5) && (wipJS > 2935.5) && (wipJS <= 3002.0) && (wipJS > 2953.5))  { ruleCode = 0.931 ; }
    return ruleCode; }
public static double checkDT18Tree3Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 811.5) && (eTardJS <= 141.5) && (eTardJS <= 21.5) && (wipJS > 2636.0) && (wipJS > 3810.0))  { ruleCode = 0.55 ; }
    return ruleCode; }
public static double checkDT18Tree3Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 3312.5) && (wipJS > 3314.0) && (wipJS > 4289.5) && (wipJS > 4623.0) && (wipJS > 5914.0))  { ruleCode = 0.753 ; }
    return ruleCode; }
public static double checkDT18Tree3Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 3312.5) && (wipJS > 3314.0) && (wipJS > 4289.5) && (wipJS <= 4623.0) && (wipJS > 4540.0))  { ruleCode = 154.311 ; }
    return ruleCode; }
public static double checkDT18Tree3Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 811.5) && (eTardJS > 141.5) && (eTardJS <= 190.0) && (eTardJS > 182.5) && (wipJS <= 3509.0))  { ruleCode = -2.999 ; }
    return ruleCode; }
public static double checkDT18Tree3Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 811.5) && (eTardJS <= 141.5) && (eTardJS <= 21.5) && (wipJS > 2636.0) && (wipJS <= 3810.0))  { ruleCode = 1.813 ; }
    return ruleCode; }
public static double checkDT18Tree3Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 811.5) && (wipJS > 2236.5) && (eTardJS <= 3143.75) && (eTardJS > 3092.0) && (wipJS > 2984.0))  { ruleCode = 0.43 ; }
    return ruleCode; }
public static double checkDT18Tree3Path33(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 811.5) && (eTardJS > 141.5) && (eTardJS <= 190.0) && (eTardJS <= 182.5) && (wipJS <= 1649.5))  { ruleCode = 1.932 ; }
    return ruleCode; }
public static double checkDT18Tree3Path34(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3312.5) && (wipJS > 2857.5) && (wipJS <= 2935.5) && (wipJS > 2916.0) && (wipJS > 2925.0))  { ruleCode = 20.791 ; }
    return ruleCode; }
public static double checkDT18Tree3Path35(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 811.5) && (eTardJS <= 141.5) && (eTardJS <= 21.5) && (wipJS <= 2636.0) && (eTardJS <= 2.75))  { ruleCode = 0.184 ; }
    return ruleCode; }
public static double checkDT18Tree3Path36(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 811.5) && (eTardJS > 141.5) && (eTardJS > 190.0) && (eTardJS <= 202.0) && (eTardJS <= 198.75))  { ruleCode = 0.868 ; }
    return ruleCode; }
public static double checkDT18Tree3Path37(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3312.5) && (wipJS > 2857.5) && (wipJS > 2935.5) && (wipJS <= 3002.0) && (wipJS <= 2953.5))  { ruleCode = 6.191 ; }
    return ruleCode; }
public static double checkDT18Tree3Path38(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 811.5) && (eTardJS > 141.5) && (eTardJS <= 190.0) && (eTardJS > 182.5) && (wipJS > 3509.0))  { ruleCode = -42.604 ; }
    return ruleCode; }
public static double checkDT18Tree3Path39(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 811.5) && (wipJS <= 2236.5) && (wipJS <= 2235.5) && (eTardJS <= 833.5) && (eTardJS <= 820.5))  { ruleCode = -4.061 ; }
    return ruleCode; }
public static double checkDT18Tree3Path40(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 3312.5) && (wipJS <= 3314.0))  { ruleCode = 622.0 ; }
    return ruleCode; }
public static double checkDT18Tree3Path41(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 811.5) && (wipJS > 2236.5) && (eTardJS <= 3143.75) && (eTardJS > 3092.0) && (wipJS <= 2984.0))  { ruleCode = 17.445 ; }
    return ruleCode; }
public static double checkDT18Tree3Path42(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 3312.5) && (wipJS > 3314.0) && (wipJS <= 4289.5) && (wipJS > 4283.5))  { ruleCode = 915.0 ; }
    return ruleCode; }
public static double checkDT18Tree3Path43(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3312.5) && (wipJS > 2857.5) && (wipJS <= 2935.5) && (wipJS > 2916.0) && (wipJS <= 2925.0))  { ruleCode = 294.0 ; }
    return ruleCode; }
public static double checkDT18Tree3Path44(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3312.5) && (wipJS > 2857.5) && (wipJS <= 2935.5) && (wipJS <= 2916.0) && (wipJS <= 2860.5))  { ruleCode = 0.097 ; }
    return ruleCode; }
public static double checkDT18Tree3Path45(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3312.5) && (wipJS <= 2857.5) && (wipJS > 2845.5))  { ruleCode = 780.0 ; }
    return ruleCode; }
public static double checkDT18Tree3Path46(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 811.5) && (eTardJS > 141.5) && (eTardJS > 190.0) && (eTardJS <= 202.0) && (eTardJS > 198.75))  { ruleCode = 20.974 ; }
    return ruleCode; }
public static double checkDT18Tree3Path47(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 3312.5) && (wipJS <= 2857.5) && (wipJS <= 2845.5) && (wipJS > 2704.5) && (wipJS <= 2708.5))  { ruleCode = 1088.0 ; }
    return ruleCode; }
public static double checkDT18Tree3Path48(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 811.5) && (wipJS <= 2236.5) && (wipJS > 2235.5))  { ruleCode = -197.24 ; }
    return ruleCode; }
public static double checkDT18Tree3Path49(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 811.5) && (wipJS <= 2236.5) && (wipJS <= 2235.5) && (eTardJS <= 833.5) && (eTardJS > 820.5))  { ruleCode = -38.763 ; }
    return ruleCode; }
public static double checkDT18Tree4Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 143.0) && (eTardJS > 183.25) && (eTardJS > 526.0) && (wipJS > 2236.5) && (eTardJS > 3333.25))  { ruleCode = 0.148 ; }
    return ruleCode; }
public static double checkDT18Tree4Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 3275.0) && (wipJS <= 2059.0) && (wipJS <= 2019.5) && (wipJS <= 1942.0) && (wipJS <= 1755.5))  { ruleCode = 28.4 ; }
    return ruleCode; }
public static double checkDT18Tree4Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 143.0) && (eTardJS > 183.25) && (eTardJS > 526.0) && (wipJS > 2236.5) && (eTardJS <= 3333.25))  { ruleCode = 0.401 ; }
    return ruleCode; }
public static double checkDT18Tree4Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 143.0) && (eTardJS > 183.25) && (eTardJS > 526.0) && (wipJS <= 2236.5) && (wipJS <= 2234.0))  { ruleCode = 0.02 ; }
    return ruleCode; }
public static double checkDT18Tree4Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 143.0) && (eTardJS > 183.25) && (eTardJS <= 526.0) && (eTardJS > 186.25) && (eTardJS <= 444.5))  { ruleCode = 0.824 ; }
    return ruleCode; }
public static double checkDT18Tree4Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 143.0) && (wipJS > 2140.0) && (eTardJS > 22.5) && (eTardJS <= 141.5) && (wipJS <= 5272.5))  { ruleCode = 1.708 ; }
    return ruleCode; }
public static double checkDT18Tree4Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 3275.0) && (wipJS > 3986.5) && (wipJS > 4235.0) && (wipJS <= 5339.5) && (wipJS <= 5224.5))  { ruleCode = 6.17 ; }
    return ruleCode; }
public static double checkDT18Tree4Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 3275.0) && (wipJS <= 3986.5) && (wipJS <= 3978.0) && (wipJS > 3290.5) && (wipJS <= 3835.0))  { ruleCode = 114.038 ; }
    return ruleCode; }
public static double checkDT18Tree4Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 3275.0) && (wipJS > 2059.0) && (wipJS <= 2494.5) && (wipJS > 2100.0) && (wipJS > 2163.5))  { ruleCode = 8.246 ; }
    return ruleCode; }
public static double checkDT18Tree4Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 3275.0) && (wipJS > 2059.0) && (wipJS > 2494.5) && (wipJS > 2500.5) && (wipJS > 2859.0))  { ruleCode = 13.93 ; }
    return ruleCode; }
public static double checkDT18Tree4Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 3275.0) && (wipJS > 2059.0) && (wipJS > 2494.5) && (wipJS > 2500.5) && (wipJS <= 2859.0))  { ruleCode = 44.845 ; }
    return ruleCode; }
public static double checkDT18Tree4Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 143.0) && (wipJS <= 2140.0) && (wipJS <= 1995.5) && (eTardJS <= 138.0) && (eTardJS > 16.0))  { ruleCode = 0.837 ; }
    return ruleCode; }
public static double checkDT18Tree4Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 3275.0) && (wipJS <= 2059.0) && (wipJS <= 2019.5) && (wipJS <= 1942.0) && (wipJS > 1755.5))  { ruleCode = 15.42 ; }
    return ruleCode; }
public static double checkDT18Tree4Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 143.0) && (eTardJS > 183.25) && (eTardJS <= 526.0) && (eTardJS > 186.25) && (eTardJS > 444.5))  { ruleCode = 2.368 ; }
    return ruleCode; }
public static double checkDT18Tree4Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 3275.0) && (wipJS > 3986.5) && (wipJS <= 4235.0) && (wipJS <= 4227.0) && (wipJS > 4092.0))  { ruleCode = 45.916 ; }
    return ruleCode; }
public static double checkDT18Tree4Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 143.0) && (wipJS > 2140.0) && (eTardJS <= 22.5) && (eTardJS <= 19.5) && (eTardJS <= 9.5))  { ruleCode = 3.498 ; }
    return ruleCode; }
public static double checkDT18Tree4Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 3275.0) && (wipJS > 3986.5) && (wipJS > 4235.0) && (wipJS > 5339.5) && (wipJS <= 5914.0))  { ruleCode = 4.578 ; }
    return ruleCode; }
public static double checkDT18Tree4Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 3275.0) && (wipJS <= 3986.5) && (wipJS <= 3978.0) && (wipJS > 3290.5) && (wipJS > 3835.0))  { ruleCode = 14.491 ; }
    return ruleCode; }
public static double checkDT18Tree4Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 3275.0) && (wipJS <= 2059.0) && (wipJS <= 2019.5) && (wipJS > 1942.0) && (wipJS > 1976.0))  { ruleCode = 6.804 ; }
    return ruleCode; }
public static double checkDT18Tree4Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 143.0) && (wipJS <= 2140.0) && (wipJS > 1995.5) && (wipJS > 1999.5) && (eTardJS <= 137.0))  { ruleCode = 0.394 ; }
    return ruleCode; }
public static double checkDT18Tree4Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 143.0) && (eTardJS <= 183.25) && (eTardJS <= 182.5) && (eTardJS <= 166.25) && (wipJS <= 3941.5))  { ruleCode = 0.187 ; }
    return ruleCode; }
public static double checkDT18Tree4Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 3275.0) && (wipJS > 2059.0) && (wipJS <= 2494.5) && (wipJS > 2100.0) && (wipJS <= 2163.5))  { ruleCode = 16.066 ; }
    return ruleCode; }
public static double checkDT18Tree4Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 143.0) && (wipJS > 2140.0) && (eTardJS > 22.5) && (eTardJS <= 141.5) && (wipJS > 5272.5))  { ruleCode = 0.529 ; }
    return ruleCode; }
public static double checkDT18Tree4Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 3275.0) && (wipJS > 3986.5) && (wipJS <= 4235.0) && (wipJS <= 4227.0) && (wipJS <= 4092.0))  { ruleCode = 3.375 ; }
    return ruleCode; }
public static double checkDT18Tree4Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 143.0) && (wipJS <= 2140.0) && (wipJS <= 1995.5) && (eTardJS <= 138.0) && (eTardJS <= 16.0))  { ruleCode = 2.502 ; }
    return ruleCode; }
public static double checkDT18Tree4Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 3275.0) && (wipJS > 3986.5) && (wipJS > 4235.0) && (wipJS > 5339.5) && (wipJS > 5914.0))  { ruleCode = 1.292 ; }
    return ruleCode; }
public static double checkDT18Tree4Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 3275.0) && (wipJS > 3986.5) && (wipJS > 4235.0) && (wipJS <= 5339.5) && (wipJS > 5224.5))  { ruleCode = 23.692 ; }
    return ruleCode; }
public static double checkDT18Tree4Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 143.0) && (wipJS > 2140.0) && (eTardJS <= 22.5) && (eTardJS <= 19.5) && (eTardJS > 9.5))  { ruleCode = 0.538 ; }
    return ruleCode; }
public static double checkDT18Tree4Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 143.0) && (eTardJS <= 183.25) && (eTardJS <= 182.5) && (eTardJS > 166.25) && (wipJS <= 2503.0))  { ruleCode = 1.273 ; }
    return ruleCode; }
public static double checkDT18Tree4Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 143.0) && (eTardJS <= 183.25) && (eTardJS <= 182.5) && (eTardJS > 166.25) && (wipJS > 2503.0))  { ruleCode = 0.521 ; }
    return ruleCode; }
public static double checkDT18Tree4Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 3275.0) && (wipJS <= 2059.0) && (wipJS <= 2019.5) && (wipJS > 1942.0) && (wipJS <= 1976.0))  { ruleCode = 158.392 ; }
    return ruleCode; }
public static double checkDT18Tree4Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 3275.0) && (wipJS > 2059.0) && (wipJS <= 2494.5) && (wipJS <= 2100.0) && (wipJS > 2065.5))  { ruleCode = 3.109 ; }
    return ruleCode; }
public static double checkDT18Tree4Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 143.0) && (eTardJS > 183.25) && (eTardJS > 526.0) && (wipJS <= 2236.5) && (wipJS > 2234.0))  { ruleCode = -49.201 ; }
    return ruleCode; }
public static double checkDT18Tree4Path33(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 143.0) && (wipJS > 2140.0) && (eTardJS <= 22.5) && (eTardJS > 19.5) && (eTardJS > 20.25))  { ruleCode = 3.86 ; }
    return ruleCode; }
public static double checkDT18Tree4Path34(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 143.0) && (eTardJS > 183.25) && (eTardJS <= 526.0) && (eTardJS <= 186.25) && (wipJS <= 3373.0))  { ruleCode = 7.449 ; }
    return ruleCode; }
public static double checkDT18Tree4Path35(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 3275.0) && (wipJS <= 2059.0) && (wipJS > 2019.5) && (wipJS > 2030.5) && (wipJS <= 2054.5))  { ruleCode = 0.213 ; }
    return ruleCode; }
public static double checkDT18Tree4Path36(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 3275.0) && (wipJS <= 2059.0) && (wipJS > 2019.5) && (wipJS > 2030.5) && (wipJS > 2054.5))  { ruleCode = 276.333 ; }
    return ruleCode; }
public static double checkDT18Tree4Path37(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 3275.0) && (wipJS > 2059.0) && (wipJS <= 2494.5) && (wipJS <= 2100.0) && (wipJS <= 2065.5))  { ruleCode = 8.244 ; }
    return ruleCode; }
public static double checkDT18Tree4Path38(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 3275.0) && (wipJS <= 3986.5) && (wipJS > 3978.0))  { ruleCode = 933.0 ; }
    return ruleCode; }
public static double checkDT18Tree4Path39(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 143.0) && (eTardJS > 183.25) && (eTardJS <= 526.0) && (eTardJS <= 186.25) && (wipJS > 3373.0))  { ruleCode = 0.095 ; }
    return ruleCode; }
public static double checkDT18Tree4Path40(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 143.0) && (wipJS <= 2140.0) && (wipJS > 1995.5) && (wipJS > 1999.5) && (eTardJS > 137.0))  { ruleCode = 4.616 ; }
    return ruleCode; }
public static double checkDT18Tree4Path41(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 3275.0) && (wipJS <= 2059.0) && (wipJS > 2019.5) && (wipJS <= 2030.5))  { ruleCode = 429.0 ; }
    return ruleCode; }
public static double checkDT18Tree4Path42(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 3275.0) && (wipJS > 3986.5) && (wipJS <= 4235.0) && (wipJS > 4227.0))  { ruleCode = 434.0 ; }
    return ruleCode; }
public static double checkDT18Tree4Path43(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 143.0) && (eTardJS <= 183.25) && (eTardJS > 182.5))  { ruleCode = -128.0 ; }
    return ruleCode; }
public static double checkDT18Tree4Path44(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 143.0) && (wipJS > 2140.0) && (eTardJS <= 22.5) && (eTardJS > 19.5) && (eTardJS <= 20.25))  { ruleCode = 12.602 ; }
    return ruleCode; }
public static double checkDT18Tree4Path45(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 3275.0) && (wipJS > 2059.0) && (wipJS > 2494.5) && (wipJS <= 2500.5))  { ruleCode = 176.0 ; }
    return ruleCode; }
public static double checkDT18Tree4Path46(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 143.0) && (wipJS <= 2140.0) && (wipJS > 1995.5) && (wipJS <= 1999.5))  { ruleCode = -16.698 ; }
    return ruleCode; }
public static double checkDT18Tree4Path47(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 143.0) && (eTardJS <= 183.25) && (eTardJS <= 182.5) && (eTardJS <= 166.25) && (wipJS > 3941.5))  { ruleCode = 0.629 ; }
    return ruleCode; }
public static double checkDT18Tree4Path48(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 3275.0) && (wipJS <= 3986.5) && (wipJS <= 3978.0) && (wipJS <= 3290.5))  { ruleCode = 870.0 ; }
    return ruleCode; }
public static double checkDT18Tree4Path49(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 143.0) && (wipJS > 2140.0) && (eTardJS > 22.5) && (eTardJS > 141.5))  { ruleCode = 6.94 ; }
    return ruleCode; }
public static double checkDT18Tree4Path50(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 143.0) && (wipJS <= 2140.0) && (wipJS <= 1995.5) && (eTardJS > 138.0))  { ruleCode = 6.255 ; }
    return ruleCode; }
public static double checkDT18Tree5Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 144.25) && (eTardJS > 183.25) && (wipJS > 2236.5) && (eTardJS > 188.0) && (eTardJS > 335.0))  { ruleCode = 0.231 ; }
    return ruleCode; }
public static double checkDT18Tree5Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2689.0) && (wipJS <= 2235.0) && (wipJS <= 2226.0) && (wipJS <= 2059.0) && (wipJS <= 1752.0))  { ruleCode = 24.114 ; }
    return ruleCode; }
public static double checkDT18Tree5Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 144.25) && (eTardJS > 183.25) && (wipJS <= 2236.5) && (wipJS <= 2235.5) && (eTardJS > 196.75))  { ruleCode = -0.015 ; }
    return ruleCode; }
public static double checkDT18Tree5Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2689.0) && (wipJS <= 3935.5) && (wipJS <= 3922.5) && (wipJS <= 3592.5) && (wipJS > 2710.0))  { ruleCode = 39.305 ; }
    return ruleCode; }
public static double checkDT18Tree5Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 144.25) && (eTardJS > 22.5) && (wipJS <= 3755.5) && (eTardJS <= 138.75) && (eTardJS <= 136.0))  { ruleCode = 1.281 ; }
    return ruleCode; }
public static double checkDT18Tree5Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2689.0) && (wipJS <= 2235.0) && (wipJS <= 2226.0) && (wipJS <= 2059.0) && (wipJS > 1752.0))  { ruleCode = 53.896 ; }
    return ruleCode; }
public static double checkDT18Tree5Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 144.25) && (eTardJS > 183.25) && (wipJS > 2236.5) && (eTardJS > 188.0) && (eTardJS <= 335.0))  { ruleCode = 1.882 ; }
    return ruleCode; }
public static double checkDT18Tree5Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2689.0) && (wipJS > 3935.5) && (wipJS > 4235.0) && (wipJS <= 5292.5) && (wipJS > 4508.0))  { ruleCode = 23.159 ; }
    return ruleCode; }
public static double checkDT18Tree5Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2689.0) && (wipJS > 3935.5) && (wipJS > 4235.0) && (wipJS <= 5292.5) && (wipJS <= 4508.0))  { ruleCode = 7.067 ; }
    return ruleCode; }
public static double checkDT18Tree5Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2689.0) && (wipJS <= 3935.5) && (wipJS <= 3922.5) && (wipJS > 3592.5) && (wipJS > 3606.0))  { ruleCode = 82.434 ; }
    return ruleCode; }
public static double checkDT18Tree5Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2689.0) && (wipJS > 2235.0) && (wipJS <= 2536.0) && (wipJS <= 2533.5) && (wipJS <= 2385.5))  { ruleCode = 12.499 ; }
    return ruleCode; }
public static double checkDT18Tree5Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 144.25) && (eTardJS <= 22.5) && (wipJS > 1901.0) && (wipJS > 1942.0) && (eTardJS <= 18.5))  { ruleCode = 2.545 ; }
    return ruleCode; }
public static double checkDT18Tree5Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2689.0) && (wipJS > 2235.0) && (wipJS <= 2536.0) && (wipJS <= 2533.5) && (wipJS > 2385.5))  { ruleCode = 3.666 ; }
    return ruleCode; }
public static double checkDT18Tree5Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2689.0) && (wipJS <= 2235.0) && (wipJS <= 2226.0) && (wipJS > 2059.0) && (wipJS > 2146.5))  { ruleCode = 3.627 ; }
    return ruleCode; }
public static double checkDT18Tree5Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 144.25) && (eTardJS <= 183.25) && (eTardJS <= 182.5) && (eTardJS > 157.25) && (eTardJS > 161.5))  { ruleCode = 0.722 ; }
    return ruleCode; }
public static double checkDT18Tree5Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2689.0) && (wipJS > 3935.5) && (wipJS <= 4235.0) && (wipJS <= 4227.0) && (wipJS <= 4097.5))  { ruleCode = 8.789 ; }
    return ruleCode; }
public static double checkDT18Tree5Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2689.0) && (wipJS > 3935.5) && (wipJS > 4235.0) && (wipJS > 5292.5) && (wipJS <= 5982.0))  { ruleCode = 3.849 ; }
    return ruleCode; }
public static double checkDT18Tree5Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2689.0) && (wipJS <= 2235.0) && (wipJS <= 2226.0) && (wipJS > 2059.0) && (wipJS <= 2146.5))  { ruleCode = 9.972 ; }
    return ruleCode; }
public static double checkDT18Tree5Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2689.0) && (wipJS > 3935.5) && (wipJS <= 4235.0) && (wipJS <= 4227.0) && (wipJS > 4097.5))  { ruleCode = 64.39 ; }
    return ruleCode; }
public static double checkDT18Tree5Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 144.25) && (eTardJS > 22.5) && (wipJS > 3755.5) && (wipJS > 4433.0) && (eTardJS <= 92.5))  { ruleCode = 0.829 ; }
    return ruleCode; }
public static double checkDT18Tree5Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2689.0) && (wipJS > 3935.5) && (wipJS > 4235.0) && (wipJS > 5292.5) && (wipJS > 5982.0))  { ruleCode = 0.533 ; }
    return ruleCode; }
public static double checkDT18Tree5Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2689.0) && (wipJS > 2235.0) && (wipJS > 2536.0) && (wipJS > 2539.5) && (wipJS <= 2651.5))  { ruleCode = 1.708 ; }
    return ruleCode; }
public static double checkDT18Tree5Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 144.25) && (eTardJS > 22.5) && (wipJS > 3755.5) && (wipJS <= 4433.0) && (wipJS <= 4194.5))  { ruleCode = 2.101 ; }
    return ruleCode; }
public static double checkDT18Tree5Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2689.0) && (wipJS > 2235.0) && (wipJS > 2536.0) && (wipJS > 2539.5) && (wipJS > 2651.5))  { ruleCode = 3.43 ; }
    return ruleCode; }
public static double checkDT18Tree5Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 144.25) && (eTardJS > 22.5) && (wipJS > 3755.5) && (wipJS > 4433.0) && (eTardJS > 92.5))  { ruleCode = 3.091 ; }
    return ruleCode; }
public static double checkDT18Tree5Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 144.25) && (eTardJS <= 183.25) && (eTardJS <= 182.5) && (eTardJS <= 157.25) && (wipJS <= 3503.0))  { ruleCode = 0.261 ; }
    return ruleCode; }
public static double checkDT18Tree5Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 144.25) && (eTardJS <= 22.5) && (wipJS > 1901.0) && (wipJS > 1942.0) && (eTardJS > 18.5))  { ruleCode = 5.276 ; }
    return ruleCode; }
public static double checkDT18Tree5Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 144.25) && (eTardJS > 22.5) && (wipJS > 3755.5) && (wipJS <= 4433.0) && (wipJS > 4194.5))  { ruleCode = 7.785 ; }
    return ruleCode; }
public static double checkDT18Tree5Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 144.25) && (eTardJS > 22.5) && (wipJS <= 3755.5) && (eTardJS > 138.75) && (wipJS > 2458.0))  { ruleCode = 1.553 ; }
    return ruleCode; }
public static double checkDT18Tree5Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 144.25) && (eTardJS > 183.25) && (wipJS <= 2236.5) && (wipJS <= 2235.5) && (eTardJS <= 196.75))  { ruleCode = -6.16 ; }
    return ruleCode; }
public static double checkDT18Tree5Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 144.25) && (eTardJS > 22.5) && (wipJS <= 3755.5) && (eTardJS <= 138.75) && (eTardJS > 136.0))  { ruleCode = -2.374 ; }
    return ruleCode; }
public static double checkDT18Tree5Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2689.0) && (wipJS <= 3935.5) && (wipJS <= 3922.5) && (wipJS <= 3592.5) && (wipJS <= 2710.0))  { ruleCode = 319.323 ; }
    return ruleCode; }
public static double checkDT18Tree5Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 144.25) && (eTardJS > 22.5) && (wipJS <= 3755.5) && (eTardJS > 138.75) && (wipJS <= 2458.0))  { ruleCode = 5.026 ; }
    return ruleCode; }
public static double checkDT18Tree5Path33(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 144.25) && (eTardJS <= 22.5) && (wipJS <= 1901.0) && (eTardJS <= 13.5) && (wipJS > 1559.5))  { ruleCode = 1.972 ; }
    return ruleCode; }
public static double checkDT18Tree5Path34(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2689.0) && (wipJS > 3935.5) && (wipJS <= 4235.0) && (wipJS > 4227.0))  { ruleCode = 221.182 ; }
    return ruleCode; }
public static double checkDT18Tree5Path35(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 144.25) && (eTardJS <= 183.25) && (eTardJS <= 182.5) && (eTardJS > 157.25) && (eTardJS <= 161.5))  { ruleCode = 4.86 ; }
    return ruleCode; }
public static double checkDT18Tree5Path36(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2689.0) && (wipJS <= 3935.5) && (wipJS <= 3922.5) && (wipJS > 3592.5) && (wipJS <= 3606.0))  { ruleCode = 1009.0 ; }
    return ruleCode; }
public static double checkDT18Tree5Path37(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 144.25) && (eTardJS > 183.25) && (wipJS <= 2236.5) && (wipJS > 2235.5) && (eTardJS <= 1649.75))  { ruleCode = 0.146 ; }
    return ruleCode; }
public static double checkDT18Tree5Path38(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 144.25) && (eTardJS <= 22.5) && (wipJS <= 1901.0) && (eTardJS > 13.5) && (wipJS > 1719.5))  { ruleCode = 0.108 ; }
    return ruleCode; }
public static double checkDT18Tree5Path39(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 144.25) && (eTardJS <= 22.5) && (wipJS <= 1901.0) && (eTardJS <= 13.5) && (wipJS <= 1559.5))  { ruleCode = 0.719 ; }
    return ruleCode; }
public static double checkDT18Tree5Path40(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 144.25) && (eTardJS <= 183.25) && (eTardJS <= 182.5) && (eTardJS <= 157.25) && (wipJS > 3503.0))  { ruleCode = 0.42 ; }
    return ruleCode; }
public static double checkDT18Tree5Path41(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2689.0) && (wipJS <= 2235.0) && (wipJS > 2226.0))  { ruleCode = 321.75 ; }
    return ruleCode; }
public static double checkDT18Tree5Path42(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2689.0) && (wipJS > 2235.0) && (wipJS <= 2536.0) && (wipJS > 2533.5))  { ruleCode = 279.0 ; }
    return ruleCode; }
public static double checkDT18Tree5Path43(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 144.25) && (eTardJS > 183.25) && (wipJS > 2236.5) && (eTardJS <= 188.0))  { ruleCode = 28.92 ; }
    return ruleCode; }
public static double checkDT18Tree5Path44(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2689.0) && (wipJS > 2235.0) && (wipJS > 2536.0) && (wipJS <= 2539.5))  { ruleCode = 7.447 ; }
    return ruleCode; }
public static double checkDT18Tree5Path45(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2689.0) && (wipJS <= 3935.5) && (wipJS > 3922.5))  { ruleCode = 775.0 ; }
    return ruleCode; }
public static double checkDT18Tree5Path46(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 144.25) && (eTardJS > 183.25) && (wipJS <= 2236.5) && (wipJS > 2235.5) && (eTardJS > 1649.75))  { ruleCode = -197.24 ; }
    return ruleCode; }
public static double checkDT18Tree5Path47(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 144.25) && (eTardJS <= 22.5) && (wipJS > 1901.0) && (wipJS <= 1942.0))  { ruleCode = 19.5 ; }
    return ruleCode; }
public static double checkDT18Tree5Path48(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 144.25) && (eTardJS <= 183.25) && (eTardJS > 182.5) && (wipJS <= 3178.5))  { ruleCode = 2.107 ; }
    return ruleCode; }
public static double checkDT18Tree5Path49(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 144.25) && (eTardJS <= 183.25) && (eTardJS > 182.5) && (wipJS > 3178.5))  { ruleCode = -128.0 ; }
    return ruleCode; }
public static double checkDT18Tree5Path50(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 144.25) && (eTardJS <= 22.5) && (wipJS <= 1901.0) && (eTardJS > 13.5) && (wipJS <= 1719.5))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT18Tree6Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1213.75) && (eTardJS > 4265.25) && (eTardJS <= 95011.25) && (eTardJS > 7645.25) && (eTardJS <= 44187.5))  { ruleCode = 0.131 ; }
    return ruleCode; }
public static double checkDT18Tree6Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2704.5) && (wipJS <= 2237.5) && (wipJS <= 1572.5) && (wipJS <= 750.5) && (wipJS <= 374.0))  { ruleCode = 24.49 ; }
    return ruleCode; }
public static double checkDT18Tree6Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1213.75) && (eTardJS > 4265.25) && (eTardJS <= 95011.25) && (eTardJS > 7645.25) && (eTardJS > 44187.5))  { ruleCode = 0.161 ; }
    return ruleCode; }
public static double checkDT18Tree6Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1213.75) && (eTardJS <= 1208.25) && (eTardJS > 22.75) && (wipJS > 2008.5) && (eTardJS > 201.0))  { ruleCode = 0.904 ; }
    return ruleCode; }
public static double checkDT18Tree6Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1213.75) && (eTardJS > 4265.25) && (eTardJS <= 95011.25) && (eTardJS <= 7645.25) && (eTardJS <= 7621.25))  { ruleCode = 0.147 ; }
    return ruleCode; }
public static double checkDT18Tree6Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1213.75) && (eTardJS <= 4265.25) && (eTardJS <= 3091.0) && (wipJS <= 4344.5) && (wipJS <= 4224.5))  { ruleCode = 0.175 ; }
    return ruleCode; }
public static double checkDT18Tree6Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2704.5) && (wipJS <= 2237.5) && (wipJS > 1572.5) && (wipJS > 1575.0) && (wipJS <= 2233.5))  { ruleCode = 46.819 ; }
    return ruleCode; }
public static double checkDT18Tree6Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1213.75) && (eTardJS <= 1208.25) && (eTardJS > 22.75) && (wipJS > 2008.5) && (eTardJS <= 201.0))  { ruleCode = 2.239 ; }
    return ruleCode; }
public static double checkDT18Tree6Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1213.75) && (eTardJS <= 1208.25) && (eTardJS > 22.75) && (wipJS <= 2008.5) && (wipJS <= 1996.0))  { ruleCode = 0.546 ; }
    return ruleCode; }
public static double checkDT18Tree6Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2704.5) && (wipJS > 2708.5) && (wipJS <= 4189.5) && (wipJS <= 4183.5) && (wipJS <= 3519.0))  { ruleCode = 31.845 ; }
    return ruleCode; }
public static double checkDT18Tree6Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1213.75) && (eTardJS <= 4265.25) && (eTardJS > 3091.0) && (eTardJS > 3106.0) && (eTardJS <= 4250.0))  { ruleCode = 0.25 ; }
    return ruleCode; }
public static double checkDT18Tree6Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2704.5) && (wipJS > 2708.5) && (wipJS <= 4189.5) && (wipJS <= 4183.5) && (wipJS > 3519.0))  { ruleCode = 110.108 ; }
    return ruleCode; }
public static double checkDT18Tree6Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1213.75) && (eTardJS > 4265.25) && (eTardJS > 95011.25) && (eTardJS <= 174992.25) && (wipJS > 4643.5))  { ruleCode = 0.203 ; }
    return ruleCode; }
public static double checkDT18Tree6Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1213.75) && (eTardJS <= 4265.25) && (eTardJS <= 3091.0) && (wipJS > 4344.5) && (wipJS > 4418.5))  { ruleCode = 0.394 ; }
    return ruleCode; }
public static double checkDT18Tree6Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2704.5) && (wipJS > 2237.5) && (wipJS <= 2699.5) && (wipJS <= 2503.5) && (wipJS <= 2493.5))  { ruleCode = 9.218 ; }
    return ruleCode; }
public static double checkDT18Tree6Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1213.75) && (eTardJS > 4265.25) && (eTardJS > 95011.25) && (eTardJS > 174992.25) && (wipJS > 4275.0))  { ruleCode = 0.327 ; }
    return ruleCode; }
public static double checkDT18Tree6Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2704.5) && (wipJS <= 2237.5) && (wipJS <= 1572.5) && (wipJS > 750.5) && (wipJS > 1291.5))  { ruleCode = 23.255 ; }
    return ruleCode; }
public static double checkDT18Tree6Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2704.5) && (wipJS > 2708.5) && (wipJS > 4189.5) && (wipJS <= 4546.5) && (wipJS <= 4544.0))  { ruleCode = 14.295 ; }
    return ruleCode; }
public static double checkDT18Tree6Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1213.75) && (eTardJS > 4265.25) && (eTardJS > 95011.25) && (eTardJS <= 174992.25) && (wipJS <= 4643.5))  { ruleCode = 0.273 ; }
    return ruleCode; }
public static double checkDT18Tree6Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2704.5) && (wipJS > 2708.5) && (wipJS > 4189.5) && (wipJS > 4546.5) && (wipJS <= 5267.5))  { ruleCode = 12.557 ; }
    return ruleCode; }
public static double checkDT18Tree6Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2704.5) && (wipJS > 2708.5) && (wipJS > 4189.5) && (wipJS > 4546.5) && (wipJS > 5267.5))  { ruleCode = 2.343 ; }
    return ruleCode; }
public static double checkDT18Tree6Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2704.5) && (wipJS > 2237.5) && (wipJS <= 2699.5) && (wipJS > 2503.5) && (wipJS <= 2684.0))  { ruleCode = 2.735 ; }
    return ruleCode; }
public static double checkDT18Tree6Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2704.5) && (wipJS <= 2237.5) && (wipJS <= 1572.5) && (wipJS > 750.5) && (wipJS <= 1291.5))  { ruleCode = 7.997 ; }
    return ruleCode; }
public static double checkDT18Tree6Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1213.75) && (eTardJS <= 1208.25) && (eTardJS <= 22.75) && (eTardJS <= 14.75) && (wipJS <= 2979.5))  { ruleCode = 1.177 ; }
    return ruleCode; }
public static double checkDT18Tree6Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1213.75) && (eTardJS <= 1208.25) && (eTardJS <= 22.75) && (eTardJS > 14.75) && (eTardJS > 15.75))  { ruleCode = 2.521 ; }
    return ruleCode; }
public static double checkDT18Tree6Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1213.75) && (eTardJS <= 1208.25) && (eTardJS <= 22.75) && (eTardJS <= 14.75) && (wipJS > 2979.5))  { ruleCode = 2.902 ; }
    return ruleCode; }
public static double checkDT18Tree6Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1213.75) && (eTardJS > 4265.25) && (eTardJS > 95011.25) && (eTardJS > 174992.25) && (wipJS <= 4275.0))  { ruleCode = 0.488 ; }
    return ruleCode; }
public static double checkDT18Tree6Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1213.75) && (eTardJS <= 1208.25) && (eTardJS > 22.75) && (wipJS <= 2008.5) && (wipJS > 1996.0))  { ruleCode = -4.911 ; }
    return ruleCode; }
public static double checkDT18Tree6Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1213.75) && (eTardJS <= 4265.25) && (eTardJS <= 3091.0) && (wipJS <= 4344.5) && (wipJS > 4224.5))  { ruleCode = -1.934 ; }
    return ruleCode; }
public static double checkDT18Tree6Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1213.75) && (eTardJS > 4265.25) && (eTardJS <= 95011.25) && (eTardJS <= 7645.25) && (eTardJS > 7621.25))  { ruleCode = 1.111 ; }
    return ruleCode; }
public static double checkDT18Tree6Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1213.75) && (eTardJS <= 4265.25) && (eTardJS <= 3091.0) && (wipJS > 4344.5) && (wipJS <= 4418.5))  { ruleCode = 1.403 ; }
    return ruleCode; }
public static double checkDT18Tree6Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2704.5) && (wipJS > 2237.5) && (wipJS <= 2699.5) && (wipJS > 2503.5) && (wipJS > 2684.0))  { ruleCode = 12.5 ; }
    return ruleCode; }
public static double checkDT18Tree6Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2704.5) && (wipJS <= 2237.5) && (wipJS > 1572.5) && (wipJS > 1575.0) && (wipJS > 2233.5))  { ruleCode = 215.696 ; }
    return ruleCode; }
public static double checkDT18Tree6Path33(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1213.75) && (eTardJS <= 1208.25) && (eTardJS <= 22.75) && (eTardJS > 14.75) && (eTardJS <= 15.75))  { ruleCode = 13.234 ; }
    return ruleCode; }
public static double checkDT18Tree6Path34(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2704.5) && (wipJS <= 2237.5) && (wipJS <= 1572.5) && (wipJS <= 750.5) && (wipJS > 374.0))  { ruleCode = 131.0 ; }
    return ruleCode; }
public static double checkDT18Tree6Path35(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2704.5) && (wipJS <= 2237.5) && (wipJS > 1572.5) && (wipJS <= 1575.0))  { ruleCode = 1079.0 ; }
    return ruleCode; }
public static double checkDT18Tree6Path36(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1213.75) && (eTardJS > 1208.25) && (wipJS <= 2886.0))  { ruleCode = 16.5 ; }
    return ruleCode; }
public static double checkDT18Tree6Path37(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2704.5) && (wipJS > 2237.5) && (wipJS <= 2699.5) && (wipJS <= 2503.5) && (wipJS > 2493.5))  { ruleCode = 176.0 ; }
    return ruleCode; }
public static double checkDT18Tree6Path38(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2704.5) && (wipJS > 2237.5) && (wipJS > 2699.5))  { ruleCode = 34.73 ; }
    return ruleCode; }
public static double checkDT18Tree6Path39(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2704.5) && (wipJS <= 2708.5))  { ruleCode = 1088.0 ; }
    return ruleCode; }
public static double checkDT18Tree6Path40(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1213.75) && (eTardJS <= 4265.25) && (eTardJS > 3091.0) && (eTardJS > 3106.0) && (eTardJS > 4250.0))  { ruleCode = 2.966 ; }
    return ruleCode; }
public static double checkDT18Tree6Path41(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1213.75) && (eTardJS > 1208.25) && (wipJS > 2886.0))  { ruleCode = 6.386 ; }
    return ruleCode; }
public static double checkDT18Tree6Path42(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2704.5) && (wipJS > 2708.5) && (wipJS <= 4189.5) && (wipJS > 4183.5))  { ruleCode = 2184.0 ; }
    return ruleCode; }
public static double checkDT18Tree6Path43(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2704.5) && (wipJS > 2708.5) && (wipJS > 4189.5) && (wipJS <= 4546.5) && (wipJS > 4544.0))  { ruleCode = 640.0 ; }
    return ruleCode; }
public static double checkDT18Tree6Path44(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1213.75) && (eTardJS <= 4265.25) && (eTardJS > 3091.0) && (eTardJS <= 3106.0))  { ruleCode = 17.445 ; }
    return ruleCode; }
public static double checkDT18Tree7Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 473.5) && (wipJS > 2236.5) && (eTardJS > 2116.25) && (eTardJS <= 96518.75) && (wipJS > 2793.5))  { ruleCode = 0.155 ; }
    return ruleCode; }
public static double checkDT18Tree7Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 1549.0) && (wipJS <= 1273.5) && (wipJS <= 1258.0) && (wipJS <= 1183.5) && (wipJS <= 1167.0))  { ruleCode = 20.733 ; }
    return ruleCode; }
public static double checkDT18Tree7Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 1549.0) && (wipJS <= 4289.5) && (wipJS <= 4273.5) && (wipJS <= 3594.5) && (wipJS > 2030.5))  { ruleCode = 28.048 ; }
    return ruleCode; }
public static double checkDT18Tree7Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 473.5) && (eTardJS <= 456.5) && (wipJS <= 3519.0) && (eTardJS > 19.75) && (wipJS > 1136.0))  { ruleCode = 0.99 ; }
    return ruleCode; }
public static double checkDT18Tree7Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 473.5) && (wipJS > 2236.5) && (eTardJS > 2116.25) && (eTardJS <= 96518.75) && (wipJS <= 2793.5))  { ruleCode = 0.078 ; }
    return ruleCode; }
public static double checkDT18Tree7Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 473.5) && (wipJS > 2236.5) && (eTardJS <= 2116.25) && (wipJS <= 3700.0) && (eTardJS <= 2109.25))  { ruleCode = 0.285 ; }
    return ruleCode; }
public static double checkDT18Tree7Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 473.5) && (wipJS <= 2236.5) && (wipJS <= 2235.5) && (eTardJS > 1314.75) && (eTardJS <= 6758.25))  { ruleCode = 0.18 ; }
    return ruleCode; }
public static double checkDT18Tree7Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 1549.0) && (wipJS <= 4289.5) && (wipJS <= 4273.5) && (wipJS <= 3594.5) && (wipJS <= 2030.5))  { ruleCode = 78.343 ; }
    return ruleCode; }
public static double checkDT18Tree7Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 473.5) && (wipJS > 2236.5) && (eTardJS <= 2116.25) && (wipJS > 3700.0) && (wipJS > 3709.0))  { ruleCode = 0.696 ; }
    return ruleCode; }
public static double checkDT18Tree7Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 473.5) && (wipJS > 2236.5) && (eTardJS > 2116.25) && (eTardJS > 96518.75) && (eTardJS <= 171096.5))  { ruleCode = 0.226 ; }
    return ruleCode; }
public static double checkDT18Tree7Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 1549.0) && (wipJS <= 4289.5) && (wipJS <= 4273.5) && (wipJS > 3594.5) && (wipJS > 3606.5))  { ruleCode = 81.749 ; }
    return ruleCode; }
public static double checkDT18Tree7Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 473.5) && (wipJS > 2236.5) && (eTardJS > 2116.25) && (eTardJS > 96518.75) && (eTardJS > 171096.5))  { ruleCode = 0.327 ; }
    return ruleCode; }
public static double checkDT18Tree7Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 473.5) && (wipJS <= 2236.5) && (wipJS <= 2235.5) && (eTardJS <= 1314.75) && (eTardJS <= 1168.75))  { ruleCode = 0.261 ; }
    return ruleCode; }
public static double checkDT18Tree7Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 1549.0) && (wipJS > 4289.5) && (wipJS <= 5328.0) && (wipJS <= 5242.0) && (wipJS <= 4776.5))  { ruleCode = 8.51 ; }
    return ruleCode; }
public static double checkDT18Tree7Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 473.5) && (wipJS <= 2236.5) && (wipJS <= 2235.5) && (eTardJS > 1314.75) && (eTardJS > 6758.25))  { ruleCode = 0.078 ; }
    return ruleCode; }
public static double checkDT18Tree7Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 473.5) && (eTardJS <= 456.5) && (wipJS > 3519.0) && (wipJS <= 4236.0) && (wipJS <= 4194.5))  { ruleCode = 2.654 ; }
    return ruleCode; }
public static double checkDT18Tree7Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 473.5) && (eTardJS <= 456.5) && (wipJS > 3519.0) && (wipJS > 4236.0) && (wipJS > 4926.0))  { ruleCode = 0.924 ; }
    return ruleCode; }
public static double checkDT18Tree7Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 473.5) && (eTardJS <= 456.5) && (wipJS > 3519.0) && (wipJS > 4236.0) && (wipJS <= 4926.0))  { ruleCode = 2.074 ; }
    return ruleCode; }
public static double checkDT18Tree7Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 1549.0) && (wipJS > 1273.5) && (wipJS > 1318.0) && (wipJS > 1342.0) && (wipJS > 1425.5))  { ruleCode = 11.182 ; }
    return ruleCode; }
public static double checkDT18Tree7Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 1549.0) && (wipJS > 4289.5) && (wipJS <= 5328.0) && (wipJS <= 5242.0) && (wipJS > 4776.5))  { ruleCode = 3.211 ; }
    return ruleCode; }
public static double checkDT18Tree7Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 473.5) && (eTardJS <= 456.5) && (wipJS <= 3519.0) && (eTardJS <= 19.75) && (eTardJS <= 14.75))  { ruleCode = 1.751 ; }
    return ruleCode; }
public static double checkDT18Tree7Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 1549.0) && (wipJS > 1273.5) && (wipJS > 1318.0) && (wipJS > 1342.0) && (wipJS <= 1425.5))  { ruleCode = 2.566 ; }
    return ruleCode; }
public static double checkDT18Tree7Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 1549.0) && (wipJS > 4289.5) && (wipJS > 5328.0) && (wipJS <= 5643.0) && (wipJS > 5355.0))  { ruleCode = 2.141 ; }
    return ruleCode; }
public static double checkDT18Tree7Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 1549.0) && (wipJS > 4289.5) && (wipJS > 5328.0) && (wipJS > 5643.0) && (wipJS > 5982.0))  { ruleCode = 0.567 ; }
    return ruleCode; }
public static double checkDT18Tree7Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 1549.0) && (wipJS > 4289.5) && (wipJS <= 5328.0) && (wipJS > 5242.0) && (wipJS > 5250.5))  { ruleCode = 9.039 ; }
    return ruleCode; }
public static double checkDT18Tree7Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 1549.0) && (wipJS > 4289.5) && (wipJS > 5328.0) && (wipJS > 5643.0) && (wipJS <= 5982.0))  { ruleCode = 9.213 ; }
    return ruleCode; }
public static double checkDT18Tree7Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 473.5) && (wipJS <= 2236.5) && (wipJS <= 2235.5) && (eTardJS <= 1314.75) && (eTardJS > 1168.75))  { ruleCode = 2.817 ; }
    return ruleCode; }
public static double checkDT18Tree7Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 473.5) && (eTardJS <= 456.5) && (wipJS <= 3519.0) && (eTardJS <= 19.75) && (eTardJS > 14.75))  { ruleCode = 7.584 ; }
    return ruleCode; }
public static double checkDT18Tree7Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 1549.0) && (wipJS <= 1273.5) && (wipJS <= 1258.0) && (wipJS > 1183.5) && (wipJS > 1207.5))  { ruleCode = 0.137 ; }
    return ruleCode; }
public static double checkDT18Tree7Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 473.5) && (eTardJS <= 456.5) && (wipJS <= 3519.0) && (eTardJS > 19.75) && (wipJS <= 1136.0))  { ruleCode = 6.614 ; }
    return ruleCode; }
public static double checkDT18Tree7Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 1549.0) && (wipJS > 1273.5) && (wipJS <= 1318.0) && (wipJS <= 1291.5) && (wipJS > 1278.0))  { ruleCode = 0.888 ; }
    return ruleCode; }
public static double checkDT18Tree7Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 1549.0) && (wipJS > 1273.5) && (wipJS > 1318.0) && (wipJS <= 1342.0) && (wipJS <= 1337.5))  { ruleCode = 5.822 ; }
    return ruleCode; }
public static double checkDT18Tree7Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 1549.0) && (wipJS > 1273.5) && (wipJS <= 1318.0) && (wipJS > 1291.5) && (wipJS > 1308.5))  { ruleCode = 0.264 ; }
    return ruleCode; }
public static double checkDT18Tree7Path33(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 1549.0) && (wipJS > 4289.5) && (wipJS > 5328.0) && (wipJS <= 5643.0) && (wipJS <= 5355.0))  { ruleCode = 0.297 ; }
    return ruleCode; }
public static double checkDT18Tree7Path34(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 1549.0) && (wipJS > 1273.5) && (wipJS > 1318.0) && (wipJS <= 1342.0) && (wipJS > 1337.5))  { ruleCode = 37.308 ; }
    return ruleCode; }
public static double checkDT18Tree7Path35(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 473.5) && (wipJS > 2236.5) && (eTardJS <= 2116.25) && (wipJS <= 3700.0) && (eTardJS > 2109.25))  { ruleCode = 1.542 ; }
    return ruleCode; }
public static double checkDT18Tree7Path36(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 1549.0) && (wipJS > 1273.5) && (wipJS <= 1318.0) && (wipJS > 1291.5) && (wipJS <= 1308.5))  { ruleCode = 0.262 ; }
    return ruleCode; }
public static double checkDT18Tree7Path37(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 1549.0) && (wipJS <= 1273.5) && (wipJS > 1258.0) && (wipJS <= 1267.0))  { ruleCode = 97.0 ; }
    return ruleCode; }
public static double checkDT18Tree7Path38(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 1549.0) && (wipJS > 1273.5) && (wipJS <= 1318.0) && (wipJS <= 1291.5) && (wipJS <= 1278.0))  { ruleCode = 0.311 ; }
    return ruleCode; }
public static double checkDT18Tree7Path39(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 1549.0) && (wipJS <= 1273.5) && (wipJS > 1258.0) && (wipJS > 1267.0))  { ruleCode = 58.2 ; }
    return ruleCode; }
public static double checkDT18Tree7Path40(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 1549.0) && (wipJS <= 1273.5) && (wipJS <= 1258.0) && (wipJS <= 1183.5) && (wipJS > 1167.0))  { ruleCode = 92.0 ; }
    return ruleCode; }
public static double checkDT18Tree7Path41(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 1549.0) && (wipJS <= 1273.5) && (wipJS <= 1258.0) && (wipJS > 1183.5) && (wipJS <= 1207.5))  { ruleCode = 0.063 ; }
    return ruleCode; }
public static double checkDT18Tree7Path42(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 473.5) && (eTardJS > 456.5) && (eTardJS <= 460.75))  { ruleCode = 25.703 ; }
    return ruleCode; }
public static double checkDT18Tree7Path43(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 1549.0) && (wipJS <= 4289.5) && (wipJS <= 4273.5) && (wipJS > 3594.5) && (wipJS <= 3606.5))  { ruleCode = 1213.0 ; }
    return ruleCode; }
public static double checkDT18Tree7Path44(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 473.5) && (eTardJS > 456.5) && (eTardJS > 460.75) && (eTardJS > 467.75) && (wipJS > 3142.5))  { ruleCode = 3.388 ; }
    return ruleCode; }
public static double checkDT18Tree7Path45(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 473.5) && (wipJS > 2236.5) && (eTardJS <= 2116.25) && (wipJS > 3700.0) && (wipJS <= 3709.0))  { ruleCode = 6.386 ; }
    return ruleCode; }
public static double checkDT18Tree7Path46(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 473.5) && (eTardJS <= 456.5) && (wipJS > 3519.0) && (wipJS <= 4236.0) && (wipJS > 4194.5))  { ruleCode = 19.2 ; }
    return ruleCode; }
public static double checkDT18Tree7Path47(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 473.5) && (wipJS <= 2236.5) && (wipJS > 2235.5) && (eTardJS > 1649.75))  { ruleCode = -197.24 ; }
    return ruleCode; }
public static double checkDT18Tree7Path48(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 1549.0) && (wipJS <= 4289.5) && (wipJS > 4273.5))  { ruleCode = 915.0 ; }
    return ruleCode; }
public static double checkDT18Tree7Path49(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 473.5) && (eTardJS > 456.5) && (eTardJS > 460.75) && (eTardJS > 467.75) && (wipJS <= 3142.5))  { ruleCode = 1.888 ; }
    return ruleCode; }
public static double checkDT18Tree7Path50(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 473.5) && (eTardJS > 456.5) && (eTardJS > 460.75) && (eTardJS <= 467.75) && (eTardJS > 464.0))  { ruleCode = 0.562 ; }
    return ruleCode; }
public static double checkDT18Tree7Path51(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 473.5) && (wipJS <= 2236.5) && (wipJS > 2235.5) && (eTardJS <= 1649.75) && (eTardJS > 1079.5))  { ruleCode = 0.117 ; }
    return ruleCode; }
public static double checkDT18Tree7Path52(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 473.5) && (wipJS <= 2236.5) && (wipJS > 2235.5) && (eTardJS <= 1649.75) && (eTardJS <= 1079.5))  { ruleCode = 0.16 ; }
    return ruleCode; }
public static double checkDT18Tree7Path53(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 473.5) && (eTardJS > 456.5) && (eTardJS > 460.75) && (eTardJS <= 467.75) && (eTardJS <= 464.0))  { ruleCode = 0.203 ; }
    return ruleCode; }
public static double checkDT18Tree7Path54(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 1549.0) && (wipJS > 4289.5) && (wipJS <= 5328.0) && (wipJS > 5242.0) && (wipJS <= 5250.5))  { ruleCode = 80.0 ; }
    return ruleCode; }
public static double checkDT18Tree8Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS > 143.0) && (eTardJS > 189.5) && (eTardJS > 1213.5) && (eTardJS > 1819.5) && (eTardJS > 3136.0))  { ruleCode = 0.147 ; }
    return ruleCode; }
public static double checkDT18Tree8Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS <= 3268.5) && (wipJS <= 2059.0) && (wipJS <= 2019.5) && (wipJS <= 1572.5) && (wipJS <= 1407.0))  { ruleCode = 30.721 ; }
    return ruleCode; }
public static double checkDT18Tree8Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS > 143.0) && (eTardJS > 189.5) && (eTardJS <= 1213.5) && (wipJS > 1178.0) && (eTardJS <= 1208.25))  { ruleCode = 0.833 ; }
    return ruleCode; }
public static double checkDT18Tree8Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS > 143.0) && (eTardJS > 189.5) && (eTardJS > 1213.5) && (eTardJS > 1819.5) && (eTardJS <= 3136.0))  { ruleCode = 0.482 ; }
    return ruleCode; }
public static double checkDT18Tree8Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS > 3268.5) && (wipJS > 3287.5) && (wipJS <= 4546.5) && (wipJS <= 4544.0) && (wipJS <= 4289.5))  { ruleCode = 105.919 ; }
    return ruleCode; }
public static double checkDT18Tree8Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS <= 3268.5) && (wipJS <= 2059.0) && (wipJS <= 2019.5) && (wipJS > 1572.5) && (wipJS > 1575.0))  { ruleCode = 46.626 ; }
    return ruleCode; }
public static double checkDT18Tree8Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS > 143.0) && (eTardJS > 189.5) && (eTardJS > 1213.5) && (eTardJS <= 1819.5) && (eTardJS <= 1810.0))  { ruleCode = 0.262 ; }
    return ruleCode; }
public static double checkDT18Tree8Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS <= 143.0) && (eTardJS > 22.5) && (eTardJS <= 139.25) && (wipJS <= 3510.5) && (eTardJS <= 135.25))  { ruleCode = 0.795 ; }
    return ruleCode; }
public static double checkDT18Tree8Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS <= 3268.5) && (wipJS > 2059.0) && (wipJS <= 2679.0) && (wipJS > 2237.5) && (wipJS <= 2521.0))  { ruleCode = 7.856 ; }
    return ruleCode; }
public static double checkDT18Tree8Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS <= 3268.5) && (wipJS > 2059.0) && (wipJS > 2679.0) && (wipJS > 2696.0) && (wipJS > 2857.5))  { ruleCode = 10.184 ; }
    return ruleCode; }
public static double checkDT18Tree8Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS > 3268.5) && (wipJS > 3287.5) && (wipJS > 4546.5) && (wipJS <= 5292.5) && (wipJS <= 5279.0))  { ruleCode = 7.277 ; }
    return ruleCode; }
public static double checkDT18Tree8Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS <= 3268.5) && (wipJS > 2059.0) && (wipJS <= 2679.0) && (wipJS <= 2237.5) && (wipJS <= 2233.5))  { ruleCode = 19.796 ; }
    return ruleCode; }
public static double checkDT18Tree8Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS <= 3268.5) && (wipJS <= 2059.0) && (wipJS <= 2019.5) && (wipJS <= 1572.5) && (wipJS > 1407.0))  { ruleCode = 14.728 ; }
    return ruleCode; }
public static double checkDT18Tree8Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS > 3268.5) && (wipJS > 3287.5) && (wipJS <= 4546.5) && (wipJS <= 4544.0) && (wipJS > 4289.5))  { ruleCode = 19.664 ; }
    return ruleCode; }
public static double checkDT18Tree8Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS <= 143.0) && (eTardJS > 22.5) && (eTardJS <= 139.25) && (wipJS > 3510.5) && (eTardJS <= 83.5))  { ruleCode = 1.683 ; }
    return ruleCode; }
public static double checkDT18Tree8Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS <= 3268.5) && (wipJS > 2059.0) && (wipJS > 2679.0) && (wipJS > 2696.0) && (wipJS <= 2857.5))  { ruleCode = 48.292 ; }
    return ruleCode; }
public static double checkDT18Tree8Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS <= 3268.5) && (wipJS > 2059.0) && (wipJS <= 2679.0) && (wipJS > 2237.5) && (wipJS > 2521.0))  { ruleCode = 2.46 ; }
    return ruleCode; }
public static double checkDT18Tree8Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS > 3268.5) && (wipJS > 3287.5) && (wipJS > 4546.5) && (wipJS > 5292.5) && (wipJS > 5339.5))  { ruleCode = 1.618 ; }
    return ruleCode; }
public static double checkDT18Tree8Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS > 143.0) && (eTardJS <= 189.5) && (eTardJS <= 182.5) && (eTardJS <= 167.25) && (wipJS <= 4040.5))  { ruleCode = 0.401 ; }
    return ruleCode; }
public static double checkDT18Tree8Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS <= 143.0) && (eTardJS <= 22.5) && (eTardJS <= 14.75) && (eTardJS <= 9.25) && (wipJS > 2422.5))  { ruleCode = 4.778 ; }
    return ruleCode; }
public static double checkDT18Tree8Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS <= 143.0) && (eTardJS > 22.5) && (eTardJS <= 139.25) && (wipJS > 3510.5) && (eTardJS > 83.5))  { ruleCode = 4.057 ; }
    return ruleCode; }
public static double checkDT18Tree8Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS <= 143.0) && (eTardJS <= 22.5) && (eTardJS <= 14.75) && (eTardJS > 9.25) && (wipJS > 2040.5))  { ruleCode = 0.463 ; }
    return ruleCode; }
public static double checkDT18Tree8Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS > 143.0) && (eTardJS <= 189.5) && (eTardJS <= 182.5) && (eTardJS > 167.25) && (wipJS <= 2739.0))  { ruleCode = 1.572 ; }
    return ruleCode; }
public static double checkDT18Tree8Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS <= 143.0) && (eTardJS <= 22.5) && (eTardJS <= 14.75) && (eTardJS <= 9.25) && (wipJS <= 2422.5))  { ruleCode = 0.874 ; }
    return ruleCode; }
public static double checkDT18Tree8Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS > 143.0) && (eTardJS <= 189.5) && (eTardJS > 182.5) && (wipJS <= 3509.0) && (eTardJS <= 188.5))  { ruleCode = 0.503 ; }
    return ruleCode; }
public static double checkDT18Tree8Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS > 143.0) && (eTardJS <= 189.5) && (eTardJS <= 182.5) && (eTardJS > 167.25) && (wipJS > 2739.0))  { ruleCode = 0.396 ; }
    return ruleCode; }
public static double checkDT18Tree8Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS <= 143.0) && (eTardJS <= 22.5) && (eTardJS > 14.75) && (wipJS <= 2372.0) && (wipJS > 1901.0))  { ruleCode = 12.69 ; }
    return ruleCode; }
public static double checkDT18Tree8Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS <= 3268.5) && (wipJS <= 2059.0) && (wipJS > 2019.5) && (wipJS > 2023.5) && (wipJS > 2039.5))  { ruleCode = 83.286 ; }
    return ruleCode; }
public static double checkDT18Tree8Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS > 3268.5) && (wipJS > 3287.5) && (wipJS > 4546.5) && (wipJS > 5292.5) && (wipJS <= 5339.5))  { ruleCode = 5.594 ; }
    return ruleCode; }
public static double checkDT18Tree8Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS <= 143.0) && (eTardJS <= 22.5) && (eTardJS > 14.75) && (wipJS > 2372.0) && (wipJS <= 3454.0))  { ruleCode = 1.029 ; }
    return ruleCode; }
public static double checkDT18Tree8Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS <= 143.0) && (eTardJS > 22.5) && (eTardJS <= 139.25) && (wipJS <= 3510.5) && (eTardJS > 135.25))  { ruleCode = -2.898 ; }
    return ruleCode; }
public static double checkDT18Tree8Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS <= 143.0) && (eTardJS <= 22.5) && (eTardJS > 14.75) && (wipJS <= 2372.0) && (wipJS <= 1901.0))  { ruleCode = 0.075 ; }
    return ruleCode; }
public static double checkDT18Tree8Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS <= 3268.5) && (wipJS <= 2059.0) && (wipJS > 2019.5) && (wipJS > 2023.5) && (wipJS <= 2039.5))  { ruleCode = 215.393 ; }
    return ruleCode; }
public static double checkDT18Tree8Path33(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS <= 143.0) && (eTardJS <= 22.5) && (eTardJS <= 14.75) && (eTardJS > 9.25) && (wipJS <= 2040.5))  { ruleCode = 2.101 ; }
    return ruleCode; }
public static double checkDT18Tree8Path34(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS <= 143.0) && (eTardJS <= 22.5) && (eTardJS > 14.75) && (wipJS > 2372.0) && (wipJS > 3454.0))  { ruleCode = 4.111 ; }
    return ruleCode; }
public static double checkDT18Tree8Path35(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS > 143.0) && (eTardJS > 189.5) && (eTardJS <= 1213.5) && (wipJS > 1178.0) && (eTardJS > 1208.25))  { ruleCode = 11.443 ; }
    return ruleCode; }
public static double checkDT18Tree8Path36(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS > 143.0) && (eTardJS <= 189.5) && (eTardJS <= 182.5) && (eTardJS <= 167.25) && (wipJS > 4040.5))  { ruleCode = 1.439 ; }
    return ruleCode; }
public static double checkDT18Tree8Path37(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS > 3268.5) && (wipJS > 3287.5) && (wipJS <= 4546.5) && (wipJS > 4544.0))  { ruleCode = 640.0 ; }
    return ruleCode; }
public static double checkDT18Tree8Path38(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS <= 3268.5) && (wipJS > 2059.0) && (wipJS <= 2679.0) && (wipJS <= 2237.5) && (wipJS > 2233.5))  { ruleCode = 321.75 ; }
    return ruleCode; }
public static double checkDT18Tree8Path39(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS <= 3268.5) && (wipJS <= 2059.0) && (wipJS <= 2019.5) && (wipJS > 1572.5) && (wipJS <= 1575.0))  { ruleCode = 1079.0 ; }
    return ruleCode; }
public static double checkDT18Tree8Path40(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS > 143.0) && (eTardJS > 189.5) && (eTardJS <= 1213.5) && (wipJS <= 1178.0))  { ruleCode = 12.5 ; }
    return ruleCode; }
public static double checkDT18Tree8Path41(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS <= 3268.5) && (wipJS <= 2059.0) && (wipJS > 2019.5) && (wipJS <= 2023.5))  { ruleCode = 810.0 ; }
    return ruleCode; }
public static double checkDT18Tree8Path42(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS > 143.0) && (eTardJS <= 189.5) && (eTardJS > 182.5) && (wipJS > 3509.0))  { ruleCode = -128.0 ; }
    return ruleCode; }
public static double checkDT18Tree8Path43(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS > 143.0) && (eTardJS <= 189.5) && (eTardJS > 182.5) && (wipJS <= 3509.0) && (eTardJS > 188.5))  { ruleCode = -38.462 ; }
    return ruleCode; }
public static double checkDT18Tree8Path44(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS <= 143.0) && (eTardJS > 22.5) && (eTardJS > 139.25) && (wipJS > 2971.0) && (eTardJS > 141.0))  { ruleCode = 0.122 ; }
    return ruleCode; }
public static double checkDT18Tree8Path45(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS > 3268.5) && (wipJS > 3287.5) && (wipJS > 4546.5) && (wipJS <= 5292.5) && (wipJS > 5279.0))  { ruleCode = 77.167 ; }
    return ruleCode; }
public static double checkDT18Tree8Path46(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS <= 143.0) && (eTardJS > 22.5) && (eTardJS > 139.25) && (wipJS > 2971.0) && (eTardJS <= 141.0))  { ruleCode = 3.108 ; }
    return ruleCode; }
public static double checkDT18Tree8Path47(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS <= 3268.5) && (wipJS > 2059.0) && (wipJS > 2679.0) && (wipJS <= 2696.0) && (wipJS <= 2690.0))  { ruleCode = 33.114 ; }
    return ruleCode; }
public static double checkDT18Tree8Path48(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS <= 3268.5) && (wipJS > 2059.0) && (wipJS > 2679.0) && (wipJS <= 2696.0) && (wipJS > 2690.0))  { ruleCode = 247.0 ; }
    return ruleCode; }
public static double checkDT18Tree8Path49(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS <= 143.0) && (eTardJS > 22.5) && (eTardJS > 139.25) && (wipJS <= 2971.0) && (wipJS > 2448.5))  { ruleCode = 6.94 ; }
    return ruleCode; }
public static double checkDT18Tree8Path50(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS <= 143.0) && (eTardJS > 22.5) && (eTardJS > 139.25) && (wipJS <= 2971.0) && (wipJS <= 2448.5))  { ruleCode = 4.616 ; }
    return ruleCode; }
public static double checkDT18Tree8Path51(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS > 3268.5) && (wipJS <= 3287.5) && (wipJS <= 3280.5))  { ruleCode = 475.0 ; }
    return ruleCode; }
public static double checkDT18Tree8Path52(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS > 3268.5) && (wipJS <= 3287.5) && (wipJS > 3280.5))  { ruleCode = 870.0 ; }
    return ruleCode; }
public static double checkDT18Tree8Path53(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS > 143.0) && (eTardJS > 189.5) && (eTardJS > 1213.5) && (eTardJS <= 1819.5) && (eTardJS > 1810.0))  { ruleCode = -197.24 ; }
    return ruleCode; }
public static double checkDT18Tree9Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS > 1213.5) && (eTardJS > 1818.75) && (eTardJS > 3143.75) && (eTardJS > 3344.5) && (eTardJS <= 95011.25))  { ruleCode = 0.148 ; }
    return ruleCode; }
public static double checkDT18Tree9Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS <= 3268.5) && (wipJS <= 1400.5) && (wipJS <= 335.0))  { ruleCode = 26.573 ; }
    return ruleCode; }
public static double checkDT18Tree9Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS <= 1213.5) && (eTardJS <= 1200.5) && (eTardJS > 33.5) && (wipJS <= 3698.5) && (eTardJS > 173.75))  { ruleCode = 0.511 ; }
    return ruleCode; }
public static double checkDT18Tree9Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS <= 3268.5) && (wipJS > 1400.5) && (wipJS > 1404.5) && (wipJS > 2059.0) && (wipJS <= 2925.0))  { ruleCode = 25.534 ; }
    return ruleCode; }
public static double checkDT18Tree9Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS > 1213.5) && (eTardJS > 1818.75) && (eTardJS > 3143.75) && (eTardJS > 3344.5) && (eTardJS > 95011.25))  { ruleCode = 0.287 ; }
    return ruleCode; }
public static double checkDT18Tree9Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS > 1213.5) && (eTardJS > 1818.75) && (eTardJS <= 3143.75) && (eTardJS <= 3092.0) && (wipJS <= 4344.5))  { ruleCode = 0.172 ; }
    return ruleCode; }
public static double checkDT18Tree9Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS <= 3268.5) && (wipJS > 1400.5) && (wipJS > 1404.5) && (wipJS <= 2059.0) && (wipJS <= 2018.0))  { ruleCode = 35.763 ; }
    return ruleCode; }
public static double checkDT18Tree9Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS <= 1213.5) && (eTardJS <= 1200.5) && (eTardJS > 33.5) && (wipJS > 3698.5) && (wipJS > 3776.0))  { ruleCode = 1.285 ; }
    return ruleCode; }
public static double checkDT18Tree9Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS <= 1213.5) && (eTardJS <= 1200.5) && (eTardJS > 33.5) && (wipJS <= 3698.5) && (eTardJS <= 173.75))  { ruleCode = 1.465 ; }
    return ruleCode; }
public static double checkDT18Tree9Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS > 1213.5) && (eTardJS <= 1818.75) && (eTardJS <= 1810.5) && (eTardJS <= 1807.5) && (wipJS > 2224.0))  { ruleCode = 0.228 ; }
    return ruleCode; }
public static double checkDT18Tree9Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS <= 1213.5) && (eTardJS <= 1200.5) && (eTardJS <= 33.5) && (eTardJS <= 32.25) && (wipJS <= 5335.0))  { ruleCode = 2.226 ; }
    return ruleCode; }
public static double checkDT18Tree9Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS > 3268.5) && (wipJS <= 4006.5) && (wipJS > 3287.5) && (wipJS > 3463.5) && (wipJS > 3480.0))  { ruleCode = 140.496 ; }
    return ruleCode; }
public static double checkDT18Tree9Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS > 3268.5) && (wipJS > 4006.5) && (wipJS > 4296.5) && (wipJS > 4623.0) && (wipJS <= 5914.0))  { ruleCode = 6.315 ; }
    return ruleCode; }
public static double checkDT18Tree9Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS <= 3268.5) && (wipJS > 1400.5) && (wipJS > 1404.5) && (wipJS > 2059.0) && (wipJS > 2925.0))  { ruleCode = 9.277 ; }
    return ruleCode; }
public static double checkDT18Tree9Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS > 3268.5) && (wipJS > 4006.5) && (wipJS > 4296.5) && (wipJS <= 4623.0) && (wipJS <= 4615.0))  { ruleCode = 9.873 ; }
    return ruleCode; }
public static double checkDT18Tree9Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS > 1213.5) && (eTardJS > 1818.75) && (eTardJS <= 3143.75) && (eTardJS <= 3092.0) && (wipJS > 4344.5))  { ruleCode = 0.531 ; }
    return ruleCode; }
public static double checkDT18Tree9Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS > 3268.5) && (wipJS <= 4006.5) && (wipJS > 3287.5) && (wipJS <= 3463.5) && (wipJS > 3293.0))  { ruleCode = 12.915 ; }
    return ruleCode; }
public static double checkDT18Tree9Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS > 1213.5) && (eTardJS <= 1818.75) && (eTardJS <= 1810.5) && (eTardJS <= 1807.5) && (wipJS <= 2224.0))  { ruleCode = 0.144 ; }
    return ruleCode; }
public static double checkDT18Tree9Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS > 1213.5) && (eTardJS > 1818.75) && (eTardJS > 3143.75) && (eTardJS <= 3344.5) && (eTardJS <= 3336.25))  { ruleCode = 0.216 ; }
    return ruleCode; }
public static double checkDT18Tree9Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS <= 3268.5) && (wipJS <= 1400.5) && (wipJS > 335.0) && (wipJS <= 1291.5) && (wipJS <= 1273.5))  { ruleCode = 8.767 ; }
    return ruleCode; }
public static double checkDT18Tree9Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS <= 3268.5) && (wipJS <= 1400.5) && (wipJS > 335.0) && (wipJS > 1291.5) && (wipJS > 1308.5))  { ruleCode = 12.665 ; }
    return ruleCode; }
public static double checkDT18Tree9Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS > 3268.5) && (wipJS > 4006.5) && (wipJS <= 4296.5) && (wipJS <= 4283.5) && (wipJS <= 4133.0))  { ruleCode = 32.388 ; }
    return ruleCode; }
public static double checkDT18Tree9Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS > 3268.5) && (wipJS > 4006.5) && (wipJS <= 4296.5) && (wipJS <= 4283.5) && (wipJS > 4133.0))  { ruleCode = 14.896 ; }
    return ruleCode; }
public static double checkDT18Tree9Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS > 3268.5) && (wipJS > 4006.5) && (wipJS > 4296.5) && (wipJS > 4623.0) && (wipJS > 5914.0))  { ruleCode = 0.645 ; }
    return ruleCode; }
public static double checkDT18Tree9Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS <= 3268.5) && (wipJS > 1400.5) && (wipJS > 1404.5) && (wipJS <= 2059.0) && (wipJS > 2018.0))  { ruleCode = 318.065 ; }
    return ruleCode; }
public static double checkDT18Tree9Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS <= 1213.5) && (eTardJS <= 1200.5) && (eTardJS > 33.5) && (wipJS > 3698.5) && (wipJS <= 3776.0))  { ruleCode = 3.911 ; }
    return ruleCode; }
public static double checkDT18Tree9Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS > 1213.5) && (eTardJS > 1818.75) && (eTardJS <= 3143.75) && (eTardJS > 3092.0) && (eTardJS > 3106.0))  { ruleCode = 0.533 ; }
    return ruleCode; }
public static double checkDT18Tree9Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS <= 3268.5) && (wipJS <= 1400.5) && (wipJS > 335.0) && (wipJS <= 1291.5) && (wipJS > 1273.5))  { ruleCode = 1.168 ; }
    return ruleCode; }
public static double checkDT18Tree9Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS <= 3268.5) && (wipJS <= 1400.5) && (wipJS > 335.0) && (wipJS > 1291.5) && (wipJS <= 1308.5))  { ruleCode = 86.381 ; }
    return ruleCode; }
public static double checkDT18Tree9Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS > 3268.5) && (wipJS <= 4006.5) && (wipJS > 3287.5) && (wipJS <= 3463.5) && (wipJS <= 3293.0))  { ruleCode = 74.59 ; }
    return ruleCode; }
public static double checkDT18Tree9Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS > 3268.5) && (wipJS > 4006.5) && (wipJS > 4296.5) && (wipJS <= 4623.0) && (wipJS > 4615.0))  { ruleCode = 169.778 ; }
    return ruleCode; }
public static double checkDT18Tree9Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS > 1213.5) && (eTardJS > 1818.75) && (eTardJS > 3143.75) && (eTardJS <= 3344.5) && (eTardJS > 3336.25))  { ruleCode = -7.216 ; }
    return ruleCode; }
public static double checkDT18Tree9Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS > 1213.5) && (eTardJS <= 1818.75) && (eTardJS > 1810.5))  { ruleCode = -197.24 ; }
    return ruleCode; }
public static double checkDT18Tree9Path33(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS > 1213.5) && (eTardJS <= 1818.75) && (eTardJS <= 1810.5) && (eTardJS > 1807.5))  { ruleCode = 0.796 ; }
    return ruleCode; }
public static double checkDT18Tree9Path34(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS <= 3268.5) && (wipJS > 1400.5) && (wipJS <= 1404.5))  { ruleCode = 462.0 ; }
    return ruleCode; }
public static double checkDT18Tree9Path35(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS <= 1213.5) && (eTardJS > 1200.5) && (wipJS > 2886.0) && (wipJS > 4347.5))  { ruleCode = 0.182 ; }
    return ruleCode; }
public static double checkDT18Tree9Path36(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS > 3268.5) && (wipJS <= 4006.5) && (wipJS <= 3287.5) && (wipJS <= 3280.5))  { ruleCode = 475.0 ; }
    return ruleCode; }
public static double checkDT18Tree9Path37(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS <= 1213.5) && (eTardJS > 1200.5) && (wipJS > 2886.0) && (wipJS <= 4347.5))  { ruleCode = 6.386 ; }
    return ruleCode; }
public static double checkDT18Tree9Path38(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS <= 1213.5) && (eTardJS <= 1200.5) && (eTardJS <= 33.5) && (eTardJS <= 32.25) && (wipJS > 5335.0))  { ruleCode = 11.29 ; }
    return ruleCode; }
public static double checkDT18Tree9Path39(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS > 3268.5) && (wipJS <= 4006.5) && (wipJS <= 3287.5) && (wipJS > 3280.5))  { ruleCode = 870.0 ; }
    return ruleCode; }
public static double checkDT18Tree9Path40(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS <= 1213.5) && (eTardJS > 1200.5) && (wipJS <= 2886.0))  { ruleCode = 16.5 ; }
    return ruleCode; }
public static double checkDT18Tree9Path41(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS > 3268.5) && (wipJS <= 4006.5) && (wipJS > 3287.5) && (wipJS > 3463.5) && (wipJS <= 3480.0))  { ruleCode = 1071.0 ; }
    return ruleCode; }
public static double checkDT18Tree9Path42(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS <= 1213.5) && (eTardJS <= 1200.5) && (eTardJS <= 33.5) && (eTardJS > 32.25))  { ruleCode = 10.104 ; }
    return ruleCode; }
public static double checkDT18Tree9Path43(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS > 3268.5) && (wipJS > 4006.5) && (wipJS <= 4296.5) && (wipJS > 4283.5))  { ruleCode = 915.0 ; }
    return ruleCode; }
public static double checkDT18Tree9Path44(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS > 1213.5) && (eTardJS > 1818.75) && (eTardJS <= 3143.75) && (eTardJS > 3092.0) && (eTardJS <= 3106.0))  { ruleCode = 17.445 ; }
    return ruleCode; }
public static double checkDT214Tree0Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS > 1.0) && (eTardJS <= 5309.75) && (eTardJS <= 2783.0) && (wipJS > 1148.5) && (wipJS <= 4070.0))  { ruleCode = 0.149 ; }
    return ruleCode; }
public static double checkDT214Tree0Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS > 1.0) && (eTardJS > 5309.75) && (eTardJS > 21531.25) && (eTardJS <= 175253.25) && (eTardJS <= 89000.5))  { ruleCode = 0.421 ; }
    return ruleCode; }
public static double checkDT214Tree0Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 335.0))  { ruleCode = 3.071 ; }
    return ruleCode; }
public static double checkDT214Tree0Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS <= 1.0) && (wipJS <= 3538.5) && (wipJS <= 3534.5) && (wipJS > 1883.5) && (wipJS > 1888.5))  { ruleCode = 1.786 ; }
    return ruleCode; }
public static double checkDT214Tree0Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS > 1.0) && (eTardJS <= 5309.75) && (eTardJS <= 2783.0) && (wipJS > 1148.5) && (wipJS > 4070.0))  { ruleCode = 0.086 ; }
    return ruleCode; }
public static double checkDT214Tree0Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS > 1.0) && (eTardJS > 5309.75) && (eTardJS <= 21531.25) && (eTardJS <= 12964.0) && (wipJS <= 3446.0))  { ruleCode = 0.343 ; }
    return ruleCode; }
public static double checkDT214Tree0Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS > 1.0) && (eTardJS > 5309.75) && (eTardJS <= 21531.25) && (eTardJS <= 12964.0) && (wipJS > 3446.0))  { ruleCode = 0.276 ; }
    return ruleCode; }
public static double checkDT214Tree0Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS > 1.0) && (eTardJS <= 5309.75) && (eTardJS > 2783.0) && (wipJS <= 4806.0) && (wipJS > 2371.5))  { ruleCode = 0.245 ; }
    return ruleCode; }
public static double checkDT214Tree0Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS > 1.0) && (eTardJS > 5309.75) && (eTardJS <= 21531.25) && (eTardJS > 12964.0) && (wipJS > 3536.0))  { ruleCode = 0.347 ; }
    return ruleCode; }
public static double checkDT214Tree0Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS > 1.0) && (eTardJS > 5309.75) && (eTardJS > 21531.25) && (eTardJS <= 175253.25) && (eTardJS > 89000.5))  { ruleCode = 0.482 ; }
    return ruleCode; }
public static double checkDT214Tree0Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS <= 1.0) && (wipJS <= 3538.5) && (wipJS <= 3534.5) && (wipJS <= 1883.5) && (wipJS > 1308.5))  { ruleCode = 0.225 ; }
    return ruleCode; }
public static double checkDT214Tree0Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS > 1.0) && (eTardJS > 5309.75) && (eTardJS <= 21531.25) && (eTardJS > 12964.0) && (wipJS <= 3536.0))  { ruleCode = 0.389 ; }
    return ruleCode; }
public static double checkDT214Tree0Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS <= 1.0) && (wipJS > 3538.5) && (wipJS <= 4235.0) && (wipJS <= 4213.5) && (wipJS > 3559.5))  { ruleCode = 0.114 ; }
    return ruleCode; }
public static double checkDT214Tree0Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS <= 1.0) && (wipJS > 3538.5) && (wipJS > 4235.0) && (wipJS > 4546.5) && (wipJS <= 7558.5))  { ruleCode = 0.025 ; }
    return ruleCode; }
public static double checkDT214Tree0Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS > 1.0) && (eTardJS <= 5309.75) && (eTardJS > 2783.0) && (wipJS <= 4806.0) && (wipJS <= 2371.5))  { ruleCode = 0.296 ; }
    return ruleCode; }
public static double checkDT214Tree0Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS <= 1.0) && (wipJS > 3538.5) && (wipJS > 4235.0) && (wipJS <= 4546.5) && (wipJS <= 4544.0))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT214Tree0Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS > 1.0) && (eTardJS > 5309.75) && (eTardJS > 21531.25) && (eTardJS > 175253.25) && (wipJS <= 7480.0))  { ruleCode = 0.696 ; }
    return ruleCode; }
public static double checkDT214Tree0Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS > 1.0) && (eTardJS > 5309.75) && (eTardJS > 21531.25) && (eTardJS > 175253.25) && (wipJS > 7480.0))  { ruleCode = 0.531 ; }
    return ruleCode; }
public static double checkDT214Tree0Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS > 1.0) && (eTardJS <= 5309.75) && (eTardJS > 2783.0) && (wipJS > 4806.0) && (wipJS > 5485.5))  { ruleCode = 0.199 ; }
    return ruleCode; }
public static double checkDT214Tree0Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS <= 1.0) && (wipJS <= 3538.5) && (wipJS <= 3534.5) && (wipJS <= 1883.5) && (wipJS <= 1308.5))  { ruleCode = 1.731 ; }
    return ruleCode; }
public static double checkDT214Tree0Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS > 1.0) && (eTardJS <= 5309.75) && (eTardJS > 2783.0) && (wipJS > 4806.0) && (wipJS <= 5485.5))  { ruleCode = 0.094 ; }
    return ruleCode; }
public static double checkDT214Tree0Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS <= 1.0) && (wipJS > 3538.5) && (wipJS <= 4235.0) && (wipJS <= 4213.5) && (wipJS <= 3559.5))  { ruleCode = 1.0 ; }
    return ruleCode; }
public static double checkDT214Tree0Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS > 1.0) && (eTardJS <= 5309.75) && (eTardJS <= 2783.0) && (wipJS <= 1148.5) && (eTardJS <= 276.5))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT214Tree0Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS <= 1.0) && (wipJS > 3538.5) && (wipJS > 4235.0) && (wipJS <= 4546.5) && (wipJS > 4544.0))  { ruleCode = 17.0 ; }
    return ruleCode; }
public static double checkDT214Tree0Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS <= 1.0) && (wipJS > 3538.5) && (wipJS > 4235.0) && (wipJS > 4546.5) && (wipJS > 7558.5))  { ruleCode = 0.205 ; }
    return ruleCode; }
public static double checkDT214Tree0Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS <= 1.0) && (wipJS > 3538.5) && (wipJS <= 4235.0) && (wipJS > 4213.5))  { ruleCode = 62.0 ; }
    return ruleCode; }
public static double checkDT214Tree0Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS <= 1.0) && (wipJS <= 3538.5) && (wipJS > 3534.5))  { ruleCode = 23.0 ; }
    return ruleCode; }
public static double checkDT214Tree0Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS <= 1.0) && (wipJS <= 3538.5) && (wipJS <= 3534.5) && (wipJS > 1883.5) && (wipJS <= 1888.5))  { ruleCode = 109.0 ; }
    return ruleCode; }
public static double checkDT214Tree0Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS > 1.0) && (eTardJS <= 5309.75) && (eTardJS <= 2783.0) && (wipJS <= 1148.5) && (eTardJS > 276.5))  { ruleCode = 4.625 ; }
    return ruleCode; }
public static double checkDT214Tree1Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS > 1.0) && (eTardJS > 4880.25) && (eTardJS > 26334.25) && (eTardJS <= 167167.25) && (wipJS > 2614.0))  { ruleCode = 0.432 ; }
    return ruleCode; }
public static double checkDT214Tree1Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1119.0) && (wipJS <= 1002.0) && (wipJS <= 750.5) && (wipJS <= 335.0))  { ruleCode = 2.488 ; }
    return ruleCode; }
public static double checkDT214Tree1Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS > 1.0) && (eTardJS > 4880.25) && (eTardJS <= 26334.25) && (eTardJS > 11694.75) && (wipJS > 2420.0))  { ruleCode = 0.364 ; }
    return ruleCode; }
public static double checkDT214Tree1Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS > 1.0) && (eTardJS <= 4880.25) && (eTardJS <= 537.25) && (wipJS > 1429.0) && (wipJS <= 4293.5))  { ruleCode = 0.094 ; }
    return ruleCode; }
public static double checkDT214Tree1Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS > 1.0) && (eTardJS <= 4880.25) && (eTardJS > 537.25) && (wipJS <= 4782.0) && (eTardJS <= 2281.0))  { ruleCode = 0.189 ; }
    return ruleCode; }
public static double checkDT214Tree1Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS > 1.0) && (eTardJS > 4880.25) && (eTardJS <= 26334.25) && (eTardJS <= 11694.75) && (wipJS <= 4300.5))  { ruleCode = 0.335 ; }
    return ruleCode; }
public static double checkDT214Tree1Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS <= 1.0) && (wipJS <= 3538.5) && (wipJS <= 3533.0) && (wipJS <= 3194.5) && (wipJS > 1883.5))  { ruleCode = 1.3 ; }
    return ruleCode; }
public static double checkDT214Tree1Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS > 1.0) && (eTardJS <= 4880.25) && (eTardJS > 537.25) && (wipJS <= 4782.0) && (eTardJS > 2281.0))  { ruleCode = 0.24 ; }
    return ruleCode; }
public static double checkDT214Tree1Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS <= 1.0) && (wipJS <= 3538.5) && (wipJS <= 3533.0) && (wipJS <= 3194.5) && (wipJS <= 1883.5))  { ruleCode = 0.218 ; }
    return ruleCode; }
public static double checkDT214Tree1Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS > 1.0) && (eTardJS > 4880.25) && (eTardJS <= 26334.25) && (eTardJS <= 11694.75) && (wipJS > 4300.5))  { ruleCode = 0.254 ; }
    return ruleCode; }
public static double checkDT214Tree1Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS <= 1.0) && (wipJS > 3538.5) && (wipJS > 3676.0) && (wipJS <= 5408.0) && (wipJS > 4141.0))  { ruleCode = 0.013 ; }
    return ruleCode; }
public static double checkDT214Tree1Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS > 1.0) && (eTardJS <= 4880.25) && (eTardJS > 537.25) && (wipJS > 4782.0) && (eTardJS <= 4011.0))  { ruleCode = 0.111 ; }
    return ruleCode; }
public static double checkDT214Tree1Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS > 1.0) && (eTardJS <= 4880.25) && (eTardJS <= 537.25) && (wipJS > 1429.0) && (wipJS > 4293.5))  { ruleCode = 0.048 ; }
    return ruleCode; }
public static double checkDT214Tree1Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS <= 1.0) && (wipJS > 3538.5) && (wipJS > 3676.0) && (wipJS <= 5408.0) && (wipJS <= 4141.0))  { ruleCode = 0.052 ; }
    return ruleCode; }
public static double checkDT214Tree1Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS > 1.0) && (eTardJS > 4880.25) && (eTardJS <= 26334.25) && (eTardJS > 11694.75) && (wipJS <= 2420.0))  { ruleCode = 0.445 ; }
    return ruleCode; }
public static double checkDT214Tree1Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS <= 1.0) && (wipJS <= 3538.5) && (wipJS <= 3533.0) && (wipJS > 3194.5) && (wipJS > 3206.5))  { ruleCode = 1.261 ; }
    return ruleCode; }
public static double checkDT214Tree1Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS > 1.0) && (eTardJS > 4880.25) && (eTardJS > 26334.25) && (eTardJS > 167167.25) && (wipJS <= 7790.5))  { ruleCode = 0.622 ; }
    return ruleCode; }
public static double checkDT214Tree1Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS > 1.0) && (eTardJS > 4880.25) && (eTardJS > 26334.25) && (eTardJS > 167167.25) && (wipJS > 7790.5))  { ruleCode = 0.511 ; }
    return ruleCode; }
public static double checkDT214Tree1Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS <= 1.0) && (wipJS > 3538.5) && (wipJS > 3676.0) && (wipJS > 5408.0) && (wipJS > 5433.5))  { ruleCode = 0.065 ; }
    return ruleCode; }
public static double checkDT214Tree1Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS > 1.0) && (eTardJS > 4880.25) && (eTardJS > 26334.25) && (eTardJS <= 167167.25) && (wipJS <= 2614.0))  { ruleCode = 0.547 ; }
    return ruleCode; }
public static double checkDT214Tree1Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS > 1.0) && (eTardJS <= 4880.25) && (eTardJS > 537.25) && (wipJS > 4782.0) && (eTardJS > 4011.0))  { ruleCode = 0.2 ; }
    return ruleCode; }
public static double checkDT214Tree1Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS > 1.0) && (eTardJS <= 4880.25) && (eTardJS <= 537.25) && (wipJS <= 1429.0) && (eTardJS > 52.0))  { ruleCode = 0.236 ; }
    return ruleCode; }
public static double checkDT214Tree1Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS <= 1.0) && (wipJS > 3538.5) && (wipJS <= 3676.0) && (wipJS <= 3649.0) && (wipJS > 3572.0))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT214Tree1Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS <= 1.0) && (wipJS > 3538.5) && (wipJS <= 3676.0) && (wipJS > 3649.0) && (wipJS > 3651.5))  { ruleCode = 0.241 ; }
    return ruleCode; }
public static double checkDT214Tree1Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS <= 1.0) && (wipJS > 3538.5) && (wipJS <= 3676.0) && (wipJS <= 3649.0) && (wipJS <= 3572.0))  { ruleCode = 0.091 ; }
    return ruleCode; }
public static double checkDT214Tree1Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS <= 1.0) && (wipJS <= 3538.5) && (wipJS <= 3533.0) && (wipJS > 3194.5) && (wipJS <= 3206.5))  { ruleCode = 20.293 ; }
    return ruleCode; }
public static double checkDT214Tree1Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1119.0) && (wipJS <= 1002.0) && (wipJS > 750.5) && (wipJS > 821.5) && (wipJS > 927.5))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT214Tree1Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS > 1.0) && (eTardJS <= 4880.25) && (eTardJS <= 537.25) && (wipJS <= 1429.0) && (eTardJS <= 52.0))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT214Tree1Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1119.0) && (wipJS <= 1002.0) && (wipJS > 750.5) && (wipJS > 821.5) && (wipJS <= 927.5) && (wipJS <= 914.0))  { ruleCode = 0.15 ; }
    return ruleCode; }
public static double checkDT214Tree1Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1119.0) && (wipJS <= 1002.0) && (wipJS <= 750.5) && (wipJS > 335.0) && (wipJS <= 709.0))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT214Tree1Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1119.0) && (wipJS <= 1002.0) && (wipJS <= 750.5) && (wipJS > 335.0) && (wipJS > 709.0))  { ruleCode = 3.0 ; }
    return ruleCode; }
public static double checkDT214Tree1Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1119.0) && (wipJS <= 1002.0) && (wipJS > 750.5) && (wipJS <= 821.5))  { ruleCode = 0.889 ; }
    return ruleCode; }
public static double checkDT214Tree1Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1119.0) && (wipJS <= 1002.0) && (wipJS > 750.5) && (wipJS > 821.5) && (wipJS <= 927.5) && (wipJS > 914.0))  { ruleCode = 0.245 ; }
    return ruleCode; }
public static double checkDT214Tree1Path33(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS <= 1.0) && (wipJS > 3538.5) && (wipJS > 3676.0) && (wipJS > 5408.0) && (wipJS <= 5433.5))  { ruleCode = 0.32 ; }
    return ruleCode; }
public static double checkDT214Tree1Path34(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1119.0) && (wipJS > 1002.0) && (wipJS <= 1070.0))  { ruleCode = 33.0 ; }
    return ruleCode; }
public static double checkDT214Tree1Path35(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1119.0) && (wipJS > 1002.0) && (wipJS > 1070.0) && (eTardJS <= 118.5) && (wipJS <= 1107.5))  { ruleCode = 20.0 ; }
    return ruleCode; }
public static double checkDT214Tree1Path36(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1119.0) && (wipJS > 1002.0) && (wipJS > 1070.0) && (eTardJS <= 118.5) && (wipJS > 1107.5))  { ruleCode = 0.288 ; }
    return ruleCode; }
public static double checkDT214Tree1Path37(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1119.0) && (wipJS > 1002.0) && (wipJS > 1070.0) && (eTardJS > 118.5) && (wipJS <= 1102.5))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT214Tree1Path38(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS <= 1.0) && (wipJS <= 3538.5) && (wipJS > 3533.0))  { ruleCode = 23.0 ; }
    return ruleCode; }
public static double checkDT214Tree1Path39(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS <= 1.0) && (wipJS > 3538.5) && (wipJS <= 3676.0) && (wipJS > 3649.0) && (wipJS <= 3651.5))  { ruleCode = 0.703 ; }
    return ruleCode; }
public static double checkDT214Tree1Path40(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1119.0) && (wipJS > 1002.0) && (wipJS > 1070.0) && (eTardJS > 118.5) && (wipJS > 1102.5))  { ruleCode = 4.625 ; }
    return ruleCode; }
public static double checkDT214Tree2Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1120.0) && (eTardJS > 1.0) && (eTardJS > 4486.5) && (eTardJS > 25058.75) && (eTardJS <= 117392.25) && (wipJS > 2589.5))  { ruleCode = 0.422 ; }
    return ruleCode; }
public static double checkDT214Tree2Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1120.0) && (wipJS <= 1048.0) && (wipJS <= 335.0))  { ruleCode = 2.86 ; }
    return ruleCode; }
public static double checkDT214Tree2Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1120.0) && (eTardJS <= 1.0) && (wipJS <= 4546.5) && (wipJS <= 4544.0) && (wipJS > 1886.5) && (wipJS > 1889.5))  { ruleCode = 0.63 ; }
    return ruleCode; }
public static double checkDT214Tree2Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1120.0) && (eTardJS > 1.0) && (eTardJS <= 4486.5) && (eTardJS <= 1213.5) && (eTardJS <= 344.75) && (wipJS <= 3978.5))  { ruleCode = 0.09 ; }
    return ruleCode; }
public static double checkDT214Tree2Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1120.0) && (eTardJS > 1.0) && (eTardJS > 4486.5) && (eTardJS <= 25058.75) && (eTardJS <= 9590.25) && (wipJS <= 4322.5))  { ruleCode = 0.315 ; }
    return ruleCode; }
public static double checkDT214Tree2Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1120.0) && (eTardJS > 1.0) && (eTardJS > 4486.5) && (eTardJS <= 25058.75) && (eTardJS > 9590.25) && (eTardJS > 15602.75))  { ruleCode = 0.376 ; }
    return ruleCode; }
public static double checkDT214Tree2Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1120.0) && (eTardJS > 1.0) && (eTardJS > 4486.5) && (eTardJS <= 25058.75) && (eTardJS > 9590.25) && (eTardJS <= 15602.75))  { ruleCode = 0.342 ; }
    return ruleCode; }
public static double checkDT214Tree2Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1120.0) && (eTardJS > 1.0) && (eTardJS <= 4486.5) && (eTardJS > 1213.5) && (wipJS <= 4880.5) && (eTardJS <= 2782.0))  { ruleCode = 0.215 ; }
    return ruleCode; }
public static double checkDT214Tree2Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1120.0) && (eTardJS > 1.0) && (eTardJS <= 4486.5) && (eTardJS <= 1213.5) && (eTardJS > 344.75) && (wipJS > 2359.0))  { ruleCode = 0.11 ; }
    return ruleCode; }
public static double checkDT214Tree2Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1120.0) && (eTardJS > 1.0) && (eTardJS <= 4486.5) && (eTardJS > 1213.5) && (wipJS <= 4880.5) && (eTardJS > 2782.0))  { ruleCode = 0.253 ; }
    return ruleCode; }
public static double checkDT214Tree2Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1120.0) && (eTardJS > 1.0) && (eTardJS > 4486.5) && (eTardJS > 25058.75) && (eTardJS > 117392.25) && (eTardJS <= 442512.75))  { ruleCode = 0.521 ; }
    return ruleCode; }
public static double checkDT214Tree2Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1120.0) && (eTardJS <= 1.0) && (wipJS <= 4546.5) && (wipJS <= 4544.0) && (wipJS <= 1886.5) && (wipJS > 1342.0))  { ruleCode = 0.128 ; }
    return ruleCode; }
public static double checkDT214Tree2Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1120.0) && (eTardJS > 1.0) && (eTardJS <= 4486.5) && (eTardJS <= 1213.5) && (eTardJS > 344.75) && (wipJS <= 2359.0))  { ruleCode = 0.165 ; }
    return ruleCode; }
public static double checkDT214Tree2Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1120.0) && (eTardJS > 1.0) && (eTardJS > 4486.5) && (eTardJS <= 25058.75) && (eTardJS <= 9590.25) && (wipJS > 4322.5))  { ruleCode = 0.236 ; }
    return ruleCode; }
public static double checkDT214Tree2Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1120.0) && (eTardJS > 1.0) && (eTardJS <= 4486.5) && (eTardJS <= 1213.5) && (eTardJS <= 344.75) && (wipJS > 3978.5))  { ruleCode = 0.049 ; }
    return ruleCode; }
public static double checkDT214Tree2Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1120.0) && (eTardJS > 1.0) && (eTardJS <= 4486.5) && (eTardJS > 1213.5) && (wipJS > 4880.5) && (eTardJS <= 4011.0))  { ruleCode = 0.101 ; }
    return ruleCode; }
public static double checkDT214Tree2Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1120.0) && (eTardJS <= 1.0) && (wipJS > 4546.5) && (wipJS <= 6276.0) && (wipJS <= 5408.0) && (wipJS <= 4925.5))  { ruleCode = 0.007 ; }
    return ruleCode; }
public static double checkDT214Tree2Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1120.0) && (eTardJS <= 1.0) && (wipJS <= 4546.5) && (wipJS <= 4544.0) && (wipJS <= 1886.5) && (wipJS <= 1342.0))  { ruleCode = 1.407 ; }
    return ruleCode; }
public static double checkDT214Tree2Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1120.0) && (eTardJS <= 1.0) && (wipJS > 4546.5) && (wipJS <= 6276.0) && (wipJS <= 5408.0) && (wipJS > 4925.5))  { ruleCode = 0.029 ; }
    return ruleCode; }
public static double checkDT214Tree2Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1120.0) && (eTardJS > 1.0) && (eTardJS > 4486.5) && (eTardJS > 25058.75) && (eTardJS <= 117392.25) && (wipJS <= 2589.5))  { ruleCode = 0.583 ; }
    return ruleCode; }
public static double checkDT214Tree2Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1120.0) && (eTardJS <= 1.0) && (wipJS > 4546.5) && (wipJS <= 6276.0) && (wipJS > 5408.0) && (wipJS > 5427.0))  { ruleCode = 0.055 ; }
    return ruleCode; }
public static double checkDT214Tree2Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1120.0) && (eTardJS > 1.0) && (eTardJS <= 4486.5) && (eTardJS > 1213.5) && (wipJS > 4880.5) && (eTardJS > 4011.0))  { ruleCode = 0.254 ; }
    return ruleCode; }
public static double checkDT214Tree2Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1120.0) && (wipJS <= 1048.0) && (wipJS > 335.0) && (eTardJS <= 69.0) && (wipJS > 934.0))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT214Tree2Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1120.0) && (eTardJS > 1.0) && (eTardJS > 4486.5) && (eTardJS > 25058.75) && (eTardJS > 117392.25) && (eTardJS > 442512.75))  { ruleCode = 0.896 ; }
    return ruleCode; }
public static double checkDT214Tree2Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1120.0) && (eTardJS <= 1.0) && (wipJS > 4546.5) && (wipJS > 6276.0) && (wipJS > 6435.5) && (wipJS <= 7558.5))  { ruleCode = 0.013 ; }
    return ruleCode; }
public static double checkDT214Tree2Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1120.0) && (eTardJS <= 1.0) && (wipJS <= 4546.5) && (wipJS <= 4544.0) && (wipJS > 1886.5) && (wipJS <= 1889.5))  { ruleCode = 36.355 ; }
    return ruleCode; }
public static double checkDT214Tree2Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1120.0) && (eTardJS <= 1.0) && (wipJS <= 4546.5) && (wipJS > 4544.0))  { ruleCode = 17.0 ; }
    return ruleCode; }
public static double checkDT214Tree2Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1120.0) && (eTardJS <= 1.0) && (wipJS > 4546.5) && (wipJS <= 6276.0) && (wipJS > 5408.0) && (wipJS <= 5427.0))  { ruleCode = 0.32 ; }
    return ruleCode; }
public static double checkDT214Tree2Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1120.0) && (wipJS > 1048.0) && (eTardJS > 118.5) && (eTardJS > 276.5))  { ruleCode = 4.625 ; }
    return ruleCode; }
public static double checkDT214Tree2Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1120.0) && (wipJS > 1048.0) && (eTardJS > 118.5) && (eTardJS <= 276.5))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT214Tree2Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1120.0) && (wipJS > 1048.0) && (eTardJS <= 118.5) && (wipJS > 1077.5))  { ruleCode = 20.0 ; }
    return ruleCode; }
public static double checkDT214Tree2Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1120.0) && (wipJS > 1048.0) && (eTardJS <= 118.5) && (wipJS <= 1077.5))  { ruleCode = 33.0 ; }
    return ruleCode; }
public static double checkDT214Tree2Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1120.0) && (wipJS <= 1048.0) && (wipJS > 335.0) && (eTardJS > 69.0))  { ruleCode = 0.319 ; }
    return ruleCode; }
public static double checkDT214Tree2Path33(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1120.0) && (eTardJS <= 1.0) && (wipJS > 4546.5) && (wipJS > 6276.0) && (wipJS > 6435.5) && (wipJS > 7558.5))  { ruleCode = 0.205 ; }
    return ruleCode; }
public static double checkDT214Tree2Path34(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1120.0) && (wipJS <= 1048.0) && (wipJS > 335.0) && (eTardJS <= 69.0) && (wipJS <= 934.0) && (wipJS > 797.0))  { ruleCode = 0.245 ; }
    return ruleCode; }
public static double checkDT214Tree2Path35(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1120.0) && (wipJS <= 1048.0) && (wipJS > 335.0) && (eTardJS <= 69.0) && (wipJS <= 934.0) && (wipJS <= 797.0))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT214Tree2Path36(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1120.0) && (eTardJS <= 1.0) && (wipJS > 4546.5) && (wipJS > 6276.0) && (wipJS <= 6435.5))  { ruleCode = 0.412 ; }
    return ruleCode; }
public static double checkDT214Tree3Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 1.0) && (eTardJS > 4908.75) && (eTardJS > 14604.5) && (eTardJS <= 167167.25) && (eTardJS > 33987.25))  { ruleCode = 0.441 ; }
    return ruleCode; }
public static double checkDT214Tree3Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS <= 1107.5) && (wipJS <= 1048.0) && (wipJS <= 750.5) && (wipJS <= 374.0))  { ruleCode = 2.676 ; }
    return ruleCode; }
public static double checkDT214Tree3Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 1.0) && (eTardJS > 4908.75) && (eTardJS > 14604.5) && (eTardJS <= 167167.25) && (eTardJS <= 33987.25))  { ruleCode = 0.391 ; }
    return ruleCode; }
public static double checkDT214Tree3Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 1.0) && (wipJS > 1883.5) && (wipJS > 1889.5) && (wipJS > 1936.5) && (wipJS > 2533.5))  { ruleCode = 1.369 ; }
    return ruleCode; }
public static double checkDT214Tree3Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 1.0) && (eTardJS <= 4908.75) && (eTardJS <= 1235.75) && (eTardJS > 237.75) && (wipJS > 1924.5))  { ruleCode = 0.108 ; }
    return ruleCode; }
public static double checkDT214Tree3Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 1.0) && (eTardJS <= 4908.75) && (eTardJS > 1235.75) && (wipJS <= 4684.0) && (wipJS > 2172.0))  { ruleCode = 0.212 ; }
    return ruleCode; }
public static double checkDT214Tree3Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 1.0) && (eTardJS > 4908.75) && (eTardJS <= 14604.5) && (eTardJS <= 9590.25) && (wipJS <= 4226.0))  { ruleCode = 0.306 ; }
    return ruleCode; }
public static double checkDT214Tree3Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 1.0) && (eTardJS <= 4908.75) && (eTardJS <= 1235.75) && (eTardJS <= 237.75) && (wipJS <= 4496.0))  { ruleCode = 0.085 ; }
    return ruleCode; }
public static double checkDT214Tree3Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 1.0) && (eTardJS > 4908.75) && (eTardJS <= 14604.5) && (eTardJS > 9590.25) && (wipJS > 1855.5))  { ruleCode = 0.341 ; }
    return ruleCode; }
public static double checkDT214Tree3Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 1.0) && (wipJS > 1883.5) && (wipJS > 1889.5) && (wipJS > 1936.5) && (wipJS <= 2533.5))  { ruleCode = 0.135 ; }
    return ruleCode; }
public static double checkDT214Tree3Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 1.0) && (eTardJS <= 4908.75) && (eTardJS > 1235.75) && (wipJS <= 4684.0) && (wipJS <= 2172.0))  { ruleCode = 0.278 ; }
    return ruleCode; }
public static double checkDT214Tree3Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 1.0) && (eTardJS > 4908.75) && (eTardJS <= 14604.5) && (eTardJS <= 9590.25) && (wipJS > 4226.0))  { ruleCode = 0.246 ; }
    return ruleCode; }
public static double checkDT214Tree3Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 1.0) && (eTardJS > 4908.75) && (eTardJS > 14604.5) && (eTardJS > 167167.25) && (wipJS > 4438.5))  { ruleCode = 0.552 ; }
    return ruleCode; }
public static double checkDT214Tree3Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 1.0) && (eTardJS <= 4908.75) && (eTardJS > 1235.75) && (wipJS > 4684.0) && (wipJS > 4844.0))  { ruleCode = 0.131 ; }
    return ruleCode; }
public static double checkDT214Tree3Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 1.0) && (eTardJS <= 4908.75) && (eTardJS <= 1235.75) && (eTardJS > 237.75) && (wipJS <= 1924.5))  { ruleCode = 0.193 ; }
    return ruleCode; }
public static double checkDT214Tree3Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 1.0) && (eTardJS <= 4908.75) && (eTardJS <= 1235.75) && (eTardJS <= 237.75) && (wipJS > 4496.0))  { ruleCode = 0.025 ; }
    return ruleCode; }
public static double checkDT214Tree3Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 1.0) && (wipJS <= 1883.5) && (wipJS > 1342.0) && (wipJS > 1569.5) && (wipJS > 1709.0))  { ruleCode = 0.059 ; }
    return ruleCode; }
public static double checkDT214Tree3Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 1.0) && (wipJS <= 1883.5) && (wipJS > 1342.0) && (wipJS <= 1569.5) && (wipJS <= 1558.5))  { ruleCode = 0.068 ; }
    return ruleCode; }
public static double checkDT214Tree3Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 1.0) && (wipJS <= 1883.5) && (wipJS > 1342.0) && (wipJS > 1569.5) && (wipJS <= 1709.0))  { ruleCode = 0.006 ; }
    return ruleCode; }
public static double checkDT214Tree3Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS > 1107.5) && (wipJS > 1195.5) && (wipJS > 1219.5) && (wipJS > 1240.5))  { ruleCode = 0.12 ; }
    return ruleCode; }
public static double checkDT214Tree3Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 1.0) && (eTardJS > 4908.75) && (eTardJS > 14604.5) && (eTardJS > 167167.25) && (wipJS <= 4438.5))  { ruleCode = 0.845 ; }
    return ruleCode; }
public static double checkDT214Tree3Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS <= 1107.5) && (wipJS <= 1048.0) && (wipJS > 750.5) && (wipJS > 926.5))  { ruleCode = 0.04 ; }
    return ruleCode; }
public static double checkDT214Tree3Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 1.0) && (wipJS > 1883.5) && (wipJS > 1889.5) && (wipJS <= 1936.5) && (wipJS <= 1917.5))  { ruleCode = 0.396 ; }
    return ruleCode; }
public static double checkDT214Tree3Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS > 1107.5) && (wipJS <= 1195.5) && (wipJS > 1118.0) && (wipJS > 1134.0))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT214Tree3Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 1.0) && (eTardJS <= 4908.75) && (eTardJS > 1235.75) && (wipJS > 4684.0) && (wipJS <= 4844.0))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT214Tree3Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 1.0) && (eTardJS > 4908.75) && (eTardJS <= 14604.5) && (eTardJS > 9590.25) && (wipJS <= 1855.5))  { ruleCode = 0.605 ; }
    return ruleCode; }
public static double checkDT214Tree3Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS > 1107.5) && (wipJS <= 1195.5) && (wipJS > 1118.0) && (wipJS <= 1134.0))  { ruleCode = 0.008 ; }
    return ruleCode; }
public static double checkDT214Tree3Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 1.0) && (wipJS <= 1883.5) && (wipJS <= 1342.0) && (wipJS <= 1338.0) && (wipJS > 1322.5))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT214Tree3Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 1.0) && (wipJS > 1883.5) && (wipJS > 1889.5) && (wipJS <= 1936.5) && (wipJS > 1917.5))  { ruleCode = 29.429 ; }
    return ruleCode; }
public static double checkDT214Tree3Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS <= 1107.5) && (wipJS <= 1048.0) && (wipJS > 750.5) && (wipJS <= 926.5))  { ruleCode = 0.839 ; }
    return ruleCode; }
public static double checkDT214Tree3Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS > 1107.5) && (wipJS > 1195.5) && (wipJS > 1219.5) && (wipJS <= 1240.5))  { ruleCode = 0.361 ; }
    return ruleCode; }
public static double checkDT214Tree3Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS > 1107.5) && (wipJS > 1195.5) && (wipJS <= 1219.5))  { ruleCode = 0.909 ; }
    return ruleCode; }
public static double checkDT214Tree3Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 1.0) && (wipJS <= 1883.5) && (wipJS <= 1342.0) && (wipJS <= 1338.0) && (wipJS <= 1322.5))  { ruleCode = 0.312 ; }
    return ruleCode; }
public static double checkDT214Tree3Path33(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 1.0) && (wipJS <= 1883.5) && (wipJS <= 1342.0) && (wipJS > 1338.0))  { ruleCode = 12.0 ; }
    return ruleCode; }
public static double checkDT214Tree3Path34(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS > 1107.5) && (wipJS <= 1195.5) && (wipJS <= 1118.0) && (wipJS > 1114.5))  { ruleCode = 0.421 ; }
    return ruleCode; }
public static double checkDT214Tree3Path35(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS > 1107.5) && (wipJS <= 1195.5) && (wipJS <= 1118.0) && (wipJS <= 1114.5))  { ruleCode = 0.288 ; }
    return ruleCode; }
public static double checkDT214Tree3Path36(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS <= 1107.5) && (wipJS > 1048.0) && (eTardJS > 118.5))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT214Tree3Path37(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS <= 1107.5) && (wipJS > 1048.0) && (eTardJS <= 118.5) && (wipJS > 1077.5))  { ruleCode = 20.0 ; }
    return ruleCode; }
public static double checkDT214Tree3Path38(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS <= 1107.5) && (wipJS > 1048.0) && (eTardJS <= 118.5) && (wipJS <= 1077.5))  { ruleCode = 33.0 ; }
    return ruleCode; }
public static double checkDT214Tree3Path39(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 1.0) && (wipJS <= 1883.5) && (wipJS > 1342.0) && (wipJS <= 1569.5) && (wipJS > 1558.5))  { ruleCode = 6.0 ; }
    return ruleCode; }
public static double checkDT214Tree3Path40(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 1.0) && (wipJS > 1883.5) && (wipJS <= 1889.5))  { ruleCode = 109.0 ; }
    return ruleCode; }
public static double checkDT214Tree3Path41(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS <= 1107.5) && (wipJS <= 1048.0) && (wipJS <= 750.5) && (wipJS > 374.0))  { ruleCode = 3.0 ; }
    return ruleCode; }
public static double checkDT214Tree3Path42(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS > 1297.0))  { ruleCode = 29.5 ; }
    return ruleCode; }
public static double checkDT214Tree4Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 0.5) && (eTardJS > 5700.5) && (eTardJS > 25111.5) && (eTardJS <= 175253.25) && (wipJS > 2380.0))  { ruleCode = 0.435 ; }
    return ruleCode; }
public static double checkDT214Tree4Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS <= 1107.5) && (wipJS <= 1027.0) && (wipJS <= 335.0))  { ruleCode = 3.199 ; }
    return ruleCode; }
public static double checkDT214Tree4Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 0.5) && (eTardJS <= 5700.5) && (eTardJS <= 1236.25) && (eTardJS > 183.25) && (eTardJS > 204.5))  { ruleCode = 0.123 ; }
    return ruleCode; }
public static double checkDT214Tree4Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 0.5) && (eTardJS <= 5700.5) && (eTardJS > 1236.25) && (wipJS <= 4901.5) && (eTardJS <= 3344.5))  { ruleCode = 0.214 ; }
    return ruleCode; }
public static double checkDT214Tree4Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 0.5) && (wipJS <= 3206.5) && (wipJS <= 3204.0) && (wipJS <= 2533.5) && (wipJS > 1346.5))  { ruleCode = 0.317 ; }
    return ruleCode; }
public static double checkDT214Tree4Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 0.5) && (eTardJS > 5700.5) && (eTardJS <= 25111.5) && (wipJS > 3453.5) && (eTardJS > 10170.5))  { ruleCode = 0.349 ; }
    return ruleCode; }
public static double checkDT214Tree4Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 0.5) && (eTardJS <= 5700.5) && (eTardJS > 1236.25) && (wipJS <= 4901.5) && (eTardJS > 3344.5))  { ruleCode = 0.271 ; }
    return ruleCode; }
public static double checkDT214Tree4Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 0.5) && (eTardJS <= 5700.5) && (eTardJS <= 1236.25) && (eTardJS <= 183.25) && (wipJS > 1890.5))  { ruleCode = 0.064 ; }
    return ruleCode; }
public static double checkDT214Tree4Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 0.5) && (eTardJS > 5700.5) && (eTardJS <= 25111.5) && (wipJS <= 3453.5) && (eTardJS > 11152.5))  { ruleCode = 0.399 ; }
    return ruleCode; }
public static double checkDT214Tree4Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 0.5) && (eTardJS > 5700.5) && (eTardJS <= 25111.5) && (wipJS <= 3453.5) && (eTardJS <= 11152.5))  { ruleCode = 0.351 ; }
    return ruleCode; }
public static double checkDT214Tree4Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 0.5) && (wipJS > 3206.5) && (wipJS <= 4235.0) && (wipJS <= 4227.0) && (wipJS <= 4092.0))  { ruleCode = 0.078 ; }
    return ruleCode; }
public static double checkDT214Tree4Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 0.5) && (eTardJS > 5700.5) && (eTardJS <= 25111.5) && (wipJS > 3453.5) && (eTardJS <= 10170.5))  { ruleCode = 0.266 ; }
    return ruleCode; }
public static double checkDT214Tree4Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 0.5) && (wipJS <= 3206.5) && (wipJS <= 3204.0) && (wipJS > 2533.5) && (wipJS > 2538.5))  { ruleCode = 2.164 ; }
    return ruleCode; }
public static double checkDT214Tree4Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 0.5) && (wipJS > 3206.5) && (wipJS > 4235.0) && (wipJS <= 5408.0) && (wipJS > 4430.0))  { ruleCode = 0.016 ; }
    return ruleCode; }
public static double checkDT214Tree4Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 0.5) && (eTardJS <= 5700.5) && (eTardJS > 1236.25) && (wipJS > 4901.5) && (wipJS > 5121.5))  { ruleCode = 0.162 ; }
    return ruleCode; }
public static double checkDT214Tree4Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 0.5) && (eTardJS > 5700.5) && (eTardJS > 25111.5) && (eTardJS > 175253.25) && (wipJS > 4451.0))  { ruleCode = 0.577 ; }
    return ruleCode; }
public static double checkDT214Tree4Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 0.5) && (eTardJS <= 5700.5) && (eTardJS <= 1236.25) && (eTardJS <= 183.25) && (wipJS <= 1890.5))  { ruleCode = 0.115 ; }
    return ruleCode; }
public static double checkDT214Tree4Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 0.5) && (wipJS > 3206.5) && (wipJS > 4235.0) && (wipJS > 5408.0) && (wipJS > 5427.0))  { ruleCode = 0.066 ; }
    return ruleCode; }
public static double checkDT214Tree4Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 0.5) && (wipJS > 3206.5) && (wipJS > 4235.0) && (wipJS <= 5408.0) && (wipJS <= 4430.0))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT214Tree4Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 0.5) && (wipJS > 3206.5) && (wipJS <= 4235.0) && (wipJS <= 4227.0) && (wipJS > 4092.0))  { ruleCode = 0.376 ; }
    return ruleCode; }
public static double checkDT214Tree4Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 0.5) && (eTardJS <= 5700.5) && (eTardJS <= 1236.25) && (eTardJS > 183.25) && (eTardJS <= 204.5))  { ruleCode = 0.209 ; }
    return ruleCode; }
public static double checkDT214Tree4Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 0.5) && (eTardJS <= 5700.5) && (eTardJS > 1236.25) && (wipJS > 4901.5) && (wipJS <= 5121.5))  { ruleCode = 0.041 ; }
    return ruleCode; }
public static double checkDT214Tree4Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 0.5) && (eTardJS > 5700.5) && (eTardJS > 25111.5) && (eTardJS <= 175253.25) && (wipJS <= 2380.0))  { ruleCode = 0.594 ; }
    return ruleCode; }
public static double checkDT214Tree4Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS > 1107.5) && (wipJS > 1230.5) && (wipJS <= 1280.0) && (eTardJS > 1.25))  { ruleCode = 0.095 ; }
    return ruleCode; }
public static double checkDT214Tree4Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 0.5) && (wipJS <= 3206.5) && (wipJS <= 3204.0) && (wipJS <= 2533.5) && (wipJS <= 1346.5))  { ruleCode = 1.587 ; }
    return ruleCode; }
public static double checkDT214Tree4Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS > 1107.5) && (wipJS <= 1230.5) && (wipJS <= 1194.5) && (wipJS <= 1176.0))  { ruleCode = 0.041 ; }
    return ruleCode; }
public static double checkDT214Tree4Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS <= 1107.5) && (wipJS <= 1027.0) && (wipJS > 335.0) && (wipJS <= 923.0))  { ruleCode = 0.717 ; }
    return ruleCode; }
public static double checkDT214Tree4Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS <= 1107.5) && (wipJS <= 1027.0) && (wipJS > 335.0) && (wipJS > 923.0))  { ruleCode = 0.116 ; }
    return ruleCode; }
public static double checkDT214Tree4Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 0.5) && (eTardJS > 5700.5) && (eTardJS > 25111.5) && (eTardJS > 175253.25) && (wipJS <= 4451.0))  { ruleCode = 0.965 ; }
    return ruleCode; }
public static double checkDT214Tree4Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS > 1107.5) && (wipJS > 1230.5) && (wipJS <= 1280.0) && (eTardJS <= 1.25))  { ruleCode = 0.031 ; }
    return ruleCode; }
public static double checkDT214Tree4Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS > 1107.5) && (wipJS <= 1230.5) && (wipJS > 1194.5) && (eTardJS <= 54.0))  { ruleCode = 0.6 ; }
    return ruleCode; }
public static double checkDT214Tree4Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 0.5) && (wipJS <= 3206.5) && (wipJS > 3204.0))  { ruleCode = 24.796 ; }
    return ruleCode; }
public static double checkDT214Tree4Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS > 1107.5) && (wipJS <= 1230.5) && (wipJS <= 1194.5) && (wipJS > 1176.0))  { ruleCode = 0.227 ; }
    return ruleCode; }
public static double checkDT214Tree4Path33(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS <= 1107.5) && (wipJS > 1027.0) && (eTardJS <= 118.5) && (wipJS <= 1077.5))  { ruleCode = 33.0 ; }
    return ruleCode; }
public static double checkDT214Tree4Path34(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS <= 1107.5) && (wipJS > 1027.0) && (eTardJS <= 118.5) && (wipJS > 1077.5))  { ruleCode = 20.0 ; }
    return ruleCode; }
public static double checkDT214Tree4Path35(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS <= 1107.5) && (wipJS > 1027.0) && (eTardJS > 118.5))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT214Tree4Path36(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 0.5) && (wipJS > 3206.5) && (wipJS <= 4235.0) && (wipJS > 4227.0))  { ruleCode = 62.0 ; }
    return ruleCode; }
public static double checkDT214Tree4Path37(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS > 1107.5) && (wipJS <= 1230.5) && (wipJS > 1194.5) && (eTardJS > 54.0))  { ruleCode = 0.286 ; }
    return ruleCode; }
public static double checkDT214Tree4Path38(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS > 1107.5) && (wipJS > 1230.5) && (wipJS > 1280.0) && (wipJS <= 1286.5))  { ruleCode = 0.324 ; }
    return ruleCode; }
public static double checkDT214Tree4Path39(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 0.5) && (wipJS > 3206.5) && (wipJS > 4235.0) && (wipJS > 5408.0) && (wipJS <= 5427.0))  { ruleCode = 0.32 ; }
    return ruleCode; }
public static double checkDT214Tree4Path40(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS > 1297.0))  { ruleCode = 29.5 ; }
    return ruleCode; }
public static double checkDT214Tree4Path41(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 0.5) && (wipJS <= 3206.5) && (wipJS <= 3204.0) && (wipJS > 2533.5) && (wipJS <= 2538.5))  { ruleCode = 48.0 ; }
    return ruleCode; }
public static double checkDT214Tree4Path42(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS > 1107.5) && (wipJS > 1230.5) && (wipJS > 1280.0) && (wipJS > 1286.5))  { ruleCode = 0.221 ; }
    return ruleCode; }
public static double checkDT214Tree5Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1111.0) && (wipJS <= 1094.5) && (wipJS <= 335.0))  { ruleCode = 3.071 ; }
    return ruleCode; }
public static double checkDT214Tree5Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1111.0) && (eTardJS > 0.5) && (eTardJS > 5513.0) && (eTardJS > 33991.75) && (eTardJS <= 167500.25) && (wipJS > 2703.5))  { ruleCode = 0.442 ; }
    return ruleCode; }
public static double checkDT214Tree5Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1111.0) && (eTardJS > 0.5) && (eTardJS > 5513.0) && (eTardJS <= 33991.75) && (eTardJS <= 13080.25) && (eTardJS <= 12925.0))  { ruleCode = 0.313 ; }
    return ruleCode; }
public static double checkDT214Tree5Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1111.0) && (eTardJS > 0.5) && (eTardJS <= 5513.0) && (eTardJS <= 1316.25) && (eTardJS <= 489.75) && (wipJS <= 4557.5))  { ruleCode = 0.097 ; }
    return ruleCode; }
public static double checkDT214Tree5Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1111.0) && (eTardJS > 0.5) && (eTardJS > 5513.0) && (eTardJS <= 33991.75) && (eTardJS > 13080.25) && (wipJS > 2854.5))  { ruleCode = 0.373 ; }
    return ruleCode; }
public static double checkDT214Tree5Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1111.0) && (eTardJS > 0.5) && (eTardJS <= 5513.0) && (eTardJS > 1316.25) && (wipJS <= 4760.0) && (eTardJS <= 3220.25))  { ruleCode = 0.2 ; }
    return ruleCode; }
public static double checkDT214Tree5Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1111.0) && (eTardJS <= 0.5) && (wipJS <= 3214.0) && (wipJS <= 3204.0) && (wipJS > 1883.0) && (wipJS > 1888.5))  { ruleCode = 0.741 ; }
    return ruleCode; }
public static double checkDT214Tree5Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1111.0) && (eTardJS > 0.5) && (eTardJS <= 5513.0) && (eTardJS <= 1316.25) && (eTardJS > 489.75) && (eTardJS <= 1080.0))  { ruleCode = 0.145 ; }
    return ruleCode; }
public static double checkDT214Tree5Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1111.0) && (eTardJS > 0.5) && (eTardJS <= 5513.0) && (eTardJS > 1316.25) && (wipJS <= 4760.0) && (eTardJS > 3220.25))  { ruleCode = 0.265 ; }
    return ruleCode; }
public static double checkDT214Tree5Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1111.0) && (eTardJS > 0.5) && (eTardJS > 5513.0) && (eTardJS <= 33991.75) && (eTardJS > 13080.25) && (wipJS <= 2854.5))  { ruleCode = 0.424 ; }
    return ruleCode; }
public static double checkDT214Tree5Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1111.0) && (eTardJS <= 0.5) && (wipJS > 3214.0) && (wipJS <= 4097.5) && (wipJS > 3303.0) && (wipJS <= 3945.0))  { ruleCode = 0.042 ; }
    return ruleCode; }
public static double checkDT214Tree5Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1111.0) && (eTardJS > 0.5) && (eTardJS <= 5513.0) && (eTardJS > 1316.25) && (wipJS > 4760.0) && (wipJS <= 6471.5))  { ruleCode = 0.123 ; }
    return ruleCode; }
public static double checkDT214Tree5Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1111.0) && (eTardJS <= 0.5) && (wipJS > 3214.0) && (wipJS > 4097.5) && (wipJS > 4235.0) && (wipJS > 4546.5))  { ruleCode = 0.029 ; }
    return ruleCode; }
public static double checkDT214Tree5Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1111.0) && (eTardJS <= 0.5) && (wipJS <= 3214.0) && (wipJS <= 3204.0) && (wipJS <= 1883.0) && (wipJS <= 1590.5))  { ruleCode = 0.624 ; }
    return ruleCode; }
public static double checkDT214Tree5Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1111.0) && (eTardJS <= 0.5) && (wipJS <= 3214.0) && (wipJS <= 3204.0) && (wipJS <= 1883.0) && (wipJS > 1590.5))  { ruleCode = 0.076 ; }
    return ruleCode; }
public static double checkDT214Tree5Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1111.0) && (eTardJS > 0.5) && (eTardJS <= 5513.0) && (eTardJS <= 1316.25) && (eTardJS <= 489.75) && (wipJS > 4557.5))  { ruleCode = 0.042 ; }
    return ruleCode; }
public static double checkDT214Tree5Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1111.0) && (eTardJS <= 0.5) && (wipJS > 3214.0) && (wipJS > 4097.5) && (wipJS > 4235.0) && (wipJS <= 4546.5))  { ruleCode = 0.293 ; }
    return ruleCode; }
public static double checkDT214Tree5Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1111.0) && (eTardJS > 0.5) && (eTardJS <= 5513.0) && (eTardJS <= 1316.25) && (eTardJS > 489.75) && (eTardJS > 1080.0))  { ruleCode = 0.077 ; }
    return ruleCode; }
public static double checkDT214Tree5Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1111.0) && (eTardJS > 0.5) && (eTardJS > 5513.0) && (eTardJS > 33991.75) && (eTardJS > 167500.25) && (wipJS <= 7467.0))  { ruleCode = 0.743 ; }
    return ruleCode; }
public static double checkDT214Tree5Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1111.0) && (eTardJS > 0.5) && (eTardJS > 5513.0) && (eTardJS > 33991.75) && (eTardJS > 167500.25) && (wipJS > 7467.0))  { ruleCode = 0.509 ; }
    return ruleCode; }
public static double checkDT214Tree5Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1111.0) && (eTardJS <= 0.5) && (wipJS > 3214.0) && (wipJS <= 4097.5) && (wipJS > 3303.0) && (wipJS > 3945.0))  { ruleCode = 0.002 ; }
    return ruleCode; }
public static double checkDT214Tree5Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1111.0) && (eTardJS <= 0.5) && (wipJS > 3214.0) && (wipJS > 4097.5) && (wipJS <= 4235.0) && (wipJS <= 4227.0))  { ruleCode = 0.641 ; }
    return ruleCode; }
public static double checkDT214Tree5Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1111.0) && (eTardJS > 0.5) && (eTardJS > 5513.0) && (eTardJS > 33991.75) && (eTardJS <= 167500.25) && (wipJS <= 2703.5))  { ruleCode = 0.66 ; }
    return ruleCode; }
public static double checkDT214Tree5Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1111.0) && (eTardJS <= 0.5) && (wipJS > 3214.0) && (wipJS <= 4097.5) && (wipJS <= 3303.0) && (wipJS <= 3293.0))  { ruleCode = 0.206 ; }
    return ruleCode; }
public static double checkDT214Tree5Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1111.0) && (eTardJS > 0.5) && (eTardJS <= 5513.0) && (eTardJS > 1316.25) && (wipJS > 4760.0) && (wipJS > 6471.5))  { ruleCode = 0.278 ; }
    return ruleCode; }
public static double checkDT214Tree5Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1111.0) && (eTardJS > 0.5) && (eTardJS > 5513.0) && (eTardJS <= 33991.75) && (eTardJS <= 13080.25) && (eTardJS > 12925.0))  { ruleCode = 0.129 ; }
    return ruleCode; }
public static double checkDT214Tree5Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1111.0) && (wipJS <= 1094.5) && (wipJS > 335.0) && (wipJS > 819.0) && (wipJS > 910.5))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT214Tree5Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1111.0) && (eTardJS <= 0.5) && (wipJS > 3214.0) && (wipJS <= 4097.5) && (wipJS <= 3303.0) && (wipJS > 3293.0))  { ruleCode = 0.837 ; }
    return ruleCode; }
public static double checkDT214Tree5Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1111.0) && (eTardJS <= 0.5) && (wipJS <= 3214.0) && (wipJS > 3204.0))  { ruleCode = 24.796 ; }
    return ruleCode; }
public static double checkDT214Tree5Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1111.0) && (eTardJS <= 0.5) && (wipJS > 3214.0) && (wipJS > 4097.5) && (wipJS <= 4235.0) && (wipJS > 4227.0))  { ruleCode = 31.0 ; }
    return ruleCode; }
public static double checkDT214Tree5Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1111.0) && (wipJS > 1094.5))  { ruleCode = 20.0 ; }
    return ruleCode; }
public static double checkDT214Tree5Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1111.0) && (wipJS <= 1094.5) && (wipJS > 335.0) && (wipJS > 819.0) && (wipJS <= 910.5))  { ruleCode = 0.198 ; }
    return ruleCode; }
public static double checkDT214Tree5Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1111.0) && (wipJS <= 1094.5) && (wipJS > 335.0) && (wipJS <= 819.0) && (wipJS > 709.0))  { ruleCode = 3.0 ; }
    return ruleCode; }
public static double checkDT214Tree5Path33(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1111.0) && (wipJS <= 1094.5) && (wipJS > 335.0) && (wipJS <= 819.0) && (wipJS <= 709.0))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT214Tree5Path34(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1111.0) && (eTardJS <= 0.5) && (wipJS <= 3214.0) && (wipJS <= 3204.0) && (wipJS > 1883.0) && (wipJS <= 1888.5))  { ruleCode = 109.0 ; }
    return ruleCode; }
public static double checkDT214Tree6Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS <= 1070.0) && (wipJS <= 1048.0) && (wipJS <= 750.5) && (wipJS <= 374.0))  { ruleCode = 2.948 ; }
    return ruleCode; }
public static double checkDT214Tree6Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 0.5) && (eTardJS > 5309.75) && (eTardJS > 36236.25) && (eTardJS <= 175445.25) && (wipJS > 2610.0))  { ruleCode = 0.442 ; }
    return ruleCode; }
public static double checkDT214Tree6Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 0.5) && (eTardJS > 5309.75) && (eTardJS <= 36236.25) && (eTardJS > 10733.25) && (wipJS > 2483.0))  { ruleCode = 0.371 ; }
    return ruleCode; }
public static double checkDT214Tree6Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 0.5) && (eTardJS <= 5309.75) && (eTardJS <= 1155.5) && (wipJS <= 4485.5) && (eTardJS > 4.5))  { ruleCode = 0.125 ; }
    return ruleCode; }
public static double checkDT214Tree6Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 0.5) && (eTardJS <= 5309.75) && (eTardJS > 1155.5) && (wipJS <= 4684.0) && (eTardJS <= 5258.75))  { ruleCode = 0.238 ; }
    return ruleCode; }
public static double checkDT214Tree6Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 0.5) && (wipJS <= 3559.5) && (wipJS <= 3413.0) && (wipJS > 1886.5) && (wipJS > 1888.5))  { ruleCode = 0.366 ; }
    return ruleCode; }
public static double checkDT214Tree6Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 0.5) && (eTardJS > 5309.75) && (eTardJS <= 36236.25) && (eTardJS <= 10733.25) && (wipJS <= 4599.0))  { ruleCode = 0.317 ; }
    return ruleCode; }
public static double checkDT214Tree6Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 0.5) && (eTardJS > 5309.75) && (eTardJS <= 36236.25) && (eTardJS <= 10733.25) && (wipJS > 4599.0))  { ruleCode = 0.245 ; }
    return ruleCode; }
public static double checkDT214Tree6Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 0.5) && (wipJS <= 3559.5) && (wipJS <= 3413.0) && (wipJS <= 1886.5) && (wipJS > 1567.5))  { ruleCode = 0.015 ; }
    return ruleCode; }
public static double checkDT214Tree6Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 0.5) && (wipJS > 3559.5) && (wipJS <= 4546.5) && (wipJS <= 4544.0) && (wipJS <= 4134.0))  { ruleCode = 0.173 ; }
    return ruleCode; }
public static double checkDT214Tree6Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 0.5) && (eTardJS <= 5309.75) && (eTardJS > 1155.5) && (wipJS > 4684.0) && (eTardJS <= 3635.5))  { ruleCode = 0.108 ; }
    return ruleCode; }
public static double checkDT214Tree6Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 0.5) && (eTardJS > 5309.75) && (eTardJS <= 36236.25) && (eTardJS > 10733.25) && (wipJS <= 2483.0))  { ruleCode = 0.444 ; }
    return ruleCode; }
public static double checkDT214Tree6Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 0.5) && (eTardJS > 5309.75) && (eTardJS > 36236.25) && (eTardJS > 175445.25) && (eTardJS > 175896.25))  { ruleCode = 0.616 ; }
    return ruleCode; }
public static double checkDT214Tree6Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 0.5) && (eTardJS <= 5309.75) && (eTardJS <= 1155.5) && (wipJS > 4485.5) && (eTardJS > 236.0))  { ruleCode = 0.089 ; }
    return ruleCode; }
public static double checkDT214Tree6Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 0.5) && (wipJS > 3559.5) && (wipJS <= 4546.5) && (wipJS <= 4544.0) && (wipJS > 4134.0))  { ruleCode = 0.01 ; }
    return ruleCode; }
public static double checkDT214Tree6Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 0.5) && (wipJS > 3559.5) && (wipJS > 4546.5) && (wipJS <= 6276.0) && (wipJS <= 5575.0))  { ruleCode = 0.005 ; }
    return ruleCode; }
public static double checkDT214Tree6Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 0.5) && (wipJS <= 3559.5) && (wipJS <= 3413.0) && (wipJS <= 1886.5) && (wipJS <= 1567.5))  { ruleCode = 0.148 ; }
    return ruleCode; }
public static double checkDT214Tree6Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 0.5) && (eTardJS <= 5309.75) && (eTardJS <= 1155.5) && (wipJS > 4485.5) && (eTardJS <= 236.0))  { ruleCode = 0.012 ; }
    return ruleCode; }
public static double checkDT214Tree6Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 0.5) && (eTardJS <= 5309.75) && (eTardJS > 1155.5) && (wipJS > 4684.0) && (eTardJS > 3635.5))  { ruleCode = 0.191 ; }
    return ruleCode; }
public static double checkDT214Tree6Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS > 1070.0) && (wipJS > 1120.0) && (wipJS > 1177.5) && (wipJS > 1239.0))  { ruleCode = 0.132 ; }
    return ruleCode; }
public static double checkDT214Tree6Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 0.5) && (wipJS <= 3559.5) && (wipJS > 3413.0) && (wipJS > 3422.5) && (wipJS <= 3534.5))  { ruleCode = 0.028 ; }
    return ruleCode; }
public static double checkDT214Tree6Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 0.5) && (eTardJS > 5309.75) && (eTardJS > 36236.25) && (eTardJS <= 175445.25) && (wipJS <= 2610.0))  { ruleCode = 0.626 ; }
    return ruleCode; }
public static double checkDT214Tree6Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 0.5) && (wipJS > 3559.5) && (wipJS > 4546.5) && (wipJS <= 6276.0) && (wipJS > 5575.0))  { ruleCode = 0.053 ; }
    return ruleCode; }
public static double checkDT214Tree6Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS <= 1070.0) && (wipJS <= 1048.0) && (wipJS > 750.5) && (wipJS > 821.5))  { ruleCode = 0.15 ; }
    return ruleCode; }
public static double checkDT214Tree6Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 0.5) && (wipJS > 3559.5) && (wipJS > 4546.5) && (wipJS > 6276.0) && (wipJS > 6435.5))  { ruleCode = 0.053 ; }
    return ruleCode; }
public static double checkDT214Tree6Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 0.5) && (eTardJS <= 5309.75) && (eTardJS <= 1155.5) && (wipJS <= 4485.5) && (eTardJS <= 4.5))  { ruleCode = 0.336 ; }
    return ruleCode; }
public static double checkDT214Tree6Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS > 1070.0) && (wipJS > 1120.0) && (wipJS > 1177.5) && (wipJS <= 1239.0))  { ruleCode = 0.401 ; }
    return ruleCode; }
public static double checkDT214Tree6Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS > 1070.0) && (wipJS > 1120.0) && (wipJS <= 1177.5))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT214Tree6Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 0.5) && (eTardJS <= 5309.75) && (eTardJS > 1155.5) && (wipJS <= 4684.0) && (eTardJS > 5258.75))  { ruleCode = 0.088 ; }
    return ruleCode; }
public static double checkDT214Tree6Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 0.5) && (wipJS <= 3559.5) && (wipJS > 3413.0) && (wipJS > 3422.5) && (wipJS > 3534.5))  { ruleCode = 10.2 ; }
    return ruleCode; }
public static double checkDT214Tree6Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS > 1070.0) && (wipJS <= 1120.0) && (wipJS <= 1117.0) && (eTardJS <= 118.5))  { ruleCode = 0.355 ; }
    return ruleCode; }
public static double checkDT214Tree6Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 0.5) && (wipJS <= 3559.5) && (wipJS <= 3413.0) && (wipJS > 1886.5) && (wipJS <= 1888.5))  { ruleCode = 54.516 ; }
    return ruleCode; }
public static double checkDT214Tree6Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 0.5) && (wipJS <= 3559.5) && (wipJS > 3413.0) && (wipJS <= 3422.5))  { ruleCode = 30.134 ; }
    return ruleCode; }
public static double checkDT214Tree6Path33(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 0.5) && (wipJS > 3559.5) && (wipJS > 4546.5) && (wipJS > 6276.0) && (wipJS <= 6435.5))  { ruleCode = 0.412 ; }
    return ruleCode; }
public static double checkDT214Tree6Path34(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS > 1070.0) && (wipJS <= 1120.0) && (wipJS > 1117.0))  { ruleCode = 4.625 ; }
    return ruleCode; }
public static double checkDT214Tree6Path35(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS > 1070.0) && (wipJS <= 1120.0) && (wipJS <= 1117.0) && (eTardJS > 118.5))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT214Tree6Path36(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS > 0.5) && (eTardJS > 5309.75) && (eTardJS > 36236.25) && (eTardJS > 175445.25) && (eTardJS <= 175896.25))  { ruleCode = 1.278 ; }
    return ruleCode; }
public static double checkDT214Tree6Path37(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS <= 1070.0) && (wipJS > 1048.0))  { ruleCode = 33.0 ; }
    return ruleCode; }
public static double checkDT214Tree6Path38(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1302.5) && (eTardJS <= 0.5) && (wipJS > 3559.5) && (wipJS <= 4546.5) && (wipJS > 4544.0))  { ruleCode = 17.0 ; }
    return ruleCode; }
public static double checkDT214Tree6Path39(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS <= 1070.0) && (wipJS <= 1048.0) && (wipJS > 750.5) && (wipJS <= 821.5))  { ruleCode = 0.889 ; }
    return ruleCode; }
public static double checkDT214Tree6Path40(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS <= 1297.0) && (wipJS <= 1070.0) && (wipJS <= 1048.0) && (wipJS <= 750.5) && (wipJS > 374.0))  { ruleCode = 3.0 ; }
    return ruleCode; }
public static double checkDT214Tree6Path41(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1302.5) && (wipJS > 1297.0))  { ruleCode = 29.5 ; }
    return ruleCode; }
public static double checkDT214Tree7Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1119.0) && (wipJS <= 1027.5) && (wipJS <= 335.0))  { ruleCode = 3.386 ; }
    return ruleCode; }
public static double checkDT214Tree7Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS > 0.5) && (eTardJS > 4878.25) && (eTardJS > 21338.0) && (eTardJS <= 118000.0) && (wipJS <= 5921.0))  { ruleCode = 0.434 ; }
    return ruleCode; }
public static double checkDT214Tree7Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS > 0.5) && (eTardJS > 4878.25) && (eTardJS <= 21338.0) && (eTardJS <= 12071.0) && (wipJS <= 4322.5))  { ruleCode = 0.335 ; }
    return ruleCode; }
public static double checkDT214Tree7Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS > 0.5) && (eTardJS <= 4878.25) && (eTardJS > 529.25) && (wipJS <= 4786.0) && (eTardJS > 2036.75))  { ruleCode = 0.237 ; }
    return ruleCode; }
public static double checkDT214Tree7Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS > 0.5) && (eTardJS <= 4878.25) && (eTardJS > 529.25) && (wipJS <= 4786.0) && (eTardJS <= 2036.75))  { ruleCode = 0.186 ; }
    return ruleCode; }
public static double checkDT214Tree7Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS <= 0.5) && (wipJS <= 3206.5) && (wipJS <= 3204.0) && (wipJS > 1883.0) && (wipJS > 1889.5))  { ruleCode = 0.875 ; }
    return ruleCode; }
public static double checkDT214Tree7Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS > 0.5) && (eTardJS <= 4878.25) && (eTardJS <= 529.25) && (wipJS <= 4564.0) && (wipJS <= 2815.5))  { ruleCode = 0.077 ; }
    return ruleCode; }
public static double checkDT214Tree7Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS > 0.5) && (eTardJS > 4878.25) && (eTardJS <= 21338.0) && (eTardJS > 12071.0) && (wipJS > 2781.0))  { ruleCode = 0.356 ; }
    return ruleCode; }
public static double checkDT214Tree7Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS > 0.5) && (eTardJS > 4878.25) && (eTardJS > 21338.0) && (eTardJS <= 118000.0) && (wipJS > 5921.0))  { ruleCode = 0.391 ; }
    return ruleCode; }
public static double checkDT214Tree7Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS > 0.5) && (eTardJS <= 4878.25) && (eTardJS <= 529.25) && (wipJS <= 4564.0) && (wipJS > 2815.5))  { ruleCode = 0.119 ; }
    return ruleCode; }
public static double checkDT214Tree7Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS > 0.5) && (eTardJS > 4878.25) && (eTardJS <= 21338.0) && (eTardJS <= 12071.0) && (wipJS > 4322.5))  { ruleCode = 0.27 ; }
    return ruleCode; }
public static double checkDT214Tree7Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS > 0.5) && (eTardJS > 4878.25) && (eTardJS > 21338.0) && (eTardJS > 118000.0) && (wipJS > 4126.0))  { ruleCode = 0.523 ; }
    return ruleCode; }
public static double checkDT214Tree7Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS <= 0.5) && (wipJS > 3206.5) && (wipJS > 3685.0) && (wipJS > 4138.0) && (wipJS <= 5250.5))  { ruleCode = 0.003 ; }
    return ruleCode; }
public static double checkDT214Tree7Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS > 0.5) && (eTardJS <= 4878.25) && (eTardJS > 529.25) && (wipJS > 4786.0) && (eTardJS <= 4031.5))  { ruleCode = 0.093 ; }
    return ruleCode; }
public static double checkDT214Tree7Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS <= 0.5) && (wipJS <= 3206.5) && (wipJS <= 3204.0) && (wipJS <= 1883.0) && (wipJS > 1579.0))  { ruleCode = 0.064 ; }
    return ruleCode; }
public static double checkDT214Tree7Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS <= 0.5) && (wipJS <= 3206.5) && (wipJS <= 3204.0) && (wipJS <= 1883.0) && (wipJS <= 1579.0))  { ruleCode = 0.317 ; }
    return ruleCode; }
public static double checkDT214Tree7Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS > 0.5) && (eTardJS > 4878.25) && (eTardJS <= 21338.0) && (eTardJS > 12071.0) && (wipJS <= 2781.0))  { ruleCode = 0.431 ; }
    return ruleCode; }
public static double checkDT214Tree7Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS > 0.5) && (eTardJS <= 4878.25) && (eTardJS <= 529.25) && (wipJS > 4564.0) && (wipJS <= 6582.5))  { ruleCode = 0.022 ; }
    return ruleCode; }
public static double checkDT214Tree7Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS <= 0.5) && (wipJS > 3206.5) && (wipJS > 3685.0) && (wipJS <= 4138.0) && (wipJS <= 4130.0))  { ruleCode = 0.024 ; }
    return ruleCode; }
public static double checkDT214Tree7Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS <= 0.5) && (wipJS > 3206.5) && (wipJS <= 3685.0) && (wipJS <= 3548.0) && (wipJS > 3303.5))  { ruleCode = 0.026 ; }
    return ruleCode; }
public static double checkDT214Tree7Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS <= 0.5) && (wipJS > 3206.5) && (wipJS > 3685.0) && (wipJS > 4138.0) && (wipJS > 5250.5))  { ruleCode = 0.027 ; }
    return ruleCode; }
public static double checkDT214Tree7Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS > 0.5) && (eTardJS > 4878.25) && (eTardJS > 21338.0) && (eTardJS > 118000.0) && (wipJS <= 4126.0))  { ruleCode = 0.713 ; }
    return ruleCode; }
public static double checkDT214Tree7Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS <= 0.5) && (wipJS > 3206.5) && (wipJS <= 3685.0) && (wipJS <= 3548.0) && (wipJS <= 3303.5))  { ruleCode = 0.193 ; }
    return ruleCode; }
public static double checkDT214Tree7Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS <= 0.5) && (wipJS > 3206.5) && (wipJS <= 3685.0) && (wipJS > 3548.0) && (wipJS > 3565.5))  { ruleCode = 0.298 ; }
    return ruleCode; }
public static double checkDT214Tree7Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS > 0.5) && (eTardJS <= 4878.25) && (eTardJS > 529.25) && (wipJS > 4786.0) && (eTardJS > 4031.5))  { ruleCode = 0.274 ; }
    return ruleCode; }
public static double checkDT214Tree7Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1119.0) && (wipJS <= 1027.5) && (wipJS > 335.0) && (wipJS > 927.5) && (eTardJS <= 39.25))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT214Tree7Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1119.0) && (wipJS <= 1027.5) && (wipJS > 335.0) && (wipJS <= 927.5) && (wipJS <= 913.0) && (wipJS > 780.0))  { ruleCode = 0.134 ; }
    return ruleCode; }
public static double checkDT214Tree7Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS > 0.5) && (eTardJS <= 4878.25) && (eTardJS <= 529.25) && (wipJS > 4564.0) && (wipJS > 6582.5))  { ruleCode = 0.203 ; }
    return ruleCode; }
public static double checkDT214Tree7Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS <= 0.5) && (wipJS <= 3206.5) && (wipJS <= 3204.0) && (wipJS > 1883.0) && (wipJS <= 1889.5))  { ruleCode = 54.516 ; }
    return ruleCode; }
public static double checkDT214Tree7Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS <= 0.5) && (wipJS <= 3206.5) && (wipJS > 3204.0))  { ruleCode = 49.398 ; }
    return ruleCode; }
public static double checkDT214Tree7Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS <= 0.5) && (wipJS > 3206.5) && (wipJS <= 3685.0) && (wipJS > 3548.0) && (wipJS <= 3565.5))  { ruleCode = 3.75 ; }
    return ruleCode; }
public static double checkDT214Tree7Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1119.0) && (eTardJS <= 0.5) && (wipJS > 3206.5) && (wipJS > 3685.0) && (wipJS <= 4138.0) && (wipJS > 4130.0))  { ruleCode = 2.578 ; }
    return ruleCode; }
public static double checkDT214Tree7Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1119.0) && (wipJS > 1027.5) && (wipJS > 1084.5) && (eTardJS <= 158.0))  { ruleCode = 0.421 ; }
    return ruleCode; }
public static double checkDT214Tree7Path33(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1119.0) && (wipJS > 1027.5) && (wipJS <= 1084.5))  { ruleCode = 33.0 ; }
    return ruleCode; }
public static double checkDT214Tree7Path34(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1119.0) && (wipJS <= 1027.5) && (wipJS > 335.0) && (wipJS > 927.5) && (eTardJS > 39.25))  { ruleCode = 0.319 ; }
    return ruleCode; }
public static double checkDT214Tree7Path35(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1119.0) && (wipJS <= 1027.5) && (wipJS > 335.0) && (wipJS <= 927.5) && (wipJS > 913.0) && (wipJS > 923.0))  { ruleCode = 0.245 ; }
    return ruleCode; }
public static double checkDT214Tree7Path36(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1119.0) && (wipJS <= 1027.5) && (wipJS > 335.0) && (wipJS <= 927.5) && (wipJS > 913.0) && (wipJS <= 923.0))  { ruleCode = 0.739 ; }
    return ruleCode; }
public static double checkDT214Tree7Path37(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1119.0) && (wipJS <= 1027.5) && (wipJS > 335.0) && (wipJS <= 927.5) && (wipJS <= 913.0) && (wipJS <= 780.0))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT214Tree7Path38(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1119.0) && (wipJS > 1027.5) && (wipJS > 1084.5) && (eTardJS > 158.0))  { ruleCode = 4.625 ; }
    return ruleCode; }
public static double checkDT214Tree8Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1084.5) && (eTardJS > 0.75) && (eTardJS > 4910.75) && (eTardJS > 21593.5) && (eTardJS <= 167500.25) && (wipJS > 2871.0))  { ruleCode = 0.423 ; }
    return ruleCode; }
public static double checkDT214Tree8Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1084.5) && (wipJS <= 1027.0) && (wipJS <= 750.5) && (wipJS <= 374.0))  { ruleCode = 3.421 ; }
    return ruleCode; }
public static double checkDT214Tree8Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1084.5) && (eTardJS > 0.75) && (eTardJS <= 4910.75) && (wipJS > 1127.5) && (eTardJS > 896.0) && (wipJS <= 4786.0))  { ruleCode = 0.22 ; }
    return ruleCode; }
public static double checkDT214Tree8Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1084.5) && (eTardJS <= 0.75) && (wipJS > 1917.5) && (wipJS > 1930.5) && (wipJS > 2690.0) && (wipJS > 2696.0))  { ruleCode = 1.035 ; }
    return ruleCode; }
public static double checkDT214Tree8Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1084.5) && (eTardJS > 0.75) && (eTardJS > 4910.75) && (eTardJS <= 21593.5) && (eTardJS <= 12979.75) && (wipJS <= 4379.5))  { ruleCode = 0.325 ; }
    return ruleCode; }
public static double checkDT214Tree8Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1084.5) && (eTardJS > 0.75) && (eTardJS <= 4910.75) && (wipJS > 1127.5) && (eTardJS <= 896.0) && (eTardJS <= 230.5))  { ruleCode = 0.079 ; }
    return ruleCode; }
public static double checkDT214Tree8Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1084.5) && (eTardJS > 0.75) && (eTardJS <= 4910.75) && (wipJS > 1127.5) && (eTardJS <= 896.0) && (eTardJS > 230.5))  { ruleCode = 0.129 ; }
    return ruleCode; }
public static double checkDT214Tree8Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1084.5) && (eTardJS > 0.75) && (eTardJS > 4910.75) && (eTardJS <= 21593.5) && (eTardJS > 12979.75) && (wipJS > 3226.5))  { ruleCode = 0.349 ; }
    return ruleCode; }
public static double checkDT214Tree8Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1084.5) && (eTardJS <= 0.75) && (wipJS > 1917.5) && (wipJS > 1930.5) && (wipJS <= 2690.0) && (wipJS > 2023.5))  { ruleCode = 0.209 ; }
    return ruleCode; }
public static double checkDT214Tree8Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1084.5) && (eTardJS > 0.75) && (eTardJS > 4910.75) && (eTardJS <= 21593.5) && (eTardJS <= 12979.75) && (wipJS > 4379.5))  { ruleCode = 0.243 ; }
    return ruleCode; }
public static double checkDT214Tree8Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1084.5) && (eTardJS > 0.75) && (eTardJS <= 4910.75) && (wipJS > 1127.5) && (eTardJS > 896.0) && (wipJS > 4786.0))  { ruleCode = 0.125 ; }
    return ruleCode; }
public static double checkDT214Tree8Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1084.5) && (eTardJS > 0.75) && (eTardJS > 4910.75) && (eTardJS > 21593.5) && (eTardJS <= 167500.25) && (wipJS <= 2871.0))  { ruleCode = 0.481 ; }
    return ruleCode; }
public static double checkDT214Tree8Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1084.5) && (eTardJS > 0.75) && (eTardJS > 4910.75) && (eTardJS <= 21593.5) && (eTardJS > 12979.75) && (wipJS <= 3226.5))  { ruleCode = 0.407 ; }
    return ruleCode; }
public static double checkDT214Tree8Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1084.5) && (eTardJS <= 0.75) && (wipJS <= 1917.5) && (wipJS > 1579.0) && (wipJS <= 1893.5) && (wipJS <= 1883.0))  { ruleCode = 0.007 ; }
    return ruleCode; }
public static double checkDT214Tree8Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1084.5) && (eTardJS <= 0.75) && (wipJS <= 1917.5) && (wipJS <= 1579.0) && (wipJS <= 1565.5) && (wipJS > 1235.0))  { ruleCode = 0.102 ; }
    return ruleCode; }
public static double checkDT214Tree8Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1084.5) && (eTardJS > 0.75) && (eTardJS > 4910.75) && (eTardJS > 21593.5) && (eTardJS > 167500.25) && (wipJS > 4233.5))  { ruleCode = 0.569 ; }
    return ruleCode; }
public static double checkDT214Tree8Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1084.5) && (eTardJS <= 0.75) && (wipJS > 1917.5) && (wipJS > 1930.5) && (wipJS <= 2690.0) && (wipJS <= 2023.5))  { ruleCode = 1.603 ; }
    return ruleCode; }
public static double checkDT214Tree8Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1084.5) && (eTardJS <= 0.75) && (wipJS <= 1917.5) && (wipJS <= 1579.0) && (wipJS <= 1565.5) && (wipJS <= 1235.0))  { ruleCode = 0.409 ; }
    return ruleCode; }
public static double checkDT214Tree8Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1084.5) && (eTardJS <= 0.75) && (wipJS <= 1917.5) && (wipJS <= 1579.0) && (wipJS > 1565.5) && (wipJS > 1569.0))  { ruleCode = 0.364 ; }
    return ruleCode; }
public static double checkDT214Tree8Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1084.5) && (eTardJS <= 0.75) && (wipJS <= 1917.5) && (wipJS > 1579.0) && (wipJS <= 1893.5) && (wipJS > 1883.0))  { ruleCode = 0.095 ; }
    return ruleCode; }
public static double checkDT214Tree8Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1084.5) && (eTardJS > 0.75) && (eTardJS > 4910.75) && (eTardJS > 21593.5) && (eTardJS > 167500.25) && (wipJS <= 4233.5))  { ruleCode = 0.8 ; }
    return ruleCode; }
public static double checkDT214Tree8Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1084.5) && (eTardJS <= 0.75) && (wipJS <= 1917.5) && (wipJS > 1579.0) && (wipJS > 1893.5) && (wipJS <= 1900.5))  { ruleCode = 0.492 ; }
    return ruleCode; }
public static double checkDT214Tree8Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1084.5) && (eTardJS <= 0.75) && (wipJS <= 1917.5) && (wipJS > 1579.0) && (wipJS > 1893.5) && (wipJS > 1900.5))  { ruleCode = 0.054 ; }
    return ruleCode; }
public static double checkDT214Tree8Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1084.5) && (wipJS <= 1027.0) && (wipJS > 750.5) && (wipJS > 821.5) && (wipJS > 927.5))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT214Tree8Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1084.5) && (wipJS <= 1027.0) && (wipJS > 750.5) && (wipJS > 821.5) && (wipJS <= 927.5) && (wipJS > 913.0))  { ruleCode = 0.492 ; }
    return ruleCode; }
public static double checkDT214Tree8Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1084.5) && (wipJS <= 1027.0) && (wipJS > 750.5) && (wipJS > 821.5) && (wipJS <= 927.5) && (wipJS <= 913.0))  { ruleCode = 0.15 ; }
    return ruleCode; }
public static double checkDT214Tree8Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1084.5) && (eTardJS <= 0.75) && (wipJS > 1917.5) && (wipJS > 1930.5) && (wipJS > 2690.0) && (wipJS <= 2696.0))  { ruleCode = 56.0 ; }
    return ruleCode; }
public static double checkDT214Tree8Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1084.5) && (eTardJS <= 0.75) && (wipJS <= 1917.5) && (wipJS <= 1579.0) && (wipJS > 1565.5) && (wipJS <= 1569.0))  { ruleCode = 6.0 ; }
    return ruleCode; }
public static double checkDT214Tree8Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1084.5) && (eTardJS <= 0.75) && (wipJS > 1917.5) && (wipJS <= 1930.5))  { ruleCode = 55.0 ; }
    return ruleCode; }
public static double checkDT214Tree8Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1084.5) && (wipJS > 1027.0))  { ruleCode = 33.0 ; }
    return ruleCode; }
public static double checkDT214Tree8Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1084.5) && (wipJS <= 1027.0) && (wipJS > 750.5) && (wipJS <= 821.5))  { ruleCode = 0.889 ; }
    return ruleCode; }
public static double checkDT214Tree8Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 1084.5) && (wipJS <= 1027.0) && (wipJS <= 750.5) && (wipJS > 374.0))  { ruleCode = 3.0 ; }
    return ruleCode; }
public static double checkDT214Tree8Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 1084.5) && (eTardJS > 0.75) && (eTardJS <= 4910.75) && (wipJS <= 1127.5))  { ruleCode = 4.625 ; }
    return ruleCode; }
public static double checkDT214Tree9Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS > 1.25) && (eTardJS > 5850.75) && (eTardJS <= 89090.5) && (eTardJS > 12979.75) && (eTardJS > 22992.5))  { ruleCode = 0.423 ; }
    return ruleCode; }
public static double checkDT214Tree9Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS <= 335.0))  { ruleCode = 2.608 ; }
    return ruleCode; }
public static double checkDT214Tree9Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS > 1.25) && (eTardJS <= 5850.75) && (eTardJS <= 1283.5) && (eTardJS <= 473.5) && (eTardJS > 17.5))  { ruleCode = 0.08 ; }
    return ruleCode; }
public static double checkDT214Tree9Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS > 1.25) && (eTardJS > 5850.75) && (eTardJS <= 89090.5) && (eTardJS > 12979.75) && (eTardJS <= 22992.5))  { ruleCode = 0.38 ; }
    return ruleCode; }
public static double checkDT214Tree9Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS > 1.25) && (eTardJS <= 5850.75) && (eTardJS > 1283.5) && (wipJS <= 4782.0) && (eTardJS <= 3229.25))  { ruleCode = 0.209 ; }
    return ruleCode; }
public static double checkDT214Tree9Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS > 1.25) && (eTardJS > 5850.75) && (eTardJS <= 89090.5) && (eTardJS <= 12979.75) && (wipJS > 2667.0))  { ruleCode = 0.303 ; }
    return ruleCode; }
public static double checkDT214Tree9Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS > 1.25) && (eTardJS <= 5850.75) && (eTardJS > 1283.5) && (wipJS <= 4782.0) && (eTardJS > 3229.25))  { ruleCode = 0.277 ; }
    return ruleCode; }
public static double checkDT214Tree9Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS <= 1.25) && (wipJS <= 3539.0) && (wipJS <= 3533.0) && (wipJS <= 2690.0) && (wipJS <= 2023.5))  { ruleCode = 0.841 ; }
    return ruleCode; }
public static double checkDT214Tree9Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS <= 1.25) && (wipJS <= 3539.0) && (wipJS <= 3533.0) && (wipJS <= 2690.0) && (wipJS > 2023.5))  { ruleCode = 0.237 ; }
    return ruleCode; }
public static double checkDT214Tree9Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS > 1.25) && (eTardJS <= 5850.75) && (eTardJS <= 1283.5) && (eTardJS > 473.5) && (eTardJS <= 950.75))  { ruleCode = 0.155 ; }
    return ruleCode; }
public static double checkDT214Tree9Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS <= 1.25) && (wipJS <= 3539.0) && (wipJS <= 3533.0) && (wipJS > 2690.0) && (wipJS > 2698.5))  { ruleCode = 0.941 ; }
    return ruleCode; }
public static double checkDT214Tree9Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS <= 1.25) && (wipJS > 3539.0) && (wipJS > 4100.0) && (wipJS <= 5636.5) && (wipJS > 4141.0))  { ruleCode = 0.01 ; }
    return ruleCode; }
public static double checkDT214Tree9Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS > 1.25) && (eTardJS > 5850.75) && (eTardJS <= 89090.5) && (eTardJS <= 12979.75) && (wipJS <= 2667.0))  { ruleCode = 0.356 ; }
    return ruleCode; }
public static double checkDT214Tree9Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS > 1.25) && (eTardJS > 5850.75) && (eTardJS > 89090.5) && (eTardJS <= 167167.25) && (wipJS > 4156.5))  { ruleCode = 0.485 ; }
    return ruleCode; }
public static double checkDT214Tree9Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS > 1.25) && (eTardJS <= 5850.75) && (eTardJS <= 1283.5) && (eTardJS > 473.5) && (eTardJS > 950.75))  { ruleCode = 0.11 ; }
    return ruleCode; }
public static double checkDT214Tree9Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS <= 1.25) && (wipJS > 3539.0) && (wipJS <= 4100.0) && (wipJS <= 4097.5) && (wipJS > 3676.0))  { ruleCode = 0.028 ; }
    return ruleCode; }
public static double checkDT214Tree9Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS > 1.25) && (eTardJS <= 5850.75) && (eTardJS > 1283.5) && (wipJS > 4782.0) && (eTardJS <= 3963.5))  { ruleCode = 0.123 ; }
    return ruleCode; }
public static double checkDT214Tree9Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS > 1.25) && (eTardJS > 5850.75) && (eTardJS > 89090.5) && (eTardJS > 167167.25) && (wipJS > 4397.0))  { ruleCode = 0.601 ; }
    return ruleCode; }
public static double checkDT214Tree9Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS > 1.25) && (eTardJS <= 5850.75) && (eTardJS <= 1283.5) && (eTardJS <= 473.5) && (eTardJS <= 17.5))  { ruleCode = 0.167 ; }
    return ruleCode; }
public static double checkDT214Tree9Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS > 1.25) && (eTardJS <= 5850.75) && (eTardJS > 1283.5) && (wipJS > 4782.0) && (eTardJS > 3963.5))  { ruleCode = 0.195 ; }
    return ruleCode; }
public static double checkDT214Tree9Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS > 1.25) && (eTardJS > 5850.75) && (eTardJS > 89090.5) && (eTardJS <= 167167.25) && (wipJS <= 4156.5))  { ruleCode = 0.603 ; }
    return ruleCode; }
public static double checkDT214Tree9Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS <= 1.25) && (wipJS > 3539.0) && (wipJS > 4100.0) && (wipJS > 5636.5) && (wipJS <= 7589.5))  { ruleCode = 0.088 ; }
    return ruleCode; }
public static double checkDT214Tree9Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS <= 1.25) && (wipJS > 3539.0) && (wipJS <= 4100.0) && (wipJS <= 4097.5) && (wipJS <= 3676.0))  { ruleCode = 0.236 ; }
    return ruleCode; }
public static double checkDT214Tree9Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS > 1.25) && (eTardJS > 5850.75) && (eTardJS > 89090.5) && (eTardJS > 167167.25) && (wipJS <= 4397.0))  { ruleCode = 0.991 ; }
    return ruleCode; }
public static double checkDT214Tree9Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS <= 1.25) && (wipJS > 3539.0) && (wipJS > 4100.0) && (wipJS <= 5636.5) && (wipJS <= 4141.0))  { ruleCode = 0.035 ; }
    return ruleCode; }
public static double checkDT214Tree9Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS <= 1.25) && (wipJS <= 3539.0) && (wipJS <= 3533.0) && (wipJS > 2690.0) && (wipJS <= 2698.5))  { ruleCode = 28.0 ; }
    return ruleCode; }
public static double checkDT214Tree9Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS <= 1.25) && (wipJS > 3539.0) && (wipJS <= 4100.0) && (wipJS > 4097.5))  { ruleCode = 7.053 ; }
    return ruleCode; }
public static double checkDT214Tree9Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS <= 1.25) && (wipJS <= 3539.0) && (wipJS > 3533.0))  { ruleCode = 23.0 ; }
    return ruleCode; }
public static double checkDT214Tree9Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((wipJS > 335.0) && (eTardJS <= 1.25) && (wipJS > 3539.0) && (wipJS > 4100.0) && (wipJS > 5636.5) && (wipJS > 7589.5))  { ruleCode = 0.205 ; }
    return ruleCode; }
public static double checkDT508Tree0Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 2704.5) && (wipJS <= 1951.5) && (wipJS <= 1341.0) && (wipJS <= 335.0))  { ruleCode = 3.606 ; }
    return ruleCode; }
public static double checkDT508Tree0Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 1065.5) && (eTardJS > 3381.0) && (eTardJS > 12953.25) && (eTardJS > 21531.25) && (eTardJS <= 67422.25))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT508Tree0Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 1065.5) && (eTardJS > 3381.0) && (eTardJS <= 12953.25) && (eTardJS <= 12945.75) && (wipJS <= 3564.5))  { ruleCode = 0.005 ; }
    return ruleCode; }
public static double checkDT508Tree0Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 1065.5) && (eTardJS > 3381.0) && (eTardJS > 12953.25) && (eTardJS > 21531.25) && (eTardJS > 67422.25))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT508Tree0Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 1065.5) && (eTardJS > 3381.0) && (eTardJS <= 12953.25) && (eTardJS <= 12945.75) && (wipJS > 3564.5))  { ruleCode = 0.015 ; }
    return ruleCode; }
public static double checkDT508Tree0Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 1065.5) && (eTardJS > 3381.0) && (eTardJS > 12953.25) && (eTardJS <= 21531.25) && (eTardJS <= 21510.0))  { ruleCode = 0.001 ; }
    return ruleCode; }
public static double checkDT508Tree0Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 1065.5) && (eTardJS <= 3381.0) && (wipJS <= 4087.0) && (eTardJS <= 3336.25) && (eTardJS > 1316.25))  { ruleCode = 0.027 ; }
    return ruleCode; }
public static double checkDT508Tree0Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 1065.5) && (eTardJS > 236.5) && (eTardJS <= 1019.25) && (wipJS <= 4068.0) && (eTardJS > 248.5))  { ruleCode = 0.111 ; }
    return ruleCode; }
public static double checkDT508Tree0Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 2704.5) && (wipJS > 2710.0) && (wipJS <= 4291.0) && (wipJS <= 4283.5) && (wipJS <= 3827.5))  { ruleCode = 17.403 ; }
    return ruleCode; }
public static double checkDT508Tree0Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 2704.5) && (wipJS <= 1951.5) && (wipJS > 1341.0) && (wipJS > 1404.5) && (wipJS <= 1941.5))  { ruleCode = 6.312 ; }
    return ruleCode; }
public static double checkDT508Tree0Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 2704.5) && (wipJS > 2710.0) && (wipJS > 4291.0) && (wipJS <= 5325.0) && (wipJS > 4312.0))  { ruleCode = 0.517 ; }
    return ruleCode; }
public static double checkDT508Tree0Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 1065.5) && (eTardJS <= 236.5) && (wipJS > 2384.0) && (eTardJS <= 189.5) && (wipJS <= 4163.5))  { ruleCode = 0.15 ; }
    return ruleCode; }
public static double checkDT508Tree0Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 2704.5) && (wipJS > 1951.5) && (wipJS > 2059.0) && (wipJS > 2377.5) && (wipJS > 2378.5))  { ruleCode = 0.493 ; }
    return ruleCode; }
public static double checkDT508Tree0Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 1065.5) && (eTardJS <= 3381.0) && (wipJS > 4087.0) && (wipJS > 4271.5) && (wipJS <= 5366.0))  { ruleCode = 0.141 ; }
    return ruleCode; }
public static double checkDT508Tree0Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 2704.5) && (wipJS > 2710.0) && (wipJS <= 4291.0) && (wipJS <= 4283.5) && (wipJS > 3827.5))  { ruleCode = 38.059 ; }
    return ruleCode; }
public static double checkDT508Tree0Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 1065.5) && (eTardJS > 236.5) && (eTardJS <= 1019.25) && (wipJS > 4068.0) && (wipJS > 4270.5))  { ruleCode = 0.143 ; }
    return ruleCode; }
public static double checkDT508Tree0Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 1065.5) && (eTardJS <= 236.5) && (wipJS <= 2384.0) && (wipJS > 1988.5) && (wipJS > 1999.5))  { ruleCode = 0.315 ; }
    return ruleCode; }
public static double checkDT508Tree0Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 1065.5) && (eTardJS <= 236.5) && (wipJS > 2384.0) && (eTardJS <= 189.5) && (wipJS > 4163.5))  { ruleCode = 0.296 ; }
    return ruleCode; }
public static double checkDT508Tree0Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 2704.5) && (wipJS > 1951.5) && (wipJS > 2059.0) && (wipJS <= 2377.5) && (wipJS <= 2274.5))  { ruleCode = 0.505 ; }
    return ruleCode; }
public static double checkDT508Tree0Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 1065.5) && (eTardJS <= 236.5) && (wipJS <= 2384.0) && (wipJS <= 1988.5) && (wipJS > 1614.0))  { ruleCode = 0.287 ; }
    return ruleCode; }
public static double checkDT508Tree0Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 1065.5) && (eTardJS <= 3381.0) && (wipJS <= 4087.0) && (eTardJS <= 3336.25) && (eTardJS <= 1316.25))  { ruleCode = 0.097 ; }
    return ruleCode; }
public static double checkDT508Tree0Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 1065.5) && (eTardJS <= 3381.0) && (wipJS > 4087.0) && (wipJS > 4271.5) && (wipJS > 5366.0))  { ruleCode = 0.028 ; }
    return ruleCode; }
public static double checkDT508Tree0Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 1065.5) && (eTardJS <= 236.5) && (wipJS <= 2384.0) && (wipJS <= 1988.5) && (wipJS <= 1614.0))  { ruleCode = 0.097 ; }
    return ruleCode; }
public static double checkDT508Tree0Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 2704.5) && (wipJS > 2710.0) && (wipJS > 4291.0) && (wipJS > 5325.0) && (wipJS <= 6756.0))  { ruleCode = 0.26 ; }
    return ruleCode; }
public static double checkDT508Tree0Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 2704.5) && (wipJS > 1951.5) && (wipJS > 2059.0) && (wipJS <= 2377.5) && (wipJS > 2274.5))  { ruleCode = 0.352 ; }
    return ruleCode; }
public static double checkDT508Tree0Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 2704.5) && (wipJS > 1951.5) && (wipJS <= 2059.0) && (wipJS <= 2011.0) && (wipJS > 1959.5))  { ruleCode = 0.453 ; }
    return ruleCode; }
public static double checkDT508Tree0Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 2704.5) && (wipJS <= 1951.5) && (wipJS <= 1341.0) && (wipJS > 335.0) && (wipJS > 963.0))  { ruleCode = 0.305 ; }
    return ruleCode; }
public static double checkDT508Tree0Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 1065.5) && (eTardJS > 236.5) && (eTardJS <= 1019.25) && (wipJS > 4068.0) && (wipJS <= 4270.5))  { ruleCode = 0.409 ; }
    return ruleCode; }
public static double checkDT508Tree0Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 1065.5) && (eTardJS <= 236.5) && (wipJS > 2384.0) && (eTardJS > 189.5) && (wipJS > 3722.5))  { ruleCode = 0.327 ; }
    return ruleCode; }
public static double checkDT508Tree0Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 1065.5) && (eTardJS <= 3381.0) && (wipJS > 4087.0) && (wipJS <= 4271.5) && (wipJS <= 4225.5))  { ruleCode = 0.178 ; }
    return ruleCode; }
public static double checkDT508Tree0Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 1065.5) && (eTardJS > 236.5) && (eTardJS <= 1019.25) && (wipJS <= 4068.0) && (eTardJS <= 248.5))  { ruleCode = 0.277 ; }
    return ruleCode; }
public static double checkDT508Tree0Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 1065.5) && (eTardJS > 236.5) && (eTardJS > 1019.25) && (wipJS <= 3529.0) && (eTardJS > 1021.5))  { ruleCode = 0.082 ; }
    return ruleCode; }
public static double checkDT508Tree0Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 2704.5) && (wipJS > 1951.5) && (wipJS <= 2059.0) && (wipJS > 2011.0) && (wipJS > 2013.5))  { ruleCode = 7.282 ; }
    return ruleCode; }
public static double checkDT508Tree0Path33(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 2704.5) && (wipJS <= 1951.5) && (wipJS > 1341.0) && (wipJS <= 1404.5) && (wipJS <= 1391.0))  { ruleCode = 25.477 ; }
    return ruleCode; }
public static double checkDT508Tree0Path34(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 1065.5) && (eTardJS <= 236.5) && (wipJS > 2384.0) && (eTardJS > 189.5) && (wipJS <= 3722.5))  { ruleCode = 0.637 ; }
    return ruleCode; }
public static double checkDT508Tree0Path35(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 2704.5) && (wipJS <= 1951.5) && (wipJS <= 1341.0) && (wipJS > 335.0) && (wipJS <= 963.0))  { ruleCode = 0.023 ; }
    return ruleCode; }
public static double checkDT508Tree0Path36(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 2704.5) && (wipJS > 2710.0) && (wipJS > 4291.0) && (wipJS > 5325.0) && (wipJS > 6756.0))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT508Tree0Path37(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 2704.5) && (wipJS > 2710.0) && (wipJS > 4291.0) && (wipJS <= 5325.0) && (wipJS <= 4312.0))  { ruleCode = 0.302 ; }
    return ruleCode; }
public static double checkDT508Tree0Path38(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 1065.5) && (eTardJS > 236.5) && (eTardJS > 1019.25) && (wipJS > 3529.0) && (wipJS <= 4871.0))  { ruleCode = 0.786 ; }
    return ruleCode; }
public static double checkDT508Tree0Path39(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 1065.5) && (eTardJS > 236.5) && (eTardJS > 1019.25) && (wipJS <= 3529.0) && (eTardJS <= 1021.5))  { ruleCode = 0.739 ; }
    return ruleCode; }
public static double checkDT508Tree0Path40(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 2704.5) && (wipJS <= 1951.5) && (wipJS > 1341.0) && (wipJS > 1404.5) && (wipJS > 1941.5))  { ruleCode = 53.663 ; }
    return ruleCode; }
public static double checkDT508Tree0Path41(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 1065.5) && (eTardJS <= 3381.0) && (wipJS > 4087.0) && (wipJS <= 4271.5) && (wipJS > 4225.5))  { ruleCode = 1.836 ; }
    return ruleCode; }
public static double checkDT508Tree0Path42(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 2704.5) && (wipJS <= 1951.5) && (wipJS > 1341.0) && (wipJS <= 1404.5) && (wipJS > 1391.0))  { ruleCode = 892.0 ; }
    return ruleCode; }
public static double checkDT508Tree0Path43(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 2704.5) && (wipJS > 1951.5) && (wipJS <= 2059.0) && (wipJS <= 2011.0) && (wipJS <= 1959.5))  { ruleCode = 0.987 ; }
    return ruleCode; }
public static double checkDT508Tree0Path44(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 1065.5) && (eTardJS <= 3381.0) && (wipJS <= 4087.0) && (eTardJS > 3336.25) && (eTardJS > 3356.75))  { ruleCode = 0.049 ; }
    return ruleCode; }
public static double checkDT508Tree0Path45(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 2704.5) && (wipJS > 1951.5) && (wipJS <= 2059.0) && (wipJS > 2011.0) && (wipJS <= 2013.5))  { ruleCode = 19.0 ; }
    return ruleCode; }
public static double checkDT508Tree0Path46(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 2704.5) && (wipJS > 1951.5) && (wipJS > 2059.0) && (wipJS > 2377.5) && (wipJS <= 2378.5))  { ruleCode = 23.0 ; }
    return ruleCode; }
public static double checkDT508Tree0Path47(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 2704.5) && (wipJS <= 2710.0))  { ruleCode = 694.0 ; }
    return ruleCode; }
public static double checkDT508Tree0Path48(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 1065.5) && (eTardJS <= 3381.0) && (wipJS <= 4087.0) && (eTardJS > 3336.25) && (eTardJS <= 3356.75))  { ruleCode = 1.396 ; }
    return ruleCode; }
public static double checkDT508Tree0Path49(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 2704.5) && (wipJS > 2710.0) && (wipJS <= 4291.0) && (wipJS > 4283.5))  { ruleCode = 398.0 ; }
    return ruleCode; }
public static double checkDT508Tree0Path50(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 1065.5) && (eTardJS > 236.5) && (eTardJS > 1019.25) && (wipJS > 3529.0) && (wipJS > 4871.0))  { ruleCode = 0.285 ; }
    return ruleCode; }
public static double checkDT508Tree0Path51(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 1065.5) && (eTardJS <= 236.5) && (wipJS <= 2384.0) && (wipJS > 1988.5) && (wipJS <= 1999.5))  { ruleCode = 6.889 ; }
    return ruleCode; }
public static double checkDT508Tree0Path52(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 1065.5) && (eTardJS > 3381.0) && (eTardJS > 12953.25) && (eTardJS <= 21531.25) && (eTardJS > 21510.0))  { ruleCode = 0.031 ; }
    return ruleCode; }
public static double checkDT508Tree0Path53(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 1065.5) && (eTardJS > 3381.0) && (eTardJS <= 12953.25) && (eTardJS > 12945.75))  { ruleCode = 0.185 ; }
    return ruleCode; }
public static double checkDT508Tree1Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 811.5) && (eTardJS > 3499.0) && (eTardJS > 5992.75) && (eTardJS > 11694.75) && (eTardJS > 18029.5))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT508Tree1Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 1341.0) && (wipJS <= 335.0))  { ruleCode = 6.692 ; }
    return ruleCode; }
public static double checkDT508Tree1Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 1341.0) && (wipJS > 1407.0) && (wipJS > 1955.5) && (wipJS <= 4289.5) && (wipJS <= 4281.0))  { ruleCode = 12.669 ; }
    return ruleCode; }
public static double checkDT508Tree1Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 811.5) && (eTardJS > 3499.0) && (eTardJS > 5992.75) && (eTardJS <= 11694.75) && (eTardJS <= 11429.25))  { ruleCode = 0.004 ; }
    return ruleCode; }
public static double checkDT508Tree1Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 811.5) && (eTardJS > 3499.0) && (eTardJS > 5992.75) && (eTardJS > 11694.75) && (eTardJS <= 18029.5))  { ruleCode = 0.002 ; }
    return ruleCode; }
public static double checkDT508Tree1Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 811.5) && (eTardJS <= 230.5) && (eTardJS <= 227.75) && (wipJS > 1637.5) && (wipJS > 2010.5))  { ruleCode = 0.239 ; }
    return ruleCode; }
public static double checkDT508Tree1Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 811.5) && (eTardJS > 3499.0) && (eTardJS <= 5992.75) && (eTardJS <= 5819.0) && (eTardJS > 4142.75))  { ruleCode = 0.011 ; }
    return ruleCode; }
public static double checkDT508Tree1Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 811.5) && (eTardJS <= 3499.0) && (eTardJS > 1340.5) && (wipJS > 2938.0) && (wipJS > 2962.5))  { ruleCode = 0.075 ; }
    return ruleCode; }
public static double checkDT508Tree1Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 811.5) && (eTardJS <= 3499.0) && (eTardJS > 1340.5) && (wipJS <= 2938.0) && (eTardJS <= 3203.25))  { ruleCode = 0.02 ; }
    return ruleCode; }
public static double checkDT508Tree1Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 811.5) && (eTardJS > 230.5) && (wipJS <= 3476.0) && (wipJS > 2013.0) && (wipJS > 2076.5))  { ruleCode = 0.12 ; }
    return ruleCode; }
public static double checkDT508Tree1Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 811.5) && (eTardJS > 230.5) && (wipJS > 3476.0) && (wipJS > 3503.5) && (eTardJS <= 808.25))  { ruleCode = 0.219 ; }
    return ruleCode; }
public static double checkDT508Tree1Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 1341.0) && (wipJS > 1407.0) && (wipJS > 1955.5) && (wipJS > 4289.5) && (wipJS <= 4870.0))  { ruleCode = 0.572 ; }
    return ruleCode; }
public static double checkDT508Tree1Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 1341.0) && (wipJS > 1407.0) && (wipJS <= 1955.5) && (wipJS <= 1951.5) && (wipJS <= 1729.5))  { ruleCode = 3.667 ; }
    return ruleCode; }
public static double checkDT508Tree1Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 1341.0) && (wipJS > 1407.0) && (wipJS <= 1955.5) && (wipJS <= 1951.5) && (wipJS > 1729.5))  { ruleCode = 24.86 ; }
    return ruleCode; }
public static double checkDT508Tree1Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 1341.0) && (wipJS > 1407.0) && (wipJS > 1955.5) && (wipJS > 4289.5) && (wipJS > 4870.0))  { ruleCode = 0.323 ; }
    return ruleCode; }
public static double checkDT508Tree1Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 811.5) && (eTardJS > 3499.0) && (eTardJS <= 5992.75) && (eTardJS <= 5819.0) && (eTardJS <= 4142.75))  { ruleCode = 0.029 ; }
    return ruleCode; }
public static double checkDT508Tree1Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 811.5) && (eTardJS <= 230.5) && (eTardJS <= 227.75) && (wipJS > 1637.5) && (wipJS <= 2010.5))  { ruleCode = 0.451 ; }
    return ruleCode; }
public static double checkDT508Tree1Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 811.5) && (eTardJS <= 3499.0) && (eTardJS <= 1340.5) && (wipJS > 2701.5) && (wipJS <= 4264.0))  { ruleCode = 0.014 ; }
    return ruleCode; }
public static double checkDT508Tree1Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 811.5) && (eTardJS <= 3499.0) && (eTardJS <= 1340.5) && (wipJS <= 2701.5) && (wipJS > 2065.0))  { ruleCode = 0.175 ; }
    return ruleCode; }
public static double checkDT508Tree1Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 811.5) && (eTardJS <= 3499.0) && (eTardJS <= 1340.5) && (wipJS > 2701.5) && (wipJS > 4264.0))  { ruleCode = 0.099 ; }
    return ruleCode; }
public static double checkDT508Tree1Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 811.5) && (eTardJS > 230.5) && (wipJS <= 3476.0) && (wipJS <= 2013.0) && (wipJS <= 1695.0))  { ruleCode = 0.095 ; }
    return ruleCode; }
public static double checkDT508Tree1Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 811.5) && (eTardJS > 230.5) && (wipJS <= 3476.0) && (wipJS <= 2013.0) && (wipJS > 1695.0))  { ruleCode = 0.009 ; }
    return ruleCode; }
public static double checkDT508Tree1Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 811.5) && (eTardJS <= 3499.0) && (eTardJS <= 1340.5) && (wipJS <= 2701.5) && (wipJS <= 2065.0))  { ruleCode = 0.072 ; }
    return ruleCode; }
public static double checkDT508Tree1Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 811.5) && (eTardJS <= 230.5) && (eTardJS <= 227.75) && (wipJS <= 1637.5) && (eTardJS > 31.25))  { ruleCode = 0.048 ; }
    return ruleCode; }
public static double checkDT508Tree1Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 811.5) && (eTardJS <= 3499.0) && (eTardJS > 1340.5) && (wipJS <= 2938.0) && (eTardJS > 3203.25))  { ruleCode = 0.076 ; }
    return ruleCode; }
public static double checkDT508Tree1Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 1341.0) && (wipJS > 335.0) && (wipJS > 1121.0) && (wipJS > 1133.0) && (wipJS > 1183.5))  { ruleCode = 1.304 ; }
    return ruleCode; }
public static double checkDT508Tree1Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 811.5) && (eTardJS > 3499.0) && (eTardJS <= 5992.75) && (eTardJS > 5819.0) && (eTardJS > 5851.0))  { ruleCode = 0.017 ; }
    return ruleCode; }
public static double checkDT508Tree1Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 811.5) && (eTardJS > 3499.0) && (eTardJS > 5992.75) && (eTardJS <= 11694.75) && (eTardJS > 11429.25))  { ruleCode = 0.024 ; }
    return ruleCode; }
public static double checkDT508Tree1Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 1341.0) && (wipJS > 335.0) && (wipJS > 1121.0) && (wipJS > 1133.0) && (wipJS <= 1183.5))  { ruleCode = 7.238 ; }
    return ruleCode; }
public static double checkDT508Tree1Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 1341.0) && (wipJS > 335.0) && (wipJS <= 1121.0) && (wipJS <= 927.5) && (wipJS > 709.0))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT508Tree1Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 1341.0) && (wipJS > 335.0) && (wipJS <= 1121.0) && (wipJS > 927.5) && (wipJS > 1002.0))  { ruleCode = 0.186 ; }
    return ruleCode; }
public static double checkDT508Tree1Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 1341.0) && (wipJS > 1407.0) && (wipJS <= 1955.5) && (wipJS > 1951.5))  { ruleCode = 371.853 ; }
    return ruleCode; }
public static double checkDT508Tree1Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 1341.0) && (wipJS > 335.0) && (wipJS <= 1121.0) && (wipJS > 927.5) && (wipJS <= 1002.0))  { ruleCode = 0.772 ; }
    return ruleCode; }
public static double checkDT508Tree1Path33(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 1341.0) && (wipJS <= 1407.0) && (wipJS <= 1400.5) && (wipJS > 1357.0) && (wipJS > 1375.0))  { ruleCode = 0.354 ; }
    return ruleCode; }
public static double checkDT508Tree1Path34(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 811.5) && (eTardJS > 3499.0) && (eTardJS <= 5992.75) && (eTardJS > 5819.0) && (eTardJS <= 5851.0))  { ruleCode = 0.21 ; }
    return ruleCode; }
public static double checkDT508Tree1Path35(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 811.5) && (eTardJS <= 230.5) && (eTardJS <= 227.75) && (wipJS <= 1637.5) && (eTardJS <= 31.25))  { ruleCode = 0.557 ; }
    return ruleCode; }
public static double checkDT508Tree1Path36(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 811.5) && (eTardJS > 230.5) && (wipJS <= 3476.0) && (wipJS > 2013.0) && (wipJS <= 2076.5))  { ruleCode = 0.587 ; }
    return ruleCode; }
public static double checkDT508Tree1Path37(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 1341.0) && (wipJS <= 1407.0) && (wipJS <= 1400.5) && (wipJS <= 1357.0))  { ruleCode = 47.373 ; }
    return ruleCode; }
public static double checkDT508Tree1Path38(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 1341.0) && (wipJS > 335.0) && (wipJS <= 1121.0) && (wipJS <= 927.5) && (wipJS <= 709.0))  { ruleCode = 0.113 ; }
    return ruleCode; }
public static double checkDT508Tree1Path39(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 1341.0) && (wipJS > 335.0) && (wipJS > 1121.0) && (wipJS <= 1133.0))  { ruleCode = 28.0 ; }
    return ruleCode; }
public static double checkDT508Tree1Path40(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 1341.0) && (wipJS <= 1407.0) && (wipJS <= 1400.5) && (wipJS > 1357.0) && (wipJS <= 1375.0))  { ruleCode = 0.848 ; }
    return ruleCode; }
public static double checkDT508Tree1Path41(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 1341.0) && (wipJS <= 1407.0) && (wipJS > 1400.5))  { ruleCode = 892.0 ; }
    return ruleCode; }
public static double checkDT508Tree1Path42(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 811.5) && (eTardJS <= 3499.0) && (eTardJS > 1340.5) && (wipJS > 2938.0) && (wipJS <= 2962.5))  { ruleCode = 0.83 ; }
    return ruleCode; }
public static double checkDT508Tree1Path43(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 811.5) && (eTardJS > 230.5) && (wipJS > 3476.0) && (wipJS > 3503.5) && (eTardJS > 808.25))  { ruleCode = 0.712 ; }
    return ruleCode; }
public static double checkDT508Tree1Path44(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 811.5) && (eTardJS > 230.5) && (wipJS > 3476.0) && (wipJS <= 3503.5))  { ruleCode = 1.391 ; }
    return ruleCode; }
public static double checkDT508Tree1Path45(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 1341.0) && (wipJS > 1407.0) && (wipJS > 1955.5) && (wipJS <= 4289.5) && (wipJS > 4281.0))  { ruleCode = 398.0 ; }
    return ruleCode; }
public static double checkDT508Tree1Path46(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 811.5) && (eTardJS <= 230.5) && (eTardJS > 227.75))  { ruleCode = 2.053 ; }
    return ruleCode; }
public static double checkDT508Tree2Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 332.75) && (eTardJS > 2381.0) && (wipJS > 1673.0) && (eTardJS > 4263.0) && (eTardJS > 12961.25))  { ruleCode = 0.001 ; }
    return ruleCode; }
public static double checkDT508Tree2Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 1396.5) && (wipJS <= 1357.0) && (wipJS <= 1342.0) && (wipJS <= 1267.0) && (wipJS <= 1252.0))  { ruleCode = 3.599 ; }
    return ruleCode; }
public static double checkDT508Tree2Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 332.75) && (eTardJS > 2381.0) && (wipJS > 1673.0) && (eTardJS > 4263.0) && (eTardJS <= 12961.25))  { ruleCode = 0.01 ; }
    return ruleCode; }
public static double checkDT508Tree2Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 1396.5) && (wipJS > 1404.5) && (wipJS <= 4189.5) && (wipJS <= 3473.5) && (wipJS > 2059.0))  { ruleCode = 6.576 ; }
    return ruleCode; }
public static double checkDT508Tree2Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 332.75) && (eTardJS <= 2381.0) && (eTardJS <= 2364.25) && (eTardJS > 811.5) && (eTardJS <= 1951.25))  { ruleCode = 0.076 ; }
    return ruleCode; }
public static double checkDT508Tree2Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 332.75) && (eTardJS > 2381.0) && (wipJS > 1673.0) && (eTardJS <= 4263.0) && (eTardJS <= 4253.75))  { ruleCode = 0.024 ; }
    return ruleCode; }
public static double checkDT508Tree2Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 1396.5) && (wipJS > 1404.5) && (wipJS <= 4189.5) && (wipJS <= 3473.5) && (wipJS <= 2059.0))  { ruleCode = 12.816 ; }
    return ruleCode; }
public static double checkDT508Tree2Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 332.75) && (eTardJS <= 2381.0) && (eTardJS <= 2364.25) && (eTardJS <= 811.5) && (wipJS <= 4122.5))  { ruleCode = 0.114 ; }
    return ruleCode; }
public static double checkDT508Tree2Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 332.75) && (wipJS > 1942.5) && (wipJS > 2001.5) && (wipJS > 3276.0) && (wipJS > 3294.5))  { ruleCode = 0.31 ; }
    return ruleCode; }
public static double checkDT508Tree2Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 1396.5) && (wipJS > 1404.5) && (wipJS <= 4189.5) && (wipJS > 3473.5) && (wipJS > 3480.0))  { ruleCode = 17.641 ; }
    return ruleCode; }
public static double checkDT508Tree2Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 1396.5) && (wipJS > 1404.5) && (wipJS > 4189.5) && (wipJS > 4385.5) && (wipJS <= 5328.0))  { ruleCode = 0.503 ; }
    return ruleCode; }
public static double checkDT508Tree2Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 332.75) && (wipJS > 1942.5) && (wipJS > 2001.5) && (wipJS <= 3276.0) && (eTardJS > 94.0))  { ruleCode = 0.153 ; }
    return ruleCode; }
public static double checkDT508Tree2Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 332.75) && (eTardJS <= 2381.0) && (eTardJS <= 2364.25) && (eTardJS > 811.5) && (eTardJS > 1951.25))  { ruleCode = 0.026 ; }
    return ruleCode; }
public static double checkDT508Tree2Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 332.75) && (wipJS > 1942.5) && (wipJS > 2001.5) && (wipJS <= 3276.0) && (eTardJS <= 94.0))  { ruleCode = 0.304 ; }
    return ruleCode; }
public static double checkDT508Tree2Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 332.75) && (wipJS <= 1942.5) && (eTardJS > 18.0) && (wipJS > 1412.0) && (wipJS > 1660.5))  { ruleCode = 0.152 ; }
    return ruleCode; }
public static double checkDT508Tree2Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 332.75) && (eTardJS <= 2381.0) && (eTardJS <= 2364.25) && (eTardJS <= 811.5) && (wipJS > 4122.5))  { ruleCode = 0.228 ; }
    return ruleCode; }
public static double checkDT508Tree2Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 1396.5) && (wipJS > 1404.5) && (wipJS > 4189.5) && (wipJS > 4385.5) && (wipJS > 5328.0))  { ruleCode = 0.19 ; }
    return ruleCode; }
public static double checkDT508Tree2Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 1396.5) && (wipJS > 1404.5) && (wipJS > 4189.5) && (wipJS <= 4385.5) && (wipJS <= 4360.0))  { ruleCode = 0.522 ; }
    return ruleCode; }
public static double checkDT508Tree2Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 332.75) && (wipJS <= 1942.5) && (eTardJS > 18.0) && (wipJS > 1412.0) && (wipJS <= 1660.5))  { ruleCode = 0.324 ; }
    return ruleCode; }
public static double checkDT508Tree2Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 1396.5) && (wipJS <= 1357.0) && (wipJS <= 1342.0) && (wipJS > 1267.0) && (wipJS > 1274.5))  { ruleCode = 0.185 ; }
    return ruleCode; }
public static double checkDT508Tree2Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 332.75) && (wipJS <= 1942.5) && (eTardJS > 18.0) && (wipJS <= 1412.0) && (eTardJS > 69.0))  { ruleCode = 0.032 ; }
    return ruleCode; }
public static double checkDT508Tree2Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 332.75) && (eTardJS > 2381.0) && (wipJS <= 1673.0) && (wipJS <= 1654.5))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT508Tree2Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 332.75) && (wipJS > 1942.5) && (wipJS <= 2001.5) && (wipJS <= 1995.5) && (wipJS > 1966.5))  { ruleCode = 0.209 ; }
    return ruleCode; }
public static double checkDT508Tree2Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 332.75) && (wipJS <= 1942.5) && (eTardJS <= 18.0) && (wipJS > 1393.5) && (eTardJS <= 14.5))  { ruleCode = 0.17 ; }
    return ruleCode; }
public static double checkDT508Tree2Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 1396.5) && (wipJS > 1404.5) && (wipJS > 4189.5) && (wipJS <= 4385.5) && (wipJS > 4360.0))  { ruleCode = 4.253 ; }
    return ruleCode; }
public static double checkDT508Tree2Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 332.75) && (wipJS <= 1942.5) && (eTardJS > 18.0) && (wipJS <= 1412.0) && (eTardJS <= 69.0))  { ruleCode = 0.267 ; }
    return ruleCode; }
public static double checkDT508Tree2Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 1396.5) && (wipJS > 1357.0) && (wipJS > 1385.5))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT508Tree2Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 1396.5) && (wipJS <= 1357.0) && (wipJS > 1342.0))  { ruleCode = 31.747 ; }
    return ruleCode; }
public static double checkDT508Tree2Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 1396.5) && (wipJS > 1357.0) && (wipJS <= 1385.5) && (wipJS > 1375.0))  { ruleCode = 0.275 ; }
    return ruleCode; }
public static double checkDT508Tree2Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 1396.5) && (wipJS <= 1357.0) && (wipJS <= 1342.0) && (wipJS > 1267.0) && (wipJS <= 1274.5))  { ruleCode = 0.974 ; }
    return ruleCode; }
public static double checkDT508Tree2Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 1396.5) && (wipJS <= 1357.0) && (wipJS <= 1342.0) && (wipJS <= 1267.0) && (wipJS > 1252.0))  { ruleCode = 26.0 ; }
    return ruleCode; }
public static double checkDT508Tree2Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 1396.5) && (wipJS <= 1404.5))  { ruleCode = 892.0 ; }
    return ruleCode; }
public static double checkDT508Tree2Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 1396.5) && (wipJS > 1357.0) && (wipJS <= 1385.5) && (wipJS <= 1375.0))  { ruleCode = 0.47 ; }
    return ruleCode; }
public static double checkDT508Tree2Path33(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 332.75) && (eTardJS > 2381.0) && (wipJS > 1673.0) && (eTardJS <= 4263.0) && (eTardJS > 4253.75))  { ruleCode = 0.597 ; }
    return ruleCode; }
public static double checkDT508Tree2Path34(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 1396.5) && (wipJS > 1404.5) && (wipJS <= 4189.5) && (wipJS > 3473.5) && (wipJS <= 3480.0))  { ruleCode = 632.0 ; }
    return ruleCode; }
public static double checkDT508Tree2Path35(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 332.75) && (wipJS <= 1942.5) && (eTardJS <= 18.0) && (wipJS <= 1393.5) && (eTardJS <= 10.0))  { ruleCode = 0.551 ; }
    return ruleCode; }
public static double checkDT508Tree2Path36(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 332.75) && (wipJS <= 1942.5) && (eTardJS <= 18.0) && (wipJS <= 1393.5) && (eTardJS > 10.0))  { ruleCode = 0.569 ; }
    return ruleCode; }
public static double checkDT508Tree2Path37(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 332.75) && (wipJS > 1942.5) && (wipJS <= 2001.5) && (wipJS <= 1995.5) && (wipJS <= 1966.5))  { ruleCode = 0.715 ; }
    return ruleCode; }
public static double checkDT508Tree2Path38(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 332.75) && (wipJS > 1942.5) && (wipJS <= 2001.5) && (wipJS > 1995.5))  { ruleCode = 6.889 ; }
    return ruleCode; }
public static double checkDT508Tree2Path39(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 332.75) && (wipJS > 1942.5) && (wipJS > 2001.5) && (wipJS > 3276.0) && (wipJS <= 3294.5))  { ruleCode = 2.053 ; }
    return ruleCode; }
public static double checkDT508Tree2Path40(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 332.75) && (eTardJS <= 2381.0) && (eTardJS > 2364.25))  { ruleCode = 2.445 ; }
    return ruleCode; }
public static double checkDT508Tree2Path41(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 332.75) && (eTardJS > 2381.0) && (wipJS <= 1673.0) && (wipJS > 1654.5))  { ruleCode = -2.88 ; }
    return ruleCode; }
public static double checkDT508Tree2Path42(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 332.75) && (wipJS <= 1942.5) && (eTardJS <= 18.0) && (wipJS > 1393.5) && (eTardJS > 14.5))  { ruleCode = 0.684 ; }
    return ruleCode; }
public static double checkDT508Tree3Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 1059.75) && (eTardJS > 4276.0) && (eTardJS > 7386.5) && (eTardJS > 12962.25) && (wipJS > 4357.5))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT508Tree3Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 1541.0) && (wipJS <= 1267.0) && (wipJS <= 1167.0) && (wipJS <= 374.0))  { ruleCode = 4.638 ; }
    return ruleCode; }
public static double checkDT508Tree3Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 1059.75) && (eTardJS > 4276.0) && (eTardJS > 7386.5) && (eTardJS > 12962.25) && (wipJS <= 4357.5))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT508Tree3Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 1541.0) && (wipJS > 1558.5) && (wipJS <= 4289.5) && (wipJS <= 4283.5) && (wipJS <= 3312.5))  { ruleCode = 12.42 ; }
    return ruleCode; }
public static double checkDT508Tree3Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 1059.75) && (eTardJS > 4276.0) && (eTardJS > 7386.5) && (eTardJS <= 12962.25) && (eTardJS <= 12929.75))  { ruleCode = 0.005 ; }
    return ruleCode; }
public static double checkDT508Tree3Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 1059.75) && (eTardJS <= 4276.0) && (wipJS <= 4090.5) && (eTardJS <= 4253.75) && (wipJS <= 3221.0))  { ruleCode = 0.038 ; }
    return ruleCode; }
public static double checkDT508Tree3Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 1059.75) && (eTardJS > 4276.0) && (eTardJS <= 7386.5) && (eTardJS <= 7121.0) && (wipJS <= 4387.0))  { ruleCode = 0.006 ; }
    return ruleCode; }
public static double checkDT508Tree3Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 1059.75) && (eTardJS <= 230.5) && (eTardJS <= 228.5) && (eTardJS > 2.75) && (eTardJS > 88.5))  { ruleCode = 0.203 ; }
    return ruleCode; }
public static double checkDT508Tree3Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 1059.75) && (eTardJS <= 230.5) && (eTardJS <= 228.5) && (eTardJS > 2.75) && (eTardJS <= 88.5))  { ruleCode = 0.295 ; }
    return ruleCode; }
public static double checkDT508Tree3Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 1541.0) && (wipJS > 1558.5) && (wipJS <= 4289.5) && (wipJS <= 4283.5) && (wipJS > 3312.5))  { ruleCode = 31.106 ; }
    return ruleCode; }
public static double checkDT508Tree3Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 1059.75) && (eTardJS > 230.5) && (wipJS > 3465.5) && (wipJS > 3503.5) && (eTardJS <= 1039.75))  { ruleCode = 0.193 ; }
    return ruleCode; }
public static double checkDT508Tree3Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 1059.75) && (eTardJS > 230.5) && (wipJS <= 3465.5) && (eTardJS > 281.0) && (wipJS > 2015.5))  { ruleCode = 0.126 ; }
    return ruleCode; }
public static double checkDT508Tree3Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 1541.0) && (wipJS > 1558.5) && (wipJS > 4289.5) && (wipJS > 4379.0) && (wipJS <= 5914.0))  { ruleCode = 0.463 ; }
    return ruleCode; }
public static double checkDT508Tree3Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 1059.75) && (eTardJS <= 4276.0) && (wipJS > 4090.5) && (wipJS > 4248.0) && (wipJS > 4677.5))  { ruleCode = 0.099 ; }
    return ruleCode; }
public static double checkDT508Tree3Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 1059.75) && (eTardJS <= 4276.0) && (wipJS <= 4090.5) && (eTardJS <= 4253.75) && (wipJS > 3221.0))  { ruleCode = 0.008 ; }
    return ruleCode; }
public static double checkDT508Tree3Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 1059.75) && (eTardJS > 230.5) && (wipJS <= 3465.5) && (eTardJS > 281.0) && (wipJS <= 2015.5))  { ruleCode = 0.052 ; }
    return ruleCode; }
public static double checkDT508Tree3Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 1059.75) && (eTardJS > 4276.0) && (eTardJS <= 7386.5) && (eTardJS <= 7121.0) && (wipJS > 4387.0))  { ruleCode = 0.035 ; }
    return ruleCode; }
public static double checkDT508Tree3Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 1059.75) && (eTardJS <= 4276.0) && (wipJS > 4090.5) && (wipJS > 4248.0) && (wipJS <= 4677.5))  { ruleCode = 0.026 ; }
    return ruleCode; }
public static double checkDT508Tree3Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 1541.0) && (wipJS > 1267.0) && (wipJS > 1331.0) && (wipJS > 1396.0) && (wipJS > 1407.0))  { ruleCode = 0.444 ; }
    return ruleCode; }
public static double checkDT508Tree3Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 1059.75) && (eTardJS > 4276.0) && (eTardJS <= 7386.5) && (eTardJS > 7121.0) && (eTardJS > 7167.0))  { ruleCode = 0.009 ; }
    return ruleCode; }
public static double checkDT508Tree3Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 1541.0) && (wipJS <= 1267.0) && (wipJS <= 1167.0) && (wipJS > 374.0) && (wipJS <= 1121.0))  { ruleCode = 0.2 ; }
    return ruleCode; }
public static double checkDT508Tree3Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 1059.75) && (eTardJS > 230.5) && (wipJS <= 3465.5) && (eTardJS <= 281.0) && (eTardJS <= 256.0))  { ruleCode = 0.036 ; }
    return ruleCode; }
public static double checkDT508Tree3Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 1059.75) && (eTardJS <= 4276.0) && (wipJS > 4090.5) && (wipJS <= 4248.0) && (wipJS <= 4235.5))  { ruleCode = 0.154 ; }
    return ruleCode; }
public static double checkDT508Tree3Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 1541.0) && (wipJS > 1267.0) && (wipJS > 1331.0) && (wipJS <= 1396.0) && (wipJS > 1334.5))  { ruleCode = 0.183 ; }
    return ruleCode; }
public static double checkDT508Tree3Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 1541.0) && (wipJS > 1558.5) && (wipJS > 4289.5) && (wipJS > 4379.0) && (wipJS > 5914.0))  { ruleCode = 0.154 ; }
    return ruleCode; }
public static double checkDT508Tree3Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 1059.75) && (eTardJS > 230.5) && (wipJS <= 3465.5) && (eTardJS <= 281.0) && (eTardJS > 256.0))  { ruleCode = 0.46 ; }
    return ruleCode; }
public static double checkDT508Tree3Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 1541.0) && (wipJS > 1558.5) && (wipJS > 4289.5) && (wipJS <= 4379.0) && (wipJS <= 4375.5))  { ruleCode = 0.49 ; }
    return ruleCode; }
public static double checkDT508Tree3Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 1541.0) && (wipJS <= 1267.0) && (wipJS <= 1167.0) && (wipJS > 374.0) && (wipJS > 1121.0))  { ruleCode = 5.87 ; }
    return ruleCode; }
public static double checkDT508Tree3Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 1541.0) && (wipJS > 1267.0) && (wipJS <= 1331.0) && (wipJS <= 1322.5) && (wipJS > 1273.5))  { ruleCode = 0.036 ; }
    return ruleCode; }
public static double checkDT508Tree3Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 1059.75) && (eTardJS > 230.5) && (wipJS > 3465.5) && (wipJS > 3503.5) && (eTardJS > 1039.75))  { ruleCode = 0.55 ; }
    return ruleCode; }
public static double checkDT508Tree3Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 1541.0) && (wipJS <= 1267.0) && (wipJS > 1167.0) && (wipJS > 1195.5) && (wipJS <= 1242.5))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT508Tree3Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 1541.0) && (wipJS > 1267.0) && (wipJS > 1331.0) && (wipJS > 1396.0) && (wipJS <= 1407.0))  { ruleCode = 2.394 ; }
    return ruleCode; }
public static double checkDT508Tree3Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 1059.75) && (eTardJS > 4276.0) && (eTardJS > 7386.5) && (eTardJS <= 12962.25) && (eTardJS > 12929.75))  { ruleCode = 0.094 ; }
    return ruleCode; }
public static double checkDT508Tree3Path33(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 1059.75) && (eTardJS <= 4276.0) && (wipJS > 4090.5) && (wipJS <= 4248.0) && (wipJS > 4235.5))  { ruleCode = 1.226 ; }
    return ruleCode; }
public static double checkDT508Tree3Path34(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 1059.75) && (eTardJS <= 230.5) && (eTardJS <= 228.5) && (eTardJS <= 2.75) && (wipJS <= 3115.5))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT508Tree3Path35(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 1059.75) && (eTardJS <= 230.5) && (eTardJS <= 228.5) && (eTardJS <= 2.75) && (wipJS > 3115.5))  { ruleCode = 0.023 ; }
    return ruleCode; }
public static double checkDT508Tree3Path36(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 1541.0) && (wipJS > 1558.5) && (wipJS <= 4289.5) && (wipJS > 4283.5))  { ruleCode = 398.0 ; }
    return ruleCode; }
public static double checkDT508Tree3Path37(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 1541.0) && (wipJS > 1558.5) && (wipJS > 4289.5) && (wipJS <= 4379.0) && (wipJS > 4375.5))  { ruleCode = 21.0 ; }
    return ruleCode; }
public static double checkDT508Tree3Path38(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS > 1541.0) && (wipJS <= 1558.5))  { ruleCode = 121.0 ; }
    return ruleCode; }
public static double checkDT508Tree3Path39(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 1541.0) && (wipJS > 1267.0) && (wipJS > 1331.0) && (wipJS <= 1396.0) && (wipJS <= 1334.5))  { ruleCode = 0.95 ; }
    return ruleCode; }
public static double checkDT508Tree3Path40(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 1541.0) && (wipJS > 1267.0) && (wipJS <= 1331.0) && (wipJS > 1322.5))  { ruleCode = 14.0 ; }
    return ruleCode; }
public static double checkDT508Tree3Path41(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 1059.75) && (eTardJS > 4276.0) && (eTardJS <= 7386.5) && (eTardJS > 7121.0) && (eTardJS <= 7167.0))  { ruleCode = 0.255 ; }
    return ruleCode; }
public static double checkDT508Tree3Path42(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 1541.0) && (wipJS > 1267.0) && (wipJS <= 1331.0) && (wipJS <= 1322.5) && (wipJS <= 1273.5))  { ruleCode = 0.974 ; }
    return ruleCode; }
public static double checkDT508Tree3Path43(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 1541.0) && (wipJS <= 1267.0) && (wipJS > 1167.0) && (wipJS > 1195.5) && (wipJS > 1242.5))  { ruleCode = 26.0 ; }
    return ruleCode; }
public static double checkDT508Tree3Path44(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS > 1059.75) && (eTardJS <= 4276.0) && (wipJS <= 4090.5) && (eTardJS > 4253.75))  { ruleCode = 0.597 ; }
    return ruleCode; }
public static double checkDT508Tree3Path45(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.0) && (wipJS <= 1541.0) && (wipJS <= 1267.0) && (wipJS > 1167.0) && (wipJS <= 1195.5))  { ruleCode = 25.0 ; }
    return ruleCode; }
public static double checkDT508Tree3Path46(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 1059.75) && (eTardJS <= 230.5) && (eTardJS > 228.5) && (wipJS <= 2860.0))  { ruleCode = 0.142 ; }
    return ruleCode; }
public static double checkDT508Tree3Path47(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 1059.75) && (eTardJS <= 230.5) && (eTardJS > 228.5) && (wipJS > 2860.0))  { ruleCode = 2.053 ; }
    return ruleCode; }
public static double checkDT508Tree3Path48(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.0) && (eTardJS <= 1059.75) && (eTardJS > 230.5) && (wipJS > 3465.5) && (wipJS <= 3503.5))  { ruleCode = 1.391 ; }
    return ruleCode; }
public static double checkDT508Tree4Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 836.0) && (eTardJS > 3344.5) && (eTardJS > 5187.25) && (eTardJS > 18029.5) && (wipJS <= 7812.5))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT508Tree4Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2823.0) && (wipJS <= 2011.0) && (wipJS <= 1755.5) && (wipJS <= 1752.0) && (wipJS <= 1551.5))  { ruleCode = 5.248 ; }
    return ruleCode; }
public static double checkDT508Tree4Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 836.0) && (eTardJS > 3344.5) && (eTardJS > 5187.25) && (eTardJS <= 18029.5) && (eTardJS <= 17952.0))  { ruleCode = 0.004 ; }
    return ruleCode; }
public static double checkDT508Tree4Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 836.0) && (eTardJS > 93.0) && (wipJS > 1655.5) && (wipJS > 1683.5) && (eTardJS > 143.0))  { ruleCode = 0.154 ; }
    return ruleCode; }
public static double checkDT508Tree4Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 836.0) && (eTardJS <= 3344.5) && (eTardJS <= 3334.0) && (wipJS <= 4194.5) && (eTardJS > 1115.75))  { ruleCode = 0.031 ; }
    return ruleCode; }
public static double checkDT508Tree4Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 836.0) && (eTardJS <= 93.0) && (eTardJS <= 84.5) && (eTardJS <= 80.25) && (eTardJS <= 72.25))  { ruleCode = 0.234 ; }
    return ruleCode; }
public static double checkDT508Tree4Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2823.0) && (wipJS > 2859.0) && (wipJS > 3835.0) && (wipJS > 4130.0) && (wipJS <= 5408.0))  { ruleCode = 0.506 ; }
    return ruleCode; }
public static double checkDT508Tree4Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 836.0) && (eTardJS <= 3344.5) && (eTardJS <= 3334.0) && (wipJS > 4194.5) && (wipJS > 4248.0))  { ruleCode = 0.083 ; }
    return ruleCode; }
public static double checkDT508Tree4Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 836.0) && (eTardJS > 3344.5) && (eTardJS <= 5187.25) && (eTardJS <= 5140.75) && (eTardJS > 4134.25))  { ruleCode = 0.028 ; }
    return ruleCode; }
public static double checkDT508Tree4Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2823.0) && (wipJS > 2859.0) && (wipJS <= 3835.0) && (wipJS <= 3827.5) && (wipJS > 3275.0))  { ruleCode = 29.023 ; }
    return ruleCode; }
public static double checkDT508Tree4Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 836.0) && (eTardJS > 3344.5) && (eTardJS <= 5187.25) && (eTardJS <= 5140.75) && (eTardJS <= 4134.25))  { ruleCode = 0.008 ; }
    return ruleCode; }
public static double checkDT508Tree4Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2823.0) && (wipJS > 2859.0) && (wipJS <= 3835.0) && (wipJS <= 3827.5) && (wipJS <= 3275.0))  { ruleCode = 9.575 ; }
    return ruleCode; }
public static double checkDT508Tree4Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 836.0) && (eTardJS > 93.0) && (wipJS > 1655.5) && (wipJS > 1683.5) && (eTardJS <= 143.0))  { ruleCode = 0.231 ; }
    return ruleCode; }
public static double checkDT508Tree4Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2823.0) && (wipJS > 2011.0) && (wipJS > 2059.0) && (wipJS <= 2494.5) && (wipJS > 2235.0))  { ruleCode = 0.533 ; }
    return ruleCode; }
public static double checkDT508Tree4Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 836.0) && (eTardJS > 3344.5) && (eTardJS > 5187.25) && (eTardJS > 18029.5) && (wipJS > 7812.5))  { ruleCode = 0.001 ; }
    return ruleCode; }
public static double checkDT508Tree4Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2823.0) && (wipJS > 2011.0) && (wipJS > 2059.0) && (wipJS > 2494.5) && (wipJS > 2500.5))  { ruleCode = 0.411 ; }
    return ruleCode; }
public static double checkDT508Tree4Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 836.0) && (eTardJS <= 3344.5) && (eTardJS <= 3334.0) && (wipJS <= 4194.5) && (eTardJS <= 1115.75))  { ruleCode = 0.123 ; }
    return ruleCode; }
public static double checkDT508Tree4Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2823.0) && (wipJS <= 2011.0) && (wipJS <= 1755.5) && (wipJS <= 1752.0) && (wipJS > 1551.5))  { ruleCode = 1.314 ; }
    return ruleCode; }
public static double checkDT508Tree4Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2823.0) && (wipJS > 2011.0) && (wipJS > 2059.0) && (wipJS <= 2494.5) && (wipJS <= 2235.0))  { ruleCode = 0.4 ; }
    return ruleCode; }
public static double checkDT508Tree4Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2823.0) && (wipJS > 2859.0) && (wipJS > 3835.0) && (wipJS <= 4130.0) && (wipJS <= 4116.5))  { ruleCode = 1.469 ; }
    return ruleCode; }
public static double checkDT508Tree4Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2823.0) && (wipJS <= 2011.0) && (wipJS > 1755.5) && (wipJS <= 1932.0) && (wipJS > 1829.0))  { ruleCode = 0.313 ; }
    return ruleCode; }
public static double checkDT508Tree4Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2823.0) && (wipJS > 2859.0) && (wipJS > 3835.0) && (wipJS > 4130.0) && (wipJS > 5408.0))  { ruleCode = 0.256 ; }
    return ruleCode; }
public static double checkDT508Tree4Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 836.0) && (eTardJS > 93.0) && (wipJS <= 1655.5) && (eTardJS <= 569.5) && (eTardJS <= 270.75))  { ruleCode = 0.041 ; }
    return ruleCode; }
public static double checkDT508Tree4Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2823.0) && (wipJS <= 2011.0) && (wipJS > 1755.5) && (wipJS > 1932.0) && (wipJS <= 1983.0))  { ruleCode = 0.82 ; }
    return ruleCode; }
public static double checkDT508Tree4Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2823.0) && (wipJS <= 2011.0) && (wipJS > 1755.5) && (wipJS <= 1932.0) && (wipJS <= 1829.0))  { ruleCode = 0.579 ; }
    return ruleCode; }
public static double checkDT508Tree4Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 836.0) && (eTardJS > 93.0) && (wipJS <= 1655.5) && (eTardJS <= 569.5) && (eTardJS > 270.75))  { ruleCode = 0.209 ; }
    return ruleCode; }
public static double checkDT508Tree4Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2823.0) && (wipJS <= 2011.0) && (wipJS > 1755.5) && (wipJS > 1932.0) && (wipJS > 1983.0))  { ruleCode = 0.279 ; }
    return ruleCode; }
public static double checkDT508Tree4Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 836.0) && (eTardJS <= 93.0) && (eTardJS <= 84.5) && (eTardJS <= 80.25) && (eTardJS > 72.25))  { ruleCode = 0.023 ; }
    return ruleCode; }
public static double checkDT508Tree4Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 836.0) && (eTardJS > 93.0) && (wipJS <= 1655.5) && (eTardJS > 569.5) && (eTardJS > 668.5))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT508Tree4Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 836.0) && (eTardJS <= 3344.5) && (eTardJS <= 3334.0) && (wipJS > 4194.5) && (wipJS <= 4248.0))  { ruleCode = 1.158 ; }
    return ruleCode; }
public static double checkDT508Tree4Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 836.0) && (eTardJS > 3344.5) && (eTardJS <= 5187.25) && (eTardJS > 5140.75) && (eTardJS > 5142.5))  { ruleCode = 0.035 ; }
    return ruleCode; }
public static double checkDT508Tree4Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 836.0) && (eTardJS > 93.0) && (wipJS > 1655.5) && (wipJS <= 1683.5) && (eTardJS <= 608.25))  { ruleCode = 0.166 ; }
    return ruleCode; }
public static double checkDT508Tree4Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 836.0) && (eTardJS <= 93.0) && (eTardJS > 84.5) && (wipJS > 2074.0) && (eTardJS > 85.5))  { ruleCode = 0.345 ; }
    return ruleCode; }
public static double checkDT508Tree4Path33(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2823.0) && (wipJS > 2011.0) && (wipJS <= 2059.0) && (wipJS <= 2054.5) && (wipJS <= 2030.5))  { ruleCode = 15.972 ; }
    return ruleCode; }
public static double checkDT508Tree4Path34(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 836.0) && (eTardJS <= 93.0) && (eTardJS <= 84.5) && (eTardJS > 80.25) && (wipJS <= 3596.0))  { ruleCode = 0.54 ; }
    return ruleCode; }
public static double checkDT508Tree4Path35(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 836.0) && (eTardJS > 93.0) && (wipJS <= 1655.5) && (eTardJS > 569.5) && (eTardJS <= 668.5))  { ruleCode = 0.038 ; }
    return ruleCode; }
public static double checkDT508Tree4Path36(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2823.0) && (wipJS > 2011.0) && (wipJS <= 2059.0) && (wipJS <= 2054.5) && (wipJS > 2030.5))  { ruleCode = 0.081 ; }
    return ruleCode; }
public static double checkDT508Tree4Path37(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2823.0) && (wipJS > 2011.0) && (wipJS <= 2059.0) && (wipJS > 2054.5))  { ruleCode = 391.667 ; }
    return ruleCode; }
public static double checkDT508Tree4Path38(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 836.0) && (eTardJS > 3344.5) && (eTardJS > 5187.25) && (eTardJS <= 18029.5) && (eTardJS > 17952.0))  { ruleCode = 0.415 ; }
    return ruleCode; }
public static double checkDT508Tree4Path39(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2823.0) && (wipJS <= 2011.0) && (wipJS <= 1755.5) && (wipJS > 1752.0))  { ruleCode = 222.0 ; }
    return ruleCode; }
public static double checkDT508Tree4Path40(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 836.0) && (eTardJS > 93.0) && (wipJS > 1655.5) && (wipJS <= 1683.5) && (eTardJS > 608.25))  { ruleCode = 1.343 ; }
    return ruleCode; }
public static double checkDT508Tree4Path41(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2823.0) && (wipJS > 2011.0) && (wipJS > 2059.0) && (wipJS > 2494.5) && (wipJS <= 2500.5))  { ruleCode = 141.0 ; }
    return ruleCode; }
public static double checkDT508Tree4Path42(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2823.0) && (wipJS <= 2859.0) && (wipJS <= 2849.0) && (wipJS <= 2837.5))  { ruleCode = 47.0 ; }
    return ruleCode; }
public static double checkDT508Tree4Path43(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2823.0) && (wipJS <= 2859.0) && (wipJS <= 2849.0) && (wipJS > 2837.5))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT508Tree4Path44(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2823.0) && (wipJS <= 2859.0) && (wipJS > 2849.0))  { ruleCode = 609.0 ; }
    return ruleCode; }
public static double checkDT508Tree4Path45(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2823.0) && (wipJS > 2859.0) && (wipJS <= 3835.0) && (wipJS > 3827.5))  { ruleCode = 1186.0 ; }
    return ruleCode; }
public static double checkDT508Tree4Path46(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2823.0) && (wipJS > 2859.0) && (wipJS > 3835.0) && (wipJS <= 4130.0) && (wipJS > 4116.5))  { ruleCode = 118.0 ; }
    return ruleCode; }
public static double checkDT508Tree4Path47(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 836.0) && (eTardJS <= 3344.5) && (eTardJS > 3334.0))  { ruleCode = 1.396 ; }
    return ruleCode; }
public static double checkDT508Tree4Path48(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 836.0) && (eTardJS <= 93.0) && (eTardJS <= 84.5) && (eTardJS > 80.25) && (wipJS > 3596.0))  { ruleCode = 0.762 ; }
    return ruleCode; }
public static double checkDT508Tree4Path49(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 836.0) && (eTardJS <= 93.0) && (eTardJS > 84.5) && (wipJS <= 2074.0) && (eTardJS <= 87.5))  { ruleCode = 6.889 ; }
    return ruleCode; }
public static double checkDT508Tree4Path50(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 836.0) && (eTardJS <= 93.0) && (eTardJS > 84.5) && (wipJS <= 2074.0) && (eTardJS > 87.5))  { ruleCode = 0.799 ; }
    return ruleCode; }
public static double checkDT508Tree4Path51(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 836.0) && (eTardJS <= 93.0) && (eTardJS > 84.5) && (wipJS > 2074.0) && (eTardJS <= 85.5))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT508Tree4Path52(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 836.0) && (eTardJS > 3344.5) && (eTardJS <= 5187.25) && (eTardJS > 5140.75) && (eTardJS <= 5142.5))  { ruleCode = 0.254 ; }
    return ruleCode; }
public static double checkDT508Tree5Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1316.25) && (wipJS > 1664.5) && (eTardJS > 3499.0) && (eTardJS > 5988.5) && (eTardJS > 12951.5))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT508Tree5Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2701.0) && (wipJS <= 1752.0) && (wipJS <= 1349.5) && (wipJS <= 1341.5) && (wipJS <= 1121.0))  { ruleCode = 2.858 ; }
    return ruleCode; }
public static double checkDT508Tree5Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1316.25) && (wipJS > 1664.5) && (eTardJS > 3499.0) && (eTardJS > 5988.5) && (eTardJS <= 12951.5))  { ruleCode = 0.007 ; }
    return ruleCode; }
public static double checkDT508Tree5Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1316.25) && (wipJS > 1664.5) && (eTardJS > 3499.0) && (eTardJS <= 5988.5) && (eTardJS <= 5981.0))  { ruleCode = 0.015 ; }
    return ruleCode; }
public static double checkDT508Tree5Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1316.25) && (wipJS > 1664.5) && (eTardJS <= 3499.0) && (wipJS <= 4039.5) && (eTardJS <= 3336.25))  { ruleCode = 0.027 ; }
    return ruleCode; }
public static double checkDT508Tree5Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1316.25) && (eTardJS > 335.0) && (wipJS <= 4068.0) && (eTardJS <= 1302.5) && (eTardJS > 418.5))  { ruleCode = 0.117 ; }
    return ruleCode; }
public static double checkDT508Tree5Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1316.25) && (eTardJS <= 335.0) && (wipJS > 2282.0) && (wipJS > 2356.5) && (eTardJS <= 321.75))  { ruleCode = 0.236 ; }
    return ruleCode; }
public static double checkDT508Tree5Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2701.0) && (wipJS > 2710.0) && (wipJS <= 4150.5) && (wipJS <= 3693.0) && (wipJS > 2921.5))  { ruleCode = 22.681 ; }
    return ruleCode; }
public static double checkDT508Tree5Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2701.0) && (wipJS > 1752.0) && (wipJS > 1770.0) && (wipJS > 2059.0) && (wipJS <= 2385.5))  { ruleCode = 0.714 ; }
    return ruleCode; }
public static double checkDT508Tree5Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2701.0) && (wipJS > 2710.0) && (wipJS > 4150.5) && (wipJS <= 5325.0) && (wipJS <= 4735.5))  { ruleCode = 0.482 ; }
    return ruleCode; }
public static double checkDT508Tree5Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1316.25) && (eTardJS <= 335.0) && (wipJS <= 2282.0) && (eTardJS > 10.0) && (wipJS <= 1969.5))  { ruleCode = 0.21 ; }
    return ruleCode; }
public static double checkDT508Tree5Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2701.0) && (wipJS > 1752.0) && (wipJS > 1770.0) && (wipJS <= 2059.0) && (wipJS <= 2054.5))  { ruleCode = 2.719 ; }
    return ruleCode; }
public static double checkDT508Tree5Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1316.25) && (wipJS > 1664.5) && (eTardJS <= 3499.0) && (wipJS > 4039.5) && (wipJS <= 5196.5))  { ruleCode = 0.136 ; }
    return ruleCode; }
public static double checkDT508Tree5Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1316.25) && (eTardJS <= 335.0) && (wipJS <= 2282.0) && (eTardJS > 10.0) && (wipJS > 1969.5))  { ruleCode = 0.113 ; }
    return ruleCode; }
public static double checkDT508Tree5Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2701.0) && (wipJS > 2710.0) && (wipJS <= 4150.5) && (wipJS > 3693.0) && (wipJS > 3699.0))  { ruleCode = 34.596 ; }
    return ruleCode; }
public static double checkDT508Tree5Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1316.25) && (eTardJS > 335.0) && (wipJS > 4068.0) && (wipJS > 4531.0) && (wipJS <= 5881.0))  { ruleCode = 0.155 ; }
    return ruleCode; }
public static double checkDT508Tree5Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2701.0) && (wipJS > 1752.0) && (wipJS > 1770.0) && (wipJS > 2059.0) && (wipJS > 2385.5))  { ruleCode = 0.388 ; }
    return ruleCode; }
public static double checkDT508Tree5Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2701.0) && (wipJS <= 1752.0) && (wipJS > 1349.5) && (wipJS <= 1678.0) && (wipJS <= 1590.5))  { ruleCode = 0.305 ; }
    return ruleCode; }
public static double checkDT508Tree5Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2701.0) && (wipJS > 2710.0) && (wipJS <= 4150.5) && (wipJS <= 3693.0) && (wipJS <= 2921.5))  { ruleCode = 4.898 ; }
    return ruleCode; }
public static double checkDT508Tree5Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2701.0) && (wipJS > 2710.0) && (wipJS > 4150.5) && (wipJS <= 5325.0) && (wipJS > 4735.5))  { ruleCode = 0.637 ; }
    return ruleCode; }
public static double checkDT508Tree5Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1316.25) && (wipJS > 1664.5) && (eTardJS <= 3499.0) && (wipJS > 4039.5) && (wipJS > 5196.5))  { ruleCode = 0.029 ; }
    return ruleCode; }
public static double checkDT508Tree5Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2701.0) && (wipJS <= 1752.0) && (wipJS <= 1349.5) && (wipJS <= 1341.5) && (wipJS > 1121.0))  { ruleCode = 4.543 ; }
    return ruleCode; }
public static double checkDT508Tree5Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1316.25) && (eTardJS > 335.0) && (wipJS <= 4068.0) && (eTardJS <= 1302.5) && (eTardJS <= 418.5))  { ruleCode = 0.022 ; }
    return ruleCode; }
public static double checkDT508Tree5Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1316.25) && (eTardJS > 335.0) && (wipJS > 4068.0) && (wipJS <= 4531.0) && (eTardJS <= 1083.5))  { ruleCode = 0.382 ; }
    return ruleCode; }
public static double checkDT508Tree5Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2701.0) && (wipJS <= 1752.0) && (wipJS > 1349.5) && (wipJS > 1678.0) && (wipJS > 1679.5))  { ruleCode = 0.387 ; }
    return ruleCode; }
public static double checkDT508Tree5Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2701.0) && (wipJS <= 1752.0) && (wipJS > 1349.5) && (wipJS <= 1678.0) && (wipJS > 1590.5))  { ruleCode = 0.563 ; }
    return ruleCode; }
public static double checkDT508Tree5Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1316.25) && (wipJS > 1664.5) && (eTardJS <= 3499.0) && (wipJS <= 4039.5) && (eTardJS > 3336.25))  { ruleCode = 0.189 ; }
    return ruleCode; }
public static double checkDT508Tree5Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2701.0) && (wipJS > 2710.0) && (wipJS > 4150.5) && (wipJS > 5325.0) && (wipJS > 5750.5))  { ruleCode = 0.116 ; }
    return ruleCode; }
public static double checkDT508Tree5Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2701.0) && (wipJS > 2710.0) && (wipJS > 4150.5) && (wipJS > 5325.0) && (wipJS <= 5750.5))  { ruleCode = 0.333 ; }
    return ruleCode; }
public static double checkDT508Tree5Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1316.25) && (eTardJS <= 335.0) && (wipJS > 2282.0) && (wipJS <= 2356.5) && (eTardJS <= 156.5))  { ruleCode = 0.485 ; }
    return ruleCode; }
public static double checkDT508Tree5Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1316.25) && (eTardJS > 335.0) && (wipJS > 4068.0) && (wipJS > 4531.0) && (wipJS > 5881.0))  { ruleCode = 0.014 ; }
    return ruleCode; }
public static double checkDT508Tree5Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1316.25) && (wipJS <= 1664.5) && (wipJS <= 1659.0) && (wipJS <= 1601.0) && (wipJS <= 1586.0))  { ruleCode = 0.017 ; }
    return ruleCode; }
public static double checkDT508Tree5Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1316.25) && (wipJS <= 1664.5) && (wipJS <= 1659.0) && (wipJS > 1601.0))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT508Tree5Path33(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1316.25) && (eTardJS <= 335.0) && (wipJS <= 2282.0) && (eTardJS <= 10.0) && (wipJS <= 2214.0))  { ruleCode = 0.59 ; }
    return ruleCode; }
public static double checkDT508Tree5Path34(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2701.0) && (wipJS > 1752.0) && (wipJS > 1770.0) && (wipJS <= 2059.0) && (wipJS > 2054.5))  { ruleCode = 288.426 ; }
    return ruleCode; }
public static double checkDT508Tree5Path35(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1316.25) && (eTardJS <= 335.0) && (wipJS > 2282.0) && (wipJS <= 2356.5) && (eTardJS > 156.5))  { ruleCode = 0.785 ; }
    return ruleCode; }
public static double checkDT508Tree5Path36(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1316.25) && (eTardJS <= 335.0) && (wipJS > 2282.0) && (wipJS > 2356.5) && (eTardJS > 321.75))  { ruleCode = 0.626 ; }
    return ruleCode; }
public static double checkDT508Tree5Path37(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2701.0) && (wipJS > 1752.0) && (wipJS <= 1770.0) && (wipJS <= 1765.0) && (wipJS > 1755.5))  { ruleCode = 0.574 ; }
    return ruleCode; }
public static double checkDT508Tree5Path38(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1316.25) && (eTardJS > 335.0) && (wipJS <= 4068.0) && (eTardJS > 1302.5) && (eTardJS > 1309.0))  { ruleCode = 0.308 ; }
    return ruleCode; }
public static double checkDT508Tree5Path39(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1316.25) && (eTardJS > 335.0) && (wipJS > 4068.0) && (wipJS <= 4531.0) && (eTardJS > 1083.5))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT508Tree5Path40(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2701.0) && (wipJS <= 1752.0) && (wipJS <= 1349.5) && (wipJS > 1341.5))  { ruleCode = 21.329 ; }
    return ruleCode; }
public static double checkDT508Tree5Path41(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2701.0) && (wipJS <= 1752.0) && (wipJS > 1349.5) && (wipJS > 1678.0) && (wipJS <= 1679.5))  { ruleCode = 43.0 ; }
    return ruleCode; }
public static double checkDT508Tree5Path42(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2701.0) && (wipJS > 1752.0) && (wipJS <= 1770.0) && (wipJS <= 1765.0) && (wipJS <= 1755.5))  { ruleCode = 222.0 ; }
    return ruleCode; }
public static double checkDT508Tree5Path43(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1316.25) && (wipJS > 1664.5) && (eTardJS > 3499.0) && (eTardJS <= 5988.5) && (eTardJS > 5981.0))  { ruleCode = 0.16 ; }
    return ruleCode; }
public static double checkDT508Tree5Path44(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2701.0) && (wipJS > 1752.0) && (wipJS <= 1770.0) && (wipJS > 1765.0))  { ruleCode = 368.0 ; }
    return ruleCode; }
public static double checkDT508Tree5Path45(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2701.0) && (wipJS <= 2710.0))  { ruleCode = 694.0 ; }
    return ruleCode; }
public static double checkDT508Tree5Path46(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2701.0) && (wipJS > 2710.0) && (wipJS <= 4150.5) && (wipJS > 3693.0) && (wipJS <= 3699.0))  { ruleCode = 415.0 ; }
    return ruleCode; }
public static double checkDT508Tree5Path47(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1316.25) && (eTardJS > 335.0) && (wipJS <= 4068.0) && (eTardJS > 1302.5) && (eTardJS <= 1309.0))  { ruleCode = 0.342 ; }
    return ruleCode; }
public static double checkDT508Tree5Path48(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1316.25) && (wipJS <= 1664.5) && (wipJS <= 1659.0) && (wipJS <= 1601.0) && (wipJS > 1586.0))  { ruleCode = 0.102 ; }
    return ruleCode; }
public static double checkDT508Tree5Path49(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1316.25) && (wipJS <= 1664.5) && (wipJS > 1659.0))  { ruleCode = -2.88 ; }
    return ruleCode; }
public static double checkDT508Tree5Path50(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1316.25) && (eTardJS <= 335.0) && (wipJS <= 2282.0) && (eTardJS <= 10.0) && (wipJS > 2214.0))  { ruleCode = 0.149 ; }
    return ruleCode; }
public static double checkDT508Tree6Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1064.5) && (eTardJS > 4265.25) && (eTardJS > 12953.25) && (eTardJS > 17994.0) && (wipJS <= 7812.5))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT508Tree6Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 1947.0) && (wipJS <= 1731.5) && (wipJS <= 374.0))  { ruleCode = 5.285 ; }
    return ruleCode; }
public static double checkDT508Tree6Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1064.5) && (eTardJS <= 4265.25) && (wipJS <= 4194.5) && (eTardJS <= 4250.0) && (eTardJS <= 4121.25))  { ruleCode = 0.028 ; }
    return ruleCode; }
public static double checkDT508Tree6Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1064.5) && (eTardJS > 88.5) && (wipJS > 1746.0) && (eTardJS > 210.5) && (wipJS > 1772.0))  { ruleCode = 0.149 ; }
    return ruleCode; }
public static double checkDT508Tree6Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1064.5) && (eTardJS > 4265.25) && (eTardJS <= 12953.25) && (eTardJS <= 12660.75) && (wipJS <= 3526.0))  { ruleCode = 0.003 ; }
    return ruleCode; }
public static double checkDT508Tree6Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1064.5) && (eTardJS > 4265.25) && (eTardJS <= 12953.25) && (eTardJS <= 12660.75) && (wipJS > 3526.0))  { ruleCode = 0.016 ; }
    return ruleCode; }
public static double checkDT508Tree6Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 1947.0) && (wipJS > 1955.5) && (wipJS <= 4189.5) && (wipJS <= 3828.5) && (wipJS > 2704.5))  { ruleCode = 22.084 ; }
    return ruleCode; }
public static double checkDT508Tree6Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 1947.0) && (wipJS > 1955.5) && (wipJS <= 4189.5) && (wipJS <= 3828.5) && (wipJS <= 2704.5))  { ruleCode = 7.723 ; }
    return ruleCode; }
public static double checkDT508Tree6Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1064.5) && (eTardJS > 4265.25) && (eTardJS > 12953.25) && (eTardJS <= 17994.0) && (eTardJS <= 17952.0))  { ruleCode = 0.001 ; }
    return ruleCode; }
public static double checkDT508Tree6Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1064.5) && (eTardJS <= 88.5) && (eTardJS <= 84.5) && (eTardJS <= 79.75) && (eTardJS <= 76.25))  { ruleCode = 0.24 ; }
    return ruleCode; }
public static double checkDT508Tree6Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1064.5) && (eTardJS <= 4265.25) && (wipJS > 4194.5) && (wipJS > 4275.0) && (wipJS <= 5468.0))  { ruleCode = 0.1 ; }
    return ruleCode; }
public static double checkDT508Tree6Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 1947.0) && (wipJS > 1955.5) && (wipJS > 4189.5) && (wipJS > 4380.0) && (wipJS <= 5328.0))  { ruleCode = 0.538 ; }
    return ruleCode; }
public static double checkDT508Tree6Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1064.5) && (eTardJS > 88.5) && (wipJS > 1746.0) && (eTardJS <= 210.5) && (eTardJS > 136.0))  { ruleCode = 0.32 ; }
    return ruleCode; }
public static double checkDT508Tree6Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 1947.0) && (wipJS <= 1731.5) && (wipJS > 374.0) && (wipJS <= 1549.0) && (wipJS > 1133.0))  { ruleCode = 0.548 ; }
    return ruleCode; }
public static double checkDT508Tree6Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1064.5) && (eTardJS > 4265.25) && (eTardJS > 12953.25) && (eTardJS > 17994.0) && (wipJS > 7812.5))  { ruleCode = 0.001 ; }
    return ruleCode; }
public static double checkDT508Tree6Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 1947.0) && (wipJS > 1955.5) && (wipJS <= 4189.5) && (wipJS > 3828.5) && (wipJS > 3835.0))  { ruleCode = 28.91 ; }
    return ruleCode; }
public static double checkDT508Tree6Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1064.5) && (eTardJS > 88.5) && (wipJS > 1746.0) && (eTardJS <= 210.5) && (eTardJS <= 136.0))  { ruleCode = 0.186 ; }
    return ruleCode; }
public static double checkDT508Tree6Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1064.5) && (eTardJS > 88.5) && (wipJS <= 1746.0) && (wipJS <= 1646.0) && (wipJS <= 1642.5))  { ruleCode = 0.08 ; }
    return ruleCode; }
public static double checkDT508Tree6Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1064.5) && (eTardJS <= 4265.25) && (wipJS > 4194.5) && (wipJS > 4275.0) && (wipJS > 5468.0))  { ruleCode = 0.028 ; }
    return ruleCode; }
public static double checkDT508Tree6Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 1947.0) && (wipJS <= 1731.5) && (wipJS > 374.0) && (wipJS > 1549.0) && (wipJS > 1557.0))  { ruleCode = 3.283 ; }
    return ruleCode; }
public static double checkDT508Tree6Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 1947.0) && (wipJS > 1955.5) && (wipJS > 4189.5) && (wipJS > 4380.0) && (wipJS > 5328.0))  { ruleCode = 0.204 ; }
    return ruleCode; }
public static double checkDT508Tree6Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 1947.0) && (wipJS > 1955.5) && (wipJS > 4189.5) && (wipJS <= 4380.0) && (wipJS <= 4373.5))  { ruleCode = 0.469 ; }
    return ruleCode; }
public static double checkDT508Tree6Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 1947.0) && (wipJS > 1731.5) && (wipJS > 1770.0) && (wipJS <= 1936.5) && (wipJS <= 1861.5))  { ruleCode = 0.496 ; }
    return ruleCode; }
public static double checkDT508Tree6Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 1947.0) && (wipJS > 1731.5) && (wipJS > 1770.0) && (wipJS <= 1936.5) && (wipJS > 1861.5))  { ruleCode = 0.262 ; }
    return ruleCode; }
public static double checkDT508Tree6Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1064.5) && (eTardJS > 88.5) && (wipJS <= 1746.0) && (wipJS > 1646.0) && (eTardJS > 163.75))  { ruleCode = 0.006 ; }
    return ruleCode; }
public static double checkDT508Tree6Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 1947.0) && (wipJS > 1731.5) && (wipJS <= 1770.0) && (wipJS <= 1765.0) && (wipJS > 1736.5))  { ruleCode = 14.381 ; }
    return ruleCode; }
public static double checkDT508Tree6Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 1947.0) && (wipJS <= 1731.5) && (wipJS > 374.0) && (wipJS <= 1549.0) && (wipJS <= 1133.0))  { ruleCode = 1.566 ; }
    return ruleCode; }
public static double checkDT508Tree6Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1064.5) && (eTardJS > 4265.25) && (eTardJS <= 12953.25) && (eTardJS > 12660.75) && (eTardJS > 12666.5))  { ruleCode = 0.012 ; }
    return ruleCode; }
public static double checkDT508Tree6Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1064.5) && (eTardJS <= 4265.25) && (wipJS <= 4194.5) && (eTardJS <= 4250.0) && (eTardJS > 4121.25))  { ruleCode = 0.149 ; }
    return ruleCode; }
public static double checkDT508Tree6Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1064.5) && (eTardJS <= 4265.25) && (wipJS > 4194.5) && (wipJS <= 4275.0) && (wipJS <= 4224.5))  { ruleCode = 0.119 ; }
    return ruleCode; }
public static double checkDT508Tree6Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1064.5) && (eTardJS <= 88.5) && (eTardJS <= 84.5) && (eTardJS > 79.75) && (eTardJS > 82.0))  { ruleCode = 0.453 ; }
    return ruleCode; }
public static double checkDT508Tree6Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1064.5) && (eTardJS > 88.5) && (wipJS <= 1746.0) && (wipJS > 1646.0) && (eTardJS <= 163.75))  { ruleCode = 0.076 ; }
    return ruleCode; }
public static double checkDT508Tree6Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1064.5) && (eTardJS <= 88.5) && (eTardJS <= 84.5) && (eTardJS <= 79.75) && (eTardJS > 76.25))  { ruleCode = 0.005 ; }
    return ruleCode; }
public static double checkDT508Tree6Path33(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1064.5) && (eTardJS <= 88.5) && (eTardJS <= 84.5) && (eTardJS > 79.75) && (eTardJS <= 82.0))  { ruleCode = 0.652 ; }
    return ruleCode; }
public static double checkDT508Tree6Path34(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 1947.0) && (wipJS <= 1955.5) && (wipJS > 1951.5))  { ruleCode = 260.594 ; }
    return ruleCode; }
public static double checkDT508Tree6Path35(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1064.5) && (eTardJS <= 88.5) && (eTardJS > 84.5) && (wipJS > 2074.0) && (eTardJS > 86.5))  { ruleCode = 0.473 ; }
    return ruleCode; }
public static double checkDT508Tree6Path36(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1064.5) && (eTardJS <= 4265.25) && (wipJS <= 4194.5) && (eTardJS > 4250.0))  { ruleCode = 0.597 ; }
    return ruleCode; }
public static double checkDT508Tree6Path37(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1064.5) && (eTardJS > 4265.25) && (eTardJS > 12953.25) && (eTardJS <= 17994.0) && (eTardJS > 17952.0))  { ruleCode = 0.415 ; }
    return ruleCode; }
public static double checkDT508Tree6Path38(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 1947.0) && (wipJS <= 1731.5) && (wipJS > 374.0) && (wipJS > 1549.0) && (wipJS <= 1557.0))  { ruleCode = 121.0 ; }
    return ruleCode; }
public static double checkDT508Tree6Path39(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 1947.0) && (wipJS > 1731.5) && (wipJS <= 1770.0) && (wipJS <= 1765.0) && (wipJS <= 1736.5))  { ruleCode = 117.0 ; }
    return ruleCode; }
public static double checkDT508Tree6Path40(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1064.5) && (eTardJS > 88.5) && (wipJS <= 1746.0) && (wipJS <= 1646.0) && (wipJS > 1642.5))  { ruleCode = 0.82 ; }
    return ruleCode; }
public static double checkDT508Tree6Path41(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 1947.0) && (wipJS > 1731.5) && (wipJS <= 1770.0) && (wipJS > 1765.0))  { ruleCode = 368.0 ; }
    return ruleCode; }
public static double checkDT508Tree6Path42(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1064.5) && (eTardJS <= 4265.25) && (wipJS > 4194.5) && (wipJS <= 4275.0) && (wipJS > 4224.5))  { ruleCode = 2.445 ; }
    return ruleCode; }
public static double checkDT508Tree6Path43(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1064.5) && (eTardJS <= 88.5) && (eTardJS > 84.5) && (wipJS > 2074.0) && (eTardJS <= 86.5))  { ruleCode = 0.626 ; }
    return ruleCode; }
public static double checkDT508Tree6Path44(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 1947.0) && (wipJS > 1731.5) && (wipJS > 1770.0) && (wipJS > 1936.5) && (wipJS <= 1942.0))  { ruleCode = 0.837 ; }
    return ruleCode; }
public static double checkDT508Tree6Path45(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 1947.0) && (wipJS <= 1955.5) && (wipJS <= 1951.5))  { ruleCode = 80.0 ; }
    return ruleCode; }
public static double checkDT508Tree6Path46(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1064.5) && (eTardJS <= 88.5) && (eTardJS > 84.5) && (wipJS <= 2074.0))  { ruleCode = 6.889 ; }
    return ruleCode; }
public static double checkDT508Tree6Path47(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 1064.5) && (eTardJS > 4265.25) && (eTardJS <= 12953.25) && (eTardJS > 12660.75) && (eTardJS <= 12666.5))  { ruleCode = 0.527 ; }
    return ruleCode; }
public static double checkDT508Tree6Path48(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 1947.0) && (wipJS > 1955.5) && (wipJS <= 4189.5) && (wipJS > 3828.5) && (wipJS <= 3835.0))  { ruleCode = 1186.0 ; }
    return ruleCode; }
public static double checkDT508Tree6Path49(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 1064.5) && (eTardJS > 88.5) && (wipJS > 1746.0) && (eTardJS > 210.5) && (wipJS <= 1772.0))  { ruleCode = 0.92 ; }
    return ruleCode; }
public static double checkDT508Tree6Path50(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 1947.0) && (wipJS > 1955.5) && (wipJS > 4189.5) && (wipJS <= 4380.0) && (wipJS > 4373.5))  { ruleCode = 21.0 ; }
    return ruleCode; }
public static double checkDT508Tree6Path51(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 1947.0) && (wipJS > 1731.5) && (wipJS > 1770.0) && (wipJS > 1936.5) && (wipJS > 1942.0))  { ruleCode = 0.882 ; }
    return ruleCode; }
public static double checkDT508Tree7Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 529.25) && (eTardJS > 4263.0) && (wipJS > 1685.0) && (eTardJS > 4870.0) && (eTardJS > 18029.5))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT508Tree7Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2702.0) && (wipJS <= 1765.0) && (wipJS <= 1683.5) && (wipJS <= 1678.0) && (wipJS <= 1549.0))  { ruleCode = 3.168 ; }
    return ruleCode; }
public static double checkDT508Tree7Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 529.25) && (eTardJS > 4263.0) && (wipJS > 1685.0) && (eTardJS > 4870.0) && (eTardJS <= 18029.5))  { ruleCode = 0.004 ; }
    return ruleCode; }
public static double checkDT508Tree7Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 529.25) && (eTardJS <= 4263.0) && (wipJS <= 4128.0) && (eTardJS <= 4253.75) && (eTardJS > 666.5))  { ruleCode = 0.035 ; }
    return ruleCode; }
public static double checkDT508Tree7Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 529.25) && (wipJS <= 3280.5) && (eTardJS > 9.5) && (eTardJS <= 190.5) && (eTardJS <= 188.5))  { ruleCode = 0.2 ; }
    return ruleCode; }
public static double checkDT508Tree7Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2702.0) && (wipJS > 2710.0) && (wipJS <= 4289.5) && (wipJS <= 4273.5) && (wipJS <= 3685.0))  { ruleCode = 13.817 ; }
    return ruleCode; }
public static double checkDT508Tree7Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 529.25) && (eTardJS <= 4263.0) && (wipJS > 4128.0) && (wipJS > 4248.0) && (wipJS <= 5713.5))  { ruleCode = 0.123 ; }
    return ruleCode; }
public static double checkDT508Tree7Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 529.25) && (wipJS > 3280.5) && (wipJS > 3287.0) && (wipJS <= 5736.5) && (wipJS <= 4605.5))  { ruleCode = 0.238 ; }
    return ruleCode; }
public static double checkDT508Tree7Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2702.0) && (wipJS > 1765.0) && (wipJS > 1770.0) && (wipJS > 2059.0) && (wipJS <= 2377.5))  { ruleCode = 0.4 ; }
    return ruleCode; }
public static double checkDT508Tree7Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2702.0) && (wipJS > 1765.0) && (wipJS > 1770.0) && (wipJS <= 2059.0) && (wipJS <= 2045.5))  { ruleCode = 11.158 ; }
    return ruleCode; }
public static double checkDT508Tree7Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2702.0) && (wipJS > 2710.0) && (wipJS <= 4289.5) && (wipJS <= 4273.5) && (wipJS > 3685.0))  { ruleCode = 38.111 ; }
    return ruleCode; }
public static double checkDT508Tree7Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2702.0) && (wipJS > 1765.0) && (wipJS > 1770.0) && (wipJS > 2059.0) && (wipJS > 2377.5))  { ruleCode = 2.942 ; }
    return ruleCode; }
public static double checkDT508Tree7Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 529.25) && (wipJS <= 3280.5) && (eTardJS > 9.5) && (eTardJS > 190.5) && (wipJS > 2215.0))  { ruleCode = 0.06 ; }
    return ruleCode; }
public static double checkDT508Tree7Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 529.25) && (wipJS <= 3280.5) && (eTardJS > 9.5) && (eTardJS > 190.5) && (wipJS <= 2215.0))  { ruleCode = 0.175 ; }
    return ruleCode; }
public static double checkDT508Tree7Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 529.25) && (eTardJS > 4263.0) && (wipJS > 1685.0) && (eTardJS <= 4870.0) && (eTardJS <= 4857.75))  { ruleCode = 0.016 ; }
    return ruleCode; }
public static double checkDT508Tree7Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 529.25) && (wipJS > 3280.5) && (wipJS > 3287.0) && (wipJS <= 5736.5) && (wipJS > 4605.5))  { ruleCode = 0.349 ; }
    return ruleCode; }
public static double checkDT508Tree7Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2702.0) && (wipJS > 2710.0) && (wipJS > 4289.5) && (wipJS <= 4995.0) && (wipJS > 4509.0))  { ruleCode = 0.514 ; }
    return ruleCode; }
public static double checkDT508Tree7Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2702.0) && (wipJS > 2710.0) && (wipJS > 4289.5) && (wipJS > 4995.0) && (wipJS <= 5982.0))  { ruleCode = 0.381 ; }
    return ruleCode; }
public static double checkDT508Tree7Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 529.25) && (eTardJS <= 4263.0) && (wipJS <= 4128.0) && (eTardJS <= 4253.75) && (eTardJS <= 666.5))  { ruleCode = 0.113 ; }
    return ruleCode; }
public static double checkDT508Tree7Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2702.0) && (wipJS > 2710.0) && (wipJS > 4289.5) && (wipJS <= 4995.0) && (wipJS <= 4509.0))  { ruleCode = 0.616 ; }
    return ruleCode; }
public static double checkDT508Tree7Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 529.25) && (eTardJS <= 4263.0) && (wipJS > 4128.0) && (wipJS > 4248.0) && (wipJS > 5713.5))  { ruleCode = 0.019 ; }
    return ruleCode; }
public static double checkDT508Tree7Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2702.0) && (wipJS <= 1765.0) && (wipJS <= 1683.5) && (wipJS <= 1678.0) && (wipJS > 1549.0))  { ruleCode = 7.955 ; }
    return ruleCode; }
public static double checkDT508Tree7Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 529.25) && (wipJS > 3280.5) && (wipJS > 3287.0) && (wipJS > 5736.5) && (eTardJS <= 329.5))  { ruleCode = 0.042 ; }
    return ruleCode; }
public static double checkDT508Tree7Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2702.0) && (wipJS <= 1765.0) && (wipJS > 1683.5) && (wipJS > 1718.0) && (wipJS > 1732.0))  { ruleCode = 0.526 ; }
    return ruleCode; }
public static double checkDT508Tree7Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 529.25) && (eTardJS <= 4263.0) && (wipJS > 4128.0) && (wipJS <= 4248.0) && (wipJS <= 4225.5))  { ruleCode = 0.153 ; }
    return ruleCode; }
public static double checkDT508Tree7Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2702.0) && (wipJS > 2710.0) && (wipJS > 4289.5) && (wipJS > 4995.0) && (wipJS > 5982.0))  { ruleCode = 0.092 ; }
    return ruleCode; }
public static double checkDT508Tree7Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2702.0) && (wipJS <= 1765.0) && (wipJS > 1683.5) && (wipJS <= 1718.0) && (wipJS <= 1703.5))  { ruleCode = 0.32 ; }
    return ruleCode; }
public static double checkDT508Tree7Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2702.0) && (wipJS > 1765.0) && (wipJS > 1770.0) && (wipJS <= 2059.0) && (wipJS > 2045.5))  { ruleCode = 144.634 ; }
    return ruleCode; }
public static double checkDT508Tree7Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2702.0) && (wipJS <= 1765.0) && (wipJS > 1683.5) && (wipJS <= 1718.0) && (wipJS > 1703.5))  { ruleCode = 0.022 ; }
    return ruleCode; }
public static double checkDT508Tree7Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 529.25) && (eTardJS > 4263.0) && (wipJS <= 1685.0) && (wipJS <= 1654.5))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT508Tree7Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2702.0) && (wipJS <= 1765.0) && (wipJS > 1683.5) && (wipJS > 1718.0) && (wipJS <= 1732.0))  { ruleCode = 0.97 ; }
    return ruleCode; }
public static double checkDT508Tree7Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 529.25) && (wipJS <= 3280.5) && (eTardJS <= 9.5) && (eTardJS > 2.75) && (wipJS > 2214.0))  { ruleCode = 0.295 ; }
    return ruleCode; }
public static double checkDT508Tree7Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 529.25) && (wipJS > 3280.5) && (wipJS > 3287.0) && (wipJS > 5736.5) && (eTardJS > 329.5))  { ruleCode = 0.209 ; }
    return ruleCode; }
public static double checkDT508Tree7Path33(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 529.25) && (eTardJS <= 4263.0) && (wipJS > 4128.0) && (wipJS <= 4248.0) && (wipJS > 4225.5))  { ruleCode = 1.226 ; }
    return ruleCode; }
public static double checkDT508Tree7Path34(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 529.25) && (wipJS <= 3280.5) && (eTardJS <= 9.5) && (eTardJS > 2.75) && (wipJS <= 2214.0))  { ruleCode = 0.663 ; }
    return ruleCode; }
public static double checkDT508Tree7Path35(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2702.0) && (wipJS <= 1765.0) && (wipJS <= 1683.5) && (wipJS > 1678.0))  { ruleCode = 43.0 ; }
    return ruleCode; }
public static double checkDT508Tree7Path36(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS <= 2702.0) && (wipJS > 1765.0) && (wipJS <= 1770.0))  { ruleCode = 368.0 ; }
    return ruleCode; }
public static double checkDT508Tree7Path37(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 529.25) && (eTardJS > 4263.0) && (wipJS > 1685.0) && (eTardJS <= 4870.0) && (eTardJS > 4857.75))  { ruleCode = 0.355 ; }
    return ruleCode; }
public static double checkDT508Tree7Path38(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2702.0) && (wipJS <= 2710.0))  { ruleCode = 694.0 ; }
    return ruleCode; }
public static double checkDT508Tree7Path39(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.5) && (wipJS > 2702.0) && (wipJS > 2710.0) && (wipJS <= 4289.5) && (wipJS > 4273.5))  { ruleCode = 398.0 ; }
    return ruleCode; }
public static double checkDT508Tree7Path40(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 529.25) && (wipJS <= 3280.5) && (eTardJS <= 9.5) && (eTardJS <= 2.75) && (wipJS <= 1922.0))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT508Tree7Path41(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 529.25) && (wipJS <= 3280.5) && (eTardJS > 9.5) && (eTardJS <= 190.5) && (eTardJS > 188.5))  { ruleCode = 1.124 ; }
    return ruleCode; }
public static double checkDT508Tree7Path42(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 529.25) && (wipJS > 3280.5) && (wipJS <= 3287.0))  { ruleCode = 2.053 ; }
    return ruleCode; }
public static double checkDT508Tree7Path43(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 529.25) && (eTardJS <= 4263.0) && (wipJS <= 4128.0) && (eTardJS > 4253.75))  { ruleCode = 0.597 ; }
    return ruleCode; }
public static double checkDT508Tree7Path44(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS > 529.25) && (eTardJS > 4263.0) && (wipJS <= 1685.0) && (wipJS > 1654.5))  { ruleCode = -2.88 ; }
    return ruleCode; }
public static double checkDT508Tree7Path45(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.5) && (eTardJS <= 529.25) && (wipJS <= 3280.5) && (eTardJS <= 9.5) && (eTardJS <= 2.75) && (wipJS > 1922.0))  { ruleCode = 0.218 ; }
    return ruleCode; }
public static double checkDT508Tree8Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS > 1064.5) && (eTardJS > 3376.25) && (wipJS > 1685.0) && (eTardJS > 5988.5) && (eTardJS > 17994.0))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT508Tree8Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS <= 4289.5) && (wipJS <= 4283.5) && (wipJS <= 3268.5) && (wipJS <= 1955.5) && (wipJS <= 1951.5))  { ruleCode = 7.712 ; }
    return ruleCode; }
public static double checkDT508Tree8Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS > 1064.5) && (eTardJS > 3376.25) && (wipJS > 1685.0) && (eTardJS > 5988.5) && (eTardJS <= 17994.0))  { ruleCode = 0.006 ; }
    return ruleCode; }
public static double checkDT508Tree8Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS > 1064.5) && (eTardJS <= 3376.25) && (eTardJS <= 3334.0) && (eTardJS <= 3091.0) && (wipJS <= 4344.5))  { ruleCode = 0.032 ; }
    return ruleCode; }
public static double checkDT508Tree8Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS > 1064.5) && (eTardJS > 3376.25) && (wipJS > 1685.0) && (eTardJS <= 5988.5) && (wipJS <= 4881.0))  { ruleCode = 0.008 ; }
    return ruleCode; }
public static double checkDT508Tree8Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS <= 4289.5) && (wipJS <= 4283.5) && (wipJS <= 3268.5) && (wipJS > 1955.5) && (wipJS <= 2823.0))  { ruleCode = 1.485 ; }
    return ruleCode; }
public static double checkDT508Tree8Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS <= 1064.5) && (eTardJS > 230.5) && (wipJS <= 3476.0) && (eTardJS <= 1019.5) && (eTardJS > 243.75))  { ruleCode = 0.101 ; }
    return ruleCode; }
public static double checkDT508Tree8Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS <= 1064.5) && (eTardJS <= 230.5) && (eTardJS <= 227.75) && (eTardJS <= 87.5) && (eTardJS <= 84.5))  { ruleCode = 0.249 ; }
    return ruleCode; }
public static double checkDT508Tree8Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS <= 4289.5) && (wipJS <= 4283.5) && (wipJS > 3268.5) && (wipJS > 3287.5) && (wipJS > 3314.0))  { ruleCode = 9.091 ; }
    return ruleCode; }
public static double checkDT508Tree8Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS <= 1064.5) && (eTardJS <= 230.5) && (eTardJS <= 227.75) && (eTardJS > 87.5) && (eTardJS > 104.5))  { ruleCode = 0.242 ; }
    return ruleCode; }
public static double checkDT508Tree8Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS <= 1064.5) && (eTardJS > 230.5) && (wipJS > 3476.0) && (wipJS > 3503.5) && (eTardJS <= 1039.75))  { ruleCode = 0.184 ; }
    return ruleCode; }
public static double checkDT508Tree8Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS > 1064.5) && (eTardJS <= 3376.25) && (eTardJS <= 3334.0) && (eTardJS <= 3091.0) && (wipJS > 4344.5))  { ruleCode = 0.082 ; }
    return ruleCode; }
public static double checkDT508Tree8Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS <= 4289.5) && (wipJS <= 4283.5) && (wipJS <= 3268.5) && (wipJS > 1955.5) && (wipJS > 2823.0))  { ruleCode = 10.213 ; }
    return ruleCode; }
public static double checkDT508Tree8Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS > 4289.5) && (wipJS > 4379.5) && (wipJS <= 5374.5) && (wipJS > 4395.5) && (wipJS <= 5256.0))  { ruleCode = 0.466 ; }
    return ruleCode; }
public static double checkDT508Tree8Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS > 1064.5) && (eTardJS > 3376.25) && (wipJS > 1685.0) && (eTardJS <= 5988.5) && (wipJS > 4881.0))  { ruleCode = 0.046 ; }
    return ruleCode; }
public static double checkDT508Tree8Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS > 1064.5) && (eTardJS <= 3376.25) && (eTardJS <= 3334.0) && (eTardJS > 3091.0) && (eTardJS > 3106.0))  { ruleCode = 0.066 ; }
    return ruleCode; }
public static double checkDT508Tree8Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS <= 1064.5) && (eTardJS <= 230.5) && (eTardJS <= 227.75) && (eTardJS > 87.5) && (eTardJS <= 104.5))  { ruleCode = 0.064 ; }
    return ruleCode; }
public static double checkDT508Tree8Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS > 4289.5) && (wipJS > 4379.5) && (wipJS <= 5374.5) && (wipJS > 4395.5) && (wipJS > 5256.0))  { ruleCode = 0.686 ; }
    return ruleCode; }
public static double checkDT508Tree8Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS <= 4289.5) && (wipJS <= 4283.5) && (wipJS > 3268.5) && (wipJS > 3287.5) && (wipJS <= 3314.0))  { ruleCode = 33.815 ; }
    return ruleCode; }
public static double checkDT508Tree8Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS > 4289.5) && (wipJS > 4379.5) && (wipJS > 5374.5) && (wipJS <= 5984.0) && (wipJS > 5427.0))  { ruleCode = 0.309 ; }
    return ruleCode; }
public static double checkDT508Tree8Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS <= 1064.5) && (eTardJS > 230.5) && (wipJS <= 3476.0) && (eTardJS <= 1019.5) && (eTardJS <= 243.75))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT508Tree8Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS > 4289.5) && (wipJS <= 4379.5) && (wipJS <= 4375.5) && (wipJS > 4294.5) && (wipJS > 4298.5))  { ruleCode = 0.49 ; }
    return ruleCode; }
public static double checkDT508Tree8Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS > 4289.5) && (wipJS > 4379.5) && (wipJS > 5374.5) && (wipJS > 5984.0) && (wipJS <= 6737.5))  { ruleCode = 0.12 ; }
    return ruleCode; }
public static double checkDT508Tree8Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS <= 1064.5) && (eTardJS > 230.5) && (wipJS <= 3476.0) && (eTardJS > 1019.5) && (wipJS <= 2554.5))  { ruleCode = 0.362 ; }
    return ruleCode; }
public static double checkDT508Tree8Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS > 1064.5) && (eTardJS > 3376.25) && (wipJS <= 1685.0) && (wipJS <= 1654.5))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT508Tree8Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS > 4289.5) && (wipJS > 4379.5) && (wipJS > 5374.5) && (wipJS > 5984.0) && (wipJS > 6737.5))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT508Tree8Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS <= 4289.5) && (wipJS <= 4283.5) && (wipJS <= 3268.5) && (wipJS <= 1955.5) && (wipJS > 1951.5))  { ruleCode = 325.497 ; }
    return ruleCode; }
public static double checkDT508Tree8Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS > 4289.5) && (wipJS > 4379.5) && (wipJS <= 5374.5) && (wipJS <= 4395.5) && (wipJS <= 4385.5))  { ruleCode = 0.9 ; }
    return ruleCode; }
public static double checkDT508Tree8Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS <= 1064.5) && (eTardJS > 230.5) && (wipJS <= 3476.0) && (eTardJS > 1019.5) && (wipJS > 2554.5))  { ruleCode = 0.138 ; }
    return ruleCode; }
public static double checkDT508Tree8Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS <= 1064.5) && (eTardJS <= 230.5) && (eTardJS <= 227.75) && (eTardJS <= 87.5) && (eTardJS > 84.5))  { ruleCode = 2.713 ; }
    return ruleCode; }
public static double checkDT508Tree8Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS > 4289.5) && (wipJS > 4379.5) && (wipJS > 5374.5) && (wipJS <= 5984.0) && (wipJS <= 5427.0))  { ruleCode = 0.076 ; }
    return ruleCode; }
public static double checkDT508Tree8Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS <= 1064.5) && (eTardJS > 230.5) && (wipJS > 3476.0) && (wipJS > 3503.5) && (eTardJS > 1039.75))  { ruleCode = 0.75 ; }
    return ruleCode; }
public static double checkDT508Tree8Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS > 1064.5) && (eTardJS <= 3376.25) && (eTardJS > 3334.0) && (eTardJS > 3344.5) && (eTardJS > 3362.25))  { ruleCode = 0.049 ; }
    return ruleCode; }
public static double checkDT508Tree8Path33(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS <= 1064.5) && (eTardJS <= 230.5) && (eTardJS > 227.75) && (wipJS > 2860.0))  { ruleCode = 2.053 ; }
    return ruleCode; }
public static double checkDT508Tree8Path34(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS > 1064.5) && (eTardJS > 3376.25) && (wipJS <= 1685.0) && (wipJS > 1654.5))  { ruleCode = -2.88 ; }
    return ruleCode; }
public static double checkDT508Tree8Path35(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS <= 1064.5) && (eTardJS <= 230.5) && (eTardJS > 227.75) && (wipJS <= 2860.0))  { ruleCode = 0.142 ; }
    return ruleCode; }
public static double checkDT508Tree8Path36(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS <= 4289.5) && (wipJS <= 4283.5) && (wipJS > 3268.5) && (wipJS <= 3287.5) && (wipJS <= 3280.5))  { ruleCode = 158.0 ; }
    return ruleCode; }
public static double checkDT508Tree8Path37(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS <= 4289.5) && (wipJS <= 4283.5) && (wipJS > 3268.5) && (wipJS <= 3287.5) && (wipJS > 3280.5))  { ruleCode = 807.0 ; }
    return ruleCode; }
public static double checkDT508Tree8Path38(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS <= 1064.5) && (eTardJS > 230.5) && (wipJS > 3476.0) && (wipJS <= 3503.5))  { ruleCode = 1.391 ; }
    return ruleCode; }
public static double checkDT508Tree8Path39(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS <= 4289.5) && (wipJS > 4283.5))  { ruleCode = 398.0 ; }
    return ruleCode; }
public static double checkDT508Tree8Path40(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS > 1064.5) && (eTardJS <= 3376.25) && (eTardJS > 3334.0) && (eTardJS > 3344.5) && (eTardJS <= 3362.25))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT508Tree8Path41(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS > 4289.5) && (wipJS <= 4379.5) && (wipJS <= 4375.5) && (wipJS <= 4294.5))  { ruleCode = 0.835 ; }
    return ruleCode; }
public static double checkDT508Tree8Path42(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS > 4289.5) && (wipJS <= 4379.5) && (wipJS <= 4375.5) && (wipJS > 4294.5) && (wipJS <= 4298.5))  { ruleCode = 0.156 ; }
    return ruleCode; }
public static double checkDT508Tree8Path43(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS > 4289.5) && (wipJS <= 4379.5) && (wipJS > 4375.5))  { ruleCode = 21.0 ; }
    return ruleCode; }
public static double checkDT508Tree8Path44(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS > 1064.5) && (eTardJS <= 3376.25) && (eTardJS <= 3334.0) && (eTardJS > 3091.0) && (eTardJS <= 3106.0))  { ruleCode = 0.83 ; }
    return ruleCode; }
public static double checkDT508Tree8Path45(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 0.75) && (eTardJS > 1064.5) && (eTardJS <= 3376.25) && (eTardJS > 3334.0) && (eTardJS <= 3344.5))  { ruleCode = 1.396 ; }
    return ruleCode; }
public static double checkDT508Tree8Path46(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 0.75) && (wipJS > 4289.5) && (wipJS > 4379.5) && (wipJS <= 5374.5) && (wipJS <= 4395.5) && (wipJS > 4385.5))  { ruleCode = 0.716 ; }
    return ruleCode; }
public static double checkDT508Tree9Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS > 1225.5) && (eTardJS > 3344.5) && (wipJS > 1685.0) && (eTardJS > 12951.5) && (eTardJS > 17994.0))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT508Tree9Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS > 1225.5) && (eTardJS > 3344.5) && (wipJS > 1685.0) && (eTardJS <= 12951.5) && (eTardJS <= 12945.75))  { ruleCode = 0.013 ; }
    return ruleCode; }
public static double checkDT508Tree9Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS <= 2849.0) && (wipJS <= 1400.5) && (wipJS <= 335.0))  { ruleCode = 6.236 ; }
    return ruleCode; }
public static double checkDT508Tree9Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS > 1225.5) && (eTardJS <= 3344.5) && (eTardJS <= 3336.25) && (wipJS > 2227.0) && (wipJS > 2236.5))  { ruleCode = 0.064 ; }
    return ruleCode; }
public static double checkDT508Tree9Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS <= 1225.5) && (eTardJS <= 208.75) && (wipJS <= 6110.5) && (wipJS <= 4409.0) && (eTardJS <= 188.5))  { ruleCode = 0.245 ; }
    return ruleCode; }
public static double checkDT508Tree9Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS > 1225.5) && (eTardJS > 3344.5) && (wipJS > 1685.0) && (eTardJS > 12951.5) && (eTardJS <= 17994.0))  { ruleCode = 0.003 ; }
    return ruleCode; }
public static double checkDT508Tree9Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS <= 1225.5) && (eTardJS > 208.75) && (wipJS <= 3690.0) && (wipJS > 1661.0) && (wipJS <= 2684.0))  { ruleCode = 0.156 ; }
    return ruleCode; }
public static double checkDT508Tree9Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS <= 2849.0) && (wipJS > 1400.5) && (wipJS > 1404.5) && (wipJS <= 2059.0) && (wipJS <= 1944.0))  { ruleCode = 5.086 ; }
    return ruleCode; }
public static double checkDT508Tree9Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS > 2849.0) && (wipJS > 2859.0) && (wipJS > 3935.5) && (wipJS > 4296.5) && (wipJS > 4377.5))  { ruleCode = 0.445 ; }
    return ruleCode; }
public static double checkDT508Tree9Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS <= 2849.0) && (wipJS > 1400.5) && (wipJS > 1404.5) && (wipJS > 2059.0) && (wipJS <= 2494.5))  { ruleCode = 0.639 ; }
    return ruleCode; }
public static double checkDT508Tree9Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS > 2849.0) && (wipJS > 2859.0) && (wipJS <= 3935.5) && (wipJS <= 3828.5) && (wipJS <= 3463.5))  { ruleCode = 20.886 ; }
    return ruleCode; }
public static double checkDT508Tree9Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS <= 1225.5) && (eTardJS > 208.75) && (wipJS > 3690.0) && (wipJS > 3783.0) && (wipJS > 4159.5))  { ruleCode = 0.239 ; }
    return ruleCode; }
public static double checkDT508Tree9Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS <= 1225.5) && (eTardJS > 208.75) && (wipJS <= 3690.0) && (wipJS > 1661.0) && (wipJS > 2684.0))  { ruleCode = 0.068 ; }
    return ruleCode; }
public static double checkDT508Tree9Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS <= 2849.0) && (wipJS > 1400.5) && (wipJS > 1404.5) && (wipJS > 2059.0) && (wipJS > 2494.5))  { ruleCode = 6.393 ; }
    return ruleCode; }
public static double checkDT508Tree9Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS > 1225.5) && (eTardJS <= 3344.5) && (eTardJS <= 3336.25) && (wipJS <= 2227.0) && (wipJS <= 2060.5))  { ruleCode = 0.012 ; }
    return ruleCode; }
public static double checkDT508Tree9Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS > 2849.0) && (wipJS > 2859.0) && (wipJS > 3935.5) && (wipJS <= 4296.5) && (wipJS <= 4283.5))  { ruleCode = 7.377 ; }
    return ruleCode; }
public static double checkDT508Tree9Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS > 2849.0) && (wipJS > 2859.0) && (wipJS <= 3935.5) && (wipJS <= 3828.5) && (wipJS > 3463.5))  { ruleCode = 68.797 ; }
    return ruleCode; }
public static double checkDT508Tree9Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS <= 2849.0) && (wipJS > 1400.5) && (wipJS > 1404.5) && (wipJS <= 2059.0) && (wipJS > 1944.0))  { ruleCode = 54.245 ; }
    return ruleCode; }
public static double checkDT508Tree9Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS <= 1225.5) && (eTardJS <= 208.75) && (wipJS <= 6110.5) && (wipJS > 4409.0) && (wipJS > 4433.0))  { ruleCode = 0.334 ; }
    return ruleCode; }
public static double checkDT508Tree9Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS <= 1225.5) && (eTardJS > 208.75) && (wipJS > 3690.0) && (wipJS > 3783.0) && (wipJS <= 4159.5))  { ruleCode = 0.11 ; }
    return ruleCode; }
public static double checkDT508Tree9Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS <= 1225.5) && (eTardJS > 208.75) && (wipJS <= 3690.0) && (wipJS <= 1661.0) && (eTardJS > 283.5))  { ruleCode = 0.018 ; }
    return ruleCode; }
public static double checkDT508Tree9Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS > 1225.5) && (eTardJS <= 3344.5) && (eTardJS <= 3336.25) && (wipJS <= 2227.0) && (wipJS > 2060.5))  { ruleCode = -0.015 ; }
    return ruleCode; }
public static double checkDT508Tree9Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS <= 2849.0) && (wipJS <= 1400.5) && (wipJS > 335.0) && (wipJS <= 1325.5) && (wipJS > 1155.0))  { ruleCode = 0.196 ; }
    return ruleCode; }
public static double checkDT508Tree9Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS <= 2849.0) && (wipJS <= 1400.5) && (wipJS > 335.0) && (wipJS <= 1325.5) && (wipJS <= 1155.0))  { ruleCode = 2.621 ; }
    return ruleCode; }
public static double checkDT508Tree9Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS > 2849.0) && (wipJS > 2859.0) && (wipJS <= 3935.5) && (wipJS > 3828.5) && (wipJS > 3835.0))  { ruleCode = 49.49 ; }
    return ruleCode; }
public static double checkDT508Tree9Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS > 2849.0) && (wipJS > 2859.0) && (wipJS > 3935.5) && (wipJS > 4296.5) && (wipJS <= 4377.5))  { ruleCode = 1.975 ; }
    return ruleCode; }
public static double checkDT508Tree9Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS <= 2849.0) && (wipJS <= 1400.5) && (wipJS > 335.0) && (wipJS > 1325.5) && (wipJS > 1349.5))  { ruleCode = 0.362 ; }
    return ruleCode; }
public static double checkDT508Tree9Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS <= 1225.5) && (eTardJS <= 208.75) && (wipJS <= 6110.5) && (wipJS <= 4409.0) && (eTardJS > 188.5))  { ruleCode = 0.456 ; }
    return ruleCode; }
public static double checkDT508Tree9Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS <= 2849.0) && (wipJS <= 1400.5) && (wipJS > 335.0) && (wipJS > 1325.5) && (wipJS <= 1349.5))  { ruleCode = 11.707 ; }
    return ruleCode; }
public static double checkDT508Tree9Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS <= 1225.5) && (eTardJS > 208.75) && (wipJS <= 3690.0) && (wipJS <= 1661.0) && (eTardJS <= 283.5))  { ruleCode = 0.081 ; }
    return ruleCode; }
public static double checkDT508Tree9Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS <= 1225.5) && (eTardJS > 208.75) && (wipJS > 3690.0) && (wipJS <= 3783.0) && (eTardJS > 468.75))  { ruleCode = 0.411 ; }
    return ruleCode; }
public static double checkDT508Tree9Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS > 1225.5) && (eTardJS > 3344.5) && (wipJS <= 1685.0) && (wipJS <= 1636.0))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT508Tree9Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS <= 1225.5) && (eTardJS > 208.75) && (wipJS > 3690.0) && (wipJS <= 3783.0) && (eTardJS <= 468.75))  { ruleCode = 0.745 ; }
    return ruleCode; }
public static double checkDT508Tree9Path33(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS > 1225.5) && (eTardJS <= 3344.5) && (eTardJS <= 3336.25) && (wipJS > 2227.0) && (wipJS <= 2236.5))  { ruleCode = 0.817 ; }
    return ruleCode; }
public static double checkDT508Tree9Path34(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS <= 1225.5) && (eTardJS <= 208.75) && (wipJS > 6110.5) && (eTardJS > 85.5))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT508Tree9Path35(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS <= 2849.0) && (wipJS > 1400.5) && (wipJS <= 1404.5))  { ruleCode = 892.0 ; }
    return ruleCode; }
public static double checkDT508Tree9Path36(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS > 1225.5) && (eTardJS > 3344.5) && (wipJS > 1685.0) && (eTardJS <= 12951.5) && (eTardJS > 12945.75))  { ruleCode = 0.185 ; }
    return ruleCode; }
public static double checkDT508Tree9Path37(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS > 2849.0) && (wipJS <= 2859.0))  { ruleCode = 609.0 ; }
    return ruleCode; }
public static double checkDT508Tree9Path38(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS > 2849.0) && (wipJS > 2859.0) && (wipJS <= 3935.5) && (wipJS > 3828.5) && (wipJS <= 3835.0))  { ruleCode = 1186.0 ; }
    return ruleCode; }
public static double checkDT508Tree9Path39(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS <= 1.25) && (wipJS > 2849.0) && (wipJS > 2859.0) && (wipJS > 3935.5) && (wipJS <= 4296.5) && (wipJS > 4283.5))  { ruleCode = 398.0 ; }
    return ruleCode; }
public static double checkDT508Tree9Path40(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS > 1225.5) && (eTardJS > 3344.5) && (wipJS <= 1685.0) && (wipJS > 1636.0))  { ruleCode = -2.88 ; }
    return ruleCode; }
public static double checkDT508Tree9Path41(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS <= 1225.5) && (eTardJS <= 208.75) && (wipJS > 6110.5) && (eTardJS <= 85.5))  { ruleCode = 0.0 ; }
    return ruleCode; }
public static double checkDT508Tree9Path42(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS > 1225.5) && (eTardJS <= 3344.5) && (eTardJS > 3336.25))  { ruleCode = 1.396 ; }
    return ruleCode; }
public static double checkDT508Tree9Path43(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    double ruleCode = -1.0;
    if ((eTardJS > 1.25) && (eTardJS <= 1225.5) && (eTardJS <= 208.75) && (wipJS <= 6110.5) && (wipJS > 4409.0) && (wipJS <= 4433.0))  { ruleCode = 0.869 ; }
    return ruleCode; }
}
