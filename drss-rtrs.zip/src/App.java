import main.Main;

public class App {
    public static void main(String[] args) throws Exception {
        //System.out.println("Hello, World! "+args[0]);
        Main.prototipo(args);
        //Main.mainGP(args);
    }
}
