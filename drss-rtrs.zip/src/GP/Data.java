package GP;

import input.Instance;
import simulator.Order;
import simulator.SimulationStatus;
import ec.gp.GPData;

@SuppressWarnings("serial")
public class Data extends GPData{

	public Instance instance;
	public Order order;
	public double timeInstant;
	public double value;
	public boolean booleanValue;
	public double utilizationLevel;
	public double allowanceFactor;
	public SimulationStatus status;
	
	public double  winQ;
	public double  ptWinRR;
	public double  winRR;
	public double  qs;	
	public double  maxPTiQ;
	public double  minPTiQ;
	public double  maxDDiQ;
	public double  minDDiQ;	
	public double  wriQ;
	public double wor;
	public double  wiQ;
	public double  nqs;
	public double  qpt;
	public double sRPT;
	public double soRPT;
	public double crPT;
	
	public void copyTo(GPData other){ 
		
		((Data)other).order = order;
		((Data)other).value = value; 
		((Data)other).booleanValue = booleanValue; 
		((Data)other).instance = instance; 
		((Data)other).utilizationLevel = utilizationLevel; 
		((Data)other).winQ = winQ; 
		((Data)other).wriQ = wriQ; 
		((Data)other).wor = wor; 
		((Data)other).wiQ = wiQ; 
		((Data)other).winRR = winRR; 
		((Data)other).ptWinRR = ptWinRR; 
		((Data)other).qs = qs; 		
		((Data)other).nqs = nqs;
		((Data)other).qpt = qpt;
		((Data)other).maxPTiQ = maxPTiQ;
		((Data)other).minPTiQ = minPTiQ;
		((Data)other).maxDDiQ = maxDDiQ;
		((Data)other).minDDiQ = minDDiQ;		
		((Data)other).sRPT = sRPT;
		((Data)other).soRPT = sRPT;
		((Data)other).crPT = crPT;
	}	
	public Object clone()
	{		
		Data other = (Data)(super.clone());
		other.setOrder(order);
		other.value = value;
		return other;
	}	
	
	public void setOrder(Order order){
		this.order = order;
	}	
}
