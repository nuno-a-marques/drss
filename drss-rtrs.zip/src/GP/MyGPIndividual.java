package GP;




import ec.gp.GPIndividual;
import ec.gp.koza.KozaFitness;

import java.util.Comparator;


public class MyGPIndividual extends GPIndividual implements Comparator<GPIndividual> {

	public boolean evaluated1;
	
	private static final long serialVersionUID = 4015227625115567474L;
	//Adicioando por mim, Rui, e classe individuo:
	//Cada individuo vai ter associado a si um Hashmap da situacao e a ordem dos jobs em cada situacao
	
	public MyGPIndividual(){
		super();
		evaluated1 = false;
	}
	
    public int compare(GPIndividual ind1, GPIndividual ind2) 
    { 
        return (int)(((KozaFitness)(ind1.fitness)).standardizedFitness() - ((KozaFitness)(ind2.fitness)).standardizedFitness()); 
    }
    
}

class SortGPIndividual implements Comparator<GPIndividual> 
{ 
    // Used for sorting in ascending order of fitness
    public int compare(GPIndividual ind1, GPIndividual ind2) 
    { 
        return (int)(((KozaFitness)(ind1.fitness)).standardizedFitness() - ((KozaFitness)(ind2.fitness)).standardizedFitness()); 
    } 
} 


