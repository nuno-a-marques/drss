package GP.terminals;

import simulator.DispatchingRule;
import simulator.Order;
import simulator.SimulationStatus;
import GP.Data;
import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;

public class WRIQNode extends GPNode{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void eval(EvolutionState state, int thread, GPData input,
			ADFStack stack, GPIndividual individual, Problem problem) {

		if(((Data)input).wriQ != 0)
			((Data)input).value = ((Data)input).wriQ;
		else{

			Order order = ((Data)input).order;
			SimulationStatus status = ((Data)input).status;

			double wriQ = DispatchingRule.getWRIQ(status, order) ;

			((Data)input).value = wriQ;
			((Data)input).wriQ  = wriQ;
		}
	}

	public String toString() { return "WriQ"; }

	public int expectedChildren() { return 0; }	
	
	public int atDepth() { return 	1; }
	
}