package GP.terminals;


import simulator.DispatchingRule;
import simulator.Order;
import GP.Data;
import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;

public class TailPTimeNode extends GPNode{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void eval(EvolutionState state, int thread, GPData input,
			ADFStack stack, GPIndividual individual, Problem problem) {

		Order order = ((Data)input).order;		
		((Data)input).value =  DispatchingRule.getTailRemaining(order);		

	}

	public String toString() { return "TailPTime"; }
	
	public int expectedChildren() { return 0; }	
	
	public int atDepth() { return 	1; }
}