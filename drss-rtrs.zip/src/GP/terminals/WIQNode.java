package GP.terminals;

import simulator.DispatchingRule;
import simulator.Order;
import simulator.SimulationStatus;
import GP.Data;
import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;

public class WIQNode extends GPNode{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void eval(EvolutionState state, int thread, GPData input,
			ADFStack stack, GPIndividual individual, Problem problem) {

		if(((Data)input).wiQ != 0)
			((Data)input).value = ((Data)input).wiQ;

		else{

			Order order = ((Data)input).order;
			SimulationStatus status = ((Data)input).status;

			double wiQ = DispatchingRule.getWIQ(status, order) ;

			((Data)input).value = wiQ;
			((Data)input).wiQ  = wiQ;
		}
	}

	public String toString() { return "WiQ"; }

	public int expectedChildren() { return 0; }	
	
	public int atDepth() { return 	1; }
}