package GP.terminals;

import GP.Data;
import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;

public class PTDividedByRPTNode extends GPNode{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void eval(EvolutionState state, int thread, GPData input,
			ADFStack stack, GPIndividual individual, Problem problem) {

			double rpt = ((Data)input).order.getRemainingProcessingTime();
			if(rpt > 0)
				((Data)input).value =  ((Data)input).order.getExpectedTime()/rpt;
			else
				((Data)input).value = ((Data)input).order.getExpectedTime();					
	}

	public String toString() { return "PT/RPT"; }

	public int expectedChildren() { return 0; }	
	
	public int atDepth() { return 	3; }
}