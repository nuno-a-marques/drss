package GP.terminals;

import simulator.Order;
import GP.Data;
import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;

public class CRPTNode extends GPNode{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void eval(EvolutionState state, int thread, GPData input,
			ADFStack stack, GPIndividual individual, Problem problem) {

		if(((Data)input).crPT != -1)
			((Data)input).value = ((Data)input).crPT;

		else{		
			Order order =  ((Data)input).order;	
			double timeInstant = ((Data)input).timeInstant;			
			double pt = order.getExpectedTime();
			double allowance = Double.max(0, order.getJob().getDueDate() - timeInstant);
			double rpt = order.getRemainingProcessingTime();
			
			if(rpt > 0)
				((Data)input).value =  pt*allowance/rpt;
			else
				((Data)input).value = pt*allowance;	
			
			((Data)input).crPT  = ((Data)input).value;
		}

	}

	public String toString() { return "CR*PT"; }

	public int expectedChildren() { return 0; }	
	
	public int atDepth() { return 	5; }
}