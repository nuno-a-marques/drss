package GP.terminals;

import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;
import simulator.DispatchingRule;
import simulator.Order;
import simulator.SimulationStatus;
import GP.Data;

public class MinPTQueueNode extends GPNode{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void eval(EvolutionState state, int thread, GPData input,
			ADFStack stack, GPIndividual individual, Problem problem) {

		if(((Data)input).minPTiQ != 0)
			((Data)input).value = ((Data)input).minPTiQ;
		else{

			Order order = ((Data)input).order;
			SimulationStatus status = ((Data)input).status;

			double minPTiQ = DispatchingRule.getMinPTQueue(status, order) ;

			((Data)input).value = minPTiQ;
			((Data)input).minPTiQ  = minPTiQ;
		}
	}

	public String toString() { return "minPTiQ"; }

	public int expectedChildren() { return 0; }	
	
	public int atDepth() { return 	1; }
	
}
