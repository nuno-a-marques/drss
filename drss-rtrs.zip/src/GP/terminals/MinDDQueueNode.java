package GP.terminals;

import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;
import simulator.DispatchingRule;
import simulator.Order;
import simulator.SimulationStatus;
import GP.Data;

public class MinDDQueueNode extends GPNode{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void eval(EvolutionState state, int thread, GPData input,
			ADFStack stack, GPIndividual individual, Problem problem) {

		if(((Data)input).minDDiQ != 0)
			((Data)input).value = ((Data)input).minDDiQ;
		else{

			Order order = ((Data)input).order;
			SimulationStatus status = ((Data)input).status;

			double minDDiQ = DispatchingRule.getMinDDQueue(status, order) ;

			((Data)input).value = minDDiQ;
			((Data)input).minDDiQ  = minDDiQ;
		}
	}

	public String toString() { return "minDDiQ"; }

	public int expectedChildren() { return 0; }	
	
	public int atDepth() { return 	1; }
	
}
