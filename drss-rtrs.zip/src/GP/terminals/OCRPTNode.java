package GP.terminals;

import simulator.Order;
import GP.Data;
import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;

public class OCRPTNode extends GPNode{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void eval(EvolutionState state, int thread, GPData input,
			ADFStack stack, GPIndividual individual, Problem problem) {

		Order order =  ((Data)input).order;	
		double timeInstant = ((Data)input).timeInstant;					
		double allowance = order.getJob().getDueDate() - timeInstant;
		double pt = order.getExpectedTime();
		
		((Data)input).value = pt*allowance/order.getRemainingProcessingTime();
			
	}

	public String toString() { return "OCR*PT"; }

	public int expectedChildren() { return 0; }	
	
	public int atDepth() { return 	5; }
}