package GP.terminals;

import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;
import GP.Data;

public class ProcessingTimePenaltyRel extends GPNode{
    private static final long serialVersionUID = 1L;

	public void eval(EvolutionState state, int thread, GPData input, ADFStack stack, GPIndividual individual, Problem problem) {
		((Data)input).value =  ( ((Data)input).order.getExpectedTime() ) / ((Data)input).order.getOperation().getAverageExpectedTime();			
	}

	public String toString() { return "PTr"; }
	
	public int expectedChildren() { return 0; }	
	
	public int atDepth() { return 	1; }    
}
