package GP.terminals;

import GP.Data;
import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;
import input.Instance;

public class PTimeNodeAdimensional extends GPNode{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void eval(EvolutionState state, int thread, GPData input,ADFStack stack, GPIndividual individual, Problem problem) {

        Instance instance = ((Data)input).instance;
        double mpt=((double)instance.getMaxProcessingTime()-(double)instance.getMinProcessingTime())/2.0;
		((Data)input).value =  ((Data)input).order.getExpectedTime()/mpt;			
	}

	public String toString() { return "PTAdm"; }
	
	public int expectedChildren() { return 0; }	
	
	public int atDepth() { return 	1; }
}
