package GP.terminals;


import simulator.DispatchingRule;
import simulator.Order;
import simulator.SimulationStatus;
import GP.Data;
import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;

public class WisqNode extends GPNode{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void eval(EvolutionState state, int thread, GPData input,
			ADFStack stack, GPIndividual individual, Problem problem) {

		SimulationStatus status = ((Data)input).status;
		
		if(((Data)input).wor != 0)
			((Data)input).value = ((Data)input).wor;
		else
		{
			Order order =  ((Data)input).order;	
			double timeInstant = ((Data)input).timeInstant;			
			
			((Data)input).value = DispatchingRule.getRelativeWisQ(status, order.getOperation(), order.getDueDate(),order.getRemainingProcessingTime(), timeInstant);			
			((Data)input).wor  = ((Data)input).value;
		}
	}

	public String toString() { return "WisQ"; }
	
	public int expectedChildren() { return 0; }	
	
	public int atDepth() { return 	1; }
		
}