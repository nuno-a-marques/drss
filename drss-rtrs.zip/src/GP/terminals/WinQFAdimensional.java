package GP.terminals;

import simulator.DispatchingRule;
import simulator.Order;
import simulator.SimulationStatus;
import GP.Data;
import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;
import input.Instance;

public class WinQFAdimensional extends GPNode{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void eval(EvolutionState state, int thread, GPData input,
			ADFStack stack, GPIndividual individual, Problem problem) {

			Order order = ((Data)input).order;
			SimulationStatus status = ((Data)input).status;
			Instance instance = ((Data)input).instance;

			double winQF = DispatchingRule.getWINQF(status, order) ;
			double mpt=((double)instance.getMaxProcessingTime()-(double)instance.getMinProcessingTime())/2.0;

			((Data)input).value = winQF/mpt;

	}

	public String toString() { return "WinQFAdm"; }

	public int expectedChildren() { return 0; }	
	
	public int atDepth() { return 	1; }
    
}
