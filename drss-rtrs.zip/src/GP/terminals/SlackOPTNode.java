package GP.terminals;

import simulator.Order;
import GP.Data;
import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;

public class SlackOPTNode extends GPNode{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void eval(EvolutionState state, int thread, GPData input,
			ADFStack stack, GPIndividual individual, Problem problem) {

		if(((Data)input).soRPT != Double.MAX_VALUE)
			((Data)input).value = ((Data)input).soRPT;

		else{

			Order order = ((Data)input).order;
			double rpt = order.getRemainingProcessingTime();			
			double timeInstant = ((Data)input).timeInstant;					
			double slack = Math.max(0,  order.getOperation().getDueDate() - timeInstant - order.getExpectedTime());
				
			if(rpt > 0)
				((Data)input).value =  slack*order.getExpectedTime()/rpt;
			else
				((Data)input).value = slack*order.getExpectedTime();	
			
			((Data)input).soRPT  = ((Data)input).value;
		}

	}

	public String toString() { return "SO*PT/RPT"; }

	public int expectedChildren() { return 0; }	
	
	public int atDepth() { return 	3; }
}