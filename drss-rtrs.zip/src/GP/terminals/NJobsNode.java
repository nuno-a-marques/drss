package GP.terminals;

import GP.Data;
import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;

public class NJobsNode extends GPNode{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void eval(EvolutionState state, int thread, GPData input,
			ADFStack stack, GPIndividual individual, Problem problem) {

		((Data)input).value =  ((Data)input).status.getNumJobs();		
	}

	public String toString() { return "j"; }
	
	public int expectedChildren() { return 0; }	
	
	public int atDepth() { return 	1; }
}