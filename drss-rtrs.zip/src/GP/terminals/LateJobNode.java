package GP.terminals;

import simulator.Order;
import GP.Data;
import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;

public class LateJobNode extends GPNode{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void eval(EvolutionState state, int thread, GPData input,
			ADFStack stack, GPIndividual individual, Problem problem) {

		double slack;
		Order order =  ((Data)input).order;	
		double timeInstant = ((Data)input).timeInstant;
		slack = order.getJob().getDueDate() - timeInstant - order.getRemainingProcessingTime();

		((Data)input).booleanValue =  slack < 0;				
	}

	public String toString() { return "LateJob"; }

	public int expectedChildren() { return 0; }	
	
	public int atDepth() { return 	1; }
}