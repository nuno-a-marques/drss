package GP.terminals;

import simulator.Order;
import GP.Data;
import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;
import input.Instance;

public class NextPTimeNodeAdimensional extends GPNode{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void eval(EvolutionState state, int thread, GPData input,
			ADFStack stack, GPIndividual individual, Problem problem) {

		Order order = ((Data)input).order;
        Instance instance = ((Data)input).instance;
        double mpt=((double)instance.getMaxProcessingTime()-(double)instance.getMinProcessingTime())/2.0;
		if(order.getOperation().getSucessor() == null)
			((Data)input).value =  0;
		else
			((Data)input).value = 	order.getOperation().getSucessor().getAverageExpectedTime()/mpt;
	}

	public String toString() { return "NPTAdm"; }
	
	public int expectedChildren() { return 0; }	
	
	public int atDepth() { return 	1; }
}
