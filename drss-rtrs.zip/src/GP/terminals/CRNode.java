package GP.terminals;

import simulator.Order;
import GP.Data;
import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;

public class CRNode extends GPNode{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void eval(EvolutionState state, int thread, GPData input,
			ADFStack stack, GPIndividual individual, Problem problem) {

		Order order =  ((Data)input).order;	
		double timeInstant = ((Data)input).timeInstant;					
		double allowance = Double.max(0, order.getJob().getDueDate() - timeInstant);
		
		((Data)input).value = allowance/order.getRemainingProcessingTime();
			
	}

	public String toString() { return "CR"; }

	public int expectedChildren() { return 0; }	
	
	public int atDepth() { return 	3; }
}