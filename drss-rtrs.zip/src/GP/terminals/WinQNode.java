package GP.terminals;

import simulator.DispatchingRule;
import simulator.Order;
import simulator.SimulationStatus;
import GP.Data;
import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;

public class WinQNode extends GPNode{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void eval(EvolutionState state, int thread, GPData input,
			ADFStack stack, GPIndividual individual, Problem problem) {

		if(((Data)input).winQ != 0)
			((Data)input).value = ((Data)input).winQ;

		else{

			Order order = ((Data)input).order;
			SimulationStatus status = ((Data)input).status;

			double winQ = DispatchingRule.getWINQ(status, order) ;

			((Data)input).value = winQ;
			((Data)input).winQ  = winQ;
		}
	}

	public String toString() { return "WinQ"; }

	public int expectedChildren() { return 0; }	
	
	public int atDepth() { return 	1; }
}