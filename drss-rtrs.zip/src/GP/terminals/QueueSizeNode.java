package GP.terminals;

import simulator.Order;
import simulator.SimulationStatus;
import GP.Data;
import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;

public class QueueSizeNode extends GPNode{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void eval(EvolutionState state, int thread, GPData input,
			ADFStack stack, GPIndividual individual, Problem problem) {

		double qs = ((Data)input).qs; 
		if(qs == 0){
			Order order = ((Data)input).order;
			SimulationStatus status = ((Data)input).status;
			((Data)input).value = status.getQueueSize(order.getMachine());		
			((Data)input).qs = ((Data)input).value;
		}
		else
			((Data)input).value = qs;

	}

	public String toString() { return "QS"; }

	public int expectedChildren() { return 0; }	
	
	public int atDepth() { return 	1; }
	

}