package GP.terminals;

import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;
import simulator.DispatchingRule;
import simulator.Order;
import simulator.SimulationStatus;
import GP.Data;

public class MaxDDQueueNode extends GPNode{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void eval(EvolutionState state, int thread, GPData input,
			ADFStack stack, GPIndividual individual, Problem problem) {

		if(((Data)input).maxDDiQ != 0)
			((Data)input).value = ((Data)input).maxDDiQ;
		else{

			Order order = ((Data)input).order;
			SimulationStatus status = ((Data)input).status;

			double maxDDiQ = DispatchingRule.getMaxDDQueue(status, order) ;

			((Data)input).value = maxDDiQ;
			((Data)input).maxDDiQ  = maxDDiQ;
		}
	}

	public String toString() { return "maxDDiQ"; }

	public int expectedChildren() { return 0; }	
	
	public int atDepth() { return 	1; }
	
}
