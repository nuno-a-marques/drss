package GP.terminals;

import simulator.Order;
import GP.Data;
import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;

public class OPReadyTimeNode extends GPNode{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void eval(EvolutionState state, int thread, GPData input,
			ADFStack stack, GPIndividual individual, Problem problem) {

		Order order =  ((Data)input).order;	
		((Data)input).value = order.getEnteringQueueTime();	

	}

	public String toString() { return "OPReady"; }

	public int expectedChildren() { return 0; }	
	
	public int atDepth() { return 	1; }
}