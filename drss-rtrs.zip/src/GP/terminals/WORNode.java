package GP.terminals;

import simulator.DispatchingRule;
import simulator.Order;
import simulator.SimulationStatus;
import GP.Data;
import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;

public class WORNode extends GPNode{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void eval(EvolutionState state, int thread, GPData input,
			ADFStack stack, GPIndividual individual, Problem problem) {

		if(((Data)input).wor != 0)
			((Data)input).value = ((Data)input).wor;

		else{

			Order order = ((Data)input).order;
			SimulationStatus status = ((Data)input).status;

			double wor = DispatchingRule.getWOR(status, order)/order.getJob().getNumOperationsLeft();

			((Data)input).value = wor;
			((Data)input).wor  = wor;
		}
	}

	public String toString() { return "WOR"; }

	public int expectedChildren() { return 0; }	
	
	public int atDepth() { return 	1; }
}