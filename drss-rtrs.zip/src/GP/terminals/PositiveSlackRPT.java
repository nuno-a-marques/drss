package GP.terminals;

import simulator.Order;
import GP.Data;
import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;

public class PositiveSlackRPT extends GPNode{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void eval(EvolutionState state, int thread, GPData input,
			ADFStack stack, GPIndividual individual, Problem problem) {

		Order order = ((Data)input).order;
		double rpt = order.getRemainingProcessingTime();			
		double timeInstant = ((Data)input).timeInstant;					
		double slack = Math.max(0,  order.getJob().getDueDate() - timeInstant - rpt);
			
		if(rpt > 0)
			((Data)input).value =  slack*rpt;
		else
			((Data)input).value = slack;	
	}

	public String toString() { return "Slack+/RPT"; }

	public int expectedChildren() { return 0; }	
	
	public int atDepth() { return 	3; }
}