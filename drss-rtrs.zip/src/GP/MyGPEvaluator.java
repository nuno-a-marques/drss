package GP;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;

//import javax.lang.model.util.ElementScanner6;

import utils.Utils.EvaluationType;

import main.GlobalParameters;

import ec.Evaluator;
import ec.EvolutionState;
import ec.Fitness;
import ec.Individual;
import ec.Population;
import ec.Subpopulation;
import ec.gp.GPIndividual;
import ec.gp.koza.KozaFitness;
import ec.select.SelectDefaults;
import ec.simple.SimpleProblemForm;
import ec.util.Parameter;
import ec.util.ThreadPool;
import main.Main;
import simulator.SimulationStatus;

public class MyGPEvaluator extends Evaluator
{
	/**
	 * 
	 */

	public static EvaluationType LEVEL_OF_EVALUATION;
	//1- Full Evaluation , 2- Small Evaluation , 3 - Simplified Evaluation

	private static final long serialVersionUID = 1L;
	public static final String P_CLONE_PROBLEM = "clone-problem";
	public static final String P_NUM_TESTS = "num-tests";
	public static final String P_MERGE = "merge";

	public static final String V_MEAN = "mean";
	public static final String V_MEDIAN = "median";
	public static final String V_BEST = "best";

	public static final String P_CHUNK_SIZE = "chunk-size";
	public static final String V_AUTO = "auto";

	public static final int MERGE_MEAN = 0;
	public static final int MERGE_MEDIAN = 1;
	public static final int MERGE_BEST = 2;

	public int numTests = 1;
	public int mergeForm = MERGE_MEAN;
	public boolean cloneProblem;

	Object[] lock = new Object[0];          // Arrays are serializable
	int individualCounter = 0;
	int subPopCounter = 0;
	int chunkSize;  // a value >= 1, or C_AUTO
	public static final int C_AUTO = 0;

	public ThreadPool pool = new ThreadPool();

	// checks to make sure that the Problem implements SimpleProblemForm
	public void setup(final EvolutionState state, final Parameter base)
	{
		super.setup(state,base);
		if (!(p_problem instanceof SimpleProblemForm))
			state.output.fatal("" + this.getClass() + " used, but the Problem is not of SimpleProblemForm",
					base.push(P_PROBLEM));

		cloneProblem =state.parameters.getBoolean(base.push(P_CLONE_PROBLEM), null, true);
		if (!cloneProblem && (state.breedthreads > 1)) // uh oh, this can't be right
			state.output.fatal("The Evaluator is not cloning its Problem, but you have more than one thread.", base.push(P_CLONE_PROBLEM));

		numTests = state.parameters.getInt(base.push(P_NUM_TESTS), null, 1);
		if (numTests < 1) numTests = 1;
		else if (numTests > 1)
		{
			String m = state.parameters.getString(base.push(P_MERGE), null);
			if (m == null)
				state.output.warning("Merge method not provided to SimpleEvaluator.  Assuming 'mean'");
			else if (m.equals(V_MEAN))
				mergeForm = MERGE_MEAN;
			else if (m.equals(V_MEDIAN))
				mergeForm = MERGE_MEDIAN;
			else if (m.equals(V_BEST))
				mergeForm = MERGE_BEST;
			else
				state.output.fatal("Bad merge method: " + m, base.push(P_NUM_TESTS), null);
		}

		if (!state.parameters.exists(base.push(P_CHUNK_SIZE), null))
		{
			chunkSize = C_AUTO;
		}
		else if (state.parameters.getString(base.push(P_CHUNK_SIZE), null).equalsIgnoreCase(V_AUTO))
		{
			chunkSize = C_AUTO;
		}
		else
		{
			chunkSize = (state.parameters.getInt(base.push(P_CHUNK_SIZE), null, 1));
			if (chunkSize == 0)  // uh oh
				state.output.fatal("Chunk Size must be either an integer >= 1 or 'auto'", base.push(P_CHUNK_SIZE), null);
		}

	} 

	Population oldpop = null;

	// replace the population with one that has some N copies of the original individuals
	protected void expand(EvolutionState state)
	{
		Population pop = (Population)(state.population.emptyClone());

		// populate with clones
		for(int i = 0;i<pop.subpops.size();++i)
		{
			for(int j = 0;j<state.population.subpops.get(i).individuals.size();++j)
			{
				for(int k=0;k<numTests;++k)
				{
					pop.subpops.get(i).individuals.add((Individual) state.population.subpops.get(i).individuals.get(j).clone());
				}
			}
		}

		// swap
		oldpop = state.population;
		state.population = pop;
	}


	// Take the N copies of the original individuals and fold their fitnesses back into the original
	// individuals, replacing them with the original individuals in the process.  See expand(...)
	void contract(EvolutionState state)
	{
		// swap back
		Population pop = state.population;
		state.population = oldpop;

		// merge fitnesses again
		for(int i = 0; i < pop.subpops.size(); i++)
		{
			Fitness[] fits = new Fitness[numTests];
			for(int j = 0; j < state.population.subpops.get(i).individuals.size(); j++)
			{
				for (int k=0; k < numTests; k++)
				{
					fits[k] = pop.subpops.get(i).individuals.get(numTests * j + k).fitness;
				}

				if (mergeForm == MERGE_MEAN)
				{
					state.population.subpops.get(i).individuals.get(j).fitness.setToMeanOf(state, fits);
				}
				else if (mergeForm == MERGE_MEDIAN)
				{
					state.population.subpops.get(i).individuals.get(j).fitness.setToMedianOf(state, fits);
				}
				else  // MERGE_BEST
				{
					state.population.subpops.get(i).individuals.get(j).fitness.setToBestOf(state, fits);
				}

				state.population.subpops.get(i).individuals.get(j).evaluated = true;
			}
		}
	}

	/** A simple evaluator that doesn't do any coevolutionary
    evaluation.  Basically it applies evaluation pipelines,
    one per thread, to various subchunks of a new population. */
	public void evaluatePopulation(final EvolutionState state)
	{
		if (numTests > 1)
			expand(state);

		// reset counters.  Only used in multithreading
		individualCounter = 0;
		subPopCounter = 0; 

		// start up if single-threaded?
		if (state.evalthreads == 1)
		{
			int[] numinds = new int[state.population.subpops.size()];
			int[] from = new int[numinds.length];

			//Penso que este numinds tem a ver com a subpopulacao que nos nao estamnos a usar
			//Por isso tem sempre o valor de 1, so usamos uma subpopulacao

			for(int i = 0; i < numinds.length; i++)
			{
				numinds[i] =  state.population.subpops.get(i).individuals.size();
				from[i] = 0;

			}

			SimpleProblemForm prob = null;
			if (cloneProblem)
				prob = (SimpleProblemForm)(p_problem.clone());
			else 
				prob = (SimpleProblemForm)(p_problem);  // just use the prototype
			evalPopChunk(state, numinds, from, 0, prob);
		}
		else
		{
			ThreadPool.Worker[] threads = new ThreadPool.Worker[state.evalthreads];
			for(int i = 0; i < threads.length; i++)
			{
				EvaluatorThread run = new EvaluatorThread();
				run.threadnum = i;
				run.state = state;
				run.prob = (SimpleProblemForm)(p_problem.clone());
				threads[i] = pool.start(run, "ECJ Evaluation Thread " + i);
			}

			// join
			pool.joinAll();
		}

		if (numTests > 1)
			contract(state);

	}


	/** The  determines that a run is complete by asking
    each individual in each population if he's optimal; if he 
    finds an individual somewhere that's optimal,
    he signals that the run is complete. */
	public String runComplete(final EvolutionState state)
	{
		for(int x = 0; x< state.population.subpops.size(); x++)
			for(int y = 0; y< state.population.subpops.get(x).individuals.size(); y++)
				if (state.population.subpops.get(x).
						individuals.get(y).fitness.isIdealFitness())
					return "Individual " + y + " of subpopulation " + x + " has an ideal fitness." ;

		if (runComplete != null) return runComplete;
		else return null;
	}

	public int evaluationNecessary(HashSet<Integer> hashCodes, int hashCode){
		int resultado = 0;
		int tempSize = hashCodes.size();
		hashCodes.add(hashCode);
		if (hashCodes.size()>tempSize)  {resultado=1;}
		else							{resultado=0;}
		return resultado;
	}

	public void setFitnessValue(Individual ind, ArrayList<Individual> inds, EvolutionState state){		
		for (int x=0;x<inds.size();x++){
			if( ind.hashCode()==inds.get(x).hashCode() ){
				KozaFitness f = ((KozaFitness)ind.fitness);
				f.setStandardizedFitness(state, inds.get(x).fitness.fitness());		// set for flowtime
				f.hits = 0;
				ind.evaluated = true;
			}			
		}
	}

	/** A private helper function for evaluatePopulation which evaluates a chunk
    of individuals in a subpopulation for a given thread.
    Although this method is declared
    protected, you should not call it. */
	@SuppressWarnings("unchecked")
	protected void evalPopChunk(EvolutionState state, int[] numinds, int[] from, int threadnum, SimpleProblemForm p)
	{
		((ec.Problem)p).prepareToEvaluate(state,threadnum);
		ArrayList<Subpopulation> subpops = state.population.subpops;
		ArrayList<Individual> inds = subpops.get(0).individuals;
		int fp = from[0];
		int upperbound = fp+numinds[0];
		int nBest = (int) (inds.size()*GlobalParameters.N_BEST_FRACTION);

		if (GlobalParameters.TYPE_OF_EVALUATION_TO_USE == EvaluationType.NORMAL){
			LEVEL_OF_EVALUATION = EvaluationType.NORMAL;
			for (int x=fp;x<upperbound;x++){
				p.evaluate(state,inds.get(x), 0, threadnum); 
			}
			state.incrementEvaluations(upperbound - fp);
			
			Collections.sort(inds);
						
			if(!GlobalParameters.FITNESSOUTPUT.equals(""))
				writeOnOutputFile(inds,inds.size());
			printFitnessIndividuals(state,inds);
		}
		
		if(GlobalParameters.TYPE_OF_EVALUATION_TO_USE == EvaluationType.SMALL){ 
			nBest=inds.size(); 
			//Medida de precaucao se utilizador se esquecer de mudar o nBest aquando de nao utilizar simplified evaluation
			//Importante precaucao para o metodo de ordenar os individuos: sortIndividuals(inds, nBest);

			//Se nao for para fazer o simplified, eu uso o small em todos os individuos
			LEVEL_OF_EVALUATION=EvaluationType.SMALL;
			for (int x=0;x<inds.size();x++){
				p.evaluate(state,inds.get(x), 0, threadnum); 
			}
		}	

		if(GlobalParameters.TYPE_OF_EVALUATION_TO_USE == EvaluationType.SIMPLIFIED){
			HashSet<Integer> hashCodes = new HashSet<Integer>();
			int procedToEval=0; 

			//Todos sao avaliados usando o halfshop model
			LEVEL_OF_EVALUATION=EvaluationType.SIMPLIFIED;
			for (int x=0;x<inds.size();x++){
				procedToEval=evaluationNecessary(hashCodes, inds.get(x).hashCode());
				if (procedToEval==1) {
					p.evaluate(state,inds.get(x), 0, threadnum);
				}
				else{
					//setFitnessValue(inds.get(x), inds, state);
					((KozaFitness)(inds.get(x).fitness)).setStandardizedFitness(state, Double.MAX_VALUE);
				}				 
			}
			state.incrementEvaluations(inds.size()); 
			printFitnessIndividuals(state,inds);
			hashCodes.clear();

			//Ordenar para anular o fitness dos piores individuos para nao entrarem nas contas da proxima geracao
			Collections.sort(inds);
			for (int x=nBest;x<inds.size();x++){
				((KozaFitness)(inds.get(x).fitness)).setStandardizedFitness(state, Double.MAX_VALUE);
			}

			LEVEL_OF_EVALUATION = EvaluationType.SMALL; 
			for (int x=0;x<nBest;x++){
				procedToEval=evaluationNecessary(hashCodes, inds.get(x).hashCode());
				if (procedToEval==1) {
					p.evaluate(state,inds.get(x), 0, threadnum);
				}
				else{
					((KozaFitness)(inds.get(x).fitness)).setStandardizedFitness(state, Double.MAX_VALUE);
					//setFitnessValue(inds.get(x), inds, state);
				} 
			}
			hashCodes.clear();						
		}
		
		if(GlobalParameters.TYPE_OF_EVALUATION_TO_USE != EvaluationType.NORMAL){ 
			
			state.incrementEvaluations(nBest); 
			//Ordenar a lista para usar na escolhas dos X melhores individuos para full evaluation
			inds = sortIndividuals(inds, nBest);
			printFitnessIndividuals(state,inds);
			
			if(GlobalParameters.NUMBER_FULL_TRAINING > 0){
				LEVEL_OF_EVALUATION = EvaluationType.NORMAL; 
				for (int x=0;x<GlobalParameters.NUMBER_FULL_TRAINING;x++){
					p.evaluate(state,inds.get(x), 0, threadnum); 
				}
				printFitnessIndividuals(state,inds);

				state.incrementEvaluations(GlobalParameters.NUMBER_FULL_TRAINING);			
			}
			
			if(!GlobalParameters.FITNESSOUTPUT.equals(""))
				writeOnOutputFile(inds,inds.size());		
		}

		((ec.Problem)p).finishEvaluating(state,threadnum);
	}


	protected void printFitnessIndividuals(EvolutionState state, ArrayList<Individual> inds){
		if (LEVEL_OF_EVALUATION==EvaluationType.SIMPLIFIED){
			System.out.println("Fitness depois de feito a etapa Simplified");
		}

		if (LEVEL_OF_EVALUATION==EvaluationType.SMALL){
			System.out.println("Fitness depois de feito a small evaluation e ordenado");
		}

		if (LEVEL_OF_EVALUATION==EvaluationType.NORMAL && GlobalParameters.TYPE_OF_EVALUATION_TO_USE != EvaluationType.NORMAL){
			System.out.println("Fitness depois de feito o full evaluation. Apenas feito ao " + GlobalParameters.NUMBER_FULL_TRAINING + " melhor(s)");
		}
		if (LEVEL_OF_EVALUATION==EvaluationType.NORMAL && GlobalParameters.TYPE_OF_EVALUATION_TO_USE== EvaluationType.NORMAL){
			System.out.println("Fitness depois de feito o full evaluation para todos - GP Normal");
		}
		for(int x=0;x<inds.size();x++){
			//inds.get(x).printIndividual(state, 0);
			System.out.println(((GPIndividual) inds.get(x)).hashCode()+" ; "+((KozaFitness)(inds.get(x).fitness)).standardizedFitness()+";");
		}
		System.out.println(" ");

	}

	protected void writeOnOutputFile(ArrayList<Individual> inds,int nBest){

		if(GlobalParameters.TYPE_OF_EVALUATION_TO_USE == EvaluationType.SIMPLIFIED){ 
			//Aqui so quero imprimir o fitness dos nBest, ou seja daqueles que foram a small e full evaluation
			try{
				for (int x=0;x<nBest;x++){
					Main.fitnessWriter.write(((KozaFitness)(inds.get(x).fitness)).standardizedFitness()+";");
				}
				Main.fitnessWriter.newLine();
			}catch(IOException ioe){
				ioe.printStackTrace();
			}
		}else{
			try{
				for (int x=0;x<inds.size();x++){
					Main.fitnessWriter.write(((KozaFitness)(inds.get(x).fitness)).standardizedFitness()+";");
				}
				Main.fitnessWriter.newLine();
			}catch(IOException ioe){
				ioe.printStackTrace();
			}
		}

	}

	protected ArrayList<Individual> sortIndividuals(ArrayList<Individual> inds, int nBest){
		Individual aux;
		for (int i=0;i<nBest-1;i++){
			for (int j=i+1;j<nBest;j++){
				if (((KozaFitness)(inds.get(j).fitness)).standardizedFitness()<((KozaFitness)(inds.get(i).fitness)).standardizedFitness()){			
					aux = inds.get(i);
					inds.set(i,inds.get(j));
					inds.set(j,aux);				
				}
			}
		}
		return inds;
	}

	// computes the chunk size if 'auto' is set.  This may be different depending on the subpopulation,
	// which is backward-compatible with previous ECJ approaches.
	int computeChunkSizeForSubpopulation(EvolutionState state, int subpop, int threadnum)
	{
		int numThreads = state.evalthreads;

		// we will have some extra individuals.  We distribute these among the early subpopulations
		int individualsPerThread = state.population.subpops.get(subpop).individuals.size() / numThreads;  // integer division
		int slop = state.population.subpops.get(subpop).individuals.size() - numThreads * individualsPerThread;

		if (threadnum >= slop) // beyond the slop
			return individualsPerThread;
		else return individualsPerThread + 1;
	}



	/** A helper class for implementing multithreaded evaluation */
	class EvaluatorThread implements Runnable
	{
		public int threadnum;
		public EvolutionState state;
		public SimpleProblemForm prob = null;

		public void run() 
		{
			ArrayList<Subpopulation> subpops = state.population.subpops;

			int[] numinds = new int[subpops.size()];
			int[] from = new int[subpops.size()];

			int count = 1;
			int start = 0;
			int subpop = 0;

			while (true)
			{
				// We need to grab the information about the next chunk we're responsible for.  This stays longer
				// in the lock than I'd like :-(
				synchronized(lock)
				{
					// has everyone done all the jobs?
					if (subPopCounter >= subpops.size()) // all done
						return;

					// has everyone finished the jobs for this subpopulation?
					if (individualCounter >= subpops.get(subPopCounter).individuals.size())  // try again, jump to next subpop
					{
						individualCounter = 0; 
						subPopCounter++;

						// has everyone done all the jobs?  Check again.
						if (subPopCounter >= subpops.size()) // all done
							return;
					}

					start = individualCounter;
					subpop = subPopCounter;
					count = chunkSize;
					if (count == C_AUTO)  // compute automatically for subpopulations
						count = computeChunkSizeForSubpopulation(state, subpop, threadnum);

					individualCounter += count;  // it can be way more than we'll actually do, that's fine                    
				}

				// Modify the true count
				if (count >= subpops.get(subpop).individuals.size() - start)
					count = subpops.get(subpop).individuals.size() - start;

				// Load into arrays to reuse evalPopChunk
				for(int i = 0; i < from.length; i++)
					numinds[i] = 0;

				numinds[subpop] = count;
				from[subpop] = start;
				evalPopChunk(state, numinds, from, threadnum, prob);
			}
		}
	}
	public Parameter defaultBase()
	{
		return SelectDefaults.base().push("best");
	}

}

