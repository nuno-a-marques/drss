package GP;

import main.DataLoader;
import main.GlobalParameters;
import simulator.Simulator;
import utils.Utils;

import java.io.IOException;

import org.json.simple.DeserializationException;

import ec.Individual;
import ec.gp.GPIndividual;
import ec.gp.koza.KozaFitness;
import ec.simple.SimpleEvolutionState;
import ec.simple.SimpleStatistics;
import ec.util.Checkpoint;
import ec.util.Parameter;


public class MyGPEvolutionState extends SimpleEvolutionState{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public int evolve() //Para cada gera��o ele chama este m�todo.
	{
		output.message("Generation " + generation +"\tEvaluations So Far " + evaluations);


		// EVALUATION
		statistics.preEvaluationStatistics(this);	
		evaluator.evaluatePopulation(this); //onde ele avalia a popula��o e chama o MyGPEvaluator


		//Now reevalueate the best of run
		try {
			reevaluateBestOfRun();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DeserializationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		statistics.postEvaluationStatistics(this);

		// SHOULD WE QUIT?
		String runCompleteMessage = evaluator.runComplete(this);
		if ((runCompleteMessage != null) && quitOnRunComplete)
		{
			output.message(runCompleteMessage);

			return R_SUCCESS;
		}

		// SHOULD WE QUIT?
		if ((numGenerations != UNDEFINED && generation >= numGenerations-1) ||
				(numEvaluations != UNDEFINED && evaluations >= numEvaluations))
		{


			return R_FAILURE;
		}

		// INCREMENT GENERATION AND CHECKPOINT
		generation++;

		// PRE-BREEDING EXCHANGING
		statistics.prePreBreedingExchangeStatistics(this);
		population = exchanger.preBreedingExchangePopulation(this);
		statistics.postPreBreedingExchangeStatistics(this);

		String exchangerWantsToShutdown = exchanger.runComplete(this);
		if (exchangerWantsToShutdown!=null)
		{ 
			output.message(exchangerWantsToShutdown);

			return R_SUCCESS;
		}


		// BREEDING - faz o crosseover.
		statistics.preBreedingStatistics(this);
		population = breeder.breedPopulation(this);
		statistics.postBreedingStatistics(this);


		// POST-BREEDING EXCHANGING
		statistics.prePostBreedingExchangeStatistics(this);
		population = exchanger.postBreedingExchangePopulation(this);
		statistics.postPostBreedingExchangeStatistics(this);

		if (checkpoint && (generation - 1) % checkpointModulo == 0) 
		{
			output.message("Checkpointing");
			statistics.preCheckpointStatistics(this);
			Checkpoint.setCheckpoint(this);
			statistics.postCheckpointStatistics(this);
		}

		return R_NOTDONE;
	}

	private void reevaluateBestOfRun() throws IOException, DeserializationException{

		int maxGen = parameters.getInt(new Parameter("generations"),null ,0);
		//population.subpops.size() � a lista de subpopula��es. N�s s� usamos 1, por isso vai ser sempre 1
		// N�o � o tamanho da popula��o!! Isso � state.population.subpops.get(i).individuals.size(), neste caso i � zero!
		for(int x = 0; x< population.subpops.size(); x++){

			if(((SimpleStatistics)statistics).getBestSoFar()[x] != null){
				//Portanto este best_of_run[X] vai ser a melhor tree de toda a run do GP desta itera��o (em que X vai ser �nica e apenas 0, s� usamos uma subpopula��o)
				Individual individual = ((SimpleStatistics)statistics).getBestSoFar()[x];
				System.out.println("Best individual: ");
				individual.printIndividualForHumans(this, 0);

				double lastFitness = ((KozaFitness)individual.fitness).standardizedFitness();	  
				int size = ((GPIndividual)individual).trees[0].child.atDepth();
				if(GlobalParameters.CO_EVOLVE){
					size += 1 + ((GPIndividual)individual).trees[1].child.atDepth();
				}
				double newPenalty = size*Utils.getIndividualSizePenalty(maxGen, generation+1);
				double fitness = newPenalty;

				//Se a seed n�o est� fixa, � preciso reavaliar o best novamente
				if(!GlobalParameters.FIXED_SEED){
					Simulator simulator = new Simulator(this);
					double simulationResult = simulator.simulate(DataLoader.instancesTS, individual); 		  
					fitness += simulationResult;
				}
				else
				{
					double lastPenalty = size*Utils.getIndividualSizePenalty(maxGen, generation);
					fitness += lastFitness - lastPenalty;	    			  
				}

				((KozaFitness)individual.fitness).setStandardizedFitness(this, fitness);

				System.out.println("Size: "+size+" Penalidade; "+newPenalty+"; Performance;"+(fitness-newPenalty)+"; Reavaliando o melhor: de; "+lastFitness+"; para ;" +fitness);
			}

			//population.subpops.get(x).printSubpopulation(this, 0);
		}      
	}
}
