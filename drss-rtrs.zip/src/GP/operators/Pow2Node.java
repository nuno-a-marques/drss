package GP.operators;

import GP.Data;
import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;

public class Pow2Node extends GPNode{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void eval(EvolutionState state, int thread, GPData input,
			ADFStack stack, GPIndividual individual, Problem problem) {

		children[0].eval(state, thread, input, stack, individual, problem);		
		double value = ((Data)input).value;
				
		((Data)input).value = Math.pow(value, 2);			
		
	}

	public String toString() { return "^2"; }
	
	public int expectedChildren() { return 1; }
	
	public int atDepth() { return 	children[0].atDepth() + 1; }
}
