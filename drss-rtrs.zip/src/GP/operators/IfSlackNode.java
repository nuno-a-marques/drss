package GP.operators;

import simulator.Order;
import GP.Data;
import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;

public class IfSlackNode extends GPNode {

/**
 * 
 */
private static final long serialVersionUID = 1L;

public void eval(EvolutionState state, int thread, GPData input,
		ADFStack stack, GPIndividual individual, Problem problem) {
	
	Order order =  ((Data)input).order;	
	double timeInstant = ((Data)input).timeInstant;					
	double slack = order.getJob().getDueDate() - timeInstant - order.getRemainingProcessingTime();

	if (slack > 0) 
		children[0].eval(state, thread, input, stack, individual, problem);
	else
		children[1].eval(state, thread, input, stack, individual, problem);
}

public String toString() { return "ifS"; }

public int expectedChildren() { return 2; }	

}