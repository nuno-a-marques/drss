package GP.operators;

import GP.Data;
import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;

public class AndNode extends GPNode {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void eval(EvolutionState state, int thread, GPData input,
			ADFStack stack, GPIndividual individual, Problem problem) {

		children[0].eval(state, thread, input, stack, individual, problem);		
		double leftValue = ((Data)input).value;
		children[1].eval(state, thread, input, stack, individual, problem);		
		double rightValue = ((Data)input).value;
		
		((Data)input).booleanValue = ((leftValue != 0.0) && (rightValue != 0.0));
	}

	public String toString() { return "&"; }
	
	public int expectedChildren() { return 2; }

	public int atDepth() { return 	children[0].atDepth() + children[1].atDepth() + 1; }
}