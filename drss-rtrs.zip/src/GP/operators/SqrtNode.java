package GP.operators;

import GP.Data;
import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;

public class SqrtNode extends GPNode {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void eval(EvolutionState state, int thread, GPData input,
			ADFStack stack, GPIndividual individual, Problem problem) {

		children[0].eval(state, thread, input, stack, individual, problem);		
		double value = ((Data)input).value;
		
		if(value >= 0)
			((Data)input).value = Math.sqrt(value);
		else{
			((Data)input).value = 1;
		}
		
	}

	public String toString() { return "Sqrt"; }
	
	public int expectedChildren() { return 1; }
	
	public int atDepth() { return 	children[0].atDepth() + 1; }
}
