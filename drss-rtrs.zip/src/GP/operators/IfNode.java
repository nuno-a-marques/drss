package GP.operators;

import GP.Data;
import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;

public class IfNode extends GPNode {

/**
 * 
 */
private static final long serialVersionUID = 1L;

public void eval(EvolutionState state, int thread, GPData input,
		ADFStack stack, GPIndividual individual, Problem problem) {
	
	children[0].eval(state, thread, input, stack, individual, problem);
	//if (((Data)input).booleanValue) // true
	if (((Data)input).value > 0) // true
		children[1].eval(state, thread, input, stack, individual, problem);
	else
		children[2].eval(state, thread, input, stack, individual, problem);
}

public String toString() { return "if"; }

public int expectedChildren() { return 3; }	

public int atDepth() { return 	children[0].atDepth() + children[1].atDepth() + children[2].atDepth() + 1; }
}