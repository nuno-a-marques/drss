package RF;

public class RandomForest {

public static int nTrees   = 10;
public static int[] nPaths = {  53, 55, 52, 51, 50, 43, 42, 51, 50, 52  };

public static int checkDTTree0Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 695.5) && (wipJS <= 1351.0) && (eTardJS <= 52.0) && (eTardJS <= 13.5) && (wipJS <= 1177.5) && (wipJS <= 1134.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree0Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 695.5) && (eTardJS > 4086.25) && (wipJS <= 5358.5) && (eTardJS <= 12962.25) && (eTardJS <= 12906.5) && (eTardJS > 4894.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree0Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 695.5) && (eTardJS > 4086.25) && (wipJS <= 5358.5) && (eTardJS > 12962.25) && (eTardJS > 17994.0) && (eTardJS <= 52365.75))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree0Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 695.5) && (wipJS > 1351.0) && (wipJS <= 6286.0) && (eTardJS <= 3.5) && (wipJS > 2531.5) && (eTardJS <= 0.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree0Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 695.5) && (wipJS > 1351.0) && (wipJS <= 6286.0) && (eTardJS <= 3.5) && (wipJS <= 2531.5) && (eTardJS <= 2.75))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree0Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 695.5) && (eTardJS <= 4086.25) && (wipJS <= 3916.5) && (wipJS <= 3214.5) && (wipJS <= 3131.0) && (wipJS <= 2859.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree0Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 695.5) && (eTardJS > 4086.25) && (wipJS > 5358.5) && (wipJS <= 6903.5) && (wipJS > 5843.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree0Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 695.5) && (wipJS > 1351.0) && (wipJS <= 6286.0) && (eTardJS > 3.5) && (eTardJS > 130.0) && (wipJS <= 3998.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree0Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 695.5) && (eTardJS > 4086.25) && (wipJS <= 5358.5) && (eTardJS > 12962.25) && (eTardJS > 17994.0) && (eTardJS > 52365.75))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree0Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 695.5) && (wipJS > 1351.0) && (wipJS <= 6286.0) && (eTardJS > 3.5) && (eTardJS <= 130.0) && (wipJS > 1431.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree0Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 695.5) && (eTardJS > 4086.25) && (wipJS <= 5358.5) && (eTardJS > 12962.25) && (eTardJS <= 17994.0) && (eTardJS <= 17940.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree0Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 695.5) && (eTardJS > 4086.25) && (wipJS > 5358.5) && (wipJS <= 6903.5) && (wipJS <= 5843.0) && (wipJS <= 5837.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree0Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 695.5) && (eTardJS <= 4086.25) && (wipJS > 3916.5) && (wipJS > 3923.0) && (eTardJS > 1237.5) && (wipJS > 4194.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree0Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 695.5) && (eTardJS > 4086.25) && (wipJS > 5358.5) && (wipJS > 6903.5) && (eTardJS > 14295.0) && (wipJS <= 7812.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree0Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 695.5) && (eTardJS > 4086.25) && (wipJS <= 5358.5) && (eTardJS <= 12962.25) && (eTardJS <= 12906.5) && (eTardJS <= 4894.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree0Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 695.5) && (wipJS > 1351.0) && (wipJS <= 6286.0) && (eTardJS > 3.5) && (eTardJS > 130.0) && (wipJS > 3998.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree0Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 695.5) && (eTardJS > 4086.25) && (wipJS > 5358.5) && (wipJS > 6903.5) && (eTardJS > 14295.0) && (wipJS > 7812.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree0Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 695.5) && (eTardJS <= 4086.25) && (wipJS <= 3916.5) && (wipJS > 3214.5) && (eTardJS <= 3905.75) && (eTardJS <= 2765.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree0Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 695.5) && (eTardJS <= 4086.25) && (wipJS > 3916.5) && (wipJS > 3923.0) && (eTardJS <= 1237.5) && (wipJS > 4143.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree0Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 695.5) && (eTardJS <= 4086.25) && (wipJS <= 3916.5) && (wipJS <= 3214.5) && (wipJS <= 3131.0) && (wipJS > 2859.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree0Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 695.5) && (eTardJS <= 4086.25) && (wipJS > 3916.5) && (wipJS > 3923.0) && (eTardJS > 1237.5) && (wipJS <= 4194.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree0Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 695.5) && (eTardJS <= 4086.25) && (wipJS <= 3916.5) && (wipJS > 3214.5) && (eTardJS <= 3905.75) && (eTardJS > 2765.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree0Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 695.5) && (wipJS <= 1351.0) && (eTardJS <= 52.0) && (eTardJS <= 13.5) && (wipJS > 1177.5) && (wipJS <= 1326.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree0Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 695.5) && (wipJS <= 1351.0) && (eTardJS > 52.0) && (eTardJS > 120.25) && (eTardJS > 138.5) && (eTardJS <= 668.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree0Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 695.5) && (eTardJS <= 4086.25) && (wipJS > 3916.5) && (wipJS > 3923.0) && (eTardJS <= 1237.5) && (wipJS <= 4143.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree0Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 695.5) && (wipJS > 1351.0) && (wipJS <= 6286.0) && (eTardJS <= 3.5) && (wipJS > 2531.5) && (eTardJS > 0.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree0Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 695.5) && (wipJS > 1351.0) && (wipJS > 6286.0) && (eTardJS > 6.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree0Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 695.5) && (wipJS <= 1351.0) && (eTardJS <= 52.0) && (eTardJS <= 13.5) && (wipJS <= 1177.5) && (wipJS > 1134.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree0Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 695.5) && (wipJS <= 1351.0) && (eTardJS <= 52.0) && (eTardJS <= 13.5) && (wipJS > 1177.5) && (wipJS > 1326.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree0Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 695.5) && (eTardJS > 4086.25) && (wipJS > 5358.5) && (wipJS > 6903.5) && (eTardJS <= 14295.0) && (eTardJS <= 12554.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree0Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 695.5) && (eTardJS <= 4086.25) && (wipJS <= 3916.5) && (wipJS <= 3214.5) && (wipJS > 3131.0) && (wipJS <= 3166.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree0Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 695.5) && (eTardJS <= 4086.25) && (wipJS <= 3916.5) && (wipJS > 3214.5) && (eTardJS > 3905.75) && (wipJS > 3381.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree0Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 695.5) && (eTardJS <= 4086.25) && (wipJS <= 3916.5) && (wipJS <= 3214.5) && (wipJS > 3131.0) && (wipJS > 3166.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree0Path33(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 695.5) && (wipJS > 1351.0) && (wipJS > 6286.0) && (eTardJS <= 6.0) && (wipJS > 6737.5) && (wipJS > 7042.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree0Path34(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 695.5) && (wipJS > 1351.0) && (wipJS > 6286.0) && (eTardJS <= 6.0) && (wipJS > 6737.5) && (wipJS <= 7042.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree0Path35(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 695.5) && (wipJS <= 1351.0) && (eTardJS <= 52.0) && (eTardJS > 13.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree0Path36(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 695.5) && (wipJS > 1351.0) && (wipJS <= 6286.0) && (eTardJS <= 3.5) && (wipJS <= 2531.5) && (eTardJS > 2.75))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree0Path37(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 695.5) && (wipJS <= 1351.0) && (eTardJS > 52.0) && (eTardJS <= 120.25) && (eTardJS > 57.0) && (wipJS <= 1105.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree0Path38(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 695.5) && (wipJS <= 1351.0) && (eTardJS > 52.0) && (eTardJS <= 120.25) && (eTardJS > 57.0) && (wipJS > 1105.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree0Path39(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 695.5) && (wipJS <= 1351.0) && (eTardJS > 52.0) && (eTardJS > 120.25) && (eTardJS <= 138.5))  { ruleCode = 18;}
    return ruleCode; }
public static int checkDTTree0Path40(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 695.5) && (eTardJS <= 4086.25) && (wipJS > 3916.5) && (wipJS <= 3923.0) && (wipJS > 3918.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree0Path41(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 695.5) && (eTardJS <= 4086.25) && (wipJS > 3916.5) && (wipJS <= 3923.0) && (wipJS <= 3918.5))  { ruleCode = 18;}
    return ruleCode; }
public static int checkDTTree0Path42(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 695.5) && (wipJS <= 1351.0) && (eTardJS > 52.0) && (eTardJS <= 120.25) && (eTardJS <= 57.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree0Path43(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 695.5) && (wipJS <= 1351.0) && (eTardJS > 52.0) && (eTardJS > 120.25) && (eTardJS > 138.5) && (eTardJS > 668.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree0Path44(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 695.5) && (eTardJS <= 4086.25) && (wipJS <= 3916.5) && (wipJS > 3214.5) && (eTardJS > 3905.75) && (wipJS <= 3381.5))  { ruleCode = 18;}
    return ruleCode; }
public static int checkDTTree0Path45(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 695.5) && (wipJS > 1351.0) && (wipJS > 6286.0) && (eTardJS <= 6.0) && (wipJS <= 6737.5) && (wipJS > 6435.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree0Path46(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 695.5) && (eTardJS > 4086.25) && (wipJS > 5358.5) && (wipJS > 6903.5) && (eTardJS <= 14295.0) && (eTardJS > 12554.5))  { ruleCode = 18;}
    return ruleCode; }
public static int checkDTTree0Path47(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 695.5) && (eTardJS > 4086.25) && (wipJS <= 5358.5) && (eTardJS <= 12962.25) && (eTardJS > 12906.5) && (wipJS <= 5161.5))  { ruleCode = 18;}
    return ruleCode; }
public static int checkDTTree0Path48(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 695.5) && (wipJS > 1351.0) && (wipJS <= 6286.0) && (eTardJS > 3.5) && (eTardJS <= 130.0) && (wipJS <= 1431.5))  { ruleCode = 18;}
    return ruleCode; }
public static int checkDTTree0Path49(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 695.5) && (eTardJS > 4086.25) && (wipJS > 5358.5) && (wipJS <= 6903.5) && (wipJS <= 5843.0) && (wipJS > 5837.0))  { ruleCode = 18;}
    return ruleCode; }
public static int checkDTTree0Path50(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 695.5) && (eTardJS > 4086.25) && (wipJS <= 5358.5) && (eTardJS <= 12962.25) && (eTardJS > 12906.5) && (wipJS > 5161.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree0Path51(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 695.5) && (wipJS > 1351.0) && (wipJS > 6286.0) && (eTardJS <= 6.0) && (wipJS <= 6737.5) && (wipJS <= 6435.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree0Path52(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 695.5) && (eTardJS > 4086.25) && (wipJS <= 5358.5) && (eTardJS > 12962.25) && (eTardJS <= 17994.0) && (eTardJS > 17940.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree1Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.5) && (wipJS <= 1705.5) && (wipJS <= 1676.5) && (wipJS <= 1662.5) && (eTardJS <= 392.75) && (eTardJS <= 218.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree1Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.5) && (wipJS <= 5660.5) && (eTardJS > 585.75) && (eTardJS > 3376.25) && (wipJS <= 3701.5) && (eTardJS > 7144.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree1Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.5) && (wipJS <= 5660.5) && (eTardJS > 585.75) && (eTardJS > 3376.25) && (wipJS > 3701.5) && (eTardJS > 11715.75))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree1Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.5) && (wipJS <= 5660.5) && (eTardJS > 585.75) && (eTardJS <= 3376.25) && (wipJS <= 4191.5) && (eTardJS <= 2980.25))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree1Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.5) && (wipJS <= 5660.5) && (eTardJS <= 585.75) && (wipJS > 3945.0) && (wipJS > 4021.0) && (eTardJS <= 237.75))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree1Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.5) && (wipJS <= 5660.5) && (eTardJS <= 585.75) && (wipJS <= 3945.0) && (wipJS > 2639.5) && (eTardJS <= 42.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree1Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.5) && (wipJS <= 5660.5) && (eTardJS <= 585.75) && (wipJS <= 3945.0) && (wipJS <= 2639.5) && (eTardJS <= 186.25))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree1Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.5) && (wipJS > 5660.5) && (wipJS > 6344.0) && (eTardJS > 504.5) && (eTardJS > 21774.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree1Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.5) && (wipJS <= 5660.5) && (eTardJS > 585.75) && (eTardJS > 3376.25) && (wipJS <= 3701.5) && (eTardJS <= 7144.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree1Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.5) && (wipJS <= 5660.5) && (eTardJS > 585.75) && (eTardJS > 3376.25) && (wipJS > 3701.5) && (eTardJS <= 11715.75))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree1Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.5) && (wipJS <= 5660.5) && (eTardJS <= 585.75) && (wipJS <= 3945.0) && (wipJS > 2639.5) && (eTardJS > 42.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree1Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.5) && (wipJS <= 5660.5) && (eTardJS > 585.75) && (eTardJS <= 3376.25) && (wipJS > 4191.5) && (eTardJS > 635.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree1Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.5) && (wipJS > 5660.5) && (wipJS <= 6344.0) && (eTardJS > 3338.5) && (wipJS <= 6018.5) && (eTardJS > 11307.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree1Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.5) && (wipJS > 5660.5) && (wipJS <= 6344.0) && (eTardJS > 3338.5) && (wipJS > 6018.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree1Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.5) && (wipJS > 1705.5) && (wipJS > 1734.0) && (eTardJS > 13.5) && (eTardJS > 1195.75) && (wipJS <= 1967.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree1Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.5) && (wipJS > 1705.5) && (wipJS > 1734.0) && (eTardJS <= 13.5) && (wipJS <= 1936.5) && (eTardJS <= 6.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree1Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.5) && (wipJS > 5660.5) && (wipJS > 6344.0) && (eTardJS > 504.5) && (eTardJS <= 21774.5) && (eTardJS <= 21503.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree1Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.5) && (wipJS > 1705.5) && (wipJS > 1734.0) && (eTardJS > 13.5) && (eTardJS <= 1195.75) && (eTardJS <= 1008.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree1Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.5) && (wipJS <= 5660.5) && (eTardJS <= 585.75) && (wipJS <= 3945.0) && (wipJS <= 2639.5) && (eTardJS > 186.25))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree1Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.5) && (wipJS <= 5660.5) && (eTardJS <= 585.75) && (wipJS > 3945.0) && (wipJS > 4021.0) && (eTardJS > 237.75))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree1Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.5) && (wipJS <= 5660.5) && (eTardJS > 585.75) && (eTardJS <= 3376.25) && (wipJS <= 4191.5) && (eTardJS > 2980.25))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree1Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.5) && (wipJS <= 1705.5) && (wipJS <= 1676.5) && (wipJS <= 1662.5) && (eTardJS > 392.75) && (wipJS <= 1589.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree1Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.5) && (wipJS > 1705.5) && (wipJS > 1734.0) && (eTardJS <= 13.5) && (wipJS > 1936.5) && (wipJS <= 1999.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree1Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.5) && (wipJS > 5660.5) && (wipJS <= 6344.0) && (eTardJS > 3338.5) && (wipJS <= 6018.5) && (eTardJS <= 11307.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree1Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.5) && (wipJS <= 1705.5) && (wipJS <= 1676.5) && (wipJS <= 1662.5) && (eTardJS > 392.75) && (wipJS > 1589.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree1Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.5) && (wipJS > 5660.5) && (wipJS <= 6344.0) && (eTardJS <= 3338.5) && (wipJS <= 6134.5) && (wipJS <= 6070.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree1Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.5) && (wipJS <= 5660.5) && (eTardJS <= 585.75) && (wipJS > 3945.0) && (wipJS <= 4021.0) && (eTardJS <= 317.25))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree1Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.5) && (wipJS > 1705.5) && (wipJS <= 1734.0) && (eTardJS > 585.25) && (eTardJS > 1721.25))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree1Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.5) && (wipJS <= 1705.5) && (wipJS <= 1676.5) && (wipJS <= 1662.5) && (eTardJS <= 392.75) && (eTardJS > 218.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree1Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.5) && (wipJS <= 1705.5) && (wipJS > 1676.5) && (eTardJS <= 8.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree1Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.5) && (wipJS > 1705.5) && (wipJS > 1734.0) && (eTardJS > 13.5) && (eTardJS > 1195.75) && (wipJS > 1967.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree1Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.5) && (wipJS > 5660.5) && (wipJS <= 6344.0) && (eTardJS <= 3338.5) && (wipJS > 6134.5) && (eTardJS > 329.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree1Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.5) && (wipJS > 1705.5) && (wipJS > 1734.0) && (eTardJS <= 13.5) && (wipJS > 1936.5) && (wipJS > 1999.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree1Path33(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.5) && (wipJS > 5660.5) && (wipJS <= 6344.0) && (eTardJS <= 3338.5) && (wipJS > 6134.5) && (eTardJS <= 329.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree1Path34(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.5) && (wipJS <= 1705.5) && (wipJS > 1676.5) && (eTardJS > 8.5) && (wipJS <= 1696.5) && (wipJS > 1684.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree1Path35(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.5) && (wipJS > 1705.5) && (wipJS > 1734.0) && (eTardJS > 13.5) && (eTardJS <= 1195.75) && (eTardJS > 1008.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree1Path36(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.5) && (wipJS > 5660.5) && (wipJS > 6344.0) && (eTardJS <= 504.5) && (wipJS > 7146.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree1Path37(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.5) && (wipJS > 5660.5) && (wipJS > 6344.0) && (eTardJS <= 504.5) && (wipJS <= 7146.0) && (wipJS > 6435.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree1Path38(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.5) && (wipJS > 5660.5) && (wipJS <= 6344.0) && (eTardJS <= 3338.5) && (wipJS <= 6134.5) && (wipJS > 6070.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree1Path39(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.5) && (wipJS > 1705.5) && (wipJS > 1734.0) && (eTardJS <= 13.5) && (wipJS <= 1936.5) && (eTardJS > 6.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree1Path40(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.5) && (wipJS <= 1705.5) && (wipJS <= 1676.5) && (wipJS > 1662.5) && (eTardJS > 226.25) && (wipJS <= 1669.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree1Path41(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.5) && (wipJS <= 1705.5) && (wipJS <= 1676.5) && (wipJS > 1662.5) && (eTardJS > 226.25) && (wipJS > 1669.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree1Path42(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.5) && (wipJS <= 1705.5) && (wipJS > 1676.5) && (eTardJS > 8.5) && (wipJS <= 1696.5) && (wipJS <= 1684.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree1Path43(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.5) && (wipJS <= 5660.5) && (eTardJS > 585.75) && (eTardJS <= 3376.25) && (wipJS > 4191.5) && (eTardJS <= 635.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree1Path44(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.5) && (wipJS > 1705.5) && (wipJS <= 1734.0) && (eTardJS <= 585.25) && (wipJS <= 1709.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree1Path45(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.5) && (wipJS > 1705.5) && (wipJS <= 1734.0) && (eTardJS <= 585.25) && (wipJS > 1709.5) && (wipJS <= 1720.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree1Path46(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.5) && (wipJS > 1705.5) && (wipJS <= 1734.0) && (eTardJS <= 585.25) && (wipJS > 1709.5) && (wipJS > 1720.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree1Path47(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.5) && (wipJS <= 5660.5) && (eTardJS <= 585.75) && (wipJS > 3945.0) && (wipJS <= 4021.0) && (eTardJS > 317.25))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree1Path48(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.5) && (wipJS > 1705.5) && (wipJS <= 1734.0) && (eTardJS > 585.25) && (eTardJS <= 1721.25) && (wipJS > 1716.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree1Path49(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.5) && (wipJS <= 1705.5) && (wipJS > 1676.5) && (eTardJS > 8.5) && (wipJS > 1696.5) && (wipJS <= 1700.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree1Path50(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.5) && (wipJS <= 1705.5) && (wipJS > 1676.5) && (eTardJS > 8.5) && (wipJS > 1696.5) && (wipJS > 1700.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree1Path51(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.5) && (wipJS > 5660.5) && (wipJS > 6344.0) && (eTardJS <= 504.5) && (wipJS <= 7146.0) && (wipJS <= 6435.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree1Path52(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.5) && (wipJS <= 1705.5) && (wipJS <= 1676.5) && (wipJS > 1662.5) && (eTardJS <= 226.25))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree1Path53(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.5) && (wipJS > 5660.5) && (wipJS > 6344.0) && (eTardJS > 504.5) && (eTardJS <= 21774.5) && (eTardJS > 21503.5))  { ruleCode = 18;}
    return ruleCode; }
public static int checkDTTree1Path54(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.5) && (wipJS > 1705.5) && (wipJS <= 1734.0) && (eTardJS > 585.25) && (eTardJS <= 1721.25) && (wipJS <= 1716.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree2Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (eTardJS > 746.5) && (eTardJS > 3387.25) && (eTardJS > 12953.25) && (eTardJS > 17188.25) && (eTardJS > 17994.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree2Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (eTardJS <= 1441.0) && (eTardJS <= 125.25) && (eTardJS <= 110.5) && (wipJS <= 1325.5) && (eTardJS <= 47.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree2Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (eTardJS > 746.5) && (eTardJS > 3387.25) && (eTardJS <= 12953.25) && (eTardJS <= 12891.5) && (wipJS > 3439.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree2Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (eTardJS <= 746.5) && (wipJS <= 3897.0) && (eTardJS <= 152.5) && (eTardJS <= 136.75) && (eTardJS <= 126.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree2Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (eTardJS <= 1441.0) && (eTardJS <= 125.25) && (eTardJS <= 110.5) && (wipJS > 1325.5) && (wipJS <= 2154.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree2Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (eTardJS <= 746.5) && (wipJS > 3897.0) && (wipJS <= 6048.5) && (eTardJS <= 243.5) && (wipJS > 4145.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree2Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (eTardJS <= 1441.0) && (eTardJS > 125.25) && (wipJS <= 2305.0) && (wipJS <= 2290.5) && (eTardJS > 136.25))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree2Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (eTardJS > 746.5) && (eTardJS > 3387.25) && (eTardJS <= 12953.25) && (eTardJS <= 12891.5) && (wipJS <= 3439.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree2Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (eTardJS > 746.5) && (eTardJS > 3387.25) && (eTardJS > 12953.25) && (eTardJS <= 17188.25) && (eTardJS <= 17163.25))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree2Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (eTardJS <= 1441.0) && (eTardJS <= 125.25) && (eTardJS <= 110.5) && (wipJS > 1325.5) && (wipJS > 2154.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree2Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (eTardJS > 1441.0) && (eTardJS <= 7144.5) && (eTardJS <= 6414.0) && (wipJS > 1936.5) && (eTardJS <= 4402.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree2Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (eTardJS > 746.5) && (eTardJS <= 3387.25) && (wipJS > 2806.5) && (wipJS <= 4331.5) && (wipJS > 3160.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree2Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (eTardJS > 746.5) && (eTardJS <= 3387.25) && (wipJS > 2806.5) && (wipJS > 4331.5) && (wipJS <= 5552.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree2Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (eTardJS > 1441.0) && (eTardJS > 7144.5) && (wipJS > 2254.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree2Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (eTardJS > 1441.0) && (eTardJS <= 7144.5) && (eTardJS <= 6414.0) && (wipJS <= 1936.5) && (eTardJS <= 4005.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree2Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (eTardJS <= 746.5) && (wipJS <= 3897.0) && (eTardJS > 152.5) && (eTardJS <= 598.0) && (wipJS > 2955.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree2Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (eTardJS > 746.5) && (eTardJS <= 3387.25) && (wipJS > 2806.5) && (wipJS <= 4331.5) && (wipJS <= 3160.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree2Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (eTardJS <= 746.5) && (wipJS <= 3897.0) && (eTardJS > 152.5) && (eTardJS <= 598.0) && (wipJS <= 2955.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree2Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (eTardJS > 1441.0) && (eTardJS <= 7144.5) && (eTardJS <= 6414.0) && (wipJS > 1936.5) && (eTardJS > 4402.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree2Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (eTardJS <= 746.5) && (wipJS > 3897.0) && (wipJS <= 6048.5) && (eTardJS <= 243.5) && (wipJS <= 4145.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree2Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (eTardJS <= 746.5) && (wipJS > 3897.0) && (wipJS <= 6048.5) && (eTardJS > 243.5) && (wipJS <= 5034.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree2Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (eTardJS > 746.5) && (eTardJS <= 3387.25) && (wipJS > 2806.5) && (wipJS > 4331.5) && (wipJS > 5552.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree2Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (eTardJS > 1441.0) && (eTardJS > 7144.5) && (wipJS <= 2254.5) && (wipJS <= 2247.0) && (eTardJS <= 11210.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree2Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (eTardJS > 1441.0) && (eTardJS > 7144.5) && (wipJS <= 2254.5) && (wipJS <= 2247.0) && (eTardJS > 11210.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree2Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (eTardJS <= 1441.0) && (eTardJS > 125.25) && (wipJS > 2305.0) && (eTardJS <= 951.0) && (eTardJS <= 923.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree2Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (eTardJS > 746.5) && (eTardJS <= 3387.25) && (wipJS <= 2806.5) && (wipJS > 2678.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree2Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (eTardJS > 746.5) && (eTardJS > 3387.25) && (eTardJS > 12953.25) && (eTardJS > 17188.25) && (eTardJS <= 17994.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree2Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (eTardJS <= 746.5) && (wipJS > 3897.0) && (wipJS <= 6048.5) && (eTardJS > 243.5) && (wipJS > 5034.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree2Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (eTardJS > 746.5) && (eTardJS <= 3387.25) && (wipJS <= 2806.5) && (wipJS <= 2678.5) && (eTardJS > 805.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree2Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (eTardJS > 1441.0) && (eTardJS <= 7144.5) && (eTardJS > 6414.0) && (eTardJS > 6442.0) && (wipJS <= 2476.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree2Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (eTardJS <= 1441.0) && (eTardJS > 125.25) && (wipJS <= 2305.0) && (wipJS <= 2290.5) && (eTardJS <= 136.25))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree2Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (eTardJS > 1441.0) && (eTardJS <= 7144.5) && (eTardJS <= 6414.0) && (wipJS <= 1936.5) && (eTardJS > 4005.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree2Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (eTardJS <= 1441.0) && (eTardJS <= 125.25) && (eTardJS > 110.5) && (wipJS > 1525.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree2Path33(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (eTardJS <= 746.5) && (wipJS <= 3897.0) && (eTardJS <= 152.5) && (eTardJS > 136.75))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree2Path34(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (eTardJS <= 746.5) && (wipJS <= 3897.0) && (eTardJS > 152.5) && (eTardJS > 598.0) && (eTardJS > 611.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree2Path35(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (eTardJS <= 746.5) && (wipJS > 3897.0) && (wipJS > 6048.5) && (eTardJS <= 115.0) && (wipJS <= 7146.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree2Path36(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (eTardJS <= 1441.0) && (eTardJS > 125.25) && (wipJS > 2305.0) && (eTardJS > 951.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree2Path37(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (eTardJS <= 746.5) && (wipJS > 3897.0) && (wipJS > 6048.5) && (eTardJS > 115.0) && (wipJS > 6286.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree2Path38(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (eTardJS <= 746.5) && (wipJS <= 3897.0) && (eTardJS > 152.5) && (eTardJS > 598.0) && (eTardJS <= 611.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree2Path39(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (eTardJS <= 746.5) && (wipJS > 3897.0) && (wipJS > 6048.5) && (eTardJS <= 115.0) && (wipJS > 7146.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree2Path40(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (eTardJS <= 1441.0) && (eTardJS <= 125.25) && (eTardJS <= 110.5) && (wipJS <= 1325.5) && (eTardJS > 47.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree2Path41(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (eTardJS <= 1441.0) && (eTardJS > 125.25) && (wipJS <= 2305.0) && (wipJS > 2290.5))  { ruleCode = 18;}
    return ruleCode; }
public static int checkDTTree2Path42(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (eTardJS <= 746.5) && (wipJS <= 3897.0) && (eTardJS <= 152.5) && (eTardJS <= 136.75) && (eTardJS > 126.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree2Path43(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (eTardJS > 746.5) && (eTardJS > 3387.25) && (eTardJS <= 12953.25) && (eTardJS > 12891.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree2Path44(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (eTardJS <= 1441.0) && (eTardJS > 125.25) && (wipJS > 2305.0) && (eTardJS <= 951.0) && (eTardJS > 923.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree2Path45(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (eTardJS > 1441.0) && (eTardJS <= 7144.5) && (eTardJS > 6414.0) && (eTardJS <= 6442.0))  { ruleCode = 18;}
    return ruleCode; }
public static int checkDTTree2Path46(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (eTardJS > 1441.0) && (eTardJS <= 7144.5) && (eTardJS > 6414.0) && (eTardJS > 6442.0) && (wipJS > 2476.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree2Path47(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (eTardJS > 1441.0) && (eTardJS > 7144.5) && (wipJS <= 2254.5) && (wipJS > 2247.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree2Path48(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (eTardJS <= 1441.0) && (eTardJS <= 125.25) && (eTardJS > 110.5) && (wipJS <= 1525.5))  { ruleCode = 18;}
    return ruleCode; }
public static int checkDTTree2Path49(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (eTardJS <= 746.5) && (wipJS > 3897.0) && (wipJS > 6048.5) && (eTardJS > 115.0) && (wipJS <= 6286.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree2Path50(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (eTardJS > 746.5) && (eTardJS <= 3387.25) && (wipJS <= 2806.5) && (wipJS <= 2678.5) && (eTardJS <= 805.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree2Path51(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (eTardJS > 746.5) && (eTardJS > 3387.25) && (eTardJS > 12953.25) && (eTardJS <= 17188.25) && (eTardJS > 17163.25))  { ruleCode = 18;}
    return ruleCode; }
public static int checkDTTree3Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (wipJS > 1766.0) && (wipJS <= 2533.0) && (wipJS <= 2424.5) && (wipJS <= 2415.5) && (wipJS <= 2412.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree3Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (wipJS <= 1766.0) && (eTardJS <= 352.75) && (eTardJS <= 116.75) && (wipJS <= 1317.5) && (wipJS <= 1281.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree3Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (wipJS <= 5660.5) && (eTardJS > 896.0) && (wipJS > 3904.0) && (eTardJS > 2419.0) && (wipJS > 4331.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree3Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (wipJS <= 5660.5) && (eTardJS > 896.0) && (wipJS <= 3904.0) && (eTardJS > 3382.25) && (eTardJS > 15043.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree3Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (wipJS <= 5660.5) && (eTardJS <= 896.0) && (wipJS <= 3944.5) && (wipJS > 2815.5) && (wipJS <= 3936.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree3Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (wipJS <= 5660.5) && (eTardJS > 896.0) && (wipJS <= 3904.0) && (eTardJS > 3382.25) && (eTardJS <= 15043.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree3Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (wipJS > 5660.5) && (wipJS > 6336.0) && (eTardJS > 6.0) && (eTardJS > 12916.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree3Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (wipJS <= 5660.5) && (eTardJS <= 896.0) && (wipJS > 3944.5) && (eTardJS <= 278.5) && (wipJS <= 4932.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree3Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (wipJS <= 5660.5) && (eTardJS > 896.0) && (wipJS > 3904.0) && (eTardJS > 2419.0) && (wipJS <= 4331.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree3Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (wipJS <= 5660.5) && (eTardJS > 896.0) && (wipJS <= 3904.0) && (eTardJS <= 3382.25) && (eTardJS > 973.75))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree3Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (wipJS > 5660.5) && (wipJS <= 6336.0) && (wipJS <= 6327.0) && (wipJS <= 6308.5) && (eTardJS > 3944.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree3Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (wipJS <= 1766.0) && (eTardJS <= 352.75) && (eTardJS <= 116.75) && (wipJS > 1317.5) && (eTardJS <= 13.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree3Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (wipJS <= 5660.5) && (eTardJS <= 896.0) && (wipJS <= 3944.5) && (wipJS <= 2815.5) && (wipJS > 2585.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree3Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (wipJS <= 5660.5) && (eTardJS > 896.0) && (wipJS > 3904.0) && (eTardJS <= 2419.0) && (eTardJS <= 1901.75))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree3Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (wipJS <= 5660.5) && (eTardJS <= 896.0) && (wipJS > 3944.5) && (eTardJS <= 278.5) && (wipJS > 4932.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree3Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (wipJS <= 5660.5) && (eTardJS <= 896.0) && (wipJS > 3944.5) && (eTardJS > 278.5) && (wipJS <= 5536.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree3Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (wipJS > 1766.0) && (wipJS <= 2533.0) && (wipJS > 2424.5) && (wipJS > 2447.0) && (eTardJS > 923.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree3Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (wipJS > 5660.5) && (wipJS <= 6336.0) && (wipJS <= 6327.0) && (wipJS <= 6308.5) && (eTardJS <= 3944.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree3Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (wipJS <= 1766.0) && (eTardJS > 352.75) && (eTardJS <= 1771.0) && (wipJS <= 1751.5) && (wipJS > 1509.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree3Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (wipJS > 5660.5) && (wipJS > 6336.0) && (eTardJS > 6.0) && (eTardJS <= 12916.5) && (wipJS > 6414.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree3Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (wipJS > 1766.0) && (wipJS <= 2533.0) && (wipJS > 2424.5) && (wipJS > 2447.0) && (eTardJS <= 923.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree3Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (wipJS <= 5660.5) && (eTardJS > 896.0) && (wipJS > 3904.0) && (eTardJS <= 2419.0) && (eTardJS > 1901.75))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree3Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (wipJS <= 1766.0) && (eTardJS <= 352.75) && (eTardJS > 116.75) && (eTardJS > 136.25) && (eTardJS > 208.75))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree3Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (wipJS <= 1766.0) && (eTardJS <= 352.75) && (eTardJS <= 116.75) && (wipJS > 1317.5) && (eTardJS > 13.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree3Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (wipJS > 1766.0) && (wipJS <= 2533.0) && (wipJS > 2424.5) && (wipJS <= 2447.0) && (eTardJS <= 2660.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree3Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (wipJS <= 1766.0) && (eTardJS > 352.75) && (eTardJS > 1771.0) && (wipJS > 1709.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree3Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (wipJS <= 1766.0) && (eTardJS > 352.75) && (eTardJS <= 1771.0) && (wipJS <= 1751.5) && (wipJS <= 1509.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree3Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (wipJS <= 1766.0) && (eTardJS > 352.75) && (eTardJS > 1771.0) && (wipJS <= 1709.5) && (eTardJS > 1884.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree3Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (wipJS <= 5660.5) && (eTardJS <= 896.0) && (wipJS <= 3944.5) && (wipJS <= 2815.5) && (wipJS <= 2585.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree3Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (wipJS <= 1766.0) && (eTardJS <= 352.75) && (eTardJS > 116.75) && (eTardJS > 136.25) && (eTardJS <= 208.75))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree3Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (wipJS > 1766.0) && (wipJS <= 2533.0) && (wipJS <= 2424.5) && (wipJS > 2415.5) && (wipJS <= 2423.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree3Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (wipJS > 5660.5) && (wipJS > 6336.0) && (eTardJS > 6.0) && (eTardJS <= 12916.5) && (wipJS <= 6414.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree3Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (wipJS <= 5660.5) && (eTardJS > 896.0) && (wipJS <= 3904.0) && (eTardJS <= 3382.25) && (eTardJS <= 973.75))  { ruleCode = 18;}
    return ruleCode; }
public static int checkDTTree3Path33(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (wipJS <= 1766.0) && (eTardJS <= 352.75) && (eTardJS > 116.75) && (eTardJS <= 136.25) && (wipJS > 1400.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree3Path34(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (wipJS <= 1766.0) && (eTardJS <= 352.75) && (eTardJS <= 116.75) && (wipJS <= 1317.5) && (wipJS > 1281.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree3Path35(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (wipJS <= 5660.5) && (eTardJS <= 896.0) && (wipJS <= 3944.5) && (wipJS > 2815.5) && (wipJS > 3936.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree3Path36(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (wipJS <= 5660.5) && (eTardJS <= 896.0) && (wipJS > 3944.5) && (eTardJS > 278.5) && (wipJS > 5536.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree3Path37(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (wipJS > 1766.0) && (wipJS > 2533.0) && (wipJS > 2535.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree3Path38(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (wipJS > 1766.0) && (wipJS <= 2533.0) && (wipJS <= 2424.5) && (wipJS <= 2415.5) && (wipJS > 2412.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree3Path39(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (wipJS > 5660.5) && (wipJS <= 6336.0) && (wipJS <= 6327.0) && (wipJS > 6308.5) && (eTardJS > 1696.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree3Path40(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (wipJS > 1766.0) && (wipJS <= 2533.0) && (wipJS > 2424.5) && (wipJS <= 2447.0) && (eTardJS > 2660.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree3Path41(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (wipJS > 5660.5) && (wipJS > 6336.0) && (eTardJS <= 6.0) && (wipJS > 7146.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree3Path42(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (wipJS <= 1766.0) && (eTardJS <= 352.75) && (eTardJS > 116.75) && (eTardJS <= 136.25) && (wipJS <= 1400.5))  { ruleCode = 18;}
    return ruleCode; }
public static int checkDTTree3Path43(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (wipJS > 1766.0) && (wipJS > 2533.0) && (wipJS <= 2535.0) && (eTardJS <= 1131.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree3Path44(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (wipJS > 5660.5) && (wipJS <= 6336.0) && (wipJS > 6327.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree3Path45(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (wipJS <= 1766.0) && (eTardJS > 352.75) && (eTardJS <= 1771.0) && (wipJS > 1751.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree3Path46(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (wipJS > 5660.5) && (wipJS > 6336.0) && (eTardJS <= 6.0) && (wipJS <= 7146.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree3Path47(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (wipJS > 1766.0) && (wipJS > 2533.0) && (wipJS <= 2535.0) && (eTardJS > 1131.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree3Path48(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (wipJS <= 1766.0) && (eTardJS > 352.75) && (eTardJS > 1771.0) && (wipJS <= 1709.5) && (eTardJS <= 1884.5))  { ruleCode = 18;}
    return ruleCode; }
public static int checkDTTree3Path49(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2540.0) && (wipJS > 1766.0) && (wipJS <= 2533.0) && (wipJS <= 2424.5) && (wipJS > 2415.5) && (wipJS > 2423.5))  { ruleCode = 18;}
    return ruleCode; }
public static int checkDTTree3Path50(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2540.0) && (wipJS > 5660.5) && (wipJS <= 6336.0) && (wipJS <= 6327.0) && (wipJS > 6308.5) && (eTardJS <= 1696.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree4Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1358.5) && (eTardJS <= 321.75) && (eTardJS <= 93.5) && (wipJS > 1326.5) && (eTardJS <= 3.5) && (wipJS <= 5691.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree4Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1358.5) && (eTardJS <= 321.75) && (eTardJS <= 93.5) && (wipJS <= 1326.5) && (eTardJS <= 69.0) && (eTardJS <= 3.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree4Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1358.5) && (wipJS <= 6172.5) && (eTardJS > 7949.0) && (eTardJS > 12962.25) && (eTardJS > 17994.0) && (wipJS <= 4080.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree4Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1358.5) && (wipJS <= 6172.5) && (eTardJS > 7949.0) && (eTardJS > 12962.25) && (eTardJS > 17994.0) && (wipJS > 4080.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree4Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1358.5) && (wipJS <= 6172.5) && (eTardJS <= 7949.0) && (wipJS <= 4587.5) && (eTardJS <= 4441.0) && (wipJS <= 4039.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree4Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1358.5) && (wipJS <= 6172.5) && (eTardJS <= 7949.0) && (wipJS <= 4587.5) && (eTardJS > 4441.0) && (eTardJS > 4774.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree4Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1358.5) && (wipJS <= 6172.5) && (eTardJS > 7949.0) && (eTardJS > 12962.25) && (eTardJS <= 17994.0) && (eTardJS <= 17951.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree4Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1358.5) && (eTardJS <= 321.75) && (eTardJS <= 93.5) && (wipJS > 1326.5) && (eTardJS > 3.5) && (eTardJS > 4.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree4Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1358.5) && (eTardJS > 321.75) && (eTardJS <= 945.75) && (wipJS > 2015.5) && (wipJS > 2199.5) && (wipJS > 2253.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree4Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1358.5) && (wipJS > 6172.5) && (wipJS > 6344.0) && (wipJS > 6899.5) && (eTardJS > 22245.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree4Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1358.5) && (wipJS > 6172.5) && (wipJS > 6344.0) && (wipJS <= 6899.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree4Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1358.5) && (wipJS <= 6172.5) && (eTardJS > 7949.0) && (eTardJS <= 12962.25) && (wipJS > 3190.0) && (wipJS > 3556.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree4Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1358.5) && (wipJS <= 6172.5) && (eTardJS > 7949.0) && (eTardJS <= 12962.25) && (wipJS <= 3190.0) && (wipJS > 2254.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree4Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1358.5) && (wipJS <= 6172.5) && (eTardJS <= 7949.0) && (wipJS > 4587.5) && (eTardJS <= 6215.5) && (eTardJS <= 3358.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree4Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1358.5) && (eTardJS <= 321.75) && (eTardJS > 93.5) && (wipJS <= 2093.5) && (wipJS <= 2082.0) && (wipJS <= 2003.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree4Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1358.5) && (eTardJS <= 321.75) && (eTardJS > 93.5) && (wipJS > 2093.5) && (eTardJS <= 196.0) && (wipJS > 2638.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree4Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1358.5) && (eTardJS <= 321.75) && (eTardJS > 93.5) && (wipJS > 2093.5) && (eTardJS > 196.0) && (eTardJS > 222.25))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree4Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1358.5) && (wipJS > 6172.5) && (wipJS <= 6344.0) && (eTardJS > 3319.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree4Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1358.5) && (eTardJS > 321.75) && (eTardJS > 945.75) && (wipJS > 2541.0) && (eTardJS <= 1327.5) && (wipJS <= 4637.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree4Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1358.5) && (wipJS <= 6172.5) && (eTardJS <= 7949.0) && (wipJS > 4587.5) && (eTardJS <= 6215.5) && (eTardJS > 3358.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree4Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1358.5) && (wipJS <= 6172.5) && (eTardJS <= 7949.0) && (wipJS <= 4587.5) && (eTardJS <= 4441.0) && (wipJS > 4039.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree4Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1358.5) && (eTardJS <= 321.75) && (eTardJS > 93.5) && (wipJS > 2093.5) && (eTardJS <= 196.0) && (wipJS <= 2638.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree4Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1358.5) && (wipJS <= 6172.5) && (eTardJS > 7949.0) && (eTardJS <= 12962.25) && (wipJS <= 3190.0) && (wipJS <= 2254.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree4Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1358.5) && (wipJS <= 6172.5) && (eTardJS <= 7949.0) && (wipJS <= 4587.5) && (eTardJS > 4441.0) && (eTardJS <= 4774.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree4Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1358.5) && (wipJS <= 6172.5) && (eTardJS <= 7949.0) && (wipJS > 4587.5) && (eTardJS > 6215.5) && (eTardJS <= 7918.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree4Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1358.5) && (eTardJS > 321.75) && (eTardJS > 945.75) && (wipJS > 2541.0) && (eTardJS <= 1327.5) && (wipJS > 4637.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree4Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1358.5) && (eTardJS > 321.75) && (eTardJS > 945.75) && (wipJS <= 2541.0) && (wipJS > 1663.5) && (wipJS > 1737.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree4Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1358.5) && (wipJS > 6172.5) && (wipJS > 6344.0) && (wipJS > 6899.5) && (eTardJS <= 22245.0) && (wipJS > 6934.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree4Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1358.5) && (eTardJS <= 321.75) && (eTardJS <= 93.5) && (wipJS > 1326.5) && (eTardJS <= 3.5) && (wipJS > 5691.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree4Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1358.5) && (eTardJS <= 321.75) && (eTardJS > 93.5) && (wipJS > 2093.5) && (eTardJS > 196.0) && (eTardJS <= 222.25))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree4Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1358.5) && (wipJS <= 6172.5) && (eTardJS > 7949.0) && (eTardJS <= 12962.25) && (wipJS > 3190.0) && (wipJS <= 3556.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree4Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1358.5) && (eTardJS > 321.75) && (eTardJS <= 945.75) && (wipJS <= 2015.5) && (wipJS > 1713.0) && (eTardJS <= 677.75))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree4Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1358.5) && (eTardJS > 321.75) && (eTardJS <= 945.75) && (wipJS <= 2015.5) && (wipJS <= 1713.0) && (eTardJS > 534.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree4Path33(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1358.5) && (eTardJS > 321.75) && (eTardJS <= 945.75) && (wipJS <= 2015.5) && (wipJS <= 1713.0) && (eTardJS <= 534.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree4Path34(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1358.5) && (eTardJS > 321.75) && (eTardJS <= 945.75) && (wipJS > 2015.5) && (wipJS <= 2199.5) && (wipJS <= 2126.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree4Path35(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1358.5) && (eTardJS > 321.75) && (eTardJS <= 945.75) && (wipJS <= 2015.5) && (wipJS > 1713.0) && (eTardJS > 677.75))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree4Path36(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1358.5) && (eTardJS > 321.75) && (eTardJS <= 945.75) && (wipJS > 2015.5) && (wipJS <= 2199.5) && (wipJS > 2126.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree4Path37(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1358.5) && (eTardJS > 321.75) && (eTardJS <= 945.75) && (wipJS > 2015.5) && (wipJS > 2199.5) && (wipJS <= 2253.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree4Path38(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1358.5) && (eTardJS > 321.75) && (eTardJS > 945.75) && (wipJS <= 2541.0) && (wipJS <= 1663.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree4Path39(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1358.5) && (eTardJS <= 321.75) && (eTardJS > 93.5) && (wipJS <= 2093.5) && (wipJS <= 2082.0) && (wipJS > 2003.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree4Path40(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1358.5) && (eTardJS <= 321.75) && (eTardJS <= 93.5) && (wipJS <= 1326.5) && (eTardJS <= 69.0) && (eTardJS > 3.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree4Path41(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1358.5) && (eTardJS <= 321.75) && (eTardJS > 93.5) && (wipJS <= 2093.5) && (wipJS > 2082.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree4Path42(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1358.5) && (eTardJS <= 321.75) && (eTardJS <= 93.5) && (wipJS > 1326.5) && (eTardJS > 3.5) && (eTardJS <= 4.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree4Path43(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1358.5) && (eTardJS > 321.75) && (eTardJS > 945.75) && (wipJS <= 2541.0) && (wipJS > 1663.5) && (wipJS <= 1737.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree4Path44(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1358.5) && (eTardJS > 321.75) && (eTardJS > 945.75) && (wipJS > 2541.0) && (eTardJS > 1327.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree4Path45(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1358.5) && (wipJS > 6172.5) && (wipJS <= 6344.0) && (eTardJS <= 3319.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree4Path46(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1358.5) && (wipJS <= 6172.5) && (eTardJS > 7949.0) && (eTardJS > 12962.25) && (eTardJS <= 17994.0) && (eTardJS > 17951.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree4Path47(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1358.5) && (wipJS <= 6172.5) && (eTardJS <= 7949.0) && (wipJS > 4587.5) && (eTardJS > 6215.5) && (eTardJS > 7918.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree4Path48(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1358.5) && (wipJS > 6172.5) && (wipJS > 6344.0) && (wipJS > 6899.5) && (eTardJS <= 22245.0) && (wipJS <= 6934.5))  { ruleCode = 18;}
    return ruleCode; }
public static int checkDTTree4Path49(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1358.5) && (eTardJS <= 321.75) && (eTardJS <= 93.5) && (wipJS <= 1326.5) && (eTardJS > 69.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree5Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 666.25) && (wipJS <= 1397.5) && (eTardJS <= 349.75) && (eTardJS <= 114.25) && (eTardJS <= 1.25) && (wipJS <= 1385.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree5Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 666.25) && (eTardJS > 3559.0) && (wipJS > 1711.5) && (eTardJS > 12948.5) && (wipJS <= 5145.5) && (eTardJS > 17994.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree5Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 666.25) && (wipJS > 1397.5) && (eTardJS <= 3.5) && (eTardJS <= 2.75) && (wipJS <= 5636.5) && (wipJS <= 3722.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree5Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 666.25) && (eTardJS > 3559.0) && (wipJS > 1711.5) && (eTardJS > 12948.5) && (wipJS > 5145.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree5Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 666.25) && (eTardJS > 3559.0) && (wipJS > 1711.5) && (eTardJS <= 12948.5) && (wipJS > 3007.5) && (wipJS > 3020.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree5Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 666.25) && (wipJS > 1397.5) && (eTardJS > 3.5) && (eTardJS <= 210.5) && (eTardJS <= 176.75) && (eTardJS <= 169.25))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree5Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 666.25) && (eTardJS <= 3559.0) && (eTardJS <= 2419.0) && (eTardJS <= 2403.5) && (eTardJS > 1314.5) && (wipJS <= 4911.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree5Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 666.25) && (wipJS > 1397.5) && (eTardJS <= 3.5) && (eTardJS <= 2.75) && (wipJS <= 5636.5) && (wipJS > 3722.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree5Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 666.25) && (eTardJS <= 3559.0) && (eTardJS <= 2419.0) && (eTardJS <= 2403.5) && (eTardJS <= 1314.5) && (eTardJS <= 1305.75))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree5Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 666.25) && (wipJS > 1397.5) && (eTardJS > 3.5) && (eTardJS > 210.5) && (eTardJS <= 620.0) && (eTardJS <= 528.25))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree5Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 666.25) && (eTardJS > 3559.0) && (wipJS > 1711.5) && (eTardJS <= 12948.5) && (wipJS <= 3007.5) && (eTardJS > 6414.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree5Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 666.25) && (eTardJS > 3559.0) && (wipJS > 1711.5) && (eTardJS > 12948.5) && (wipJS <= 5145.5) && (eTardJS <= 17994.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree5Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 666.25) && (eTardJS > 3559.0) && (wipJS > 1711.5) && (eTardJS <= 12948.5) && (wipJS <= 3007.5) && (eTardJS <= 6414.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree5Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 666.25) && (eTardJS <= 3559.0) && (eTardJS > 2419.0) && (wipJS > 1960.0) && (eTardJS > 2987.5) && (wipJS <= 5809.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree5Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 666.25) && (eTardJS <= 3559.0) && (eTardJS > 2419.0) && (wipJS > 1960.0) && (eTardJS <= 2987.5) && (eTardJS <= 2909.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree5Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 666.25) && (wipJS > 1397.5) && (eTardJS > 3.5) && (eTardJS > 210.5) && (eTardJS <= 620.0) && (eTardJS > 528.25))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree5Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 666.25) && (eTardJS <= 3559.0) && (eTardJS <= 2419.0) && (eTardJS <= 2403.5) && (eTardJS > 1314.5) && (wipJS > 4911.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree5Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 666.25) && (wipJS > 1397.5) && (eTardJS > 3.5) && (eTardJS <= 210.5) && (eTardJS > 176.75) && (wipJS > 1642.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree5Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 666.25) && (eTardJS <= 3559.0) && (eTardJS > 2419.0) && (wipJS > 1960.0) && (eTardJS <= 2987.5) && (eTardJS > 2909.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree5Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 666.25) && (wipJS > 1397.5) && (eTardJS <= 3.5) && (eTardJS <= 2.75) && (wipJS > 5636.5) && (wipJS <= 6737.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree5Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 666.25) && (eTardJS <= 3559.0) && (eTardJS > 2419.0) && (wipJS <= 1960.0) && (eTardJS <= 3481.0) && (eTardJS > 2842.25))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree5Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 666.25) && (wipJS <= 1397.5) && (eTardJS <= 349.75) && (eTardJS <= 114.25) && (eTardJS > 1.25) && (wipJS <= 1260.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree5Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 666.25) && (wipJS > 1397.5) && (eTardJS > 3.5) && (eTardJS <= 210.5) && (eTardJS <= 176.75) && (eTardJS > 169.25))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree5Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 666.25) && (wipJS > 1397.5) && (eTardJS <= 3.5) && (eTardJS > 2.75))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree5Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 666.25) && (wipJS > 1397.5) && (eTardJS > 3.5) && (eTardJS > 210.5) && (eTardJS > 620.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree5Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 666.25) && (eTardJS <= 3559.0) && (eTardJS > 2419.0) && (wipJS > 1960.0) && (eTardJS > 2987.5) && (wipJS > 5809.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree5Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 666.25) && (wipJS <= 1397.5) && (eTardJS <= 349.75) && (eTardJS <= 114.25) && (eTardJS > 1.25) && (wipJS > 1260.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree5Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 666.25) && (wipJS > 1397.5) && (eTardJS <= 3.5) && (eTardJS <= 2.75) && (wipJS > 5636.5) && (wipJS > 6737.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree5Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 666.25) && (eTardJS > 3559.0) && (wipJS <= 1711.5) && (wipJS <= 1654.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree5Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 666.25) && (eTardJS <= 3559.0) && (eTardJS > 2419.0) && (wipJS <= 1960.0) && (eTardJS <= 3481.0) && (eTardJS <= 2842.25))  { ruleCode = 18;}
    return ruleCode; }
public static int checkDTTree5Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 666.25) && (wipJS <= 1397.5) && (eTardJS > 349.75))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree5Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 666.25) && (eTardJS <= 3559.0) && (eTardJS <= 2419.0) && (eTardJS <= 2403.5) && (eTardJS <= 1314.5) && (eTardJS > 1305.75))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree5Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 666.25) && (eTardJS <= 3559.0) && (eTardJS <= 2419.0) && (eTardJS > 2403.5) && (wipJS > 3013.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree5Path33(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 666.25) && (wipJS <= 1397.5) && (eTardJS <= 349.75) && (eTardJS > 114.25) && (wipJS <= 1361.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree5Path34(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 666.25) && (wipJS <= 1397.5) && (eTardJS <= 349.75) && (eTardJS <= 114.25) && (eTardJS <= 1.25) && (wipJS > 1385.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree5Path35(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 666.25) && (eTardJS > 3559.0) && (wipJS > 1711.5) && (eTardJS <= 12948.5) && (wipJS > 3007.5) && (wipJS <= 3020.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree5Path36(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 666.25) && (wipJS > 1397.5) && (eTardJS > 3.5) && (eTardJS <= 210.5) && (eTardJS > 176.75) && (wipJS <= 1642.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree5Path37(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 666.25) && (eTardJS > 3559.0) && (wipJS <= 1711.5) && (wipJS > 1654.5) && (eTardJS > 6186.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree5Path38(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 666.25) && (eTardJS > 3559.0) && (wipJS <= 1711.5) && (wipJS > 1654.5) && (eTardJS <= 6186.5))  { ruleCode = 18;}
    return ruleCode; }
public static int checkDTTree5Path39(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 666.25) && (eTardJS <= 3559.0) && (eTardJS <= 2419.0) && (eTardJS > 2403.5) && (wipJS <= 3013.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree5Path40(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 666.25) && (wipJS <= 1397.5) && (eTardJS <= 349.75) && (eTardJS > 114.25) && (wipJS > 1361.5))  { ruleCode = 18;}
    return ruleCode; }
public static int checkDTTree5Path41(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 666.25) && (eTardJS <= 3559.0) && (eTardJS > 2419.0) && (wipJS <= 1960.0) && (eTardJS > 3481.0) && (eTardJS <= 3520.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree5Path42(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 666.25) && (eTardJS <= 3559.0) && (eTardJS > 2419.0) && (wipJS <= 1960.0) && (eTardJS > 3481.0) && (eTardJS > 3520.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree6Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.0) && (wipJS <= 5660.5) && (wipJS > 2728.5) && (wipJS <= 3701.5) && (wipJS <= 3597.5) && (wipJS <= 3593.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree6Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.0) && (wipJS <= 1170.0) && (wipJS <= 1130.5) && (wipJS <= 1048.0) && (wipJS <= 926.5) && (wipJS <= 376.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree6Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.0) && (wipJS <= 5660.5) && (wipJS <= 2728.5) && (wipJS <= 2726.5) && (wipJS > 2211.0) && (wipJS > 2215.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree6Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.0) && (wipJS <= 5660.5) && (wipJS > 2728.5) && (wipJS > 3701.5) && (wipJS <= 5146.5) && (eTardJS > 2381.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree6Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.0) && (wipJS <= 5660.5) && (wipJS > 2728.5) && (wipJS > 3701.5) && (wipJS <= 5146.5) && (eTardJS <= 2381.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree6Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.0) && (wipJS > 5660.5) && (wipJS > 6312.0) && (eTardJS > 6.0) && (eTardJS > 21960.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree6Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.0) && (wipJS <= 5660.5) && (wipJS <= 2728.5) && (wipJS <= 2726.5) && (wipJS <= 2211.0) && (wipJS <= 2150.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree6Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.0) && (wipJS <= 5660.5) && (wipJS > 2728.5) && (wipJS > 3701.5) && (wipJS > 5146.5) && (eTardJS > 283.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree6Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.0) && (wipJS > 5660.5) && (wipJS <= 6312.0) && (eTardJS > 900.0) && (wipJS <= 6308.0) && (eTardJS > 3810.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree6Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.0) && (wipJS > 1170.0) && (eTardJS <= 3.5) && (eTardJS <= 1.5) && (wipJS > 1326.0) && (wipJS <= 1883.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree6Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.0) && (wipJS > 1170.0) && (eTardJS > 3.5) && (wipJS > 1388.5) && (wipJS > 1400.5) && (wipJS <= 1801.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree6Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.0) && (wipJS > 1170.0) && (eTardJS > 3.5) && (wipJS > 1388.5) && (wipJS > 1400.5) && (wipJS > 1801.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree6Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.0) && (wipJS <= 5660.5) && (wipJS > 2728.5) && (wipJS <= 3701.5) && (wipJS > 3597.5) && (wipJS <= 3676.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree6Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.0) && (wipJS <= 5660.5) && (wipJS <= 2728.5) && (wipJS <= 2726.5) && (wipJS <= 2211.0) && (wipJS > 2150.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree6Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.0) && (wipJS > 5660.5) && (wipJS > 6312.0) && (eTardJS > 6.0) && (eTardJS <= 21960.5) && (wipJS <= 7763.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree6Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.0) && (wipJS > 1170.0) && (eTardJS <= 3.5) && (eTardJS <= 1.5) && (wipJS > 1326.0) && (wipJS > 1883.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree6Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.0) && (wipJS <= 5660.5) && (wipJS > 2728.5) && (wipJS > 3701.5) && (wipJS > 5146.5) && (eTardJS <= 283.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree6Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.0) && (wipJS <= 5660.5) && (wipJS > 2728.5) && (wipJS <= 3701.5) && (wipJS > 3597.5) && (wipJS > 3676.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree6Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.0) && (wipJS > 5660.5) && (wipJS <= 6312.0) && (eTardJS > 900.0) && (wipJS <= 6308.0) && (eTardJS <= 3810.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree6Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.0) && (wipJS > 1170.0) && (eTardJS > 3.5) && (wipJS <= 1388.5) && (wipJS > 1285.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree6Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.0) && (wipJS > 5660.5) && (wipJS <= 6312.0) && (eTardJS <= 900.0) && (wipJS > 5809.0) && (wipJS > 6048.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree6Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.0) && (wipJS > 1170.0) && (eTardJS > 3.5) && (wipJS <= 1388.5) && (wipJS <= 1285.0) && (eTardJS > 53.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree6Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.0) && (wipJS <= 1170.0) && (wipJS > 1130.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree6Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.0) && (wipJS > 5660.5) && (wipJS > 6312.0) && (eTardJS > 6.0) && (eTardJS <= 21960.5) && (wipJS > 7763.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree6Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.0) && (wipJS > 1170.0) && (eTardJS <= 3.5) && (eTardJS <= 1.5) && (wipJS <= 1326.0) && (wipJS <= 1280.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree6Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.0) && (wipJS > 1170.0) && (eTardJS <= 3.5) && (eTardJS <= 1.5) && (wipJS <= 1326.0) && (wipJS > 1280.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree6Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.0) && (wipJS <= 5660.5) && (wipJS <= 2728.5) && (wipJS <= 2726.5) && (wipJS > 2211.0) && (wipJS <= 2215.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree6Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.0) && (wipJS > 5660.5) && (wipJS <= 6312.0) && (eTardJS <= 900.0) && (wipJS > 5809.0) && (wipJS <= 6048.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree6Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.0) && (wipJS <= 1170.0) && (wipJS <= 1130.5) && (wipJS > 1048.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree6Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.0) && (wipJS <= 1170.0) && (wipJS <= 1130.5) && (wipJS <= 1048.0) && (wipJS > 926.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree6Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.0) && (wipJS <= 1170.0) && (wipJS <= 1130.5) && (wipJS <= 1048.0) && (wipJS <= 926.5) && (wipJS > 376.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree6Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.0) && (wipJS <= 5660.5) && (wipJS <= 2728.5) && (wipJS > 2726.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree6Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.0) && (wipJS > 5660.5) && (wipJS <= 6312.0) && (eTardJS <= 900.0) && (wipJS <= 5809.0) && (wipJS > 5715.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree6Path33(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.0) && (wipJS > 5660.5) && (wipJS > 6312.0) && (eTardJS <= 6.0) && (wipJS > 6890.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree6Path34(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.0) && (wipJS <= 5660.5) && (wipJS > 2728.5) && (wipJS <= 3701.5) && (wipJS <= 3597.5) && (wipJS > 3593.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree6Path35(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.0) && (wipJS > 1170.0) && (eTardJS <= 3.5) && (eTardJS > 1.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree6Path36(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.0) && (wipJS > 1170.0) && (eTardJS > 3.5) && (wipJS <= 1388.5) && (wipJS <= 1285.0) && (eTardJS <= 53.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree6Path37(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2010.0) && (wipJS > 1170.0) && (eTardJS > 3.5) && (wipJS > 1388.5) && (wipJS <= 1400.5))  { ruleCode = 18;}
    return ruleCode; }
public static int checkDTTree6Path38(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.0) && (wipJS > 5660.5) && (wipJS > 6312.0) && (eTardJS <= 6.0) && (wipJS <= 6890.5) && (wipJS > 6435.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree6Path39(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.0) && (wipJS > 5660.5) && (wipJS > 6312.0) && (eTardJS <= 6.0) && (wipJS <= 6890.5) && (wipJS <= 6435.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree6Path40(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.0) && (wipJS > 5660.5) && (wipJS <= 6312.0) && (eTardJS <= 900.0) && (wipJS <= 5809.0) && (wipJS <= 5715.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree6Path41(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2010.0) && (wipJS > 5660.5) && (wipJS <= 6312.0) && (eTardJS > 900.0) && (wipJS > 6308.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree7Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 1856.0) && (eTardJS <= 540.0) && (wipJS <= 1745.0) && (eTardJS <= 475.25) && (eTardJS <= 392.25) && (wipJS <= 1729.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree7Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 1856.0) && (eTardJS > 502.5) && (eTardJS > 2459.25) && (eTardJS <= 17994.0) && (wipJS <= 4024.5) && (eTardJS <= 17459.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree7Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 1856.0) && (eTardJS > 502.5) && (eTardJS > 2459.25) && (eTardJS > 17994.0) && (wipJS > 4088.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree7Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 1856.0) && (eTardJS <= 502.5) && (eTardJS <= 3.5) && (wipJS <= 5408.0) && (eTardJS <= 2.75) && (wipJS <= 4023.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree7Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 1856.0) && (eTardJS > 502.5) && (eTardJS <= 2459.25) && (eTardJS <= 2444.25) && (wipJS > 1981.0) && (wipJS <= 4686.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree7Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 1856.0) && (eTardJS > 502.5) && (eTardJS > 2459.25) && (eTardJS > 17994.0) && (wipJS <= 4088.5) && (eTardJS <= 51802.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree7Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 1856.0) && (eTardJS > 502.5) && (eTardJS > 2459.25) && (eTardJS <= 17994.0) && (wipJS > 4024.5) && (eTardJS <= 8810.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree7Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 1856.0) && (eTardJS > 502.5) && (eTardJS > 2459.25) && (eTardJS <= 17994.0) && (wipJS > 4024.5) && (eTardJS > 8810.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree7Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 1856.0) && (eTardJS <= 502.5) && (eTardJS <= 3.5) && (wipJS <= 5408.0) && (eTardJS <= 2.75) && (wipJS > 4023.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree7Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 1856.0) && (eTardJS <= 502.5) && (eTardJS > 3.5) && (wipJS <= 4297.0) && (wipJS <= 2829.0) && (eTardJS > 32.25))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree7Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 1856.0) && (eTardJS > 502.5) && (eTardJS > 2459.25) && (eTardJS > 17994.0) && (wipJS <= 4088.5) && (eTardJS > 51802.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree7Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 1856.0) && (eTardJS <= 502.5) && (eTardJS > 3.5) && (wipJS <= 4297.0) && (wipJS > 2829.0) && (eTardJS <= 448.75))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree7Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 1856.0) && (eTardJS > 502.5) && (eTardJS <= 2459.25) && (eTardJS <= 2444.25) && (wipJS > 1981.0) && (wipJS > 4686.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree7Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 1856.0) && (eTardJS <= 502.5) && (eTardJS > 3.5) && (wipJS > 4297.0) && (eTardJS > 12.5) && (wipJS <= 6189.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree7Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 1856.0) && (eTardJS > 502.5) && (eTardJS <= 2459.25) && (eTardJS <= 2444.25) && (wipJS <= 1981.0) && (eTardJS <= 2307.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree7Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 1856.0) && (eTardJS > 540.0) && (wipJS > 1561.0) && (eTardJS > 1329.0) && (wipJS <= 1820.0) && (wipJS > 1713.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree7Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 1856.0) && (eTardJS <= 540.0) && (wipJS > 1745.0) && (wipJS <= 1838.5) && (eTardJS <= 7.0) && (wipJS <= 1828.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree7Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 1856.0) && (eTardJS <= 502.5) && (eTardJS > 3.5) && (wipJS <= 4297.0) && (wipJS <= 2829.0) && (eTardJS <= 32.25))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree7Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 1856.0) && (eTardJS > 540.0) && (wipJS > 1561.0) && (eTardJS > 1329.0) && (wipJS <= 1820.0) && (wipJS <= 1713.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree7Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 1856.0) && (eTardJS > 540.0) && (wipJS > 1561.0) && (eTardJS <= 1329.0) && (wipJS > 1666.0) && (wipJS > 1694.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree7Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 1856.0) && (eTardJS <= 502.5) && (eTardJS <= 3.5) && (wipJS > 5408.0) && (wipJS <= 5730.5) && (wipJS <= 5691.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree7Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 1856.0) && (eTardJS > 540.0) && (wipJS > 1561.0) && (eTardJS <= 1329.0) && (wipJS <= 1666.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree7Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 1856.0) && (eTardJS <= 502.5) && (eTardJS <= 3.5) && (wipJS > 5408.0) && (wipJS > 5730.5) && (wipJS > 6276.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree7Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 1856.0) && (eTardJS <= 540.0) && (wipJS <= 1745.0) && (eTardJS <= 475.25) && (eTardJS <= 392.25) && (wipJS > 1729.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree7Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 1856.0) && (eTardJS <= 502.5) && (eTardJS > 3.5) && (wipJS <= 4297.0) && (wipJS > 2829.0) && (eTardJS > 448.75))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree7Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 1856.0) && (eTardJS <= 540.0) && (wipJS <= 1745.0) && (eTardJS > 475.25))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree7Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 1856.0) && (eTardJS > 502.5) && (eTardJS > 2459.25) && (eTardJS <= 17994.0) && (wipJS <= 4024.5) && (eTardJS > 17459.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree7Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 1856.0) && (eTardJS <= 540.0) && (wipJS > 1745.0) && (wipJS > 1838.5) && (eTardJS <= 129.75) && (wipJS > 1842.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree7Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 1856.0) && (eTardJS <= 502.5) && (eTardJS <= 3.5) && (wipJS > 5408.0) && (wipJS > 5730.5) && (wipJS <= 6276.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree7Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 1856.0) && (eTardJS <= 540.0) && (wipJS > 1745.0) && (wipJS <= 1838.5) && (eTardJS > 7.0) && (wipJS <= 1794.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree7Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 1856.0) && (eTardJS <= 540.0) && (wipJS <= 1745.0) && (eTardJS <= 475.25) && (eTardJS > 392.25))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree7Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 1856.0) && (eTardJS > 540.0) && (wipJS > 1561.0) && (eTardJS > 1329.0) && (wipJS > 1820.0) && (wipJS > 1831.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree7Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 1856.0) && (eTardJS <= 502.5) && (eTardJS > 3.5) && (wipJS > 4297.0) && (eTardJS <= 12.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree7Path33(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 1856.0) && (eTardJS <= 540.0) && (wipJS > 1745.0) && (wipJS <= 1838.5) && (eTardJS <= 7.0) && (wipJS > 1828.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree7Path34(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 1856.0) && (eTardJS > 540.0) && (wipJS <= 1561.0) && (eTardJS > 820.5) && (wipJS > 1380.5) && (eTardJS <= 2205.25))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree7Path35(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 1856.0) && (eTardJS <= 502.5) && (eTardJS <= 3.5) && (wipJS <= 5408.0) && (eTardJS > 2.75))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree7Path36(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 1856.0) && (eTardJS <= 502.5) && (eTardJS > 3.5) && (wipJS > 4297.0) && (eTardJS > 12.5) && (wipJS > 6189.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree7Path37(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 1856.0) && (eTardJS > 540.0) && (wipJS <= 1561.0) && (eTardJS > 820.5) && (wipJS <= 1380.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree7Path38(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 1856.0) && (eTardJS > 540.0) && (wipJS <= 1561.0) && (eTardJS <= 820.5) && (wipJS > 1290.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree7Path39(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 1856.0) && (eTardJS > 540.0) && (wipJS > 1561.0) && (eTardJS <= 1329.0) && (wipJS > 1666.0) && (wipJS <= 1694.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree7Path40(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 1856.0) && (eTardJS > 540.0) && (wipJS > 1561.0) && (eTardJS > 1329.0) && (wipJS > 1820.0) && (wipJS <= 1831.0))  { ruleCode = 18;}
    return ruleCode; }
public static int checkDTTree7Path41(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 1856.0) && (eTardJS > 540.0) && (wipJS <= 1561.0) && (eTardJS <= 820.5) && (wipJS <= 1290.5) && (eTardJS <= 690.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree7Path42(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 1856.0) && (eTardJS <= 540.0) && (wipJS > 1745.0) && (wipJS > 1838.5) && (eTardJS > 129.75) && (wipJS > 1845.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree7Path43(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 1856.0) && (eTardJS <= 540.0) && (wipJS > 1745.0) && (wipJS > 1838.5) && (eTardJS > 129.75) && (wipJS <= 1845.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree7Path44(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 1856.0) && (eTardJS > 540.0) && (wipJS <= 1561.0) && (eTardJS <= 820.5) && (wipJS <= 1290.5) && (eTardJS > 690.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree7Path45(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 1856.0) && (eTardJS <= 540.0) && (wipJS > 1745.0) && (wipJS > 1838.5) && (eTardJS <= 129.75) && (wipJS <= 1842.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree7Path46(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 1856.0) && (eTardJS <= 540.0) && (wipJS > 1745.0) && (wipJS <= 1838.5) && (eTardJS > 7.0) && (wipJS > 1794.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree7Path47(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 1856.0) && (eTardJS > 540.0) && (wipJS <= 1561.0) && (eTardJS > 820.5) && (wipJS > 1380.5) && (eTardJS > 2205.25))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree7Path48(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 1856.0) && (eTardJS > 502.5) && (eTardJS <= 2459.25) && (eTardJS <= 2444.25) && (wipJS <= 1981.0) && (eTardJS > 2307.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree7Path49(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 1856.0) && (eTardJS > 502.5) && (eTardJS <= 2459.25) && (eTardJS > 2444.25))  { ruleCode = 18;}
    return ruleCode; }
public static int checkDTTree7Path50(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 1856.0) && (eTardJS <= 502.5) && (eTardJS <= 3.5) && (wipJS > 5408.0) && (wipJS <= 5730.5) && (wipJS > 5691.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree8Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2447.0) && (wipJS <= 5450.0) && (wipJS <= 4019.0) && (wipJS > 2837.5) && (eTardJS > 332.75) && (wipJS > 2851.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree8Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2447.0) && (wipJS <= 1695.0) && (wipJS <= 1678.0) && (eTardJS <= 352.75) && (wipJS <= 1569.0) && (eTardJS <= 52.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree8Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2447.0) && (wipJS <= 5450.0) && (wipJS <= 4019.0) && (wipJS > 2837.5) && (eTardJS <= 332.75) && (wipJS > 2859.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree8Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2447.0) && (wipJS <= 5450.0) && (wipJS > 4019.0) && (eTardJS > 908.0) && (eTardJS > 10984.0) && (eTardJS > 17214.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree8Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2447.0) && (wipJS > 5450.0) && (wipJS <= 6414.0) && (wipJS <= 6412.5) && (eTardJS > 3338.5) && (wipJS > 5489.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree8Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2447.0) && (wipJS <= 5450.0) && (wipJS > 4019.0) && (eTardJS > 908.0) && (eTardJS <= 10984.0) && (eTardJS <= 10317.25))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree8Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2447.0) && (wipJS > 1695.0) && (eTardJS > 744.5) && (wipJS <= 2437.0) && (eTardJS <= 4426.25) && (eTardJS <= 4380.75))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree8Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2447.0) && (wipJS > 1695.0) && (eTardJS <= 744.5) && (wipJS > 1711.5) && (wipJS <= 2265.5) && (eTardJS <= 36.25))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree8Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2447.0) && (wipJS > 1695.0) && (eTardJS > 744.5) && (wipJS <= 2437.0) && (eTardJS > 4426.25) && (wipJS > 1800.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree8Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2447.0) && (wipJS <= 5450.0) && (wipJS <= 4019.0) && (wipJS <= 2837.5) && (eTardJS > 1173.0) && (eTardJS > 3382.25))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree8Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2447.0) && (wipJS > 5450.0) && (wipJS > 6414.0) && (wipJS > 6484.5) && (wipJS > 7056.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree8Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2447.0) && (wipJS <= 5450.0) && (wipJS > 4019.0) && (eTardJS <= 908.0) && (wipJS <= 4954.0) && (eTardJS <= 130.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree8Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2447.0) && (wipJS > 5450.0) && (wipJS > 6414.0) && (wipJS > 6484.5) && (wipJS <= 7056.0) && (eTardJS > 68.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree8Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2447.0) && (wipJS > 1695.0) && (eTardJS <= 744.5) && (wipJS > 1711.5) && (wipJS <= 2265.5) && (eTardJS > 36.25))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree8Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2447.0) && (wipJS <= 5450.0) && (wipJS <= 4019.0) && (wipJS <= 2837.5) && (eTardJS <= 1173.0) && (eTardJS <= 126.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree8Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2447.0) && (wipJS <= 5450.0) && (wipJS > 4019.0) && (eTardJS > 908.0) && (eTardJS > 10984.0) && (eTardJS <= 17214.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree8Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2447.0) && (wipJS > 5450.0) && (wipJS <= 6414.0) && (wipJS <= 6412.5) && (eTardJS <= 3338.5) && (wipJS > 5467.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree8Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2447.0) && (wipJS <= 5450.0) && (wipJS <= 4019.0) && (wipJS <= 2837.5) && (eTardJS <= 1173.0) && (eTardJS > 126.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree8Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2447.0) && (wipJS > 1695.0) && (eTardJS <= 744.5) && (wipJS > 1711.5) && (wipJS > 2265.5) && (wipJS > 2356.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree8Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2447.0) && (wipJS <= 5450.0) && (wipJS <= 4019.0) && (wipJS <= 2837.5) && (eTardJS > 1173.0) && (eTardJS <= 3382.25))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree8Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2447.0) && (wipJS <= 5450.0) && (wipJS > 4019.0) && (eTardJS <= 908.0) && (wipJS <= 4954.0) && (eTardJS > 130.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree8Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2447.0) && (wipJS > 1695.0) && (eTardJS <= 744.5) && (wipJS > 1711.5) && (wipJS > 2265.5) && (wipJS <= 2356.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree8Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2447.0) && (wipJS <= 1695.0) && (wipJS <= 1678.0) && (eTardJS <= 352.75) && (wipJS > 1569.0) && (wipJS <= 1662.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree8Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2447.0) && (wipJS <= 5450.0) && (wipJS > 4019.0) && (eTardJS <= 908.0) && (wipJS > 4954.0) && (wipJS <= 5262.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree8Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2447.0) && (wipJS <= 5450.0) && (wipJS > 4019.0) && (eTardJS <= 908.0) && (wipJS > 4954.0) && (wipJS > 5262.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree8Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2447.0) && (wipJS <= 1695.0) && (wipJS <= 1678.0) && (eTardJS > 352.75) && (eTardJS <= 1126.75) && (eTardJS <= 1008.75))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree8Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2447.0) && (wipJS <= 1695.0) && (wipJS <= 1678.0) && (eTardJS <= 352.75) && (wipJS <= 1569.0) && (eTardJS > 52.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree8Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2447.0) && (wipJS > 5450.0) && (wipJS > 6414.0) && (wipJS <= 6484.5) && (eTardJS > 1333.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree8Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2447.0) && (wipJS <= 1695.0) && (wipJS <= 1678.0) && (eTardJS > 352.75) && (eTardJS > 1126.75) && (wipJS > 1380.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree8Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2447.0) && (wipJS > 1695.0) && (eTardJS > 744.5) && (wipJS <= 2437.0) && (eTardJS > 4426.25) && (wipJS <= 1800.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree8Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2447.0) && (wipJS <= 5450.0) && (wipJS <= 4019.0) && (wipJS > 2837.5) && (eTardJS > 332.75) && (wipJS <= 2851.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree8Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2447.0) && (wipJS <= 5450.0) && (wipJS > 4019.0) && (eTardJS > 908.0) && (eTardJS <= 10984.0) && (eTardJS > 10317.25))  { ruleCode = 18;}
    return ruleCode; }
public static int checkDTTree8Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2447.0) && (wipJS > 5450.0) && (wipJS <= 6414.0) && (wipJS <= 6412.5) && (eTardJS > 3338.5) && (wipJS <= 5489.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree8Path33(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2447.0) && (wipJS <= 5450.0) && (wipJS <= 4019.0) && (wipJS > 2837.5) && (eTardJS <= 332.75) && (wipJS <= 2859.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree8Path34(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2447.0) && (wipJS > 1695.0) && (eTardJS <= 744.5) && (wipJS <= 1711.5) && (eTardJS <= 307.75) && (eTardJS <= 148.75))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree8Path35(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2447.0) && (wipJS <= 1695.0) && (wipJS > 1678.0) && (eTardJS <= 1525.5) && (eTardJS <= 8.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree8Path36(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2447.0) && (wipJS > 1695.0) && (eTardJS > 744.5) && (wipJS <= 2437.0) && (eTardJS <= 4426.25) && (eTardJS > 4380.75))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree8Path37(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2447.0) && (wipJS <= 1695.0) && (wipJS <= 1678.0) && (eTardJS <= 352.75) && (wipJS > 1569.0) && (wipJS > 1662.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree8Path38(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2447.0) && (wipJS <= 1695.0) && (wipJS <= 1678.0) && (eTardJS > 352.75) && (eTardJS <= 1126.75) && (eTardJS > 1008.75))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree8Path39(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2447.0) && (wipJS <= 1695.0) && (wipJS > 1678.0) && (eTardJS <= 1525.5) && (eTardJS > 8.5) && (eTardJS > 102.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree8Path40(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2447.0) && (wipJS > 1695.0) && (eTardJS <= 744.5) && (wipJS <= 1711.5) && (eTardJS > 307.75))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree8Path41(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2447.0) && (wipJS > 5450.0) && (wipJS > 6414.0) && (wipJS > 6484.5) && (wipJS <= 7056.0) && (eTardJS <= 68.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree8Path42(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2447.0) && (wipJS > 5450.0) && (wipJS <= 6414.0) && (wipJS <= 6412.5) && (eTardJS <= 3338.5) && (wipJS <= 5467.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree8Path43(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2447.0) && (wipJS <= 1695.0) && (wipJS > 1678.0) && (eTardJS <= 1525.5) && (eTardJS > 8.5) && (eTardJS <= 102.0))  { ruleCode = 18;}
    return ruleCode; }
public static int checkDTTree8Path44(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2447.0) && (wipJS <= 1695.0) && (wipJS > 1678.0) && (eTardJS > 1525.5))  { ruleCode = 18;}
    return ruleCode; }
public static int checkDTTree8Path45(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2447.0) && (wipJS > 1695.0) && (eTardJS <= 744.5) && (wipJS <= 1711.5) && (eTardJS <= 307.75) && (eTardJS > 148.75))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree8Path46(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2447.0) && (wipJS <= 1695.0) && (wipJS <= 1678.0) && (eTardJS > 352.75) && (eTardJS > 1126.75) && (wipJS <= 1380.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree8Path47(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2447.0) && (wipJS > 5450.0) && (wipJS <= 6414.0) && (wipJS > 6412.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree8Path48(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS <= 2447.0) && (wipJS > 1695.0) && (eTardJS > 744.5) && (wipJS > 2437.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree8Path49(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((wipJS > 2447.0) && (wipJS > 5450.0) && (wipJS > 6414.0) && (wipJS <= 6484.5) && (eTardJS <= 1333.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree9Path0(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1121.25) && (wipJS <= 3944.5) && (eTardJS <= 190.5) && (eTardJS <= 37.5) && (eTardJS <= 36.75) && (wipJS <= 1317.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree9Path1(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1121.25) && (wipJS <= 3944.5) && (eTardJS <= 190.5) && (eTardJS <= 37.5) && (eTardJS <= 36.75) && (wipJS > 1317.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree9Path2(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1121.25) && (wipJS <= 5236.0) && (eTardJS > 4456.5) && (wipJS <= 5227.5) && (eTardJS > 12969.25) && (wipJS <= 4083.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree9Path3(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1121.25) && (wipJS <= 5236.0) && (eTardJS > 4456.5) && (wipJS <= 5227.5) && (eTardJS <= 12969.25) && (wipJS <= 4557.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree9Path4(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1121.25) && (wipJS <= 5236.0) && (eTardJS <= 4456.5) && (wipJS <= 4613.5) && (eTardJS <= 4381.0) && (wipJS <= 4044.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree9Path5(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1121.25) && (wipJS > 5236.0) && (eTardJS > 3586.0) && (wipJS > 5985.0) && (eTardJS > 21593.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree9Path6(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1121.25) && (wipJS > 3944.5) && (wipJS <= 6232.0) && (wipJS <= 5395.0) && (wipJS <= 5256.0) && (wipJS <= 5175.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree9Path7(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1121.25) && (wipJS <= 5236.0) && (eTardJS > 4456.5) && (wipJS <= 5227.5) && (eTardJS > 12969.25) && (wipJS > 4083.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree9Path8(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1121.25) && (wipJS > 5236.0) && (eTardJS > 3586.0) && (wipJS <= 5985.0) && (wipJS <= 5983.0) && (eTardJS > 6867.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree9Path9(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1121.25) && (wipJS <= 3944.5) && (eTardJS > 190.5) && (wipJS <= 2816.5) && (wipJS > 2116.0) && (eTardJS <= 1080.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree9Path10(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1121.25) && (wipJS <= 3944.5) && (eTardJS > 190.5) && (wipJS <= 2816.5) && (wipJS <= 2116.0) && (eTardJS <= 1072.75))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree9Path11(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1121.25) && (wipJS > 5236.0) && (eTardJS > 3586.0) && (wipJS > 5985.0) && (eTardJS <= 21593.5) && (wipJS <= 7597.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree9Path12(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1121.25) && (wipJS <= 3944.5) && (eTardJS <= 190.5) && (eTardJS > 37.5) && (wipJS > 2168.0) && (eTardJS > 54.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree9Path13(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1121.25) && (wipJS <= 3944.5) && (eTardJS <= 190.5) && (eTardJS > 37.5) && (wipJS <= 2168.0) && (eTardJS > 54.75))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree9Path14(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1121.25) && (wipJS <= 3944.5) && (eTardJS > 190.5) && (wipJS > 2816.5) && (wipJS <= 3608.5) && (wipJS <= 3476.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree9Path15(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1121.25) && (wipJS <= 5236.0) && (eTardJS > 4456.5) && (wipJS <= 5227.5) && (eTardJS <= 12969.25) && (wipJS > 4557.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree9Path16(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1121.25) && (wipJS <= 5236.0) && (eTardJS <= 4456.5) && (wipJS <= 4613.5) && (eTardJS <= 4381.0) && (wipJS > 4044.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree9Path17(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1121.25) && (wipJS > 3944.5) && (wipJS <= 6232.0) && (wipJS > 5395.0) && (eTardJS <= 527.0) && (eTardJS <= 394.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree9Path18(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1121.25) && (wipJS > 3944.5) && (wipJS <= 6232.0) && (wipJS <= 5395.0) && (wipJS > 5256.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree9Path19(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1121.25) && (wipJS > 5236.0) && (eTardJS <= 3586.0) && (eTardJS <= 3452.0) && (eTardJS <= 3111.5) && (wipJS > 5530.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree9Path20(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1121.25) && (wipJS > 5236.0) && (eTardJS > 3586.0) && (wipJS <= 5985.0) && (wipJS <= 5983.0) && (eTardJS <= 6867.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree9Path21(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1121.25) && (wipJS <= 5236.0) && (eTardJS <= 4456.5) && (wipJS > 4613.5) && (wipJS > 4901.5) && (wipJS > 5044.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree9Path22(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1121.25) && (wipJS <= 5236.0) && (eTardJS <= 4456.5) && (wipJS > 4613.5) && (wipJS <= 4901.5) && (wipJS > 4748.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree9Path23(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1121.25) && (wipJS <= 3944.5) && (eTardJS > 190.5) && (wipJS > 2816.5) && (wipJS > 3608.5) && (wipJS > 3738.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree9Path24(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1121.25) && (wipJS <= 3944.5) && (eTardJS > 190.5) && (wipJS > 2816.5) && (wipJS > 3608.5) && (wipJS <= 3738.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree9Path25(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1121.25) && (wipJS <= 5236.0) && (eTardJS <= 4456.5) && (wipJS > 4613.5) && (wipJS <= 4901.5) && (wipJS <= 4748.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree9Path26(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1121.25) && (wipJS <= 3944.5) && (eTardJS > 190.5) && (wipJS > 2816.5) && (wipJS <= 3608.5) && (wipJS > 3476.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree9Path27(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1121.25) && (wipJS <= 5236.0) && (eTardJS <= 4456.5) && (wipJS > 4613.5) && (wipJS > 4901.5) && (wipJS <= 5044.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree9Path28(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1121.25) && (wipJS > 3944.5) && (wipJS <= 6232.0) && (wipJS > 5395.0) && (eTardJS > 527.0) && (wipJS > 5508.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree9Path29(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1121.25) && (wipJS <= 3944.5) && (eTardJS <= 190.5) && (eTardJS > 37.5) && (wipJS > 2168.0) && (eTardJS <= 54.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree9Path30(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1121.25) && (wipJS > 5236.0) && (eTardJS <= 3586.0) && (eTardJS <= 3452.0) && (eTardJS <= 3111.5) && (wipJS <= 5530.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree9Path31(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1121.25) && (wipJS > 3944.5) && (wipJS <= 6232.0) && (wipJS > 5395.0) && (eTardJS > 527.0) && (wipJS <= 5508.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree9Path32(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1121.25) && (wipJS > 3944.5) && (wipJS > 6232.0) && (eTardJS > 6.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree9Path33(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1121.25) && (wipJS > 5236.0) && (eTardJS > 3586.0) && (wipJS > 5985.0) && (eTardJS <= 21593.5) && (wipJS > 7597.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree9Path34(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1121.25) && (wipJS <= 3944.5) && (eTardJS <= 190.5) && (eTardJS > 37.5) && (wipJS <= 2168.0) && (eTardJS <= 54.75))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree9Path35(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1121.25) && (wipJS > 3944.5) && (wipJS <= 6232.0) && (wipJS <= 5395.0) && (wipJS <= 5256.0) && (wipJS > 5175.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree9Path36(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1121.25) && (wipJS <= 3944.5) && (eTardJS > 190.5) && (wipJS <= 2816.5) && (wipJS > 2116.0) && (eTardJS > 1080.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree9Path37(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1121.25) && (wipJS > 3944.5) && (wipJS > 6232.0) && (eTardJS <= 6.0) && (wipJS > 7042.5) && (wipJS > 7146.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree9Path38(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1121.25) && (wipJS > 3944.5) && (wipJS <= 6232.0) && (wipJS > 5395.0) && (eTardJS <= 527.0) && (eTardJS > 394.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree9Path39(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1121.25) && (wipJS <= 5236.0) && (eTardJS <= 4456.5) && (wipJS <= 4613.5) && (eTardJS > 4381.0) && (wipJS <= 2134.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree9Path40(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1121.25) && (wipJS <= 5236.0) && (eTardJS <= 4456.5) && (wipJS <= 4613.5) && (eTardJS > 4381.0) && (wipJS > 2134.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree9Path41(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1121.25) && (wipJS <= 3944.5) && (eTardJS > 190.5) && (wipJS <= 2816.5) && (wipJS <= 2116.0) && (eTardJS > 1072.75))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree9Path42(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1121.25) && (wipJS <= 3944.5) && (eTardJS <= 190.5) && (eTardJS <= 37.5) && (eTardJS > 36.75))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree9Path43(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1121.25) && (wipJS > 3944.5) && (wipJS > 6232.0) && (eTardJS <= 6.0) && (wipJS <= 7042.5) && (wipJS <= 6737.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree9Path44(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1121.25) && (wipJS > 5236.0) && (eTardJS <= 3586.0) && (eTardJS <= 3452.0) && (eTardJS > 3111.5) && (wipJS > 6052.5))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree9Path45(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1121.25) && (wipJS > 3944.5) && (wipJS > 6232.0) && (eTardJS <= 6.0) && (wipJS <= 7042.5) && (wipJS > 6737.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree9Path46(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1121.25) && (wipJS > 5236.0) && (eTardJS <= 3586.0) && (eTardJS <= 3452.0) && (eTardJS > 3111.5) && (wipJS <= 6052.5))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree9Path47(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS <= 1121.25) && (wipJS > 3944.5) && (wipJS > 6232.0) && (eTardJS <= 6.0) && (wipJS > 7042.5) && (wipJS <= 7146.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree9Path48(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1121.25) && (wipJS > 5236.0) && (eTardJS > 3586.0) && (wipJS <= 5985.0) && (wipJS > 5983.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree9Path49(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1121.25) && (wipJS <= 5236.0) && (eTardJS > 4456.5) && (wipJS > 5227.5) && (eTardJS <= 33672.0))  { ruleCode = 214;}
    return ruleCode; }
public static int checkDTTree9Path50(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1121.25) && (wipJS <= 5236.0) && (eTardJS > 4456.5) && (wipJS > 5227.5) && (eTardJS > 33672.0))  { ruleCode = 508;}
    return ruleCode; }
public static int checkDTTree9Path51(double nJobs, double wipJS, double rptJS, double tptJS, double allowJS, double slkJS, double eTardJS, double eEarlJS, double eLatJS){
    int ruleCode = -1;
    if ((eTardJS > 1121.25) && (wipJS > 5236.0) && (eTardJS <= 3586.0) && (eTardJS > 3452.0))  { ruleCode = 214;}
    return ruleCode; }
}
