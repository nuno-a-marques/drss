package RL;

public class ObservationCustom {
    int iteration;
    double timestamp;
    
    //Estado s
    double workInfo;
    double allowanceInfo;
    
    //descricao da acao
    double pt;
    double npt;
    double rpt;
    double allowance;
    double slack;
    double winq;

    double reward;
    
    //Guarda também o estado seguinte
    double workInfo2;
    double allowanceInfo2;

    public ObservationCustom(double timestamp){
        
        this.iteration=0;
        this.timestamp=timestamp;

        this.workInfo=0.0;
        this.allowanceInfo=0.0;

        this.pt=0.0;
        this.npt=0.0;
        this.rpt=0.0;
        this.allowance=0.0;
        this.slack=0.0;
        this.winq=0.0;

        this.reward=0.0;

        this.workInfo2=0.0;
        this.allowanceInfo2=0.0;

    }

    public void setIteration(int iter){
        this.iteration=iter;
    }

    public void setWorkInfo(double wi){
        this.workInfo=wi;
    }

    public double getWorkInfo(){
        return this.workInfo;
    }

    public void setAllowanceInfo(double ai){
        this.allowanceInfo=ai;
    }

    public double getAllowanceInfo(){
        return this.allowanceInfo;
    }

    public void setAction(double pt, double npt,double rpt, double allowance, double slack, double winq){
        this.pt=pt;
        this.npt=npt;
        this.rpt=rpt;
        this.allowance=allowance;
        this.slack=slack;
        this.winq=winq;
    }

    public double[] getAction(){
        double[] resultado={this.pt,this.npt,this.rpt,this.allowance,this.slack,this.winq};
        return resultado;
    }

    public double getProcessingTime(){
        return this.pt;
    }
    
    public double getNextProcessingTime(){
        return this.npt;
    }
    
    public double getRemainingProcessingTime(){
        return this.rpt;
    }
    
    public double getAllowance(){
        return this.allowance;
    }
    
    public double getSlack(){
        return this.slack;
    }
    
    public double getWinq(){
        return this.winq;
    }

    public void setReward(double reward){
        this.reward=reward;
    }

    public double getReward(){
        return this.reward;
    }

    public void setPreviousState(double workInfo,double allowanceInfo){
        this.workInfo2=workInfo;
        this.allowanceInfo2=allowanceInfo;
    }

    public double[] getFollowingStateAsArray(){
        double[] resultado=new double[]{workInfo2,allowanceInfo2};
        return resultado;
    }
    
    public String toString(){
        String str=iteration+";"+timestamp+";"+workInfo+";"+allowanceInfo+";"+pt+";"+npt+";"+rpt+";"+allowance+";"+slack+";"+winq+";"+reward+";"+workInfo2+";"+allowanceInfo2;
        return str;    
    }

    public int argmax (double [] elems)
    {
      int bestIdx = -1;
      double max = Double.NEGATIVE_INFINITY;
      for (int i = 0; i < elems.length; i++) {
        double elem = elems[i];
        if (elem > max) {
          max = elem;
          bestIdx = i;
        }
      }
      return bestIdx;
    }
    
}
