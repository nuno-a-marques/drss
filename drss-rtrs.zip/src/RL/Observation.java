package RL;

public class Observation{
    double timestamp;
    double machineUtilisationMean;
    double machineUtilisationSD;
    double operationsRate;
    double jobsRateMean;
    double jobsRateSD;
    double estimatedTard;
    double actualTard;
    double action;
    double random;
    double reward;
    //Guarda também o estado seguinte
    double machineUtilisationMean2;
    double machineUtilisationSD2;
    double operationsRate2;
    double jobsRateMean2;
    double jobsRateSD2;
    double estimatedTard2;
    double actualTard2;
    int iteration;

    public Observation(double timestamp){
        this.timestamp=timestamp;
        this.machineUtilisationMean=0.0;
        this.machineUtilisationSD=0.0;
        this.operationsRate=0.0;
        this.jobsRateMean=0.0;
        this.jobsRateSD=0.0;
        this.estimatedTard=0.0;
        this.actualTard=0.0;
        this.action=0.0;
        this.random=0.0;
        this.reward=0.0;

        this.machineUtilisationMean2=0.0;
        this.machineUtilisationSD2=0.0;
        this.operationsRate2=0.0;
        this.jobsRateMean2=0.0;
        this.jobsRateSD2=0.0;
        this.estimatedTard2=0.0;
        this.actualTard2=0.0;

        this.iteration=0;
    }

    public void setMachineUtilisation(double muMean,double muSD){
        this.machineUtilisationMean=muMean;
        this.machineUtilisationSD=muSD;
    }

    public void setOperationsRate(double opRate){
        this.operationsRate=opRate;
    }

    public void setJobsRate(double jrMean,double jrSD){
        this.jobsRateMean=jrMean;
        this.jobsRateSD=jrSD;
    }

    public void setTardiness(double eTard,double aTard){
        this.estimatedTard=eTard;
        this.actualTard=aTard;
    }

    public void setAction(double action){
        this.action=action;
    }

    public void setRandomStatus(double rdn){
        this.random=rdn;
    }

    public double getRandomStatus(){
        return this.random;
    }

    public void setReward(double reward){
        this.reward=reward;
    }

    public double getMachineUtilisationMean(){
        return this.machineUtilisationMean;
    }

    public double getMachineUtilisationSD(){
        return this.machineUtilisationSD;
    }

    public double getOperationsRate(){
        return this.operationsRate;
    }

    public double getJobsRateMean(){
        return this.jobsRateMean;
    }

    public double getJobsRateSD(){
        return this.jobsRateSD;
    }

    public double getEstimatedTardiness(){
        return this.estimatedTard;
    }

    public double getActualTardiness(){
        return this.actualTard;
    }

    public double getAction(){
        return this.action;
    }

    public double getReward(){
        return this.reward;
    }

    public void setIteration(int iter){
        this.iteration=iter;
    }

    public int getIteration(){
        return this.iteration;
    }

    public void setPreviousState(double machinesUtilisationMeanTemp, double machinesUtilisationSDTemp, double operationsRateTemp, double jobsRateMeanTemp, double jobsRateSDTemp, double estimatedTardTemp, double actualTardTemp){
        machineUtilisationMean2=machinesUtilisationMeanTemp;
        machineUtilisationSD2=machinesUtilisationSDTemp;
        operationsRate2=operationsRateTemp;
        jobsRateMean2=jobsRateMeanTemp;
        jobsRateSD2=jobsRateSDTemp;
        actualTard2=actualTardTemp;
        estimatedTard2=estimatedTardTemp;
    }

    public double[] getFollowingStateAsArray(){
        double[] resultado=new double[]{machineUtilisationMean2,machineUtilisationSD2,operationsRate2,jobsRateMean2,jobsRateSD2,estimatedTard2,actualTard2};
        return resultado;
    }
    
    public String toString(){
        String str=iteration+";"+timestamp+";"+machineUtilisationMean+";"+machineUtilisationSD+";"+operationsRate+";"+jobsRateMean+";"+jobsRateSD+";"+estimatedTard+";"+actualTard+";"+action+";"+random+";"+reward+";"+machineUtilisationMean2+";"+machineUtilisationSD2+";"+operationsRate2+";"+jobsRateMean2+";"+jobsRateSD2+";"+estimatedTard2+";"+actualTard2;
        return str;    
    }

    public int argmax (double [] elems)
    {
      int bestIdx = -1;
      double max = Double.NEGATIVE_INFINITY;
      for (int i = 0; i < elems.length; i++) {
        double elem = elems[i];
        if (elem > max) {
          max = elem;
          bestIdx = i;
        }
      }
      return bestIdx;
    }
}