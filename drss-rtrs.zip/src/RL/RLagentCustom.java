package RL;

import java.util.ArrayList;
//import java.util.List.
import java.util.List;
import java.util.Scanner;
//import java.util.stream.IntStream;
import java.util.Collections;
//import java.util.Iterator;
//import com.github.lwhite1.tablesaw.*;
//import com.github.lwhite1.tablesaw.api.*;
import java.io.*;
//import java.util.List;

import org.neuroph.nnet.MultiLayerPerceptron;
import org.neuroph.util.TransferFunctionType;

import main.GlobalParameters;

//import org.neuroph.nnet.learning.MomentumBackpropagation;
import org.neuroph.nnet.learning.BackPropagation;
import org.neuroph.nnet.learning.ResilientPropagation;
import org.neuroph.core.Weight;
import org.neuroph.core.data.DataSet;
import org.neuroph.core.data.DataSetRow;
//import org.neuroph.core.transfer.TransferFunction;
import org.neuroph.core.transfer.Linear;
import org.neuroph.core.transfer.RectifiedLinear;
import org.neuroph.core.events.LearningEvent;
import org.neuroph.core.events.LearningEventListener;
import org.neuroph.core.learning.LearningRule;
import org.json.simple.JsonObject;
import org.json.simple.Jsoner;
import org.json.simple.DeserializationException;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

// RL agent, DQN

public class RLagentCustom{
    List<ObservationCustom> dataset;
    List<ObservationCustom> episodeDataset;

    public RLagentCustom(){
        System.out.println("AGENTE RL INICIADO");
        dataset=new ArrayList<ObservationCustom>();
        episodeDataset=new ArrayList<ObservationCustom>();
    }

    public void addObservation(ObservationCustom obs) {
        if(dataset.size()>=1000){
            dataset.remove(0);
        }        
        dataset.add(obs);
        episodeDataset.add(obs);
	}

    public int getDatasetSize() {return dataset.size();}

    public void clearEpisodeDataset(){
        this.episodeDataset.clear();
    }

    public void setPreviousObservation(ObservationCustom obs){
        if(dataset.size()>1){
            ObservationCustom previousState   =   dataset.get(dataset.size()-2);
            previousState.setPreviousState(obs.getWorkInfo(),obs.getAllowanceInfo());
        }

        //Informaçãom atualizada
    }
    
    public void dumpData() throws IOException{
        String fileName="dataset.txt";
        BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true));

        for (ObservationCustom obs : dataset) {
            //System.out.println("Next item: " + s[0]);
            String str=obs.toString();
            writer.append(str);
            writer.newLine();
         }
            
        writer.close();       
    }

    public void dumpEpisodeData(MultiLayerPerceptron neuralNet) throws IOException{
        String fileName="episodeDataset.txt";
        BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true));

        for (ObservationCustom obs : episodeDataset) {
            //System.out.println("Next item: " + s[0]);
            String str=obs.toString();
            double qvalue=makePrediction(neuralNet, obs);
            writer.append(str+";"+String.valueOf(qvalue));
            writer.newLine();
        }
            
        writer.close();       
    }

    public void dumpWeights(MultiLayerPerceptron neuralNet,String type) throws IOException{
        int controlo=0;
        JsonObject obj = new JsonObject();
        int nLayers=neuralNet.getLayersCount();
        for(int l = 1; l < nLayers; l++){
            int nNeurons=neuralNet.getLayerAt(l).getNeuronsCount();
            for(int n = 0; n < nNeurons; n++){
                Weight[] weightList=neuralNet.getLayerAt(l).getNeuronAt(n).getWeights();
                //Weight[] weightList2=targetNet.getLayerAt(l).getNeuronAt(n).getWeights();

                for(int w=0;w<weightList.length;w++){
                    controlo=controlo+1;
                    Weight weightTemp=weightList[w];
                    //Weight weightTemp2=weightList2[w];
                    double weightvalue=weightTemp.getValue();
                    obj.put(String.valueOf(controlo),Double.toString(weightvalue));     
                    
                }
            }
        }

        try (FileWriter file = new FileWriter(type+".json")) {
            file.write(obj.toJson());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void loadWeights(MultiLayerPerceptron neuralNet,String type){
        JSONParser parser = new JSONParser();
        try (Reader reader = new FileReader(type+".json")) {
            //JsonObject jsonObject = (JsonObject) Jsoner.deserialize(type+".json");
            //JsonObject jsonObject = (JsonObject) parser.parse(reader);
            JsonObject jsonObject = (JsonObject) Jsoner.deserialize(reader);     

            int controlo=0;
            int nLayers=neuralNet.getLayersCount();
            for(int l = 1; l < nLayers; l++){
                int nNeurons=neuralNet.getLayerAt(l).getNeuronsCount();
                for(int n = 0; n < nNeurons; n++){
                    Weight[] weightList=neuralNet.getLayerAt(l).getNeuronAt(n).getWeights();
                    for(int w=0;w<weightList.length;w++){
                        controlo=controlo+1;
                        Weight weightTemp=weightList[w];
                        String temp = (String) jsonObject.get(String.valueOf(controlo));
                        double weight=Double.parseDouble(temp); 
                        weightTemp.setValue(weight);  
                        
                    }
                }
            }


        } catch (IOException e) {
            e.printStackTrace();
        }
        // catch (ParseException e) {
        //     e.printStackTrace();
        // }
        catch (DeserializationException e) {
            throw new RuntimeException("Can't deserialize JSON", e);
        }
    }

    public void loadDataset() throws FileNotFoundException{

        Scanner read = new Scanner (new File("episodeDataset.txt"));
        //read.useDelimiter(";");
        String iterationTemp, timestampTemp, workinfoTemp, allowanceinfoTemp, ptTemp, nptTemp, rptTemp, allowanceTemp,slackTemp,winqTemp,rewardTemp,workinfo2Temp,allowanceinfo2Temp,qvalueTemp;

        while(read.hasNextLine()){
            String str=read.nextLine();
            Scanner sc = new Scanner(str);
            sc.useDelimiter(";");
            while (sc.hasNext()){
                iterationTemp = sc.next();
                timestampTemp = sc.next();
                workinfoTemp = sc.next();
                allowanceinfoTemp = sc.next();
                ptTemp = sc.next();
                nptTemp=sc.next();
                rptTemp=sc.next();
                allowanceTemp=sc.next();
                slackTemp=sc.next();
                winqTemp=sc.next();
                rewardTemp=sc.next();
                workinfo2Temp=sc.next();
                allowanceinfo2Temp=sc.next();
                qvalueTemp=sc.next();
                //System.out.println(iterationTemp + " " + timestampTemp + " " + workinfoTemp + " " +allowanceinfoTemp + " " + ptTemp+ " " + nptTemp+ " " + rptTemp+ " " + allowanceTemp+ " " + slackTemp+ " " + winqTemp+ " " + rewardTemp+ " " + workinfo2Temp+ " " + allowanceinfo2Temp+ " " + qvalueTemp); // just for debugging
                ObservationCustom obs =new ObservationCustom(Double.valueOf(timestampTemp));
                obs.setIteration(Integer.valueOf(iterationTemp));
                obs.setWorkInfo(Double.valueOf(workinfoTemp));
                obs.setAllowanceInfo(Double.valueOf(allowanceinfoTemp));
                obs.setAction(Double.valueOf(ptTemp), Double.valueOf(nptTemp), Double.valueOf(rptTemp), Double.valueOf(allowanceTemp), Double.valueOf(slackTemp), Double.valueOf(winqTemp));
                obs.setReward(Double.valueOf(rewardTemp));
                obs.setPreviousState(Double.valueOf(workinfo2Temp), Double.valueOf(allowanceinfo2Temp));
                addObservation(obs);
            }
            sc.close();
        }
        read.close();
    }

    public void computeReward(){
        double reward=0.0;
        if(dataset.size()>=2){
            ObservationCustom previousState   =   dataset.get(dataset.size()-2);
            ObservationCustom currentState    =   dataset.get(dataset.size()-1);
            
            if(currentState.getAllowanceInfo()>previousState.getAllowanceInfo()){
                reward=1.0;
                if(previousState.getAllowanceInfo()!=0){
                    reward=reward+Math.min((currentState.getAllowanceInfo()-previousState.getAllowanceInfo())/Math.abs(previousState.getAllowanceInfo()),1.0);
                }                 
            }
            else if (currentState.getAllowanceInfo()==previousState.getAllowanceInfo()){
                reward=-0.1;
            }
            else{
                reward=-1.0;
                if(previousState.getAllowanceInfo()!=0){
                    reward=reward+Math.max((currentState.getAllowanceInfo()-previousState.getAllowanceInfo())/Math.abs(previousState.getAllowanceInfo()),-1.0);
                }
            }
            previousState.setReward(reward);
        }

    }

    public MultiLayerPerceptron initializeNetwork(String type){
        MultiLayerPerceptron neuralNet = new MultiLayerPerceptron(TransferFunctionType.TANH, 8, 30,30,30,30,30, 1);
                
        //MomentumBackpropagation learningRule = (MomentumBackpropagation) neuralNet.getLearningRule();
        //learningRule.setLearningRate(0.5);
        //learningRule.setMomentum(0.8);
        if(GlobalParameters.LOAD_WEIGHTS){
            if(type=="target"){
                loadWeights(neuralNet,"target");
            }
            else if (type=="online"){
                loadWeights(neuralNet,"online");
            }
            else{
                System.out.println("ERRO: os pesos nao foram carregados");
                neuralNet.randomizeWeights();
            }
        }
        else{neuralNet.randomizeWeights();}
        

        //RectifiedLinear ln0=new RectifiedLinear();
        Linear ln0=new Linear();
        // RectifiedLinear ln1=new RectifiedLinear();
        // RectifiedLinear ln2=new RectifiedLinear();
        // RectifiedLinear ln3=new RectifiedLinear();
        // RectifiedLinear ln4=new RectifiedLinear();
        // RectifiedLinear ln5=new RectifiedLinear();

        neuralNet.getLayerAt(6).getNeuronAt(0).setTransferFunction(ln0);
        // neuralNet.getLayerAt(6).getNeuronAt(1).setTransferFunction(ln1);
        // neuralNet.getLayerAt(6).getNeuronAt(2).setTransferFunction(ln2);
        // neuralNet.getLayerAt(6).getNeuronAt(3).setTransferFunction(ln3);
        // neuralNet.getLayerAt(6).getNeuronAt(4).setTransferFunction(ln4);
        // neuralNet.getLayerAt(6).getNeuronAt(5).setTransferFunction(ln5);

        BackPropagation learningRule = neuralNet.getLearningRule();

        learningRule.setLearningRate(0.5);
        learningRule.setMaxError(0.001);
        learningRule.setMaxIterations(1);

        BackPropagation rbackprop=new ResilientPropagation();
        rbackprop.setMaxError(0.001);
        rbackprop.setMaxIterations(1);
        rbackprop.setLearningRate(0.2);
        
        //add learning listener in order to print out training info
        if(GlobalParameters.VERBOSE){
            rbackprop.addListener(new LearningEventListener() {
                @Override
                public void handleLearningEvent(LearningEvent event) {
                    BackPropagation bp = (BackPropagation) event.getSource();
                    if (event.getEventType().equals(LearningEvent.Type.LEARNING_STOPPED)) {
                        System.out.println();
                        System.out.println("Training completed in " + bp.getCurrentIteration() + " iterations");
                        System.out.println("With total error " + bp.getTotalNetworkError() + '\n');
                    } else {
                        System.out.println("Iteration: " + bp.getCurrentIteration() + " | Network error: " + bp.getTotalNetworkError());
                    }
                }
            });
        }

        neuralNet.setLearningRule(rbackprop);

        return neuralNet;
    }

    public void synchronizeWeights(MultiLayerPerceptron neuralNet, MultiLayerPerceptron targetNet){
        int nLayers=neuralNet.getLayersCount();
            for(int l = 1; l < nLayers; l++){
                int nNeurons=neuralNet.getLayerAt(l).getNeuronsCount();
                for(int n = 0; n < nNeurons; n++){
                    Weight[] weightList=neuralNet.getLayerAt(l).getNeuronAt(n).getWeights();
                    Weight[] weightList2=targetNet.getLayerAt(l).getNeuronAt(n).getWeights();

                    for(int w=0;w<weightList.length;w++){
                        Weight weightTemp=weightList[w];
                        Weight weightTemp2=weightList2[w];
                        double weightvalue=weightTemp.getValue();
                        //è preciso escolher o peso da network certa
                        weightTemp2.setValue(weightvalue);
                    }
                }
            }

    }

    public DataSet getMiniBatch(MultiLayerPerceptron neuralNet, MultiLayerPerceptron targetNet,int replicationID){
        DataSet ds = new DataSet(8, 1);
        
        ArrayList<Integer> a = new ArrayList<>(dataset.size()-3);
        for (int i = 2; i < dataset.size()-1; i++){
            //to generate from 0-10 inclusive. 
            //For 0-9 inclusive, remove the = on the <=
            a.add(i);
        }

        Collections.shuffle(a);
        
        //Nota é preciso definir o tamanho do dataset
        int miniBatchSize=32;

        for (int i = 0; i <= miniBatchSize-1; i++){
            int temp=a.get(i);
            ObservationCustom obs=dataset.get(temp);
            ObservationCustom followingObs=dataset.get(temp+1);


            double[] rowInput=new double[]{ obs.getWorkInfo(),
                                            obs.getAllowanceInfo(),
                                            obs.getProcessingTime(),
                                            obs.getNextProcessingTime(),
                                            obs.getRemainingProcessingTime(),
                                            obs.getAllowance(),
                                            obs.getSlack(),
                                            obs.getWinq()
                                            };           
            
            // neuralNet.setInput(rowInput[0],rowInput[1],rowInput[2],rowInput[3],rowInput[4],rowInput[5],rowInput[6],rowInput[7]);
            // neuralNet.calculate();
            // double[] networkOutputOne = new double[]{neuralNet.getOutput()[0]};
            
            //Ação que maximiza o Q value do st+1, de acordo com Q
            double[] followingState=obs.getFollowingStateAsArray();
            //neuralNet.setInput(followingState[0],followingState[1],followingState[2],followingState[3],followingState[4],followingState[5],followingState[6]);
            //neuralNet.calculate();
            //double[] networkOutputTwo = new double[]{neuralNet.getOutput()[0],neuralNet.getOutput()[1],neuralNet.getOutput()[2],neuralNet.getOutput()[3],neuralNet.getOutput()[4],neuralNet.getOutput()[5]};
            double[] action2=followingObs.getAction();
            
            //Q value da politica Q^, do estado seguinte
            targetNet.setInput(followingState[0],followingState[1],action2[0],action2[1],action2[2],action2[3],action2[4],action2[5]);
            targetNet.calculate();
            double[] networkOutputThree = new double[]{targetNet.getOutput()[0]};
            double qvalue= networkOutputThree[0];

            // if(replicationID==0){
            //     networkOutputOne[action-1]=obs.getReward();
            // }
            // else{
            //     networkOutputOne[action-1]=obs.getReward()+0.8*networkOutputTwo[obs.argmax(networkOutputTwo)];
            // }
            
            double[] returns={0.0};
            if      (replicationID==0)   {returns[0]=obs.getReward()+GlobalParameters.DISCOUNT_FACTOR*qvalue;}
            else                         {returns[0]=obs.getReward()+GlobalParameters.DISCOUNT_FACTOR*qvalue;}
            

            //System.out.println(replicationID+"; "+String.valueOf(followingState[0])+"; "+String.valueOf(followingState[1])+"; "+String.valueOf(action2[0])+"; "+String.valueOf(action2[1])+"; "+String.valueOf(action2[2])+"; "+String.valueOf(action2[3])+"; "+String.valueOf(action2[4])+"; "+String.valueOf(action2[5])+"; "+String.valueOf(qvalue));
            
            DataSetRow rTemp  = new DataSetRow(rowInput, returns);
            ds.add(rTemp);
        }
        
        return ds;
    }

    public double makePrediction(MultiLayerPerceptron neuralNet, ObservationCustom obs){
        double resultado=0.0;
        double[] rowInput=new double[]{ obs.getWorkInfo(),
                                        obs.getAllowanceInfo(),
                                        obs.getProcessingTime(),
                                        obs.getNextProcessingTime(),
                                        obs.getRemainingProcessingTime(),
                                        obs.getAllowance(),
                                        obs.getSlack(),
                                        obs.getWinq()
                                        };
                                        
        neuralNet.setInput(rowInput);
        neuralNet.calculate();
        double[] networkOutputOne = new double[]{neuralNet.getOutput()[0]};
        resultado=networkOutputOne[0];

        return resultado;
    }

    public void softPolicyUpdate(MultiLayerPerceptron neuralNet, MultiLayerPerceptron targetNet,int replicationID){
        //Só se o dataset for superior a 35 linhas, OK?

        //É preciso definir, ok?
        double learningRate=0.01;
        if(dataset.size()>34){
            DataSet ds=getMiniBatch(neuralNet, targetNet, replicationID);
            //O número de iterações deverá ser apenas 1;
            neuralNet.learn(ds);

            int nLayers=neuralNet.getLayersCount();
            for(int l = 1; l < nLayers; l++){
                int nNeurons=neuralNet.getLayerAt(l).getNeuronsCount();
                for(int n = 0; n < nNeurons; n++){
                    Weight[] weightList=neuralNet.getLayerAt(l).getNeuronAt(n).getWeights();
                    Weight[] weightList2=targetNet.getLayerAt(l).getNeuronAt(n).getWeights();

                    for(int w=0;w<weightList.length;w++){
                        Weight weightTemp=weightList[w];
                        Weight weightTemp2=weightList2[w];
                        double weightvalue=GlobalParameters.WEIGHT_UPDATE*weightTemp.getValue()+(1-GlobalParameters.WEIGHT_UPDATE)*weightTemp2.getValue();
                        //e preciso escolher o peso da network certa
                        weightTemp2.setValue(weightvalue);
                    }
                }
            }


        }
    }

}