package RL;

import java.util.Random;

import java.util.ArrayList;
//import java.util.List.
import java.util.List;
import java.util.Scanner;
//import java.util.stream.IntStream;
import java.util.Collections;
//import java.util.Iterator;
//import com.github.lwhite1.tablesaw.*;
//import com.github.lwhite1.tablesaw.api.*;
import java.io.*;
//import java.util.List;
import utils.Utils;

import org.deeplearning4j.nn.api.OptimizationAlgorithm;
//import org.deeplearning4j.nn.conf.graph.MergeVertex;
import org.deeplearning4j.nn.conf.layers.DenseLayer;
import org.deeplearning4j.nn.conf.layers.OutputLayer;
import org.deeplearning4j.nn.conf.NeuralNetConfiguration;
//import org.deeplearning4j.nn.conf.ComputationGraphConfiguration;
import org.deeplearning4j.nn.conf.MultiLayerConfiguration;
//import org.deeplearning4j.nn.conf.Updater;
//import org.deeplearning4j.nn.graph.ComputationGraph;
import org.deeplearning4j.nn.multilayer.MultiLayerNetwork;
import org.deeplearning4j.nn.weights.WeightInit;
import org.nd4j.linalg.activations.Activation;
import org.nd4j.linalg.learning.config.AdaGrad;
import org.nd4j.linalg.lossfunctions.LossFunctions;

import org.neuroph.nnet.MultiLayerPerceptron;
import org.neuroph.util.TransferFunctionType;

import main.GlobalParameters;

import org.neuroph.nnet.learning.MomentumBackpropagation;
import org.neuroph.nnet.learning.BackPropagation;
import org.neuroph.nnet.learning.ResilientPropagation;
import org.neuroph.core.Weight;
import org.neuroph.core.data.DataSet;
import org.neuroph.core.data.DataSetRow;
//import org.neuroph.core.transfer.TransferFunction;
import org.neuroph.core.transfer.Linear;
import org.neuroph.core.transfer.RectifiedLinear;
import org.neuroph.core.events.LearningEvent;
import org.neuroph.core.events.LearningEventListener;

import org.json.simple.JsonObject;
import org.json.simple.Jsoner;
import org.json.simple.DeserializationException;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.math.BigDecimal;

// Q Table RL


public class RLagent{
    List<Observation> dataset;
    List<Observation> episodeDataset;
    MultiLayerNetwork net;
    double[][][][][][][][] qTable;

    public RLagent(){
        System.out.println("AGENTE RL INICIADO");
        dataset=new ArrayList<Observation>();
        episodeDataset=new ArrayList<Observation>();
        qTable=new double[5][5][5][5][5][5][5][6];
        randomizeQTable();
    }

    public void addObservation(Observation obs) {
        if(dataset.size()>=1000){
            dataset.remove(0);
        }        
        dataset.add(obs);
        //episodeDataset.add(obs);
	}

    public void addObservationEpisodeSet(Observation obs) {
        episodeDataset.add(obs);
	}

    public void clearDataset(){
        this.dataset.clear();
    }

    public void clearEpisodeDataset(){
        this.episodeDataset.clear();
    }

    public double[] getActionFrequencies(){
        double[] frequencias={0.0,0.0,0.0,0.0,0.0,0.0};
        double contador=0.0;

        for(Observation obs: episodeDataset){
            if(obs.getRandomStatus()==0.0){
                int temp=(int) obs.getAction();
                if(temp!=0){
                    frequencias[temp-1]=frequencias[temp-1]+1;
                    contador=contador+1;
                }

            }
        }

        for (int i = 0; i < frequencias.length; i++) {
            frequencias[i]=frequencias[i]/contador;
        }
        return frequencias;
    }

    public void setPreviousObservation(Observation obs){
        if(dataset.size()>1){
            Observation previousState   =   dataset.get(dataset.size()-2);
            previousState.setPreviousState(obs.getMachineUtilisationMean(), obs.getMachineUtilisationSD(), obs.getOperationsRate(), obs.getJobsRateMean(), obs.getJobsRateSD(), obs.getEstimatedTardiness(), obs.getActualTardiness());
        }
    }

    public void setAction(double action){
        if(!GlobalParameters.ONLINE_MODE){
            Observation currentState    =   dataset.get(dataset.size()-1);
            currentState.setAction(action);
        }
        else{      
            Observation currentState    =   episodeDataset.get(dataset.size()-1);
            currentState.setAction(action);}

    }

    
    public void dumpData() throws IOException{
        String fileName="dataset.txt";
        BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true));

        for (Observation obs : dataset) {
            //System.out.println("Next item: " + s[0]);
            String str=obs.toString();
            writer.append(str);
            writer.newLine();
         }
            
        writer.close();       
    }

    public void dumpEpisodeData() throws IOException{
        String fileName="";
        if(!GlobalParameters.ONLINE_MODE){
            fileName="episodeDataset.txt";
        }
        else{
            fileName="./test/episodeDataset.txt";
        }
        
        BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true));

        for (Observation obs : episodeDataset) {
            //System.out.println("Next item: " + s[0]);
            String str=obs.toString();
            int[] index=idx(obs);
            writer.append(str+";"+index[0]+";"+index[1]+";"+index[2]+";"+index[3]+";"+index[4]+";"+index[5]+";"+index[6]);
            writer.newLine();
         }
            
        writer.close();       
    }

    public void dumpActionFrequencies() throws IOException{
        if(episodeDataset.size()>0){
            String fileName="";
            if(!GlobalParameters.ONLINE_MODE){
                fileName="actionFrequencies.txt";
            }
            else{
                fileName="./test/actionFrequencies.txt";
            }
            BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true));

            double[] frequencies=getActionFrequencies();
            writer.append(String.valueOf(frequencies[0])+";"+String.valueOf(frequencies[1])+";"+String.valueOf(frequencies[2])+";"+String.valueOf(frequencies[3])+";"+String.valueOf(frequencies[4])+";"+String.valueOf(frequencies[5]));
            writer.newLine();
            System.out.println("Frequencia das acoes");
            System.out.println(String.valueOf(frequencies[0])+";"+String.valueOf(frequencies[1])+";"+String.valueOf(frequencies[2])+";"+String.valueOf(frequencies[3])+";"+String.valueOf(frequencies[4])+";"+String.valueOf(frequencies[5]));
            writer.close();
        }       
    }

    public void dumpQTable(int id) throws IOException{
        String fileName="";
        if(!GlobalParameters.ONLINE_MODE){
            fileName="qTable"+id+".txt";
        }
        else{
            fileName="./test/qTable"+id+".txt";
        }
        BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, false));
        for(int f1=0;f1<=4;f1++){
            for(int f2=0;f2<=4;f2++){
                for(int f3=0;f3<=4;f3++){
                    for(int f4=0;f4<=4;f4++){
                        for(int f5=0;f5<=4;f5++){
                            for(int f6=0;f6<=4;f6++){
                                for(int f7=0;f7<=4;f7++){
                                    for(int a=1;a<=6;a++){
                                        int[] index=new int[]{f1,f2,f3,f4,f5,f6,f7};
                                        writer.append(f1+";"+f2+";"+f3+";"+f4+";"+f5+";"+f6+";"+f7+";"+a+";"+String.valueOf(getQValuesbyAction(index,a)));
                                        writer.newLine();
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        writer.close();
    }

    public void loadQTable() throws FileNotFoundException{

        Scanner read = new Scanner (new File("qTable.txt"));
        //read.useDelimiter(";");
        String f1, f2, f3, f4, f5, f6, f7, a,val;

        while(read.hasNextLine()){
            String str=read.nextLine();
            Scanner sc = new Scanner(str);
            sc.useDelimiter(";");
            while (sc.hasNext()){
                f1 = sc.next();
                f2 = sc.next();
                f3 = sc.next();
                f4 = sc.next();
                f5 = sc.next();
                f6=sc.next();
                f7=sc.next();
                a=sc.next();
                val=sc.next();

                int[] index=new int[]{Integer.valueOf(f1),Integer.valueOf(f2),Integer.valueOf(f3),Integer.valueOf(f4),Integer.valueOf(f5),Integer.valueOf(f6),Integer.valueOf(f7)};

                setQValues(index, Integer.valueOf(a), Double.valueOf(val));
            }
            sc.close();
        }
        read.close();
    }

    public void dumpWeights(MultiLayerPerceptron neuralNet,String type) throws IOException{
        int controlo=0;
        JsonObject obj = new JsonObject();
        int nLayers=neuralNet.getLayersCount();
        for(int l = 1; l < nLayers; l++){
            int nNeurons=neuralNet.getLayerAt(l).getNeuronsCount();
            for(int n = 0; n < nNeurons; n++){
                Weight[] weightList=neuralNet.getLayerAt(l).getNeuronAt(n).getWeights();
                //Weight[] weightList2=targetNet.getLayerAt(l).getNeuronAt(n).getWeights();

                for(int w=0;w<weightList.length;w++){
                    controlo=controlo+1;
                    Weight weightTemp=weightList[w];
                    //Weight weightTemp2=weightList2[w];
                    double weightvalue=weightTemp.getValue();
                    obj.put(String.valueOf(controlo),Double.toString(weightvalue));     
                    
                }
            }
        }

        try (FileWriter file = new FileWriter(type+".json")) {
            file.write(obj.toJson());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void loadWeights(MultiLayerPerceptron neuralNet,String type){
        JSONParser parser = new JSONParser();
        try (Reader reader = new FileReader(type+".json")) {
            //JsonObject jsonObject = (JsonObject) Jsoner.deserialize(type+".json");
            //JsonObject jsonObject = (JsonObject) parser.parse(reader);
            JsonObject jsonObject = (JsonObject) Jsoner.deserialize(reader);     

            int controlo=0;
            int nLayers=neuralNet.getLayersCount();
            for(int l = 1; l < nLayers; l++){
                int nNeurons=neuralNet.getLayerAt(l).getNeuronsCount();
                for(int n = 0; n < nNeurons; n++){
                    Weight[] weightList=neuralNet.getLayerAt(l).getNeuronAt(n).getWeights();
                    for(int w=0;w<weightList.length;w++){
                        controlo=controlo+1;
                        Weight weightTemp=weightList[w];
                        String temp = (String) jsonObject.get(String.valueOf(controlo));
                        double weight=Double.parseDouble(temp); 
                        weightTemp.setValue(weight);  
                        
                    }
                }
            }


        } catch (IOException e) {
            e.printStackTrace();
        }
        // catch (ParseException e) {
        //     e.printStackTrace();
        // }
        catch (DeserializationException e) {
            throw new RuntimeException("Can't deserialize JSON", e);
        }
    }

    public void loadDataset() throws FileNotFoundException{

        Scanner read = new Scanner (new File("episodeDataset.txt"));
        //read.useDelimiter(";");
        String iterationTemp, timestampTemp, machineUtilisationMean, machineUtilisationSD, operationsRate, jobsRateMean, jobsRateSD, estimatedTard,actualTard,action,actionStatus,reward,machineUtilisationMean2,machineUtilisationSD2,operationsRate2, jobsRateMean2,jobsrateSD2,estimatedTard2,actualTard2;

        while(read.hasNextLine()){
            String str=read.nextLine();
            Scanner sc = new Scanner(str);
            sc.useDelimiter(";");
            while (sc.hasNext()){
                iterationTemp = sc.next();
                timestampTemp = sc.next();
                machineUtilisationMean = sc.next();
                machineUtilisationSD = sc.next();
                operationsRate = sc.next();
                jobsRateMean=sc.next();
                jobsRateSD=sc.next();
                estimatedTard=sc.next();
                actualTard=sc.next();
                action=sc.next();
                actionStatus=sc.next();
                reward=sc.next();
                machineUtilisationMean2=sc.next();
                machineUtilisationSD2=sc.next();
                operationsRate2=sc.next();
                jobsRateMean2=sc.next();
                jobsrateSD2=sc.next();
                estimatedTard2=sc.next();
                actualTard2=sc.next();

                //System.out.println(iterationTemp + " " + timestampTemp + " " + machineUtilisationMean + " " +machineUtilisationSD + " " + operationsRate+ " " + jobsRateMean+ " " + jobsRateSD+ " " + estimatedTard+ " " + actualTard+ " " + action+ " " + reward+ " " + machineUtilisationMean2+ " " + machineUtilisationSD2+ " " + operationsRate2+ " " + jobsRateMean2+ " " + jobsrateSD2+ " " + estimatedTard2+ " " + actualTard2); // just for debugging
                Observation obs =new Observation(Double.valueOf(timestampTemp));
                obs.setIteration(Integer.valueOf(iterationTemp));
                obs.setMachineUtilisation(Double.valueOf(machineUtilisationMean), Double.valueOf(machineUtilisationSD));
                obs.setOperationsRate(Double.valueOf(operationsRate));
                obs.setJobsRate(Double.valueOf(jobsRateMean),Double.valueOf(jobsRateSD));
                obs.setTardiness(Double.valueOf(estimatedTard), Double.valueOf(actualTard));
                obs.setAction(Double.valueOf(action));
                obs.setRandomStatus(Double.valueOf(actionStatus));
                obs.setReward(Double.valueOf(reward));
                obs.setPreviousState(Double.valueOf(machineUtilisationMean2), Double.valueOf(machineUtilisationSD2), Double.valueOf(operationsRate2), Double.valueOf(jobsRateMean2), Double.valueOf(jobsrateSD2), Double.valueOf(estimatedTard2), Double.valueOf(actualTard2));
                addObservation(obs);
            }
            sc.close();
        }
        read.close();
    }

    public void computeReward(){
        double reward=0.0;
        if(dataset.size()>=2){
            Observation previousState   =   dataset.get(dataset.size()-2);
            Observation currentState    =   dataset.get(dataset.size()-1);
            
            if(currentState.getActualTardiness()<previousState.getActualTardiness()){
                reward=1.0;
            }
            else{
                if(currentState.getActualTardiness()>previousState.getActualTardiness()){
                    reward=-1.0;
                }
                else{
                    if(currentState.getEstimatedTardiness()<previousState.getEstimatedTardiness()){
                        reward=1.0;
                    }
                    else{
                        if(currentState.getEstimatedTardiness()>previousState.getEstimatedTardiness()){
                            reward=-1.0;
                        }
                        else{
                            if(currentState.getMachineUtilisationMean()>previousState.getMachineUtilisationMean()){
                                reward=1.0;                                
                            }
                            else{
                                if(currentState.getMachineUtilisationMean()>0.95*previousState.getMachineUtilisationMean()){
                                    reward=0;
                                }
                                else{
                                    reward=-1.0;
                                }
                            }
                        }
                    }
                }
            }
            reward=reward*(-1);
            previousState.setReward(reward);
        }

    }

    public void computeRewardLA(){
        double reward=0.0;
        if(dataset.size()>=27){
            Observation previousState   =   dataset.get(dataset.size()-1-26);
            Observation currentState    =   dataset.get(dataset.size()-1);
            
            if(currentState.getActualTardiness()<previousState.getActualTardiness()){
                reward=1.0;
            }
            else{
                if(currentState.getActualTardiness()>previousState.getActualTardiness()){
                    reward=-1.0;
                }
                else{
                    if(currentState.getEstimatedTardiness()<previousState.getEstimatedTardiness()){
                        reward=1.0;
                    }
                    else{
                        if(currentState.getEstimatedTardiness()>previousState.getEstimatedTardiness()){
                            reward=-1.0;
                        }
                        else{
                            if(currentState.getMachineUtilisationMean()>previousState.getMachineUtilisationMean()){
                                reward=1.0;                                
                            }
                            else{
                                if(currentState.getMachineUtilisationMean()>0.95*previousState.getMachineUtilisationMean()){
                                    reward=0;
                                }
                                else{
                                    reward=-1.0;
                                }
                            }
                        }
                    }
                }
            }
            previousState.setReward(reward);
        }

    }

    public MultiLayerNetwork inititializeNNModelDeprecated(){
        
        //É preciso DEFINIR
        //int NB_INPUTS = 86;
        //int NB_EPOCHS = 10;
        //int RANDOM_SEED = 1234;
        //double LEARNING_RATE = 0.005;
        //int BATCH_SIZE = 32;
        //int LSTM_LAYER_SIZE = 200;
        //int NUM_LABEL_CLASSES = 2;

        MultiLayerConfiguration conf = new NeuralNetConfiguration.Builder()
        .seed(12345)
        .weightInit(WeightInit.XAVIER)
        .updater(new AdaGrad(0.5))
        .activation(Activation.RELU)
        .optimizationAlgo(OptimizationAlgorithm.STOCHASTIC_GRADIENT_DESCENT)
        .l2(0.0001)
        .list()
        //First hidden layer
        .layer(0, new DenseLayer.Builder()
                .nIn(2).nOut(30)
                .weightInit(WeightInit.XAVIER)
                .activation(Activation.RELU) 
                .build())
        //Second hidden layer
        .layer(1, new DenseLayer.Builder()
                .nIn(30).nOut(30)
                .weightInit(WeightInit.XAVIER)
                .activation(Activation.RELU) 
                .build())
        //Third hidden layer
        .layer(2, new DenseLayer.Builder()
                .nIn(30).nOut(30)
                .weightInit(WeightInit.XAVIER)
                .activation(Activation.RELU)
                .build())
        //Output layer
        .layer(3, new OutputLayer.Builder()
                .nIn(30).nOut(1)
                .weightInit(WeightInit.XAVIER)
                //a softmax não vai funcionar ahah
                .activation(Activation.SOFTMAX) 
                .lossFunction(LossFunctions.LossFunction.NEGATIVELOGLIKELIHOOD)
                .build())
        .build();
        

        MultiLayerNetwork net = new MultiLayerNetwork(conf);
        return net;
    
    }

    public MultiLayerPerceptron initializeNetwork(String type){
        MultiLayerPerceptron neuralNet = new MultiLayerPerceptron(TransferFunctionType.TANH, 7, 30,30,30,30,30,6);
                
        //MomentumBackpropagation learningRule = (MomentumBackpropagation) neuralNet.getLearningRule();
        //learningRule.setLearningRate(0.5);
        //learningRule.setMomentum(0.8);
        if(GlobalParameters.LOAD_WEIGHTS){
            if(type=="target"){
                loadWeights(neuralNet,"target");
            }
            else if (type=="online"){
                loadWeights(neuralNet,"online");
            }
            else{
                System.out.println("ERRO: os pesos nao foram carregados");
                neuralNet.randomizeWeights();
            }
        }
        else{neuralNet.randomizeWeights();}
        

        // RectifiedLinear ln0=new RectifiedLinear();
        // RectifiedLinear ln1=new RectifiedLinear();
        // RectifiedLinear ln2=new RectifiedLinear();
        // RectifiedLinear ln3=new RectifiedLinear();
        // RectifiedLinear ln4=new RectifiedLinear();
        // RectifiedLinear ln5=new RectifiedLinear();

        Linear ln0=new Linear();
        Linear ln1=new Linear();
        Linear ln2=new Linear();
        Linear ln3=new Linear();
        Linear ln4=new Linear();
        Linear ln5=new Linear();

        neuralNet.getLayerAt(6).getNeuronAt(0).setTransferFunction(ln0);
        neuralNet.getLayerAt(6).getNeuronAt(1).setTransferFunction(ln1);
        neuralNet.getLayerAt(6).getNeuronAt(2).setTransferFunction(ln2);
        neuralNet.getLayerAt(6).getNeuronAt(3).setTransferFunction(ln3);
        neuralNet.getLayerAt(6).getNeuronAt(4).setTransferFunction(ln4);
        neuralNet.getLayerAt(6).getNeuronAt(5).setTransferFunction(ln5);

        MomentumBackpropagation learningRule = (MomentumBackpropagation) neuralNet.getLearningRule();

        learningRule.setLearningRate(0.005);
        learningRule.setMomentum(0.001);
        learningRule.setMaxError(0.0001);
        learningRule.setMaxIterations(1);
        //learningRule.setBatchMode(false);


        BackPropagation rbackprop=new ResilientPropagation();
        rbackprop.setMaxError(0.001);
        rbackprop.setMaxIterations(1);
        rbackprop.setLearningRate(0.2);
        //rbackprop.setBatchMode(false);
        

        //add learning listener in order to print out training info
        if(GlobalParameters.VERBOSE){
            learningRule.addListener(new LearningEventListener() {
                @Override
                public void handleLearningEvent(LearningEvent event) {
                    BackPropagation bp = (BackPropagation) event.getSource();
                    if (event.getEventType().equals(LearningEvent.Type.LEARNING_STOPPED)) {
                        //System.out.println();
                        //System.out.println("Training completed in " + bp.getCurrentIteration() + " iterations");
                        //System.out.println("With total error " + bp.getTotalNetworkError() + '\n');
                        System.out.println("Iteration: " + bp.getCurrentIteration() + " | Network error: " + bp.getTotalNetworkError());
                    } else {
                        System.out.println("Iteration: " + bp.getCurrentIteration() + " | Network error: " + bp.getTotalNetworkError());
                    }
                }
            });
        }

        //neuralNet.setLearningRule(rbackprop);
        return neuralNet;
    }

    public void synchronizeWeights(MultiLayerPerceptron neuralNet, MultiLayerPerceptron targetNet){
        int nLayers=neuralNet.getLayersCount();
            for(int l = 1; l < nLayers; l++){
                int nNeurons=neuralNet.getLayerAt(l).getNeuronsCount();
                for(int n = 0; n < nNeurons; n++){
                    Weight[] weightList=neuralNet.getLayerAt(l).getNeuronAt(n).getWeights();
                    Weight[] weightList2=targetNet.getLayerAt(l).getNeuronAt(n).getWeights();

                    for(int w=0;w<weightList.length;w++){
                        Weight weightTemp=weightList[w];
                        Weight weightTemp2=weightList2[w];
                        double weightvalue=weightTemp.getValue();
                        //è preciso escolher o peso da network certa
                        weightTemp2.setValue(weightvalue);
                    }
                }
            }

    }

    public DataSet getTrainingSet(MultiLayerPerceptron neuralNet, int replicationID){
        DataSet ds = new DataSet(7, 6);
        
        ArrayList<Integer> a = new ArrayList<>(dataset.size()-2);
        for (int i = 2; i <= dataset.size()-1; i++){
            //to generate from 0-10 inclusive. 
            //For 0-9 inclusive, remove the = on the <=
            a.add(i);
        }

        Collections.shuffle(a);
        
        //Nota é preciso definir o tamanho do dataset
        int trainingDatasetSize=dataset.size()-2;
        if(trainingDatasetSize>1000){
            trainingDatasetSize=1000;
        }
        for (int i = 0; i <= trainingDatasetSize; i++){
            int temp=a.get(i);
            Observation obs=dataset.get(temp);


            double[] rowInput=new double[]{ obs.getMachineUtilisationMean(),
                                            obs.getMachineUtilisationSD(),
                                            obs.getOperationsRate(),
                                            obs.getJobsRateMean(),
                                            obs.getJobsRateSD(),
                                            obs.getEstimatedTardiness(),
                                            obs.getActualTardiness()};           
            
            neuralNet.setInput(rowInput[0],rowInput[1],rowInput[2],rowInput[3],rowInput[4],rowInput[5],rowInput[6]);
            neuralNet.calculate();
            double[] networkOutputOne = new double[]{neuralNet.getOutput()[0],neuralNet.getOutput()[1],neuralNet.getOutput()[2],neuralNet.getOutput()[3],neuralNet.getOutput()[4],neuralNet.getOutput()[5]};
            
            
            neuralNet.setInput(obs.getFollowingStateAsArray()[0],obs.getFollowingStateAsArray()[1],obs.getFollowingStateAsArray()[2],obs.getFollowingStateAsArray()[3],obs.getFollowingStateAsArray()[4],obs.getFollowingStateAsArray()[5],obs.getFollowingStateAsArray()[6]);
            neuralNet.calculate();
            double[] networkOutputTwo = new double[]{neuralNet.getOutput()[0],neuralNet.getOutput()[1],neuralNet.getOutput()[2],neuralNet.getOutput()[3],neuralNet.getOutput()[4],neuralNet.getOutput()[5]};
            

            int action = (int) obs.getAction();

            if(replicationID==0){
                networkOutputOne[action-1]=obs.getReward();
            }
            else{
                networkOutputOne[action-1]=obs.getReward()+0.8*networkOutputTwo[obs.argmax(networkOutputTwo)];
            }      

            DataSetRow rTemp  = new DataSetRow(rowInput, networkOutputOne);
            ds.add(rTemp);
        }
        
        return ds;
    }

    public void updatePolicy(MultiLayerPerceptron neuralNet, int replicationID){
        DataSet ds=getTrainingSet(neuralNet, replicationID);
        //BackPropagation backPropagation = new BackPropagation();
        //backPropagation.setMaxIterations(5);
        //neuralNet.learn(ds,backPropagation);
        neuralNet.learn(ds);
    }

    public int makePrediction(MultiLayerPerceptron neuralNet, Observation obs){
        double[] rowInput=new double[]{ obs.getMachineUtilisationMean(),
                                        obs.getMachineUtilisationSD(),
                                        obs.getOperationsRate(),
                                        obs.getJobsRateMean(),
                                        obs.getJobsRateSD(),
                                        obs.getEstimatedTardiness(),
                                        obs.getActualTardiness()};           

        neuralNet.setInput(rowInput[0],rowInput[1],rowInput[2],rowInput[3],rowInput[4],rowInput[5],rowInput[6]);
        neuralNet.calculate();
        double[] networkOutputOne = new double[]{neuralNet.getOutput()[0],neuralNet.getOutput()[1],neuralNet.getOutput()[2],neuralNet.getOutput()[3],neuralNet.getOutput()[4],neuralNet.getOutput()[5]};
        
        //System.out.println(String.valueOf(neuralNet.getOutput()[0])+";"+String.valueOf(neuralNet.getOutput()[1])+";"+String.valueOf(neuralNet.getOutput()[2])+";"+String.valueOf(neuralNet.getOutput()[3])+";"+String.valueOf(neuralNet.getOutput()[4])+";"+String.valueOf(neuralNet.getOutput()[5]));
        int action=obs.argmax(networkOutputOne)+1;
        return action;
    }

    public void randomizeQTable() {
        Random rand = new Random();
        for(int f1=0;f1<=4;f1++){
            for(int f2=0;f2<=4;f2++){
                for(int f3=0;f3<=4;f3++){
                    for(int f4=0;f4<=4;f4++){
                        for(int f5=0;f5<=4;f5++){
                            for(int f6=0;f6<=4;f6++){
                                for(int f7=0;f7<=4;f7++){
                                    for(int a=1;a<=6;a++){
                                        int[] index=new int[]{f1,f2,f3,f4,f5,f6,f7};
                                        double rand_dub1 = rand.nextDouble();
                                        setQValues(index, a, rand_dub1*0.001);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    public double[] getQValues(int[] idx){
        double[] resultado=new double[6];
        resultado[0]=qTable[idx[0]][idx[1]][idx[2]][idx[3]][idx[4]][idx[5]][idx[6]][0];
        resultado[1]=qTable[idx[0]][idx[1]][idx[2]][idx[3]][idx[4]][idx[5]][idx[6]][1];
        resultado[2]=qTable[idx[0]][idx[1]][idx[2]][idx[3]][idx[4]][idx[5]][idx[6]][2];
        resultado[3]=qTable[idx[0]][idx[1]][idx[2]][idx[3]][idx[4]][idx[5]][idx[6]][3];
        resultado[4]=qTable[idx[0]][idx[1]][idx[2]][idx[3]][idx[4]][idx[5]][idx[6]][4];
        resultado[5]=qTable[idx[0]][idx[1]][idx[2]][idx[3]][idx[4]][idx[5]][idx[6]][5];
        return resultado;
    }
    public void setQValues(int[] idx,int action,double val){
        qTable[idx[0]][idx[1]][idx[2]][idx[3]][idx[4]][idx[5]][idx[6]][action-1]=val;
    }

    public double getQValuesbyAction(int[] idx,int action){
        double resultado=qTable[idx[0]][idx[1]][idx[2]][idx[3]][idx[4]][idx[5]][idx[6]][action-1];
        return resultado;
    }

    public int makePredictionQTable(int[] idx){
        double[] qValues=getQValues(idx);
        int action=Utils.argmax(qValues)+1;
        return action;
    }

    public void updateQtable(int[] indexCS){

        if(dataset.size()>=2){
            double alfa=0.6;
            double gamma=0.5;

            Observation previousState   =   dataset.get(dataset.size()-2);
            Observation currentState    =   dataset.get(dataset.size()-1);

            double reward=previousState.getReward();

            int[] indexPS=idx(previousState);
            double qValue=getQValuesbyAction(indexPS, (int) previousState.getAction());

            double qValue2=0.0;
            
            if(currentState.getRandomStatus()==1.0){
                int bestAction=makePredictionQTable(indexCS);
                qValue2=getQValuesbyAction(indexCS, bestAction);
            }
            else{
                qValue2=getQValuesbyAction(indexCS, (int) currentState.getAction());
            }

            double resultado=qValue+alfa*(reward+gamma*qValue2-qValue);

            setQValues(indexPS, (int) previousState.getAction(), resultado);

        }
    }

    public void updateQtableLA(int[] indexCS){
        int n=4;
        if(dataset.size()>n){
            double alfa=0.4;
            double gamma=0.6;
            double g = 0.0;
            int iter=0;
            boolean val=true;
            double qValue2=0.0;
            double prob = 1.0;
            Observation currentState;
            Observation previousState;
            currentState    =   dataset.get(dataset.size()-1);
            previousState   =   dataset.get(dataset.size()-n);

            for(int i=n;i>=2;i--){
                Observation obs =dataset.get(dataset.size()-i);
                g=g+Math.pow(gamma,(n-i+1))*obs.getReward();

                //assume que há 10% de ações random
                if(obs.getRandomStatus()==0.0){
                    prob=prob*(1/0.91666);
                }
                else{
                    double actionTaken=obs.getAction();
                    int[] indexObs=idx(obs);
                    double actionShouldTake=makePredictionQTable(indexObs);
                    if(actionTaken!=actionShouldTake){
                        prob=prob*0;
                    }
                    else{
                        prob=prob*(1/0.91666);
                    }
                }

                if(i==n){
                    iter=obs.getIteration();                    
                }
                else{
                    val= iter==obs.getIteration() ? true : false;
                    if(!val||prob==0.0){break;}
                }
            }

            if(val && currentState.getIteration()==iter && prob>0.0){
                qValue2=getQValuesbyAction(indexCS, (int) currentState.getAction());
                g=g+Math.pow(gamma,n)*qValue2;

                int[] indexPS=idx(previousState);
                double qValue=getQValuesbyAction(indexPS, (int) previousState.getAction());
                double resultado=qValue+alfa*(g-qValue);
                setQValues(indexPS, (int) previousState.getAction(), resultado);              
            }
        }
    }

    public int[] idx(Observation obs){
		int[] index=new int[7];
		// index[0]=group(obs.getMachineUtilisationMean(),"m");
		// index[1]=group(obs.getMachineUtilisationSD(),"m");
		// index[2]=group(obs.getOperationsRate(),"s");
		// index[3]=group(obs.getJobsRateMean(),"s");
		// index[4]=group(obs.getJobsRateSD(),"a");
		// index[5]=group(obs.getEstimatedTardiness(),"s");
		// index[6]=group(obs.getActualTardiness(),"s");

        index[0]=groupFJS(obs.getMachineUtilisationMean(),"mu");
		index[1]=groupFJS(obs.getMachineUtilisationSD(),"m2.5");
		index[2]=groupFJS(obs.getOperationsRate(),"s");
		index[3]=groupFJS(obs.getJobsRateMean(),"s");
		index[4]=groupFJS(obs.getJobsRateSD(),"m3");
		index[5]=groupFJS(obs.getEstimatedTardiness(),"m6");
		index[6]=groupFJS(obs.getActualTardiness(),"m4");

		return index;
	}

	public int group(double val,String type){
		int resultado=0;
        if(type=="s"|| type=="m"){
            if(type=="m"){
                val=val*10;
            }
            if(val>=0.0 && val<0.20){
                resultado=0;
            }
            if(val>=0.2 && val<0.40){
                resultado=1;
            }
            if(val>=0.4 && val<0.60){
                resultado=2;
            }
            if(val>=0.6 && val<0.80){
                resultado=3;
            }
            if(val>=0.8 && val<=1){
                resultado=4;
            }
            if(val>1){
                resultado=4;
                //System.out.println("Um estado excede 1");
            }
        }
        if(type=="a"){
            if(val>=0.0 && val<0.10){
                resultado=0;
            }
            if(val>=0.1 && val<0.20){
                resultado=1;
            }
            if(val>=0.2 && val<0.30){
                resultado=2;
            }
            if(val>=0.3 && val<0.40){
                resultado=3;
            }
            if(val>=0.4 && val<=1){
                resultado=4;
            }
            if(val>1){
                resultado=4;
                //System.out.println("Um estado excede 1");
            }
        }
		
		return resultado;

	}

    public int groupAlt(double val,String type){
        int resultado=0;
    
        if(type=="m3"){
            val=val*3.333;
        }
        if(type=="m4"){
            val=val*2.500;
        }
        if(type=="m6"){
            val=val*1.425;
        }
        if(type=="mu"){
            val=val*3.333-2.0;
        }
        if(type=="m2.5"){
            val=val*4;
        }


        if(val<0.20){
            resultado=0;
        }
        if(val>=0.2 && val<0.40){
            resultado=1;
        }
        if(val>=0.4 && val<0.60){
            resultado=2;
        }
        if(val>=0.6 && val<0.80){
            resultado=3;
        }
        if(val>=0.8 && val<=1){
            resultado=4;
        }
        if(val>1){
            resultado=4;
            //System.out.println("Um estado excede 1");
        }
    
    
        return resultado;

	}

    public int groupFJS(double val,String type){
        int resultado=0;

        switch(type){
            case "mu":
                val=val*3.333-2.0;
                break;
            case "m2.5":
                val=val*4;
                break;
            case"m3":
                val=val*3.333;
                break;
            case "m4":
                val=val*2.500;
                break;
            case "m6":
                val=val*1.425;
                break;
        }

        if(val<0.20){
            resultado=0;
        }
        else if(val>=0.2 && val<0.40){
            resultado=1;
        }
        else if(val>=0.4 && val<0.60){
            resultado=2;
        }
        else if(val>=0.6 && val<0.80){
            resultado=3;
        }
        else if(val>=0.8 && val<=1){
            resultado=4;
        }
        else{
            resultado=4;
            //System.out.println("Um estado excede 1");
        }    
        return resultado;

	}

    public DataSet getMiniBatch(MultiLayerPerceptron neuralNet, MultiLayerPerceptron targetNet,int replicationID){
        DataSet ds = new DataSet(7, 6);
        
        ArrayList<Integer> a = new ArrayList<>(dataset.size()-2);
        for (int i = 2; i <= dataset.size()-1; i++){
            //to generate from 0-10 inclusive. 
            //For 0-9 inclusive, remove the = on the <=
            a.add(i);
        }

        Collections.shuffle(a);
        
        //Nota é preciso definir o tamanho do dataset
        int miniBatchSize=32;

        for (int i = 0; i <= miniBatchSize-1; i++){
            int temp=a.get(i);
            Observation obs=dataset.get(temp);


            double[] rowInput=new double[]{ obs.getMachineUtilisationMean(),
                                            obs.getMachineUtilisationSD(),
                                            obs.getOperationsRate(),
                                            obs.getJobsRateMean(),
                                            obs.getJobsRateSD(),
                                            obs.getEstimatedTardiness(),
                                            obs.getActualTardiness()};           
            
            neuralNet.setInput(rowInput[0],rowInput[1],rowInput[2],rowInput[3],rowInput[4],rowInput[5],rowInput[6]);
            neuralNet.calculate();
            double[] networkOutputOne = new double[]{neuralNet.getOutput()[0],neuralNet.getOutput()[1],neuralNet.getOutput()[2],neuralNet.getOutput()[3],neuralNet.getOutput()[4],neuralNet.getOutput()[5]};
            //System.out.print(String.valueOf(neuralNet.getOutput()[0])+"; "+String.valueOf(neuralNet.getOutput()[1])+"; "+String.valueOf(neuralNet.getOutput()[2])+"; "+String.valueOf(neuralNet.getOutput()[3])+"; "+String.valueOf(neuralNet.getOutput()[4])+"; "+String.valueOf(neuralNet.getOutput()[5]));
            //Ação que maximiza o Q value do st+1, de acordo com Q
            double[] followingState=obs.getFollowingStateAsArray();
            neuralNet.setInput(followingState[0],followingState[1],followingState[2],followingState[3],followingState[4],followingState[5],followingState[6]);
            neuralNet.calculate();
            double[] networkOutputTwo = new double[]{neuralNet.getOutput()[0],neuralNet.getOutput()[1],neuralNet.getOutput()[2],neuralNet.getOutput()[3],neuralNet.getOutput()[4],neuralNet.getOutput()[5]};
            int action2=obs.argmax(networkOutputTwo)+1;

            //Q value da politica Q^, do estado seguinte
            targetNet.setInput(followingState[0],followingState[1],followingState[2],followingState[3],followingState[4],followingState[5],followingState[6]);
            targetNet.calculate();
            double[] networkOutputThree = new double[]{targetNet.getOutput()[0],targetNet.getOutput()[1],targetNet.getOutput()[2],targetNet.getOutput()[3],targetNet.getOutput()[4],targetNet.getOutput()[5]};
            double qvalue= networkOutputThree[action2-1];

            int action = (int) obs.getAction();

            // if(replicationID==0){
            //     networkOutputOne[action-1]=obs.getReward();
            // }
            // else{
            //     networkOutputOne[action-1]=obs.getReward()+0.8*networkOutputTwo[obs.argmax(networkOutputTwo)];
            // }
            
            networkOutputOne[action-1]=obs.getReward()+GlobalParameters.DISCOUNT_FACTOR*qvalue;

            DataSetRow rTemp  = new DataSetRow(rowInput, networkOutputOne);
            ds.add(rTemp);
        }
        
        return ds;
    }

    public void softPolicyUpdate(MultiLayerPerceptron neuralNet, MultiLayerPerceptron targetNet,int replicationID){
        //so se o dataset for superior a 35 linhas

        //e preciso definir
        double learningRate=GlobalParameters.WEIGHT_UPDATE;
        if(dataset.size()>34){
            DataSet ds=getMiniBatch(neuralNet, targetNet, replicationID);
            //O numero de iterações devera ser apenas 1;
            neuralNet.learn(ds);

            int nLayers=neuralNet.getLayersCount();
            for(int l = 1; l < nLayers; l++){
                int nNeurons=neuralNet.getLayerAt(l).getNeuronsCount();
                for(int n = 0; n < nNeurons; n++){
                    Weight[] weightList=neuralNet.getLayerAt(l).getNeuronAt(n).getWeights();
                    Weight[] weightList2=targetNet.getLayerAt(l).getNeuronAt(n).getWeights();

                    for(int w=0;w<weightList.length;w++){
                        Weight weightTemp=weightList[w];
                        Weight weightTemp2=weightList2[w];
                        double weightvalue=learningRate*weightTemp.getValue()+(1-learningRate)*weightTemp2.getValue();
                        //e preciso escolher o peso da network certa
                        weightTemp2.setValue(weightvalue);
                    }
                }
            }


        }
    }

    public void endOfEpisodeUpdate(MultiLayerPerceptron neuralNet, MultiLayerPerceptron targetNet,int replicationID){
        int numberOfEpochs=100;

        ArrayList<Integer> a = new ArrayList<>(dataset.size()-2);
        for (int i = 2; i <= dataset.size()-1; i++){
            //to generate from 0-10 inclusive. 
            //For 0-9 inclusive, remove the = on the <=
            a.add(i);
        }        

        for(int e=0;e<numberOfEpochs;e++){
            Collections.shuffle(a);
            for(int b=0;b<30;b++){
                DataSet ds=new DataSet(7,6);
                for (int i = 30*b+1; i <= 30*(b+1); i++){
                    
                    int temp=a.get(i);
                    Observation obs=dataset.get(temp);
        
        
                    double[] rowInput=new double[]{ obs.getMachineUtilisationMean(),
                                                    obs.getMachineUtilisationSD(),
                                                    obs.getOperationsRate(),
                                                    obs.getJobsRateMean(),
                                                    obs.getJobsRateSD(),
                                                    obs.getEstimatedTardiness(),
                                                    obs.getActualTardiness()};           
                    
                    neuralNet.setInput(rowInput[0],rowInput[1],rowInput[2],rowInput[3],rowInput[4],rowInput[5],rowInput[6]);
                    neuralNet.calculate();
                    double[] networkOutputOne = new double[]{neuralNet.getOutput()[0],neuralNet.getOutput()[1],neuralNet.getOutput()[2],neuralNet.getOutput()[3],neuralNet.getOutput()[4],neuralNet.getOutput()[5]};
                    //System.out.print(String.valueOf(neuralNet.getOutput()[0])+"; "+String.valueOf(neuralNet.getOutput()[1])+"; "+String.valueOf(neuralNet.getOutput()[2])+"; "+String.valueOf(neuralNet.getOutput()[3])+"; "+String.valueOf(neuralNet.getOutput()[4])+"; "+String.valueOf(neuralNet.getOutput()[5]));
                    //Ação que maximiza o Q value do st+1, de acordo com Q
                    double[] followingState=obs.getFollowingStateAsArray();
                    neuralNet.setInput(followingState[0],followingState[1],followingState[2],followingState[3],followingState[4],followingState[5],followingState[6]);
                    neuralNet.calculate();
                    double[] networkOutputTwo = new double[]{neuralNet.getOutput()[0],neuralNet.getOutput()[1],neuralNet.getOutput()[2],neuralNet.getOutput()[3],neuralNet.getOutput()[4],neuralNet.getOutput()[5]};
                    int action2=obs.argmax(networkOutputTwo)+1;
        
                    //Q value da politica Q^, do estado seguinte
                    targetNet.setInput(followingState[0],followingState[1],followingState[2],followingState[3],followingState[4],followingState[5],followingState[6]);
                    targetNet.calculate();
                    double[] networkOutputThree = new double[]{targetNet.getOutput()[0],targetNet.getOutput()[1],targetNet.getOutput()[2],targetNet.getOutput()[3],targetNet.getOutput()[4],targetNet.getOutput()[5]};
                    double qvalue= networkOutputThree[action2-1];
        
                    int action = (int) obs.getAction();
        
                    // if(replicationID==0){
                    //     networkOutputOne[action-1]=obs.getReward();
                    // }
                    // else{
                    //     networkOutputOne[action-1]=obs.getReward()+0.8*networkOutputTwo[obs.argmax(networkOutputTwo)];
                    // }
                    
                    networkOutputOne[action-1]=obs.getReward()+GlobalParameters.DISCOUNT_FACTOR*qvalue;
        
                    DataSetRow rTemp  = new DataSetRow(rowInput, networkOutputOne);
                    ds.add(rTemp);
                }
                //O número de iterações deverá ser apenas 1;
                neuralNet.learn(ds);
            }
        }       
        
    }

}




   