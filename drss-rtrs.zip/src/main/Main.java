package main;

import input.Instance;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.LineNumberReader;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import org.json.simple.DeserializationException;

import simulator.Simulator;
import utils.Utils;
import utils.Utils.EvaluationType;
import GP.MyGPIndividual;
import GP.MyGPEvolutionState;
import GP.operators.AndNode;
import GP.operators.DivisionNode;
import GP.operators.GreaterThanNode;
import GP.operators.IfNode;
import GP.operators.IfSlackNode;
import GP.operators.LessThanNode;
import GP.operators.MaxNode;
import GP.operators.MinNode;
import GP.operators.MultiplyNode;
import GP.operators.NegativeNode;
import GP.operators.NotNode;
import GP.operators.OrNode;
import GP.operators.PowNode;
import GP.operators.SubtractNode;
import GP.operators.SumNode;
import GP.operators.Pow7Node;
import GP.operators.Pow133Node;
import GP.operators.Pow15Node;
import GP.operators.Pow2Node;
import GP.operators.Pow3Node;
import GP.operators.Pow67Node;
import GP.operators.Pow75Node;
import ec.EvolutionState;
import ec.Evolve;
import ec.Individual;
import ec.gp.GPIndividual;
import ec.gp.koza.KozaFitness;
import ec.simple.SimpleStatistics;
import ec.util.Parameter;
import ec.util.ParameterDatabase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Main {

	public static BufferedWriter fitnessWriter = null;	
	
	public static void    main(String[] args) throws IOException, DeserializationException {
		//databaseConnection();
		//prototipo(args);
		mainGP(args);
	}

	public static void databaseConnection(){
		try (Connection connection = DriverManager.getConnection("jdbc:postgresql://db.fe.up.pt/up201503975", "up201503975", "3Q9J3QZa8")) { 
            //Class.forName("org.postgresql.Driver");
			System.out.println("Connected to PostgreSQL database!");
            Statement statement = connection.createStatement();
            System.out.println("Reading car records...");
            //System.out.printf("%-30.30s  %-30.30s%n", "Model", "Price");
            ResultSet resultSet = statement.executeQuery("SELECT * FROM cars");
            while (resultSet.next()) {
				int carId = resultSet.getInt("id");
         		String  carBrand = resultSet.getString("brand");
				System.out.println(carId+" ; "+carBrand);
            }
			resultSet.close();
      		statement.close();
      		connection.close();
 
        } /*catch (ClassNotFoundException e) {
            System.out.println("PostgreSQL JDBC driver not found.");
            e.printStackTrace();
        }*/ catch (SQLException e) {
            System.out.println("Connection failure.");
            e.printStackTrace();
        }
	}

	public static void mainGP(String[] args) {	

		//Lendo parametros e dados de inst�ncias
		readUserParameters(args);			
		List<Instance> trainingInstances = DataLoader.readTrainingSet();	
		DataLoader.readTrainingBenchmark(trainingInstances);
		
		if(GlobalParameters.TEST_DR){
			GlobalParameters.CVS 					= GlobalParameters.TEST_CVS;
			GlobalParameters.VALIDATION_SET_FILE 	= GlobalParameters.TEST_SET_FILE;
			GlobalParameters.UTILIZATION			= GlobalParameters.TEST_UTILIZATION;
			GlobalParameters.ALLOWANCE_FACTOR 		= GlobalParameters.TEST_ALLOWANCE_FACTOR;
		}
		
		//Inicializa dados auxiliares
		Utils.initializeData();

		GPIndividual bestIndividual = null;
		
		//GP corre com um mecanismo multi-start, em que cada 'iteration' e uma corrida completamente independente.
		//Ao final, o algoritmo retorna o melhor individuo (regra de despacho) de cada rodada
		for(int iteration = 0; iteration < GlobalParameters.ITERATIONS; iteration++)
		{
			try{
				//Inicializacoes necessarias
				EvolutionState state = initializeGP(args, iteration);

				System.out.println("A iniciar a iteracao: " + iteration);
				
				//Start GP!
				state.run(EvolutionState.C_STARTED_FRESH); 				
				GPIndividual bestIteration = (GPIndividual) ((SimpleStatistics)state.statistics).getBestSoFar()[0];
				System.out.println("BEST INDIVIDUAL GP: ");
				bestIteration.printIndividualForHumans(state, 0);
				//Atualiza o melhor individuo ate entao
				bestIndividual = updateBestIndividual(state, bestIteration, bestIndividual);

				//Imprime em ficheiro separado todas as regras presentes na ultima geracao
				printRules(state, bestIndividual, iteration);

				//Finalizacao
				Evolve.cleanup(state);			
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					// Close the writer regardless of what happens...
					fitnessWriter.close();
	
				} catch (Exception e) {
				}
			} 
		}		
		
		//RunSimulator.statisticalTest(bestIndividual);
				
		//Executa o simulador no conjunto de instancias de validacao
		//Apos o treinamento, precisamos descobrir a performance final da regra encontrada (bestIndividual)
		//double performance = RunSimulator.evaluateRule(bestIndividual, false);	
		//System.out.println("Final performance: "+performance);
	}

	public static void prototipo(String[] args) throws IOException, DeserializationException{
		//Lendo parametros e dados de instâncias
		readUserParameters(args);			
		//DataLoader.readTrainingBenchmark(trainingInstances);
		//GPIndividual bestIndividual=null;
		Utils.initializeData();
		System.out.println("A INICIAR PROTOTIPO");	

		RunSimulator.evaluateRuleRL(null, false);
	}

	public static void gpHierTL(String[] args){
		readUserParameters(args);
		
		Utils.initializeData();

		for(int iteration = 0; iteration < GlobalParameters.ITERATIONS; iteration++)
		{
			try{
				//Inicializacoes necessarias
				EvolutionState state = initializeGP(args, iteration);

				System.out.println("A iniciar a iteracao: " + iteration);
				
				//Start GP!
				state.run(EvolutionState.C_STARTED_FRESH); 					
				Evolve.cleanup(state);			
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			finally {
				try {
					// Close the writer regardless of what happens...
					fitnessWriter.close();
				}
				catch (Exception e) {
				}
			} 
		}	
	}
	
	/**
	 * Initializa todas as estruturas de dados necess�rias para correr o GP
	 * @param args
	 * @param iteration
	 * @return
	 * @throws IOException
	 */
	public static EvolutionState initializeGP(String[] args, int iteration) throws IOException{
		
		//Inicializa o ficheiro que armazena o fitness de todos os indiv�duos encontrados
		initializeFitnessOutputFile(iteration);

		//Inicializando o state
		EvolutionState state = Evolve.possiblyRestoreFromCheckpoint(args);		
		ParameterDatabase parameters = Evolve.loadParameterDatabase(args);
		state = Evolve.initialize(parameters, 0);
		
		//A carregar os par�metros especificados pelo usu�rios
		updateParameters(state, args);
		
		Simulator.performanceNormal = new HashMap<MyGPIndividual, Double>();
		Simulator.performanceSmall = new HashMap<MyGPIndividual, Double>();
		Simulator.performanceSimplified = new HashMap<MyGPIndividual, Double>();
		
		return state;
	}
	
	public static void initializeFitnessOutputFile(int iteration) throws IOException{
		
		//Escreve o fitness de todos os individuos a cada gera��o
		if(!GlobalParameters.FITNESSOUTPUT.equals("")){
			String fileName = (GlobalParameters.ITERATIONS > 1)? GlobalParameters.FITNESSOUTPUT+"_"+iteration+".csv":
				GlobalParameters.FITNESSOUTPUT+".csv";
			File instanceFile = new File(fileName);
			fitnessWriter = new BufferedWriter(new FileWriter(instanceFile, false));				
		}		
	}
	
	public static void printRules(EvolutionState state, GPIndividual bestIndividual, int iteration){
		
		File rulesFile = new File(Utils.getExpressionsFileName(iteration));
		// Rules_<gen i>.txt;
		try{
			PrintWriter writer = new PrintWriter(rulesFile);		
			state.population.printPopulation(state, writer);
			writer.close();
		}catch(FileNotFoundException fnfe){
			fnfe.printStackTrace();
		}
		
		File bestRuleFile = new File(Utils.getBestRuleFileName(iteration));
		// BestRule_<gen i>.txt;
		try{
			PrintWriter writer = new PrintWriter(bestRuleFile);			
			bestIndividual.trees[0].printTree(state, writer);
			if(GlobalParameters.CO_EVOLVE){
				bestIndividual.trees[1].printTree(state, writer);
			}

			writer.close();
		}catch(FileNotFoundException fnfe){
			fnfe.printStackTrace();
		}
		
		rulesFile = new File(Utils.getRulesFileName(iteration));
		// RulesSize_<gen i>.csv;
		try{
			PrintWriter writer = new PrintWriter(rulesFile);	
			double fitness = ((KozaFitness)bestIndividual.fitness).standardizedFitness();
			long size = ((GPIndividual)bestIndividual).trees[0].child.atDepth();
			if(GlobalParameters.CO_EVOLVE){
				size += 1 + ((GPIndividual)bestIndividual).trees[1].child.atDepth();
			}
			writer.write(fitness+";"+size+"\n");	
			
			for(Individual ind: state.population.subpops.get(0).individuals){
				
				fitness = ((KozaFitness)ind.fitness).standardizedFitness();
				size = ((GPIndividual)ind).trees[0].child.atDepth();
				if(GlobalParameters.CO_EVOLVE){
					size += 1 + ((GPIndividual)ind).trees[1].child.atDepth();
				}
				writer.write(fitness+";"+size+"\n");					
			}

			writer.close();
		}catch(FileNotFoundException fnfe){
			fnfe.printStackTrace();
		}
	}
	public static void updateParameters(EvolutionState state, String[] args){
		
		String maxGen = "";
		String popSize = "";
		String breed = "";
		String tSize = "";
		
		for(int i=0; i < args.length; i++){
			if(args[i].equals("-maxGen"))
				maxGen = args[i+1];
			if(args[i].equals("-popSize"))
				popSize = args[i+1];
			if(args[i].equals("-breed"))
				breed = args[i+1];		
			if(args[i].equals("-tSize"))
				tSize = args[i+1];		
		}
		
		System.out.println("Max Gen: "+maxGen+" Pop Size: "+popSize);
		
		if(!maxGen.equals("")){			
			state.parameters.set(new Parameter("generations"), maxGen);
		}
		if(!popSize.equals("")){					
			state.parameters.set(new Parameter("pop.subpop.0.size"), popSize);
		}
		if(!breed.equals("")){					
			state.parameters.set(new Parameter("breed.reproduce.source.0"), breed);
		}		
		if(!tSize.equals("")){					
			state.parameters.set(new Parameter("select.tournament.size"), tSize);
			state.parameters.set(new Parameter("select.best.size"), tSize);
		}	
		if(GlobalParameters.GP_SEED > 0){
			for(int i = 0; i < 8;i++)
				state.parameters.set(new Parameter("seed."+i), Integer.toString((i*10+GlobalParameters.GP_SEED*100)));					
		}		
	}
	
	public static GPIndividual updateBestIndividual(EvolutionState state, GPIndividual  bestIndIteration, GPIndividual bestIndividual){
		
		double sizePenalty = Utils.getIndividualSizePenalty(state.numGenerations, state.numGenerations-1);
		
		if(bestIndividual == null)
			bestIndividual = bestIndIteration;
		else{
			double fitness1 = ((KozaFitness)bestIndividual.fitness).standardizedFitness() - sizePenalty*(bestIndividual.size());
			double fitness2 = ((KozaFitness)bestIndIteration.fitness).standardizedFitness() - sizePenalty*(bestIndIteration.size());

			bestIndividual = (fitness2 < fitness1)? bestIndIteration: bestIndividual;
		}		
		return bestIndividual;
	}
	
	public static void readUserParameters(String[] args){
	
		for(int i=0; i < args.length; i++){
			if(args[i].equals("-coevolve"))
				GlobalParameters.CO_EVOLVE = true;	
			if(args[i].equals("-testdr"))
				GlobalParameters.TEST_DR = true;	
			if(args[i].equals("-verbose"))
				GlobalParameters.VERBOSE = true;
			if(args[i].equals("-pen"))
				GlobalParameters.SIZE_PENALTY = Double.valueOf(args[i+1]);			
			if(args[i].equals("-valset"))
				GlobalParameters.VALIDATION_SET_FILE = args[i+1];
			if(args[i].equals("-trainset"))
				GlobalParameters.TRAINING_SET_FILE = args[i+1];		
			if(args[i].equals("-obj"))
				GlobalParameters.OBJECTIVE_FUNCTION = Integer.valueOf(args[i+1]);		
			if(args[i].equals("-fixSeed"))
				GlobalParameters.FIXED_SEED = true;
			if(args[i].equals("-geo"))
				GlobalParameters.GEO_MEAN = true;	
			if(args[i].equals("-nrep"))
				GlobalParameters.REPLICATIONS = Integer.valueOf(args[i+1]);		
			if(args[i].equals("-iterations"))
				GlobalParameters.ITERATIONS = Integer.valueOf(args[i+1]);	
			if(args[i].equals("-i"))
				GlobalParameters.FIXED_INSTANCE = args[i+1];			
			if(args[i].equals("-u"))
				GlobalParameters.FIXED_UTILIZATION = Double.valueOf(args[i+1]);		
			if(args[i].equals("-cv"))
				GlobalParameters.FIXED_CV = Double.valueOf(args[i+1]);	
			if(args[i].equals("-a"))
				GlobalParameters.FIXED_ALLOWANCE = Double.valueOf(args[i+1]);	
			if(args[i].equals("-m"))
				GlobalParameters.FIXED_NMACHINES = Double.valueOf(args[i+1]);				
			if(args[i].equals("-test")){
				GlobalParameters.TEST_NAME = args[i+1];			
			}
			if(args[i].equals("-dir")){
				GlobalParameters.DIRECTORY = args[i+1];
			}
			if(args[i].equals("-outdir"))
				GlobalParameters.OUTPUT_DIR = args[i+1];
			if(args[i].equals("-out"))
				GlobalParameters.OUTPUTFILE = GlobalParameters.OUTPUT_DIR + args[i+1];	
			if(args[i].equals("-fitness"))
				GlobalParameters.FITNESSOUTPUT = GlobalParameters.OUTPUT_DIR + args[i+1];
			if(args[i].equals("-rules"))
				GlobalParameters.OUTPUTFILE_RULES = GlobalParameters.OUTPUT_DIR + args[i+1];	
			if(args[i].equals("-exps"))
				GlobalParameters.OUTPUTFILE_EXPRESSIONS = GlobalParameters.OUTPUT_DIR + args[i+1];	
			if(args[i].equals("-typeeval")){
				if(Integer.parseInt(args[i+1])==1){
					GlobalParameters.TYPE_OF_EVALUATION_TO_USE=EvaluationType.NORMAL;
				}else if(Integer.parseInt(args[i+1])==2){
					GlobalParameters.TYPE_OF_EVALUATION_TO_USE=EvaluationType.SMALL;
				}else
					GlobalParameters.TYPE_OF_EVALUATION_TO_USE=EvaluationType.SIMPLIFIED;
			}
			if(args[i].equals("-GPseed"))
				GlobalParameters.GP_SEED = Integer.valueOf(args[i+1]);
			if(args[i].equals("-nBest"))
				GlobalParameters.N_BEST_FRACTION = Double.valueOf(args[i+1]);	
			if(args[i].equals("-nFull"))
				GlobalParameters.NUMBER_FULL_TRAINING = Integer.valueOf(args[i+1]);	
			if(args[i].equals("-fixPen"))
				GlobalParameters.FIXED_PENALTY = true;
			if(args[i].equals("-loadWeights")){
				GlobalParameters.LOAD_WEIGHTS = true;
				System.out.println("LEITURA DE PESOS ATIVADA");
			}
			if(args[i].equals("-loadQTable")){
				GlobalParameters.LOAD_QTABLE = true;
				System.out.println("LEITURA DA QTABLE ATIVADA");
			}
			if(args[i].equals("-loadDataset")){
				GlobalParameters.LOAD_DATASET = true;
				System.out.println("LEITURA DO DATASET ATIVADA");
			}
			if(args[i].equals("-episodes")){
				GlobalParameters.EPISODES = Integer.valueOf(args[i+1]);
				System.out.println("NUMERO DE EPISODIOS DEFINIDOS PELO UTILIZADOR: "+args[i+1]);
			}

			if(args[i].equals("-benchmarkMode")){
				GlobalParameters.BENCHMARK_MODE = true;
				GlobalParameters.BENCHMARK_RULE = Integer.valueOf(args[i+1]);
				System.out.println("Benchmark ativado: "+args[i+1]);
			}

			if(args[i].equals("-testMode")){
				GlobalParameters.TESTMODE = String.valueOf(args[i+1]);
			}

			if(args[i].equals("-windowLimit")){
				GlobalParameters.WINDOWLIMIT = Integer.valueOf(args[i+1]);
				System.out.println("WINDOW IN FOCUS: "+args[i+1]);
			}

			if(args[i].equals("-windowRule")){
				GlobalParameters.WINDOWRULE = Integer.valueOf(args[i+1]);
				System.out.println("WINDOW RULE: "+args[i+1]);
			}

			if(args[i].equals("-windowInterval")){
				GlobalParameters.WINDOWINTERVAL = Integer.valueOf(args[i+1]);
				System.out.println("WINDOW INTERVAL: "+args[i+1]);
			}

			if(args[i].equals("-rlAgentCustom")){
				GlobalParameters.rlAgentCustom = true;
				System.out.println("Agente Customizado");
			}

			if(args[i].equals("-onlineMode")){
				GlobalParameters.ONLINE_MODE = true;
				System.out.println("Modo de Teste");
			}
			if(args[i].equals("-numMachines")){
				GlobalParameters.NUMMACHINES = Integer.valueOf(args[i+1]);			
			}
			if(args[i].equals("-maxPTime")){
				GlobalParameters.MAXPTIME = Integer.valueOf(args[i+1]);			
			}
			if(args[i].equals("-instanceToTest")){
				GlobalParameters.INSTANCETOTEST = Integer.valueOf(args[i+1]);
			}
			if(args[i].equals("-nnSetup")){
				GlobalParameters.NNSETUP = Integer.valueOf(args[i+1]);
			}
		}		
		
		if(!GlobalParameters.TEST_NAME.equals("")){
			GlobalParameters.OUTPUTFILE = GlobalParameters.OUTPUT_DIR + "Results_"+GlobalParameters.TEST_NAME+".csv";	
			GlobalParameters.FITNESSOUTPUT = GlobalParameters.OUTPUT_DIR + "Fitness_"+GlobalParameters.TEST_NAME;
			GlobalParameters.OUTPUTFILE_RULES = GlobalParameters.OUTPUT_DIR + "RulesSize_"+GlobalParameters.TEST_NAME;	
			GlobalParameters.BEST_RULE_FILE = GlobalParameters.OUTPUT_DIR + "BestRule_"+GlobalParameters.TEST_NAME;	
			GlobalParameters.OUTPUTFILE_EXPRESSIONS = GlobalParameters.OUTPUT_DIR + "Rules_"+GlobalParameters.TEST_NAME;
		}
		System.out.println("Directory: "+GlobalParameters.DIRECTORY);
	}

}