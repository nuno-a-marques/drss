package main;

import utils.Utils.EvaluationType;

public class GlobalParameters {
	
	public static String DIRECTORY = "./";
	
	//Test
	//--------------------------------------------------------------------------------
	public static double[] TEST_CVS = {0, 0.2, 0.4, 0.6, 0.8, 1};				
	public static String TEST_SET_FILE = "TestInstances.csv";
	public static  double[] TEST_UTILIZATION = {0.7, .8, .85, .9, .95, .97, .99};
	public static  double[] TEST_ALLOWANCE_FACTOR = {1.3, 2, 3, 4, 6, 8, 10};	
		
	//Validation
	//--------------------------------------------------------------------------------
	public static double[] CVS = {0};			
	public static String VALIDATION_SET_FILE = "ValidationInstances.csv";
	public static  double[] UTILIZATION = {.8, .85, .9, .95, .97};
	public static  double[] ALLOWANCE_FACTOR = {2, 3, 4, 6, 8};	

	//Training
	//--------------------------------------------------------------------------------	
	public static String TRAINING_SET_FILE = "TrainingInstances.csv";
	public static  int SMALL_TRAINING_REPLICATIONS = 10;
	public static  int FULL_TRAINING_REPLICATIONS = 0;			
	public static  double[] TRAINING_UTILIZATION =  {.80, .97};
	public static  double[] TRAINING_ALLOWANCE_FACTOR = {3, 4, 6};	
	public static  double[] TRAINING_CVS = {0};		
	public static String SIMPLIFIED_TRAINING_SET_FILE = "TrainingInstances.csv";
	public static  int SIMPLIFIED_TRAINING_REPLICATIONS = 2;	
	public static  double[] SIMPLIFIED_TRAINING_UTILIZATION = {.80};
	public static  double[] SIMPLIFIED_TRAINING_ALLOWANCE_FACTOR = {3, 4, 6};		
	public static  double[] SIMPLIFIED_TRAINING_CVS = {0};	
	
	//--------------------------------------------------------------------------------
	//PAR�METROS EXCLUSIVOS PARA CORRER DYNAMIC SCHEDULING HRTS	
//	public static String VALIDATION_SET_FILE = "PMInstances.csv";
//	public static  double[] UTILIZATION = {.85, .95};	
//	public static  int[] ALLOWANCE_FACTOR = {3, 6};		
//
//	public static String TRAINING_SET_FILE = "PMInstances_Training.csv";
//	public static  int SMALL_TRAINING_REPLICATIONS = 4;	
//	public static  double[] TRAINING_UTILIZATION =  {.85, .95};
//	public static  double[] TRAINING_CVS = {0, 0.4};
//	public static  int[] TRAINING_ALLOWANCE_FACTOR = {3, 6};
//	public static String SIMPLIFIED_TRAINING_SET_FILE = "PMInstances_Training.csv";
//	public static  int SIMPLIFIED_TRAINING_REPLICATIONS = 1;	
//	public static  double[] SIMPLIFIED_TRAINING_UTILIZATION = {.85, .95};
//	public static  int[] SIMPLIFIED_TRAINING_ALLOWANCE_FACTOR = {3, 6};		
//	public static  double[] SIMPLIFIED_TRAINING_CVS = {0.4};	

	//--------------------------------------------------------------------------------
	//PAR�METROS EXCLUSIVOS DO GP
	
	public static boolean CO_EVOLVE = false;
	//N�mero de itera��es do algoritmo GP (Multi-Start)
	public static int ITERATIONS = 1;	
	//Tipo de avalia��o 
	public static EvaluationType TYPE_OF_EVALUATION_TO_USE = EvaluationType.SIMPLIFIED;
	//NORMAL - One evaluation phase: Full training set
	//SMALL - Two evaluation phases: Full and small training sets
	//SIMPLIFIED - Three evaluation phases: Full, small and simplified training sets
	//Number to use full evaluation in case of using efficient GP
	public static int NUMBER_FULL_TRAINING = 0;
	public static double N_BEST_FRACTION = 0.5;		
	//Se true, as metricas s�o calculadas com media geometrica
	public static boolean GEO_MEAN = true;
	//Penalidade aplicada por cada n�s da �rvore
	public static double SIZE_PENALTY = 0.0001;
	//Se true, a penalidade especificada em SIZE_PENALTY � fixa, sen�o � multiplicada 
	//pelo n�mero de gera��es decorridas
	public static boolean FIXED_PENALTY = false;
	//Se true, a semente � fixa em todas as gera��es
	public static boolean FIXED_SEED = true;
	//0 - Makespan; 1 - Number of tardy jobs; 2 - Mean tardiness; 3 - Relative Mean tardiness
	public static int OBJECTIVE_FUNCTION = 3;
	
	//Training Parameters
	public static final int MAX_JOBS_TRAINING_SIMULATION = 2000;	
	public static  int SIMPLIFIED_MAX_JOBS_TRAINING_SIMULATION = 2000;
	
	//--------------------------------------------------------------------------------
	// INSTANCE PARAMETERS
	public static  int INSTANCETOTEST = 0;
	public static  int NUMMACHINES = 0;			// DEPRECATED
	public static  int MAXPTIME = 0;			// DEPRECATED
	
	//--------------------------------------------------------------------------------
	//PAR�METROS DO SIMULADOR
	
	//ID dos jobs m�nimo e m�ximos jobs considerados na simula��o
	//� preciso considerar somente os jobs durante o estado de estabilidade do sistema
	public static int MIN_JOBS_STEADY_STATE = 500;
	public static int MAX_JOBS_STEADY_STATE = 2500;
	public static int REPLICATIONS = 2;
	//N�mero de predecessores de um job
	public static final int MAX_PREDECESSORS = 2;
	//Se true permite que os jobs voltem a m�quinas que j� passaram (recircula��o)
	//Isto � utilizado na gera��o din�mica de rotas para os jobs
	public static boolean ALLOW_RECIRCULATION = true;
	//Parametros para a gera��o das distribui��es gamma
	//Que ser�o usadas no sorteio dos tempos de processamento realizados
	public static final int MIN_PROCESSING_TIME = 1;
	public static final int MAX_PROCESSING_TIME = 1000;
	public static int GP_SEED = 0;

	public static String TESTMODE = "none";
	//--------------------------------------------------------------------------------

	//PARAMETROS LUO

	public static boolean LOAD_WEIGHTS = false;
	public static boolean LOAD_DATASET=false;
	public static boolean LOAD_QTABLE=false;	
	public static int EPISODES = 10;
	public static double EXPLORATION = 0.5; 		//Simulator 686
	public static double DISCOUNT_FACTOR=0.9;		//Simulator 476	
	public static double WEIGHT_UPDATE = 0.01;		//RL AGENT  485
	public static boolean ONLINE_MODE=false;			

	public static boolean BENCHMARK_MODE=false;
	public static int BENCHMARK_RULE=0;
	public static int MAR_RULE=-1;
	public static	String EPISODE_CODE="";

	public static boolean rlAgentCustom=false;

	public static int lastCheckPoint=0;
	public static int NNSETUP = 0;
		
	//--------------------------------------------------------------------------------	
	//OUTROS PARAMETROS
	
	//Se true, indica que o gerador de inst�ncias deve ser acionado (e somente ele)
	public static boolean INSTANCE_GEN = false;		
	//Se true, o simulador imprime detalhes do schedule dos jobs
	public static boolean VERBOSE = false;
	public static boolean TEST_DR = false;
		
	public static double FIXED_ALLOWANCE = -1;
	public static double FIXED_CV = -1;
	public static double FIXED_UTILIZATION = -1;
	public static String FIXED_INSTANCE = "";
	public static double FIXED_NMACHINES = -1;
	public static int SEED = 0;
	
	public static int WINDOWINTERVAL = 50;
	public static int WINDOWLIMIT    = 999999;								// apenas para dados de treino
	public static int WINDOWRULE	 = -1;

	public static int DEBUGSTOP	= -1;

	public static String rtrsTYPE = "";
	public static String rtrsSS   = "";

	//--------------------------------------------------------------------------------	
	public static String[] BENCHMARK_RULES = {"RR", "2PTWINQNPT"};
	//REGRAS DE DESPACHO
	//public static String[] RULES = {"SPT", "RR", "PTWINQ", "2PTWINQNPT", "PTWINQSL", "PTWINQNPTWSL"};
	public static String[] RULES = {"2PTWINQNPT"};
	//public static String[] RULES = {"SPT", "DD", "CR", "Finish"};

	//--------------------------------------------------------------------------------	
	//FICHEIROS E DIRETORIOS
	public static String OUTPUT_DIR = "";
	public static String TEST_NAME = "";
	public static String BEST_TRAINING_FILE = "BestResultsTraining.csv";
	public static String BEST_RESULT_FILE =  "BestResults.csv";
	public static String OUTPUTFILE = GlobalParameters.OUTPUT_DIR + "Results.csv";
	public static String FITNESSOUTPUT = GlobalParameters.OUTPUT_DIR + "Fitness_";
	public static String OUTPUTFILE_EXPRESSIONS = GlobalParameters.OUTPUT_DIR + "Rules_";
	public static String BEST_RULE_FILE = GlobalParameters.OUTPUT_DIR + "BestRule_";
	public static String OUTPUTFILE_RULES = GlobalParameters.OUTPUT_DIR + "RulesSize_";

}
