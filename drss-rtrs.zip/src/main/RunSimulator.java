package main;

import input.Instance;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import org.json.simple.DeserializationException;

import simulator.PerformanceMetrics;
import simulator.Simulator;
import utils.Utils;
import ec.Individual;

public class RunSimulator {

	public static void main(String[] args) {

		if(GlobalParameters.TEST_DR){
			GlobalParameters.CVS 					= GlobalParameters.TEST_CVS;
			GlobalParameters.VALIDATION_SET_FILE 	= GlobalParameters.TEST_SET_FILE;
			GlobalParameters.UTILIZATION			= GlobalParameters.TEST_UTILIZATION;
			GlobalParameters.ALLOWANCE_FACTOR 		= GlobalParameters.TEST_ALLOWANCE_FACTOR;			
		}
		
		readUserParameters(args);
		Utils.initializeData();
				
		//evaluateRule(null, false);
	}

	/**
	 * Corre o simulador para todas as inst�ncias e escreve os resultados em ficheiro
	 * @param ind - Individuo resultante do GP (se null, utiliza as regras de despacho especificadas em parametros)
	 * @param apendFile (se true, faz apend no ficheiro de resultados)
	 * Re
	 * torna a performance geral da regra, se for um individuo GP
	 * @throws IOException
	 * @throws DeserializationException
	 */

	public static void evaluateRuleRL(Individual ind, boolean apendFile) throws IOException, DeserializationException{
		Simulator simulator = new Simulator();  
		String fileName=GlobalParameters.DIRECTORY + GlobalParameters.VALIDATION_SET_FILE;
		List<Instance> instances = DataLoader.readInstanceSetList(fileName);
		
		Instance instance=instances.get(GlobalParameters.INSTANCETOTEST);

		Utils.initializeExpDistributions(instance, 0.85);				    // just to initialize


		int[] nnToTest					=   new int[]     {                2030,      1210,       950,	    380,        690,        680       };
		String[] ssList                 =   new String[]  {           "ql-ss-1", "ql-ss-2", "ql-ss-3", "dql-ss-1", "dql-ss-2", "dql-ss-3"     };
		int[] rulesToTest				=	new int[]  {  18  };
		double[] flexibilityArray		=	{  1.0  };
		double[] utilisationArray		= 	{  0, 1, 2, 3, 4, 5     };			                    // 0.80, 0.85, 0.90, 0.95, 0.97
		double[] allowanceArray			=	{  0, 1, 2, 3, 4, 5     };								// 0.80, 0.85, 0.90, 0.95, 0.97
		int instanceExtension = 0;					    	    
		double cv = 0;

		boolean print_log = false;
		switch(GlobalParameters.TESTMODE){
			
			case "train":
				if (print_log) { System.out.println("TRAIN instances will be used"); }
				instanceExtension = 3;
				
				utilisationArray[0] = 0.85;
				utilisationArray[1] = 0.90;
				utilisationArray[2] = 0.95;

				allowanceArray[0] = 3.0;
				allowanceArray[1] = 4.0;
				allowanceArray[2] = 6.0;

				break;
			case "test":
			if (print_log) { System.out.println("TEST instances will be used"); }
				instanceExtension = 5;
					
				utilisationArray[0] = 0.80;
				utilisationArray[1] = 0.85;
				utilisationArray[2] = 0.90;
				utilisationArray[3] = 0.95;
				utilisationArray[4] = 0.97;

				allowanceArray[0] = 2.0;
				allowanceArray[1] = 3.0;
				allowanceArray[2] = 4.0;
				allowanceArray[3] = 6.0;
				allowanceArray[4] = 8.0;

				break;
			case "validation":
			if (print_log) { System.out.println("VALIDATION instances will be used"); }
				instanceExtension = 4;
					
				utilisationArray[0] = 0.83;
				utilisationArray[1] = 0.87;
				utilisationArray[2] = 0.93;
				utilisationArray[3] = 0.96;

				allowanceArray[0] = 2.5;
				allowanceArray[1] = 3.5;
				allowanceArray[2] = 5.0;
				allowanceArray[3] = 7.0;
				
				break;
			default :
				//code
				if (print_log) { System.out.println("No test mode was found"); }
				int a = 1000/0;
		}

		for(int n=0;n<nnToTest.length;n++){
			GlobalParameters.NNSETUP = nnToTest[n];
			Utils.checkRTRStype(ssList[n]);												// determina se e QL ou DQL e qual o SS
			for(int r=0;r<rulesToTest.length;r++){
				//ATIVAR APENAS NAS CORRIDAS GRID
				GlobalParameters.BENCHMARK_RULE=rulesToTest[r];							// vai alterando dinamicamente
				GlobalParameters.WINDOWRULE= rulesToTest[r];							// fica sempre fixa
				//Utils.setDistributionsSeed(200, 0);
				for(int i = 0; i < flexibilityArray.length; i++){
					double flexibility=flexibilityArray[i];
					instance.setOpFlexibility(flexibility);
					for(int j = 0; j < instanceExtension; j++){
						double uLevel=utilisationArray[j];
						//Utils.initializeExpDistributions(instance, uLevel);
						for(int k = 0; k < instanceExtension; k++){
							double allowance=allowanceArray[k];
							if(GlobalParameters.BENCHMARK_MODE){
								simulator.runBenchmark(ind, instance, cv, GlobalParameters.EPISODES, uLevel, allowance);
							}
							else{
								if		(GlobalParameters.rlAgentCustom)	{simulator.runCustom(ind, instance, cv, GlobalParameters.EPISODES, uLevel, allowance);}
								else										{simulator.runInstanceRL(ind, instance, cv, GlobalParameters.EPISODES, uLevel, allowance);}
							}
						}
					}
				}	
			}
		}
	}
	
	public static double[] getEpisodeParam(int n,double flexibilityTemp){
		double[] resultado=new double[]{0.85,1.0};
		if(n>8)	{n=n-9;}
		switch(n){
			case 0:
				resultado[0]=0.85;
				resultado[1]=1.0;
				if(flexibilityTemp==1.0)	{GlobalParameters.EPISODE_CODE="J";}
				else						{GlobalParameters.EPISODE_CODE="A";}				
				break;
			case 1:
				resultado[0]=0.85;
				resultado[1]=1.3;
				if(flexibilityTemp==1.0)	{GlobalParameters.EPISODE_CODE="K";}
				else						{GlobalParameters.EPISODE_CODE="B";}
				break;
			case 2:
				resultado[0]=0.85;
				resultado[1]=1.5;
				if(flexibilityTemp==1.0)	{GlobalParameters.EPISODE_CODE="L";}
				else						{GlobalParameters.EPISODE_CODE="C";}
				break;
			case 3:
				resultado[0]=0.90;
				resultado[1]=1.0;
				if(flexibilityTemp==1.0)	{GlobalParameters.EPISODE_CODE="M";}
				else						{GlobalParameters.EPISODE_CODE="D";}
				break;
			case 4:
				resultado[0]=0.90;
				resultado[1]=1.3;
				if(flexibilityTemp==1.0)	{GlobalParameters.EPISODE_CODE="N";}
				else						{GlobalParameters.EPISODE_CODE="E";}
				break;
			case 5:
				resultado[0]=0.90;
				resultado[1]=1.5;
				if(flexibilityTemp==1.0)	{GlobalParameters.EPISODE_CODE="O";}
				else						{GlobalParameters.EPISODE_CODE="F";}
				break;
			case 6:
				resultado[0]=0.95;
				resultado[1]=1.0;
				if(flexibilityTemp==1.0)	{GlobalParameters.EPISODE_CODE="P";}
				else						{GlobalParameters.EPISODE_CODE="G";}
				break;
			case 7:
				resultado[0]=0.95;
				resultado[1]=1.3;
				if(flexibilityTemp==1.0)	{GlobalParameters.EPISODE_CODE="Q";}
				else						{GlobalParameters.EPISODE_CODE="H";}
				break;
			case 8:
				resultado[0]=0.95;
				resultado[1]=1.5;
				if(flexibilityTemp==1.0)	{GlobalParameters.EPISODE_CODE="R";}
				else						{GlobalParameters.EPISODE_CODE="I";}
				break;
			default:
				resultado[0]=0.99;
				resultado[1]=1.0;
				if(flexibilityTemp==1.0)	{GlobalParameters.EPISODE_CODE="N";}
				else						{GlobalParameters.EPISODE_CODE="E";}
				break;
		}
		return resultado;
	}

	
	public static double evaluateRule(Individual ind, boolean apendFile){
			
		double performance = 1;
		//Apos executar a simulacao,
		//escreve resultados separadamente, para cada regra que foi simulada
		int numRules = (ind != null)? 1: GlobalParameters.RULES.length;	
		Simulator simulator = new Simulator();  	
		List<Instance> instances = DataLoader.readInstanceSetList(GlobalParameters.DIRECTORY + GlobalParameters.VALIDATION_SET_FILE);
		DataLoader.readBenchmark(instances);

		BufferedWriter writer = null;	
		try{
			File resultFile = new File(GlobalParameters.OUTPUTFILE);
			writer = new BufferedWriter(new FileWriter(resultFile, apendFile));	
			
			try{
				//writeHeaderLine(writer);
				
				//Run simulator for each instance
				for(Instance instance: instances){				
					
					if(!GlobalParameters.FIXED_INSTANCE.equals("") &&
							!GlobalParameters.FIXED_INSTANCE.equals(instance.getName()))
						continue;
					
					if(GlobalParameters.FIXED_NMACHINES != -1 &&
							GlobalParameters.FIXED_NMACHINES != instance.getNumMachines())
						continue;					
					
					//Para cada nivel de utilizacao do shop
					for(int u = 0;u < GlobalParameters.UTILIZATION.length; u++){
						double uLevel = GlobalParameters.UTILIZATION[u];

						if(GlobalParameters.FIXED_UTILIZATION > -1 &&
								uLevel != GlobalParameters.FIXED_UTILIZATION)
							continue;

						Utils.initializeExpDistributions(instance, uLevel);
						//Para cada n�vel de due date
						for(int d = 0; d < GlobalParameters.ALLOWANCE_FACTOR.length; d++){
							double allowance = GlobalParameters.ALLOWANCE_FACTOR[d];			

							if(GlobalParameters.FIXED_ALLOWANCE > -1 && 
									allowance != GlobalParameters.FIXED_ALLOWANCE)
								continue;			
							
							//Para tempo de processamento maior que 200, nao e necessario considerar os extremos
							if((instance.getMaxProcessingTime() > 200) && (allowance < 2 || allowance > 8 || uLevel < 0.8 || uLevel > 0.97))
								continue;	
							
							//Para numero de maquinas maior que 10, nao e necessario considerar os extremos
							if((instance.getNumMachines() > 10) && (allowance < 2 || allowance > 8 || uLevel < 0.8 || uLevel > 0.97))
								continue;								
							
							for(int cvIndex = 0; cvIndex < GlobalParameters.CVS.length; cvIndex++){													

								double cv = GlobalParameters.CVS[cvIndex];
								if(GlobalParameters.FIXED_CV > -1 &&
										cv != GlobalParameters.FIXED_CV)
									continue;
																
								//Consideramos cenarios estocasticos somente para instancias das 25 celulas (a = {2-8} e u = {0.8-0.97})
								if((cv > 0) && (instance.getNumMachines() == 0 || instance.getNumMachines() > 10 ||
										instance.getMaxProcessingTime() > 200 || 
										allowance < 2 || allowance > 8 || uLevel < 0.8 || uLevel > 0.97))
									continue;								
																
								//Executa a simulacao para todas as regras de despacho
								//O output e um conjunto de metricas de performance calculadas para cada regra
								PerformanceMetrics[] rulesPerformance = simulator.runInstance(ind, instance, cv, GlobalParameters.REPLICATIONS, uLevel, allowance);							
													
								for(int r= 0; r < numRules; r++){

									String rule = (ind == null)? GlobalParameters.RULES[r]: ind.genotypeToString();
									writeResultLine(writer, rule, instance, allowance, uLevel, cv,rulesPerformance[r]);	
									
									if(ind != null)
										performance *= rulesPerformance[r].getRelativePerformanceTardiness();
								}
							}
						}
					}
				}
			}catch(IOException ioe){
				ioe.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				// Close the writer regardless of what happens...
				writer.close();
			} catch (Exception e) {
			}
		}   
		
		return performance/(numRules*GlobalParameters.CVS.length*GlobalParameters.ALLOWANCE_FACTOR.length*GlobalParameters.UTILIZATION.length*instances.size());
	}
	
	
	/**
	 * Corre o simulador para todas as inst�ncias e escreve os resultados em ficheiro
	 * @param ind - Individuo resultante do GP (se null, utiliza as regras de despacho especificadas em parametros)
	 * @param apendFile (se true, faz apend no ficheiro de resultados)
	 * Re
	 * torna a performance geral da regra, se for um individuo GP
	 * @throws IOException
	 * @throws DeserializationException
	 */
	public static void statisticalTest(Individual ind) throws IOException, DeserializationException{
			
		Simulator simulator = new Simulator();  	
		List<Instance> instances = DataLoader.readInstanceSetList(GlobalParameters.DIRECTORY + GlobalParameters.VALIDATION_SET_FILE);
		DataLoader.readBenchmark(instances);
		
		//Para cada nivel de utiliza��o do shop
		for(int u = 0;u < GlobalParameters.UTILIZATION.length; u++){
			double uLevel = GlobalParameters.UTILIZATION[u];

			//Para cada n�vel de due date
			for(int d = 0; d < GlobalParameters.ALLOWANCE_FACTOR.length; d++){
				double allowance = GlobalParameters.ALLOWANCE_FACTOR[d];					
				
				for(int cvIndex = 0; cvIndex < GlobalParameters.CVS.length; cvIndex++){	
					double cv = GlobalParameters.CVS[cvIndex];
				
					//Run simulator for each instance	
					//Executa a simula��o para todas as regras de despacho
					//O output � um conjunto de m�tricas de performance calculadas para cada regra
					simulator.testInstances(ind, instances, cv, GlobalParameters.REPLICATIONS, uLevel, allowance);							
				}
			}
		}  
	}
	
	public static void writeHeaderLine(BufferedWriter writer) throws IOException{
		
			writer.write("Rule; Instance; Problem; NumJobs; NumHumans; NumRobots; " +
					"MinTime;MaxTime; MinOperations; MaxOperations; RElig; HElig; MMElig; MinRoutes; " +
					"MaxRoutes;Allowance; Utilization;CV;"+
					"MeanFlowTime;MaxFlowTime;TardyJobs;MeanTardiness;MaxTardiness;");					
			writer.newLine();		
	}
	
	
	public static void writeResultLine(BufferedWriter writer, String rule, Instance instance, double a, double uLevel, double cv, PerformanceMetrics performance) throws IOException{

		writer.write(rule+";");

		writer.write(instance.getName()+";");
		writer.write(instance.getProblem()+";");							
		writer.write(instance.getNumMachines()+";");
		writer.write(instance.getMinProcessingTime()+";");
		writer.write(instance.getMaxProcessingTime()+";");
		writer.write(instance.getMinNumOperations()+";");
		writer.write(instance.getMaxNumOperations()+";");
		writer.write(a+";");
		writer.write(uLevel+";");
		writer.write(cv+";");

		writer.write(performance.toString());

		writer.newLine();		
	}
	
	public static void readUserParameters(String[] args){
		
		for(int i=0; i < args.length; i++){
			if(args[i].equals("-verbose"))
				GlobalParameters.VERBOSE = true;
			if(args[i].equals("-minJob"))
				GlobalParameters.MIN_JOBS_STEADY_STATE = Integer.valueOf(args[i+1]);	
			if(args[i].equals("-maxJob"))
				GlobalParameters.MAX_JOBS_STEADY_STATE = Integer.valueOf(args[i+1]);	
			if(args[i].equals("-nrep"))
				GlobalParameters.REPLICATIONS = Integer.valueOf(args[i+1]);						
			if(args[i].equals("-instanceGen"))
				GlobalParameters.INSTANCE_GEN = true;		
			if(args[i].equals("-out"))
				GlobalParameters.OUTPUTFILE = GlobalParameters.DIRECTORY + args[i+1];
			if(args[i].equals("-i"))
				GlobalParameters.FIXED_INSTANCE = args[i+1];			
			if(args[i].equals("-valset"))
				GlobalParameters.VALIDATION_SET_FILE = args[i+1];
			if(args[i].equals("-u"))
				GlobalParameters.FIXED_UTILIZATION = Double.valueOf(args[i+1]);		
			if(args[i].equals("-cv"))
				GlobalParameters.FIXED_CV = Double.valueOf(args[i+1]);	
			if(args[i].equals("-a"))
				GlobalParameters.FIXED_ALLOWANCE = Double.valueOf(args[i+1]);	
			if(args[i].equals("-m"))
				GlobalParameters.FIXED_NMACHINES = Double.valueOf(args[i+1]);	
			if(args[i].equals("-trainset"))
				GlobalParameters.TRAINING_SET_FILE = args[i+1];		
			if(args[i].equals("-seed"))
				GlobalParameters.SEED = Integer.valueOf(args[i+1]);	
		}			
	}

}
