package main;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import input.Instance;
import simulator.BenchmarkResult;
import utils.Utils;
import utils.Utils.EvaluationType;
import utils.Utils.ProblemType;


public class DataLoader {

	public static List<Instance> instancesTS;
	public static List<Instance> instancesSimplifiedTS;

	public static List<Instance> readTrainingSet(){

		if (GlobalParameters.TYPE_OF_EVALUATION_TO_USE == EvaluationType.SIMPLIFIED){

			if (GlobalParameters.TYPE_OF_EVALUATION_TO_USE == EvaluationType.SIMPLIFIED){
				instancesSimplifiedTS=readInstanceSetList(GlobalParameters.DIRECTORY + GlobalParameters.SIMPLIFIED_TRAINING_SET_FILE);
			}
		}
		instancesTS=readInstanceSetList(GlobalParameters.DIRECTORY + GlobalParameters.TRAINING_SET_FILE);
		return instancesTS;
	}

	public static void readBenchmark(List<Instance> instances){

		Map<Integer,Map<Integer,Map<Double,Map<Integer,BenchmarkResult> > > > benchmarkResults = new HashMap<Integer, Map<Integer,Map<Double,Map<Integer,BenchmarkResult>>>>();

		for(Instance instance: instances){ 

			int instanceId = Integer.valueOf(instance.getName());

			Map<Integer,Map<Double,Map<Integer,BenchmarkResult> > > benchmarkCV  = new HashMap<Integer,Map<Double,Map<Integer,BenchmarkResult> > > ();
			benchmarkResults.put(instanceId, benchmarkCV);

			for(int i = 0; i < GlobalParameters.CVS.length; i++){
				
				int cv = (int) (GlobalParameters.CVS[i]*100.0);
				Map<Double,Map<Integer,BenchmarkResult> > benchmarkA = new HashMap<Double,Map<Integer,BenchmarkResult> >();
				benchmarkCV.put(cv,benchmarkA);

				for(int a = 0; a < GlobalParameters.ALLOWANCE_FACTOR.length; a++){

					double allowanceFactor = GlobalParameters.ALLOWANCE_FACTOR[a];	
					Map<Integer,BenchmarkResult> benchmarkU = new HashMap<Integer, BenchmarkResult>();
					benchmarkA.put(allowanceFactor, benchmarkU);
				}
			}
		}
		setUpBenchmarkResults(benchmarkResults, GlobalParameters.DIRECTORY +GlobalParameters.BEST_RESULT_FILE);
	}
	
	public static void readTrainingBenchmark(List<Instance> instances){

		Map<Integer,Map<Integer,Map<Double,Map<Integer,BenchmarkResult> > > > benchmarkResults = new HashMap<Integer, Map<Integer,Map<Double,Map<Integer,BenchmarkResult>>>>();

		for(Instance instance: instances){ 

			int instanceId = Integer.valueOf(instance.getName());

			Map<Integer,Map<Double,Map<Integer,BenchmarkResult> > > benchmarkCV  = new HashMap<Integer,Map<Double,Map<Integer,BenchmarkResult> > > ();
			benchmarkResults.put(instanceId, benchmarkCV);

			for(int i = 0; i < GlobalParameters.TRAINING_CVS.length; i++){
				
				int cv = (int) (GlobalParameters.TRAINING_CVS[i]*100.0);	
				Map<Double,Map<Integer,BenchmarkResult> > benchmarkA = new HashMap<Double,Map<Integer,BenchmarkResult> >();
				benchmarkCV.put(cv,benchmarkA);

				for(int a = 0; a < GlobalParameters.TRAINING_ALLOWANCE_FACTOR.length; a++){

					double allowanceFactor = GlobalParameters.TRAINING_ALLOWANCE_FACTOR[a];	
					Map<Integer,BenchmarkResult> benchmarkU = new HashMap<Integer, BenchmarkResult>();
					benchmarkA.put(allowanceFactor, benchmarkU);
				}
			}
		}
		setUpBenchmarkResults(benchmarkResults, GlobalParameters.DIRECTORY + GlobalParameters.BEST_TRAINING_FILE);
	}	

	private static void setUpBenchmarkResults(Map<Integer,Map<Integer,Map<Double,Map<Integer,BenchmarkResult> > > > benchmarkResults, String bestResultsfile){

		try {
			FileReader file = new FileReader(bestResultsfile);
			BufferedReader fileReader = new BufferedReader(file);

			String line = fileReader.readLine();
			line = fileReader.readLine();
			while (line != null) {

				String[] lineTokens = line.split(";");

				int instanceId = Integer.valueOf(lineTokens[0]);
				double allowanceFactor = Double.valueOf(lineTokens[1]);
				int utilization = (int) Math.round(100*Double.valueOf(lineTokens[2]));
				int cv = (int) Math.round(100*Double.valueOf(lineTokens[3]));
				double flowtime = Double.valueOf(lineTokens[4]);
				double percentageTardyJobs = Double.valueOf(lineTokens[5]);
				double tardiness = Double.valueOf(lineTokens[6]);

				BenchmarkResult result = new BenchmarkResult(tardiness, percentageTardyJobs, flowtime);

				Map<Integer,Map<Double,Map<Integer,BenchmarkResult> > > benchmarkCV = benchmarkResults.get(instanceId);
				if(benchmarkCV != null){
					Map<Double,Map<Integer,BenchmarkResult> > benchmarkA = benchmarkCV.get(cv);
					if(benchmarkA!= null){
						Map<Integer,BenchmarkResult> benchmarkU =benchmarkA.get(allowanceFactor);
						if(benchmarkU != null)
							benchmarkU.put(utilization, result);													
					}
				}

				line = fileReader.readLine();
			}

			file.close();
		} catch (IOException e) {
			System.err.printf("Error on openning file: %s.\n",
					e.getMessage());
		}						 

		Utils.setBenchmarkResults(benchmarkResults);
	}
	
	public static List<Instance>  readInstanceSetList(String instanceListFile){

		List<Instance> instances;
		instances = new ArrayList<Instance>();

		try {
			FileReader file = new FileReader(instanceListFile);
			BufferedReader fileReader = new BufferedReader(file);

			String line = fileReader.readLine();
			line = fileReader.readLine();
			while (line != null) {

				String[] lineTokens = line.split(";");

				ProblemType problem;
				if(lineTokens[1].equals("js")){
					problem = ProblemType.JOBSHOP; 
				} else if(lineTokens[1].equals("fjs")){
					problem = ProblemType.FLEXIBLE_JOBSHOP; 
				}else{
					problem = ProblemType.PARALLEL_MACHINE;
				}

				Instance instance = new Instance(lineTokens[0], problem);
				if(GlobalParameters.FIXED_INSTANCE == "" ||
					GlobalParameters.FIXED_INSTANCE.equals(instance.getName())){
					
					instance.setNumMachines(Integer.parseInt(lineTokens[2]));
					instance.setMinProcessingTime(Integer.parseInt(lineTokens[3]));
					instance.setMaxProcessingTime(Integer.parseInt(lineTokens[4]));
					instance.setMinNumOperations(Integer.parseInt(lineTokens[5]));
					instance.setMaxNumOperations(Integer.parseInt(lineTokens[6]));
					instance.setOpFlexibility(Double.parseDouble(lineTokens[7]));

					InstanceGenerator.createInstanceData(instance);
					instances.add(instance);					
				}

				line = fileReader.readLine();
			}

			file.close();
		} catch (IOException e) {
			System.err.printf("Error on openning file: %s.\n",
					e.getMessage());
		}

		return instances;	
	}	
}
