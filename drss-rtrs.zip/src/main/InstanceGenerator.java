package main;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import javax.xml.stream.events.ProcessingInstruction;

import org.json.simple.JsonArray;
import org.json.simple.JsonObject;

import input.Instance;
import input.Job;
import input.Machine;
import input.Operation;
import input.Route;
import utils.Utils;
import utils.Utils.ProblemType;

public class InstanceGenerator {

	public static double MIN_SPEED_UP = 0.5;
	public static double MAX_SPEED_UP = 1;
	public static double[] machinePerformance =new double[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};    // HARD CODED
	public static double meanMachinePerformance=0.0;	

	/** 
	 * Cria os dados auxiliares de todas as inst�ncias
	 * @param instance
	 */
	public static List<Instance> createInstanceSet(String instanceListFile){

		List<Instance> instances = DataLoader.readInstanceSetList(instanceListFile);				
		for(Instance instance: instances){
			createInstanceData(instance);											
		}		

		return instances;
	}
	
	/** 
	 * Instancia os recursos da inst�ncia: m�quinas, humanos ou robos
	 * @param instance
	 */
	public static void createInstanceData(Instance instance){

		instance.clearData();

		//Criando as maquinas
		for(int mId = 1; mId <= instance.getNumMachines(); mId++){
			Machine machine = new Machine(mId, false);
			instance.addMachine(machine);
		}
	}

	public static void initMachinePerformance(int nMac){
		//boolean verbose=true;
		String output = "";
		double sum=0.0;
		for(int mId = 1; mId <= nMac; mId++){
			double performanceMAX = 1.20; //HARD CODED VALUES
			double performanceMIN = 0.8;  //HARD CODED VALUES

			machinePerformance[mId-1] = Utils.getRandomNumber(performanceMIN, performanceMAX);

			sum=sum+machinePerformance[mId-1];
			output = output + ", " + String.valueOf(machinePerformance[mId-1]);

			/* if (true){
				System.out.println(String.valueOf(machinePerformance[mId-1]));
			} */
		}

		meanMachinePerformance=sum/nMac;
		//System.out.println(output);

	}

	public static double getMachineMeanPerformance(){
		return meanMachinePerformance;
	}
	
	private static void dumpDebugDataOperations(int oid, Operation operation, int jid){
		// TOIMPROVE  nao esta robusto a varias corridas
		String output="";

		output=oid + ";" + operation.getNumEligibleMachines();

		String machineArray = "";
		String operationTimeArray = "";
		for(Machine machine: operation.getEligibleMachines()){
			machineArray=machineArray + " - " + machine.getId();
			operationTimeArray=operationTimeArray + " - " + String.valueOf(operation.getTime(machine));
		}
		//for(Machine machine: instance.getMachines()){	

		output=output + ";" + machineArray.substring(3) + " ; " + operationTimeArray.substring(3) + " ; " + String.valueOf(operation.getDueDate()) + " ; "+ jid;		

		FileWriter fw;
		try {
			fw = new FileWriter("debugDataOperations.txt", true);
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(output);
			bw.newLine();
			bw.close();
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Instancia um job em mem�ria e sorteia seus dados: rotas, opera��es e chegada.
	 */
	public static Job createJob(Instance instance, int jobId, int operationId){

		Job job = new Job(jobId);

		Route route = new Route(job);			
		job.setRoute(route);	

		boolean[] choosenMachines = new boolean[instance.getNumMachines()];
		for(Machine machine: instance.getMachines()){
			choosenMachines[machine.getId()-1] = false;
		}

		//Sorteando o n�mero de opera��es
		/**System.out.println("Final performance: "+instance.getMinNumOperations());	
		System.out.println("Final performance2: "+instance.getMaxNumOperations());
		instance.print();	*/

		//System.out.println("Final performance: "+instance.getMinNumOperations());	
		//System.out.println("Final performance2: "+instance.getMaxNumOperations());
		int numOperations = Utils.getRandomInt(instance.getMinNumOperations(), instance.getMaxNumOperations());
		//int temp = Utils.getRandomInt(1, 100);
		//double temp2 = Utils.getRandomNumber(1, 100);
		//double temp3 = Utils.getRandomNumber(1, 100);
		Operation[] operations = new Operation[numOperations];

		Operation lastOperation = null;
		Machine lastMachine = null;
		//Criando as opera��es de cada job
		for(int nOps = 1; nOps <= numOperations; operationId++, nOps++){

			Operation operation = new Operation(route, operationId, instance.getNumMachines());			
			if(nOps > 1){
				operation.setPrecedent(lastOperation);
				lastOperation.setSucessor(operation);					
			}

			operations[nOps-1] = operation;
			route.addOperation(operation);

			//Se for um Flexible Job Shop,
			//H� mais uma op��o de maquina para cada opera��o
			//O c�digo a seguir faz o sorteio
			if(instance.getProblem().equals(ProblemType.FLEXIBLE_JOBSHOP)){

				int nSelectedMachines=0;
				double maxNumMachines = instance.getOpFlexibility()*instance.getNumMachines();		//above 50 percent the uniform distribution is not verified
				maxNumMachines=Math.ceil(maxNumMachines);
				int numMacsOp = Utils.getRandomInt(1, (int)maxNumMachines);
				if (numMacsOp>instance.getNumMachines()){
					System.out.println(" !!! Algo esta mal !!! ");
				}
				
				double processingTime = Utils.getRandomNumber(instance.getMinProcessingTime(), instance.getMaxProcessingTime());		// defines the mean procesing time of an operation in the different machine it can be processed

				Set<Integer> machineIDarray = new HashSet< Integer >(); 		
        
        		if (instance.getOpFlexibility()>10) {						// is a bit HARD CODED
					for(Machine mach: instance.getMachines()){
						nSelectedMachines=nSelectedMachines+1;
						double processingTimeJM=Math.max(processingTime*machinePerformance[mach.getId()-1]*(Utils.getRandomNumber(0.0, 1.0)*0.4+0.8),1);  // it is a bit HARD CODED
						operation.setTime(mach, processingTimeJM);						
					}
				}
				else{
					while(machineIDarray.size() < numMacsOp){
						int tentativeMachineID=Utils.getRandomInt(1, instance.getNumMachines());
						machineIDarray.add(tentativeMachineID);
						if (nSelectedMachines<machineIDarray.size()){
							nSelectedMachines=nSelectedMachines+1;
							double processingTimeJM=Math.max(processingTime*machinePerformance[tentativeMachineID-1]*(Utils.getRandomNumber(0.0, 1.0)*0.4+0.8),1);  // it is a bit HARD CODED
							Machine machine2 = instance.getMachine(tentativeMachineID);
							operation.setTime(machine2, processingTimeJM);
						}
					}
				}
				// finda a logica para o flexible job shop

				// VERBOSE
				//System.out.println("Number of Macs:            " + numMacsOp);
				//System.out.println("Effective Number of Macs:  " + nSelectedMachines);
			}
			else{

				int machineId = Utils.getRandomInt(1, instance.getNumMachines());
				Machine machine = instance.getMachine(machineId);

				if(!GlobalParameters.ALLOW_RECIRCULATION){
					//Como as inst�ncias assumem que n�o � permitido recircula��o,
					//N�o se pode escolher a mesma m�quina para duas opera�oes distintas na mesma rota
					while(choosenMachines[machineId-1]){
						machineId = Utils.getRandomInt(1, instance.getNumMachines());
					}						
					choosenMachines[machineId-1] = true;
				}
				else if(lastMachine != null)
				{
					//Mesmo com recircula��o, n�o se permite duas opera��es sucessivas na mesma maquina
					while(lastMachine.equals(machine)){
						machineId = Utils.getRandomInt(1, instance.getNumMachines());
						machine = instance.getMachine(machineId);
					}							
				}

				double time = Utils.getRoundedRandomNumber(instance.getMinProcessingTime(),instance.getMaxProcessingTime());				

				//System.out.println("Time "+time);
				operation.setTime(machine, time);
				lastMachine = machine;
			}
			lastOperation = operation;
			//termina o ciclo que determina as maquinas de cada operacao
			//dumpDebugDataOperations(operation.getId(), operation, jobId);
		}					
		job.calculateAuxiliaryData();	

		return job;
	}
	
	public static Job createJobFromRecord(Instance instance, int jobId, int operationId, JsonObject obj){

		Job job = new Job(jobId);

		Route route = new Route(job);			
		job.setRoute(route);	

		boolean[] choosenMachines = new boolean[instance.getNumMachines()];
		for(Machine machine: instance.getMachines()){
			choosenMachines[machine.getId()-1] = false;
		}

		int numOperations =Integer.valueOf(obj.get("nOperations").toString());
		Operation[] operations = new Operation[numOperations];

		Operation lastOperation = null;
		Machine lastMachine = null;
		//Criando as opera��es de cada job
		for(int nOps = 1; nOps <= numOperations; operationId++, nOps++){

			Operation operation = new Operation(route, operationId, instance.getNumMachines());			
			if(nOps > 1){
				operation.setPrecedent(lastOperation);
				lastOperation.setSucessor(operation);					
			}

			operations[nOps-1] = operation;
			route.addOperation(operation);

			if(instance.getProblem().equals(ProblemType.FLEXIBLE_JOBSHOP)){
					// loop array
					JsonArray opMachines = (JsonArray) obj.get("opMachines"+(nOps-1));
					JsonArray opTimes= (JsonArray) obj.get("opTimes"+(nOps-1));
					int controlo=0;
					Iterator<Object> iterator = opMachines.iterator();
					while (iterator.hasNext()) {
						//System.out.println(iterator.next().toString());
						int machineId=Integer.valueOf(iterator.next().toString());
						Machine m = instance.getMachine(machineId);
						double opMachineProcessingTime=opTimes.getDouble(controlo);
						operation.setTime(m, opMachineProcessingTime);
						controlo=controlo+1;
					}			
			}
			lastOperation = operation;
		}					
		job.calculateAuxiliaryData();	

		return job;
	}
	
	public static Job createJobFromRecordAlt(Instance instance, int jobId, int operationId, String str){

		Job job = new Job(jobId);

		Route route = new Route(job);			
		job.setRoute(route);	

		boolean[] choosenMachines = new boolean[instance.getNumMachines()];
		for(Machine machine: instance.getMachines()){
			choosenMachines[machine.getId()-1] = false;
		}
		Scanner sc = new Scanner(str);
    	sc.useDelimiter(";");
        double arrivalTime= Double.valueOf(sc.next());
		//System.out.println(String.valueOf(arrivalTime));

		int numOperations=Integer.valueOf(sc.next());
		//System.out.println(nOperations);
		Operation[] operations = new Operation[numOperations];

		Operation lastOperation = null;
		Machine lastMachine = null;
		//Criando as opera��es de cada job
		for(int nOps = 1; nOps <= numOperations; operationId++, nOps++){

			Operation operation = new Operation(route, operationId, instance.getNumMachines());			
			if(nOps > 1){
				operation.setPrecedent(lastOperation);
				lastOperation.setSucessor(operation);					
			}

			operations[nOps-1] = operation;
			route.addOperation(operation);

			if(instance.getProblem().equals(ProblemType.FLEXIBLE_JOBSHOP)){
				int nMachines=Integer.valueOf(sc.next());
				//System.out.println(nMachines);
				for(int j=0;j<nMachines;j++){
					int machineID=Integer.valueOf(sc.next());
					Machine m = instance.getMachine(machineID);
					double processingTime= Double.valueOf(sc.nextFloat());
					operation.setTime(m, processingTime);
				}
			}
			lastOperation = operation;
		}					
		job.calculateAuxiliaryData();	
		sc.close();

		return job;
	}	


}
