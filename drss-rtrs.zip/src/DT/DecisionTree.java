package DT;

// IMPORT LIST

public class DecisionTree {

    // CLASS VARIABLES
    public static int nPaths = 1;

    // CLASS METHODS        

    public static int checkDTPath0(double meanSlackinQueue, double meanEstLateness, double queueSize, double meanEstTardiness, double machineAvailability, double machineUtilisation, double arrivalRate, double cumArrivalRate, double expectedTardiness, double rpt, double bottleneckLoad, double bottleneckSlack){
        int ruleCode = -1;
        double min = Double.MAX_VALUE;
        double val = 0.0;


        if        ( ( machineUtilisation < 0.80 ) && ( machineUtilisation >= 0.76 ) && (expectedTardiness <=  800)){
                        ruleCode = 214;
        }
        else if   ( ( machineUtilisation <= 0.85 ) && ( machineUtilisation >= 0.80 ) && (expectedTardiness <=  400)){
                        ruleCode = 214;
        }
        else if   ( ( machineUtilisation <= 0.89 ) && ( machineUtilisation > 0.85 ) && (expectedTardiness <=  800)){
                        ruleCode = 214;
        }
        else if   ( ( machineUtilisation <= 0.91 ) && ( machineUtilisation > 0.89 ) && (expectedTardiness <=  50)){
                        ruleCode = 214;
        }
        else if (  1320775 * machineUtilisation + -2358799/2 > expectedTardiness ) {
            ruleCode =  18;
        }
        else if (  1320775 * machineUtilisation + -2358799/2 < expectedTardiness ) {
            // if ( ( expectedTardiness<= 15000) && (machineUtilisation>=0.89) ){
            //     ruleCode =  18;
            // }
            // else{
            //     ruleCode = 508;
            // }
            ruleCode = 508;
        }
        else{
            System.out.println("A regra de recurso teve que ser utilizada");
            ruleCode = 508;
        }
        
        return ruleCode;
    }
}