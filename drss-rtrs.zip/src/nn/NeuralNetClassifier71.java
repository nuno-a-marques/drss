package nn;

import org.neuroph.nnet.MultiLayerPerceptron;
import org.neuroph.core.transfer.Linear;
import org.neuroph.util.TransferFunctionType;
import org.apache.commons.math3.util.Precision;
import org.neuroph.core.Weight;

import main.GlobalParameters;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class NeuralNetClassifier71 {
    MultiLayerPerceptron mainNet   = new MultiLayerPerceptron(TransferFunctionType.SIGMOID, 3, 4,4,4,3);

    public NeuralNetClassifier71(){  
        // setup da neural net
        Linear ln1=new Linear();
        Linear ln2=new Linear();
        Linear ln3=new Linear();
        mainNet.getLayerAt(4).getNeuronAt(0).setTransferFunction(ln1);   // options, rectified linear
        mainNet.getLayerAt(4).getNeuronAt(1).setTransferFunction(ln2);   // options, rectified linear
        mainNet.getLayerAt(4).getNeuronAt(2).setTransferFunction(ln3);   // options, rectified linear
                                               
        // pesos                                                    !!! atualizar sempre
        // os pesos devem vir pela ordem do neuroph, ordem natural
        double [] readWeights = readNNWeights();                     // HC, hard coded
        
        // transfer dos pesos para a neural net
        int controlo=0;
        int nLayers=mainNet.getLayersCount();
        for(int l = 1; l < nLayers; l++){
            int nNeurons=mainNet.getLayerAt(l).getNeuronsCount();
            for(int n = 0; n < nNeurons; n++){
                Weight[] weightList     =   mainNet.getLayerAt(l).getNeuronAt(n).getWeights();
                for(int w=0;w<weightList.length;w++){                    
                    Weight weightTemp   =  weightList[w];
                    weightTemp.setValue(readWeights[controlo]);
                    controlo = controlo + 1 ;   
                }
            }
        }

        //int debugVar1 = getNNSugestion(1560.0, -15339.0);
        //int a = 1000/0;
    }

    public double[] getMainNetworkOutput(double x, double y, double z){
        double[] resultado;                                                           // !!! assume acoes 0 1 2 !!!
        double[] rowInput   =  new double[]{  x, y , z };
                                        
        mainNet.setInput(rowInput);
        mainNet.calculate();
        double[] networkOutputOne = mainNet.getOutput();
        resultado=networkOutputOne;
        
        // Debug
        //System.out.println("resultado antes da softmax");
        //System.out.println(String.valueOf(networkOutputOne[0]));
        //System.out.println(String.valueOf(networkOutputOne[1]));
        //System.out.println(String.valueOf(networkOutputOne[2]));

        return resultado;
    }

    public double[] readNNWeights(){
        String fileName = "";        
        fileName = "nn_param_" + GlobalParameters.NNSETUP + ".txt";
        double [] readWeights = new double[71];                     // HC, hard coded
        int controlo=0;
        try{
            File myObj = new File(fileName);
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                // System.out.println(data);                          // only in VERBOSE
                String[] tokens = data.split(",");                
                double   x = Double.parseDouble(tokens[1]);
                readWeights[controlo] = x;
                controlo = controlo + 1 ;  
        }
        myReader.close();
        }
        catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            int randomVar = 1000/0;
            e.printStackTrace();
        }

        return  readWeights;
    }

    public int getNNSugestion(double x1, double x2, double x3){
        // obter suggestions
        //x1 =  6765.0;
        //x2 = 27175.0;

        double resultado[] = getMainNetworkOutput(x1, x2 ,x3);
        SoftMax sft = new SoftMax(mainNet.getLayerAt(4));
        double[] resultado2 = sft.getLayerOutput(resultado);

        int out = 18;

        double q1 = resultado2[2];
        double q2 = resultado2[1];
        double q3 = resultado2[0];

        q1 = Precision.round(q1,5);
        q2 = Precision.round(q2,5);
        q3 = Precision.round(q3,5);

        if ( (q1 > q2) & (q1 > q3) ){
            out = 18;
            //System.out.print("a RR foi escolhida");
        }
        else{
            if (q2>q3){
                out = 214;
                //System.out.print("a Hunt foi escolhida");
            }
            else {
                out = 508;
            }
        }

        return out;
    }

}
