package nn;

import org.neuroph.core.Weight;
import org.neuroph.core.transfer.Linear;
import org.neuroph.nnet.MultiLayerPerceptron;
import org.neuroph.util.TransferFunctionType;

import main.GlobalParameters;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import org.apache.commons.math3.util.Precision;

public class NeuralNet4v {

    // SUPPORTS 4V 3R

    // CLASS VARIABLES
    MultiLayerPerceptron mainNet   = new MultiLayerPerceptron(TransferFunctionType.SIGMOID, 6, 6,6,6,1);

    // CLASS METHODS
    public NeuralNet4v(){  
        // setup da neural net
        Linear ln1=new Linear();                                        // options, rectified linear
        mainNet.getLayerAt(4).getNeuronAt(0).setTransferFunction(ln1);
        
        // pesos                                                    !!! atualizar sempre
        // os pesos devem vir pela ordem do neuroph, ordem natural
        double [] readWeights = readNNWeights();                     // HC, hard coded
        
        // transfer dos pesos para a neural net
        int controlo=0;
        int nLayers=mainNet.getLayersCount();
        for(int l = 1; l < nLayers; l++){
            int nNeurons=mainNet.getLayerAt(l).getNeuronsCount();
            for(int n = 0; n < nNeurons; n++){
                Weight[] weightList     =   mainNet.getLayerAt(l).getNeuronAt(n).getWeights();
                for(int w=0;w<weightList.length;w++){                    
                    Weight weightTemp   =  weightList[w];
                    weightTemp.setValue(readWeights[controlo]);
                    controlo = controlo + 1 ;   
                }
            }
        }
    }

    public double[] readNNWeights(){
        String fileName = "";        
        fileName = "nn_param_" + GlobalParameters.NNSETUP + ".txt";
        double [] readWeights = new double[133];                     // HC, hard coded
        int controlo=0;
        try{
            File myObj = new File(fileName);
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                // System.out.println(data);                          // only in VERBOSE
                String[] tokens = data.split(",");                
                double   x = Double.parseDouble(tokens[1]);
                readWeights[controlo] = x;
                controlo = controlo + 1 ;  
        }
        myReader.close();
        }
        catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            int randomVar = 1000/0;
            e.printStackTrace();
        }

        return  readWeights;
    }

    public double [] getActionConversion(int a){
        // 0  rr  0 0 1 0 0      18
        // 1  h2  0 0 0 1 0     214
        // 2  a9  0 0 0 0 1     508

        double [] out = {0.0, 0.0};         // standard for action 0 18 rr
        
        if      (a == 1) { out[0] = 1.0;  }
        else if (a == 2) { out[1] = 1.0;  }

        return out;
    }

    public double getMainNetworkOutput(double x, double y, double z, double w, int a){
        double resultado      =  0.0;
        double[] a_conversion =  getActionConversion(a);                                                            // !!! assume acoes 0 1 2 !!!
        double[] rowInput     =  new double[]{  x/10000.0, y/10000.0, z, w/10000.0, a_conversion[0], a_conversion[1]  };
                                        
        mainNet.setInput(rowInput);
        mainNet.calculate();
        double[] networkOutputOne = new double[]{mainNet.getOutput()[0]};
        resultado=networkOutputOne[0];        
        return resultado;
    }

    public int getNNSugestion(double x1, double x2, double x3, double x4){
        // obter suggestions

        int out = 18;

        int[]  ruleList  = {18, 214, 508};
        double qval      = - 999999999;

        for (int idx = 0; idx < 3; idx++) {                     // iterar entre as 6 regras disponiveis
            double qTemp = Precision.round ( getMainNetworkOutput(x1, x2, x3, x4, idx), 5 );
            if (qTemp >= qval) {                // ter cuidado comos empates
                out = ruleList[idx];         // code da regra em analise

                qval = qTemp;
            }
        }

        return out;
    }
    
}
