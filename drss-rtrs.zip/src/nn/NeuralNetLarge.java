package nn;

import org.neuroph.core.Weight;
import org.neuroph.core.transfer.Linear;
import org.neuroph.nnet.MultiLayerPerceptron;
import org.neuroph.util.TransferFunctionType;

import main.GlobalParameters;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import org.apache.commons.math3.util.Precision;

// SUPPORTS 2V 6R

public class NeuralNetLarge {
    // CLASS VARIABLES
    MultiLayerPerceptron mainNet   = new MultiLayerPerceptron(TransferFunctionType.SIGMOID, 7, 7,7,7,1);

    // CLASS METHODS
    public NeuralNetLarge(){  
        // setup da neural net
        Linear ln1=new Linear();                                        // options, rectified linear
        mainNet.getLayerAt(4).getNeuronAt(0).setTransferFunction(ln1);
        
        // pesos                                                    !!! atualizar sempre
        // os pesos devem vir pela ordem do neuroph, ordem natural
        double [] readWeights = readNNWeights();                     // HC, hard coded
        
        // transfer dos pesos para a neural net
        int controlo=0;
        int nLayers=mainNet.getLayersCount();
        for(int l = 1; l < nLayers; l++){
            int nNeurons=mainNet.getLayerAt(l).getNeuronsCount();
            for(int n = 0; n < nNeurons; n++){
                Weight[] weightList     =   mainNet.getLayerAt(l).getNeuronAt(n).getWeights();
                for(int w=0;w<weightList.length;w++){                    
                    Weight weightTemp   =  weightList[w];
                    weightTemp.setValue(readWeights[controlo]);
                    controlo = controlo + 1 ;   
                }
            }
        }
    }

    public double [] getActionConversion(int a){
        // 0  c2  0 0 0 0 0      22
        // 1  h4  1 0 0 0 0     216
        // 2  a8  0 1 0 0 0     507
        // 3  rr  0 0 1 0 0      18
        // 4  h2  0 0 0 1 0     214
        // 5  a9  0 0 0 0 1     508

        double [] out = {0.0, 0.0, 0.0, 0.0, 0.0};         // standard for action 0 22 cris2
        
        if      (a == 1) { out[0] = 1.0;  }
        else if (a == 2) { out[1] = 1.0;  }
        else if (a == 3) { out[2] = 1.0;  }
        else if (a == 4) { out[3] = 1.0;  }
        else if (a == 5) { out[4] = 1.0;  }

        return out;
    }

    public double getMainNetworkOutput(double x, double y, int a){
        double resultado      =  0.0;
        double[] a_conversion =  getActionConversion(a);                                                            // !!! assume acoes 0 1 2 !!!
        double[] rowInput     =  new double[]{  x/10000.0, y/10000.0, a_conversion[0], a_conversion[1], a_conversion[2], a_conversion[3], a_conversion[4]  };
                                        
        mainNet.setInput(rowInput);
        mainNet.calculate();
        double[] networkOutputOne = new double[]{mainNet.getOutput()[0]};
        resultado=networkOutputOne[0];        
        return resultado;
    }

    public int getNNSugestion(double x1, double x2){
        // obter suggestions

        int out = 18;

        int[]  ruleList  = {22, 216, 507, 18, 214, 508};
        double qval      = - 999999999;

        for (int idx = 0; idx < 6; idx++) {                     // iterar entre as 6 regras disponiveis
            double qTemp = Precision.round ( getMainNetworkOutput(x1, x2, idx), 5 );
            if (qTemp >= qval) {                // ter cuidado comos empates
                out = ruleList[idx];         // code da regra em analise

                qval = qTemp;
            }
        }

        //revealOutputs();       //only for debug

        return out;
    }

    public double[] readNNWeights(){
        String fileName = "";        
        fileName = "nn_param_" + GlobalParameters.NNSETUP + ".txt";
        double [] readWeights = new double[176];                     // HC, hard coded
        int controlo=0;
        try{
            File myObj = new File(fileName);
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                // System.out.println(data);                          // only in VERBOSE
                String[] tokens = data.split(",");                
                double   x = Double.parseDouble(tokens[1]);
                readWeights[controlo] = x;
                controlo = controlo + 1 ;  
        }
        myReader.close();
        }
        catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            int randomVar = 1000/0;
            e.printStackTrace();
        }

        return  readWeights;
    }
}
