package nn;

import org.neuroph.nnet.MultiLayerPerceptron;
import org.neuroph.core.transfer.Linear;
import org.apache.commons.math3.util.Precision;
import org.neuroph.core.Weight;
import org.neuroph.util.TransferFunctionType;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import main.GlobalParameters;

// todo
//  detetar a tipologia de modelo, 2, 3 ou 4 vars de input
//  ajustar as redes e as funcoes de decisao de acordo
//  get suggestion

public class NeuralNetRegressor {

    MultiLayerPerceptron model_18;
    MultiLayerPerceptron model_214;
    MultiLayerPerceptron model_508;

    int remainder = 1 ;

    public NeuralNetRegressor(int a){
        // void initializer
    }

    public NeuralNetRegressor(){
        
        // numero de neuronios de input
        setRemainder();
        int neuronios_input = getNumberInputNeurons() ;                                                                           
        int neuronios_total = getNumberNeurons()      ;

        Linear ln1=new Linear();
        Linear ln2=new Linear();
        Linear ln3=new Linear();

        model_18   = new MultiLayerPerceptron(TransferFunctionType.RECTIFIED, neuronios_input, 4,4,4,1);
        model_18.getLayerAt(4).getNeuronAt(0).setTransferFunction(ln1);

        model_214   = new MultiLayerPerceptron(TransferFunctionType.RECTIFIED, neuronios_input, 4,4,4,1);
        model_214.getLayerAt(4).getNeuronAt(0).setTransferFunction(ln2);

        model_508   = new MultiLayerPerceptron(TransferFunctionType.RECTIFIED, neuronios_input, 4,4,4,1);
        model_508.getLayerAt(4).getNeuronAt(0).setTransferFunction(ln3);

        double [] readWeights = readNNWeights(neuronios_total * 3);

        int controlo    =   0;
        int nLayers     =   model_18.getLayersCount();
        
        for(int l = 1; l < nLayers; l++){
            int nNeurons = model_18.getLayerAt(l).getNeuronsCount();
            for(int n = 0; n < nNeurons; n++){
                Weight[] weightList     =   model_18.getLayerAt(l).getNeuronAt(n).getWeights();
                for(int w=0;w<weightList.length;w++){                    
                    Weight weightTemp   =  weightList[w];
                    weightTemp.setValue(readWeights[controlo]);
                    controlo = controlo + 1 ;   
                }
            }
        }

        for(int l = 1; l < nLayers; l++){
            int nNeurons = model_214.getLayerAt(l).getNeuronsCount();
            for(int n = 0; n < nNeurons; n++){
                Weight[] weightList     =   model_214.getLayerAt(l).getNeuronAt(n).getWeights();
                for(int w=0;w<weightList.length;w++){                    
                    Weight weightTemp   =  weightList[w];
                    weightTemp.setValue(readWeights[controlo]);
                    controlo = controlo + 1 ;   
                }
            }
        }

        for(int l = 1; l < nLayers; l++){
            int nNeurons = model_508.getLayerAt(l).getNeuronsCount();
            for(int n = 0; n < nNeurons; n++){
                Weight[] weightList     =   model_508.getLayerAt(l).getNeuronAt(n).getWeights();
                for(int w=0;w<weightList.length;w++){                    
                    Weight weightTemp   =  weightList[w];
                    weightTemp.setValue(readWeights[controlo]);
                    controlo = controlo + 1 ;   
                }
            }
        }

        // debugNetworks();

    }

    public void setRemainder(){
        String configStr = String.valueOf(GlobalParameters.NNSETUP);
        configStr = configStr.substring(3,4);
        int configIDX = Integer.parseInt(configStr);
        remainder = configIDX;
    }

    public int getNumberInputNeurons(){
        int out = 0;
        if (remainder < 4) {
            out = 2;
        }
        else if (remainder < 6) {
            out = 3;
        }
        else {
            out = 4;
        }
        return out;
    }

    public int getNumberNeurons(){
        int out = 0;
        if (remainder < 4) {
            out = 57;
        }
        else if (remainder < 6) {
            out = 61;                                                     
        }
        else {
            out = 65;                                                     
        }
        return out;
    }

    public double[] readNNWeights(int nweights){
        String fileName = "";        
        fileName = "nn_param_" + GlobalParameters.NNSETUP + ".txt";
        double [] readWeights = new double[nweights];                     // HC, hard coded
        int controlo=0;
        try{
            File myObj = new File(fileName);
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                // System.out.println(data);                          // only in VERBOSE
                String[] tokens = data.split(",");                
                double   x = Double.parseDouble(tokens[1]);
                readWeights[controlo] = x;
                controlo = controlo + 1 ;  
        }
        myReader.close();
        }
        catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            int randomVar = 1000/0;
            e.printStackTrace();
        }

        return  readWeights;
    }

    public double[] getInputVector(double x, double y, double z, double w){
        // selecao das variaveis importantes
        double[] rowInput;
        if (remainder == 1) {
            // wip x tard
            rowInput = new double[]{  x , y  } ;
            return rowInput;
        }
        else if (remainder == 2) {
            // wip x earl
            rowInput = new double[]{  x , z  } ;
            return rowInput; 
        }
        else if (remainder == 3) {
            // wip x lat
            rowInput = new double[]{  x , w } ;
            return rowInput;  
        }
        else if (remainder == 4) {
            // wip x tard x earli 
            rowInput = new double[]{  x , y, z  };
            return rowInput;
        }
        else if (remainder == 5) { 
            // wip x earl lat
            rowInput = new double[]{  x , z, w  };
            return rowInput;
        }
        else if (remainder == 6) { 
            rowInput = new double[]{  x , y, z, w  };
            return rowInput;
        }
        double[] fakeInput = {0.0,0.0};
        return fakeInput;
    }

    public double[] getMainNetworkOutput(double x, double y, double z, double w){
        //     wip        tard     earl     lat 
        double[] resultado = {0.0, 0.0, 0.0};                                                           // !!! assume acoes 0 1 2 !!!
        double[] rowInput  = getInputVector(x, y, z, w);                                      // atualizar
            
        model_18.setInput(rowInput);
        model_18.calculate();
        double[] networkOutputOne = model_18.getOutput();
        resultado[0] = networkOutputOne[0];

        model_214.setInput(rowInput);
        model_214.calculate();
        double[] networkOutputTwo = model_214.getOutput();
        resultado[1] = networkOutputTwo[0];

        model_508.setInput(rowInput);
        model_508.calculate();
        double[] networkOutputThree = model_508.getOutput();
        resultado[2] = networkOutputThree[0];

        // Debug
        //System.out.println("resultado antes da softmax");
        //System.out.println(String.valueOf(networkOutputOne[0]));
        //System.out.println(String.valueOf(networkOutputOne[1]));
        //System.out.println(String.valueOf(networkOutputOne[2]));

        return resultado;
    }

    public int getSuggestion(double x, double y, double z, double w){
        //    wip   tard    earl   lat

        double [] resultado_1 = getMainNetworkOutput(x, y, z, w );

        int out = 18;

        double q1 = resultado_1[0];         // pred rr
        double q2 = resultado_1[1];         // pred h2
        double q3 = resultado_1[2];         // pred a9

        q1 = Precision.round(q1,5);
        q2 = Precision.round(q2,5);
        q3 = Precision.round(q3,5);

        if ( (q1 < q2) & (q1 < q3) ){
            out = 18;
            //System.out.print("a RR foi escolhida");
        }
        else{
            if (q2 < q3){
                out = 214;
                //System.out.print("a Hunt foi escolhida");
            }
            else {
                out = 508;
            }
        }

        return out;
    }    

    public void debugNetworks(){
        
        double [] resultado_1 = getMainNetworkOutput(2000, 150, 0, 0 );

        System.out.println( String.valueOf(  resultado_1[0]   )     );
        System.out.println( String.valueOf(  resultado_1[1]   )     );
        System.out.println( String.valueOf(  resultado_1[2]   )     );


        double [] resultado_2 = getMainNetworkOutput(5000, 3000, 0, 0 );

        System.out.println( String.valueOf(  resultado_2[0]   )     );
        System.out.println( String.valueOf(  resultado_2[1]   )     );
        System.out.println( String.valueOf(  resultado_2[2]   )     );

    }

    
}
