package nn;

import org.neuroph.core.Weight;
import org.neuroph.core.transfer.Linear;
import org.neuroph.nnet.MultiLayerPerceptron;
import org.neuroph.util.TransferFunctionType;

import main.GlobalParameters;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import org.apache.commons.math3.util.Precision;

// SUPPORTS 2V 3R

public class NeuralNet {
    // CLASS VARIABLES
    MultiLayerPerceptron mainNetSmall   = new MultiLayerPerceptron(TransferFunctionType.SIGMOID, 4, 4,4,4,1);        // UPDT
    MultiLayerPerceptron mainNetLarge   = new MultiLayerPerceptron(TransferFunctionType.SIGMOID, 5, 5,5,5,1);        // UPDT
    // CLASS METHODS
    public NeuralNet(){  
        // setup da neural net

        if (      GlobalParameters.rtrsSS.equals("ss-1") ){
            setupNetworkSmall();
        }
        else if ( GlobalParameters.rtrsSS.equals("ss-2") ){
            setupNetworkSmall();
        }
        else if ( GlobalParameters.rtrsSS.equals("ss-3") ){
            setupNetworkLarge();
        }
        
    }

    public NeuralNet(int a){
        
    }

    public void setupNetworkSmall(){
        Linear ln1=new Linear();                                        // options, rectified linear
        mainNetSmall.getLayerAt(4).getNeuronAt(0).setTransferFunction(ln1);
        
        // pesos                                                    !!! atualizar sempre
        // os pesos devem vir pela ordem do neuroph, ordem natural
        double [] readWeights = readNNWeights(65);                     // HC, hard coded   65 or 96
        
        // transfer dos pesos para a neural net
        int controlo=0;
        int nLayers=mainNetSmall.getLayersCount();
        for(int l = 1; l < nLayers; l++){
            int nNeurons=mainNetSmall.getLayerAt(l).getNeuronsCount();
            for(int n = 0; n < nNeurons; n++){
                Weight[] weightList     =   mainNetSmall.getLayerAt(l).getNeuronAt(n).getWeights();
                for(int w=0;w<weightList.length;w++){                    
                    Weight weightTemp   =  weightList[w];
                    weightTemp.setValue(readWeights[controlo]);
                    controlo = controlo + 1 ;   
                }
            }
        }
    }

    public void setupNetworkLarge(){
        Linear ln1=new Linear();                                        // options, rectified linear
        mainNetSmall.getLayerAt(4).getNeuronAt(0).setTransferFunction(ln1);
        
        // pesos                                                    !!! atualizar sempre
        // os pesos devem vir pela ordem do neuroph, ordem natural
        double [] readWeights = readNNWeights(96);                     // HC, hard coded   65 or 96
        
        // transfer dos pesos para a neural net
        int controlo=0;
        int nLayers=mainNetSmall.getLayersCount();
        for(int l = 1; l < nLayers; l++){
            int nNeurons=mainNetSmall.getLayerAt(l).getNeuronsCount();
            for(int n = 0; n < nNeurons; n++){
                Weight[] weightList     =   mainNetSmall.getLayerAt(l).getNeuronAt(n).getWeights();
                for(int w=0;w<weightList.length;w++){                    
                    Weight weightTemp   =  weightList[w];
                    weightTemp.setValue(readWeights[controlo]);
                    controlo = controlo + 1 ;   
                }
            }
        }
    }

    public double [] getActionConversion(int a){
        // 0  rr  0 0
        // 1  h2  1 0
        // 2  a9  0 1

        double [] out = {0.0, 0.0};         // standard for action 0 18 rr
        
        if      (a == 1) { out[0] = 1.0;  }
        else if (a == 2) { out[1] = 1.0;  }

        return out;
    }

    public double[] readNNWeights( int numParams){
        String fileName = "";        
        fileName = "nn_param_" + GlobalParameters.NNSETUP + ".txt";
        double [] readWeights = new double[numParams];                     // HC, hard coded     65 or 96
        int controlo=0;
        try{
            File myObj = new File(fileName);
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                // System.out.println(data);                          // only in VERBOSE
                String[] tokens = data.split(",");                
                double   x = Double.parseDouble(tokens[1]);
                readWeights[controlo] = x;
                controlo = controlo + 1 ;  
        }
        myReader.close();
        }
        catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            int randomVar = 1000/0;
            e.printStackTrace();
        }

        return  readWeights;
    }

    public double baseVarTransformation(double val){
        return ( val / 10000.0 ) ;
    }

    public double logVarTransformations(double val){
        return ( Math.log( val + 1.0) );
    }

    public double getMainNetworkOutput(double x, double y, double z, int a){
        double resultado    =  0.0;
        double[] a_conversion =  getActionConversion(a);                                                            // !!! assume acoes 0 1 2 !!!
        
        
        if (      GlobalParameters.rtrsSS.equals("ss-1") ){
            double[] rowInput   =  new double[]{  logVarTransformations(x), logVarTransformations(y), a_conversion[0], a_conversion[1]  };
            mainNetSmall.setInput(rowInput);
            mainNetSmall.calculate();
            double[] networkOutputOne = new double[]{mainNetSmall.getOutput()[0]};
            resultado=networkOutputOne[0]; 
        }
        else if ( GlobalParameters.rtrsSS.equals("ss-2") ){
            double[] rowInput   =  new double[]{  logVarTransformations(x), logVarTransformations(z), a_conversion[0], a_conversion[1]  };
            mainNetSmall.setInput(rowInput);
            mainNetSmall.calculate();
            double[] networkOutputOne = new double[]{mainNetSmall.getOutput()[0]};
            resultado=networkOutputOne[0];
        }
        else if ( GlobalParameters.rtrsSS.equals("ss-3") ){
            double[] rowInput   =  new double[]{  logVarTransformations(x), logVarTransformations(y), logVarTransformations(z), a_conversion[0], a_conversion[1]  };
            mainNetLarge.setInput(rowInput);
            mainNetLarge.calculate();
            double[] networkOutputOne = new double[]{mainNetLarge.getOutput()[0]};
            resultado=networkOutputOne[0];
        }
  
        return resultado;
    }

    public int getNNSugestion(double x1, double x2, double x3){
        // obter suggestions

        int out = 18;

        // transformacao
        //x1 = Math.log(x1+1.0);
        //x2 = Math.log(x2+1.0);

        double q1 = getMainNetworkOutput(x1, x2, x3, 0);
        double q2 = getMainNetworkOutput(x1, x2, x3, 1);
        double q3 = getMainNetworkOutput(x1, x2, x3, 2);

        q1 = Precision.round(q1,5);
        q2 = Precision.round(q2,5);
        q3 = Precision.round(q3,5);

        if ( (q1 > q2) & (q1 > q3) ){
            out = 18;
        }
        else{
            if (q2>q3){
                out = 214;
            }
            else {
                out = 508;
            }
        }

        //revealOutputs();       //only for debug

        return out;
    }

}
