package nn;

import org.neuroph.nnet.MultiLayerPerceptron;
import org.neuroph.core.transfer.Linear;
import org.neuroph.util.TransferFunctionType;
import org.apache.commons.math3.util.Precision;
import org.neuroph.core.Weight;

import main.GlobalParameters;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class NeuralNetClassFlex {
    
    MultiLayerPerceptron mainNet;
    int remainder;

    public NeuralNetClassFlex(){
    
        // setup da neural net
        int[] nnparams = getNoInputNeurons();
        mainNet   = new MultiLayerPerceptron(TransferFunctionType.SIGMOID, nnparams[0], 4,4,4,3);

        Linear ln1=new Linear();
        Linear ln2=new Linear();
        Linear ln3=new Linear();
        mainNet.getLayerAt(4).getNeuronAt(0).setTransferFunction(ln1);   // options, rectified linear
        mainNet.getLayerAt(4).getNeuronAt(1).setTransferFunction(ln2);   // options, rectified linear
        mainNet.getLayerAt(4).getNeuronAt(2).setTransferFunction(ln3);   // options, rectified linear
                                               
        // pesos                                                    !!! atualizar sempre
        // os pesos devem vir pela ordem do neuroph, ordem natural
        double [] readWeights = readNNWeights(nnparams[1]);                     // HC, hard coded
        
        // transfer dos pesos para a neural net
        int controlo=0;
        int nLayers=mainNet.getLayersCount();
        for(int l = 1; l < nLayers; l++){
            int nNeurons=mainNet.getLayerAt(l).getNeuronsCount();
            for(int n = 0; n < nNeurons; n++){
                Weight[] weightList     =   mainNet.getLayerAt(l).getNeuronAt(n).getWeights();
                for(int w=0;w<weightList.length;w++){                    
                    Weight weightTemp   =  weightList[w];
                    weightTemp.setValue(readWeights[controlo]);
                    controlo = controlo + 1 ;   
                }
            }
        }
        //int debugVar1 = getNNSugestion(1560.0, -15339.0);
        //int a = 1000/0;
    }

    public NeuralNetClassFlex(int a){  
    }

    public int[] getNoInputNeurons(){

        int [] output = { 0, 0 };
        int nparams = 0;
        String configStr = String.valueOf(GlobalParameters.NNSETUP);
        configStr = configStr.substring(3,4);
        int configIDX = Integer.parseInt(configStr);
        remainder = configIDX;

        int out = 0;
        if (configIDX < 4) {
            out = 2;
            nparams = 67;
        }
        else if (configIDX <6){
            out = 3;
            nparams = 71;
        }
        else {
            out = 4;
            nparams = 75;
        }

        output[0] = out;
        output[1] = nparams;

        return output;
    }

    public double[] getInputVector(double x, double y, double z, double w){
        // selecao das variaveis importantes
        double[] rowInput;
        if (remainder == 1) {
            // wip x tard
            rowInput = new double[]{  x , y  } ;
            return rowInput;
        }
        else if (remainder == 2) {
            // wip x earl
            rowInput = new double[]{  x , z  } ;
            return rowInput; 
        }
        else if (remainder == 3) {
            // wip x lat
            rowInput = new double[]{  x , w } ;
            return rowInput;  
        }
        else if (remainder == 4) {
            // wip x tard x earli 
            rowInput = new double[]{  x , y, z  };
            return rowInput;
        }
        else if (remainder == 5) { 
            // wip x earl lat
            rowInput = new double[]{  x , z, w  };
            return rowInput;
        }
        else if (remainder == 6) { 
            rowInput = new double[]{  x , y, z, w  };
            return rowInput;
        }
        double[] fakeInput = {0.0,0.0};
        return fakeInput;
    }

    public double[] getMainNetworkOutput(double x, double y, double z, double w){
                                    //     wip        tard     earl     lat 
        double[] resultado;                                                           // !!! assume acoes 0 1 2 !!!
        double[] rowInput= getInputVector(x, y, z, w);
                                   
        mainNet.setInput(rowInput);
        mainNet.calculate();
        double[] networkOutputOne = mainNet.getOutput();
        resultado=networkOutputOne;
        
        // Debug
        //System.out.println("resultado antes da softmax");
        //System.out.println(String.valueOf(networkOutputOne[0]));
        //System.out.println(String.valueOf(networkOutputOne[1]));
        //System.out.println(String.valueOf(networkOutputOne[2]));

        return resultado;
    }

    public double[] readNNWeights(int nweights){
        String fileName = "";        
        fileName = "nn_param_" + GlobalParameters.NNSETUP + ".txt";
        double [] readWeights = new double[nweights];                     // HC, hard coded
        int controlo=0;
        try{
            File myObj = new File(fileName);
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                // System.out.println(data);                          // only in VERBOSE
                String[] tokens = data.split(",");                
                double   x = Double.parseDouble(tokens[1]);
                readWeights[controlo] = x;
                controlo = controlo + 1 ;  
        }
        myReader.close();
        }
        catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            int randomVar = 1000/0;
            e.printStackTrace();
        }

        return  readWeights;
    }

    public int getNNSugestion(double x1, double x2, double x3, double x4){
        //                       wip      tard        earl        lat

        // obter suggestions
        //x1 =  6765.0;
        //x2 = 27175.0;

        double resultado[] = getMainNetworkOutput(x1, x2, x3, x4 );

        SoftMax sft = new SoftMax(mainNet.getLayerAt(4));
        double[] resultado2 = sft.getLayerOutput(resultado);

        int out = 18;

        double q1 = resultado2[2];
        double q2 = resultado2[1];
        double q3 = resultado2[0];

        q1 = Precision.round(q1,5);
        q2 = Precision.round(q2,5);
        q3 = Precision.round(q3,5);

        if ( (q1 > q2) & (q1 > q3) ){
            out = 18;
            //System.out.print("a RR foi escolhida");
        }
        else{
            if (q2>q3){
                out = 214;
                //System.out.print("a Hunt foi escolhida");
            }
            else {
                out = 508;
            }
        }

        return out;
    }

}
