package nn;

//package org.neuroph.contrib.learning;

import org.neuroph.core.Layer;
import org.neuroph.core.Neuron;
import org.neuroph.core.transfer.TransferFunction;

/**
 * Activation function which enforces that output neurons have probability distribution (sum of all outputs is one)
 */
public class SoftMax extends TransferFunction {

    private Layer layer;
    private double totalLayerInput;

    public SoftMax(final Layer layer) {
        this.layer = layer;
    }


    @Override
    public double getOutput(double netInput) {
        totalLayerInput = 0;
                // add max here for numerical stability - find max netInput for all neurons in this lyer
        double max = 0;
        
        for (Neuron neuron : layer.getNeurons()) {
            totalLayerInput += Math.exp(neuron.getNetInput()-max);
        }

        double out_0 = Math.exp(netInput-max) / totalLayerInput;

        System.out.println(String.valueOf(out_0));

        return out_0;
    }

    public double[] getLayerOutput(double[] netInput){
        totalLayerInput = 0;
        // add max here for numerical stability - find max netInput for all neurons in this lyer
        double max = 0;

        for (Neuron neuron : layer.getNeurons()) {
            totalLayerInput += Math.exp(neuron.getNetInput()-max);
        }

        //debug
        //System.out.println("normalizacao softmax");
        //System.out.println(totalLayerInput);

        double out_0 = Math.exp(netInput[0]-max) / totalLayerInput;
        double out_1 = Math.exp(netInput[1]-max) / totalLayerInput;
        double out_2 = Math.exp(netInput[2]-max) / totalLayerInput;

        // debug
        //System.out.println("layer final apos normalizacao");
        //System.out.println(String.valueOf(out_0));
        //System.out.println(String.valueOf(out_1));
        //System.out.println(String.valueOf(out_2));

        double [] output = { out_0, out_1, out_2};
        return output;
    }

    @Override
    public double getDerivative(double net) {
        return output * (1d - output); // ovaj izvod nije dobar vec zavisi koji je neuron - ima dva izvoda
        // -yi * yj
    }
}
