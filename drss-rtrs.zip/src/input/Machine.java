package input;


public class Machine {
	private int id;
	private boolean robot;
	
	public boolean isRobot() {
		return robot;
	}

	public void setRobot(boolean robot) {
		this.robot = robot;
	}

	public Machine(int id, boolean r){
		this.id  = id;
		this.robot = r;
	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	
	public boolean equals(Object obj) {
	    if (this == obj)
	      return true;
	    if (obj == null)
	      return false;
	    if (getClass() != obj.getClass())
	      return false;
	    
	    Machine other = (Machine) obj;
	    if (id == other.getId()) {
	        return true;
	    } else 
	      return false;
	  }		
}
