package input;

import java.util.ArrayList;
import java.util.List;

public class Operation  implements Comparable<Operation>{
	
	private int id;
	boolean terminal;
	private double actualOperationTime;
	private double dueDate;
	
	private double times[];
	List<Machine> eligibleMachines;

	Operation precedent;
	Operation sucessor;
		
	private Route route;
	double averageProcessingtime;
	double minProcessingTime;
	int bestMachineID;
	
	public Operation(Route r, int id, int nMachines){
		this.id = id;
		precedent = null;
		sucessor = null;
		eligibleMachines = new ArrayList<Machine>();
		
		route = r;
		averageProcessingtime = 0;
		terminal = true;
		actualOperationTime = 0;
		
		times = new double[nMachines];
		for(int i=0; i< nMachines; i++) {
			times[i] = Double.MAX_VALUE;
		}

		minProcessingTime=Double.MAX_VALUE;
		bestMachineID=0;

	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	
	public int compareTo(Operation operation) {
		if (this.id < operation.getId())
			return -1;
		else if(this.id > operation.getId())
			return 1;
		else
			return 0;
	}
	
	public double getDueDate() {
		return dueDate;
	}

	public void setDueDate(double dueDate) {
		this.dueDate = dueDate;
	}	
		
	public boolean equals(Object obj) {
	    if (this == obj)
	      return true;
	    if (obj == null)
	      return false;
	    if (getClass() != obj.getClass())
	      return false;
	    
	    Operation other = (Operation) obj;
	    if (id == other.getId()) {
	        return true;
	    } else 
	      return false;
	  }	 		
	
	public double getAverageExpectedTime(){
			
		return averageProcessingtime;
	}
	
	public void setAverageExpectedTime(double t){
		averageProcessingtime = t;
	}

	public void updateMinProcessingTime(double val, int macid){
		minProcessingTime=Math.min(minProcessingTime,val);
		if (val==minProcessingTime){
			bestMachineID=macid;
		}
	}

	public int getBestMachine(){
		return bestMachineID;
	}

	public double getMinProcessingTime(){
		return minProcessingTime;
	}

	public Route getRoute() {
		return route;
	}
	
	public boolean hasPrecedent(){
		return (precedent != null);
	}

	
	public Job getJob(){
		return route.getJob();
	}
	
	public void setPrecedent(Operation operation){
		terminal = false;
		precedent = operation;
	}
	
	public boolean isTerminal() {
		return terminal;
	}

	public void setSucessor(Operation operation){
		sucessor = operation;
	}	
	
	public Operation getPrecedent(){
		return precedent;
	}
	
	public Operation getSucessor(){
		return sucessor;
	}

	public void setTime(Machine machine, double time) {
		eligibleMachines.add(machine);
		times[machine.getId()-1] = time;
	}
	
	public double getTime(Machine machine) {
		return times[machine.getId()-1];
	}

	public double getTimebyMachineIDX(int idx) {
		return times[idx];
	}

	public boolean isEligible(Machine machine) {
		return times[machine.getId()-1] < Double.MAX_VALUE;
	}
	
	public List<Machine> getEligibleMachines(){
		return eligibleMachines;
	}
	
	public int getNumEligibleMachines() {
		return eligibleMachines.size();
	}
	
	public Machine getFirstMachine() {
		return eligibleMachines.get(0);
	}
	
	public double getActualOperationTime() {
		return actualOperationTime;
	}
	
	public void setActualOperationTime(double actualOperationTime) {
		this.actualOperationTime = actualOperationTime;
	}	
	
	public boolean isExecuted(){
		
		return actualOperationTime > 0;
	}	

}
