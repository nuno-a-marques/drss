package input;

public class Job {
	
	protected int id;
	protected int numOperationsWorstCase;
	protected int numOperationsBestCase;
	protected int totalNumOperations;
	protected double avgProcessingTime;
	protected double arrivalTime;
	protected double dueDate;	
	protected Route route;
	protected double earliestCompletionTime;
	
	public Job(int id){
		
		this.id = id;
		numOperationsWorstCase = Integer.MAX_VALUE;
		numOperationsBestCase = 0;	
		avgProcessingTime = 0;
		arrivalTime = 0;
		earliestCompletionTime= 0;
		dueDate = Integer.MAX_VALUE;
		route = null;
	}
	
	public void setRoute(Route r){
		route = r;
	}
	
	public Route getRoute(){
		return route;
	}
	
	public int getId(){
		return id;
	}	
	
	public int getNumOperations(Route route){
		return route.getNumOperations();
	}
	
	public int getNumOperationsBestCase(){

		return numOperationsBestCase;
	}
	
	public int getNumOperationsWorstCase(){

		return numOperationsWorstCase;		
	}
	
	
	public double getAvgProcessingTime() {
		return avgProcessingTime;
	}
	
	public int getTotalNumOperations(){
		return totalNumOperations;
	}
	
	public double getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(double a) {
		this.arrivalTime = a;
	}

	public double getDueDate() {
		return dueDate;
	}
	
	public void setDueDate(double allowanceFactor) {
		//System.out.println("A definir a DUE DATE");
		//System.out.println(avgProcessingTime);
		double correctionFactor=0.0;
		//System.out.println("Arrival T:  " + String.valueOf(arrivalTime));
		this.dueDate = arrivalTime + (avgProcessingTime)*allowanceFactor;
		//System.out.println("Due Date:  " + String.valueOf(this.dueDate));		
	
		double cummulativeTime = 0;
		for (Operation operation: route.getOperations()) {
			cummulativeTime+= (operation.getAverageExpectedTime()-correctionFactor);
			double opDueDate = arrivalTime + allowanceFactor*cummulativeTime;
			operation.setDueDate(opDueDate);
		}
	
		earliestCompletionTime = dueDate + avgProcessingTime;	
	}		
	
	public double getEarliestCompletionTime() {
		return earliestCompletionTime;
	}

	public boolean equals(Object obj) {
	    if (this == obj)
	      return true;
	    if (obj == null)
	      return false;
	    if (getClass() != obj.getClass())
	      return false;
	    
	    Job other = (Job) obj;
	    if (id == other.getId()) {
	        return true;
	    } else 
	      return false;
	  }
	
	public void calculateAuxiliaryData(){
						
		numOperationsBestCase = Integer.MAX_VALUE;
		numOperationsWorstCase = 0;	
		totalNumOperations = 0;
		avgProcessingTime = 0;		
			
		for(Operation operation: route.getOperations()){
			
			double avgTime = 0;
			for(Machine machine: operation.getEligibleMachines())
			{							
				avgTime += operation.getTime(machine);
				operation.updateMinProcessingTime(operation.getTime(machine), machine.getId());		
			}	
			operation.setAverageExpectedTime((int) avgTime/operation.getNumEligibleMachines());								
			avgProcessingTime += operation.getAverageExpectedTime();
			//System.out.println("Op Avg time: " + operation.getAverageExpectedTime());
			//System.out.println("Job Avg time: " + String.valueOf(avgProcessingTime));
		}	

		totalNumOperations += route.getOperations().size();
		route.setTotalProcessingTime(avgProcessingTime);
		
		if(route.getNumOperations() < numOperationsBestCase)
			numOperationsBestCase = route.getNumOperations();	
		if(route.getNumOperations() > numOperationsWorstCase)
			numOperationsWorstCase = route.getNumOperations();						
			
	}
}
