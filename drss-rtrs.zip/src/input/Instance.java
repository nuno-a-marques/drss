package input;
import java.util.ArrayList;
import java.util.List;

import main.GlobalParameters;
import utils.Utils.ProblemType;

public class Instance {

	private String name;
	private ProblemType problem;
	private double averageProcessingTime;
	
	//Atributos utilizados para a geracao dos dados da instancia
	private int numMachines;
	private int minProcessingTime;
	private int maxProcessingTime;
	private int minNumOperations;
	private int maxNumOperations;
	private double opFlexibility;	

	private List<Machine> machines;	
	
	public Instance(String name, ProblemType p){
		this.name = name;
		this.problem = p;
		this.machines = new ArrayList<Machine>();
		averageProcessingTime = 0;			
	}	
	
	public double getAverageProcessingTime() {
		return averageProcessingTime;
	}
	public void setAverageProcessingTime(double avg) {
		this.averageProcessingTime = avg;
	}
	public ProblemType getProblem() {
		return problem;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	public int getNumMachines() {
		return numMachines;
	}
	public void setNumMachines(int m) {
		this.numMachines = m;
	}
	public int getMinProcessingTime() {
		return minProcessingTime;
	}
	public void setMinProcessingTime(int minProcessingTime) {
		this.minProcessingTime = minProcessingTime;
	}
	public int getMaxProcessingTime() {
		return maxProcessingTime;
	}
	public void setMaxProcessingTime(int maxProcessingTime) {
		this.maxProcessingTime = maxProcessingTime;
	}
	public int getMinNumOperations() {
		return minNumOperations;
	}
	public void setMinNumOperations(int minNumOperations) {
		this.minNumOperations = minNumOperations;
	}
	public int getMaxNumOperations() {
		return maxNumOperations;
	}
	public void setMaxNumOperations(int maxNumOperations) {
		this.maxNumOperations = maxNumOperations;
	}

	public double getMeanNumberofOperationsperJob(){
		double resultado=(maxNumOperations+minNumOperations)/2;
		return resultado;
	}

	public double getMeanNumberofMachinesperOperation(){
		double resultado=(double) numMachines/2;
		return resultado;
	}

	public double getMeanOperationProcessingTime(){
		double resultado=(double) (minProcessingTime+maxProcessingTime)/2;
		return resultado;
	}


	public void setName(String name) {
		this.name = name;
	}
	
	public List<Machine> getMachines(){
		return machines;
	}	

	public void addMachine(Machine machine){
				
		machines.add(machine);		
	}

	public double getOpFlexibility() {
		return opFlexibility;
	}

	public void setOpFlexibility(double opFlexibility) {
		this.opFlexibility = opFlexibility;
	}
	
	public Machine getMachine(int machineId) {
		return machines.get(machineId-1);
	}
	
	public void print(){
		
		System.out.println("Instance Id  = "+name);
		System.out.println("numMachines = "+numMachines);
		System.out.println("minProcessingTime = "+minProcessingTime);
		System.out.println("maxProcessingTime = "+maxProcessingTime);
		System.out.println("minNumOperations = "+minNumOperations);
		System.out.println("maxNumOperations = "+maxNumOperations);
		System.out.println("opFlexibility = "+opFlexibility);

		
	}
	
	public void describeInstance(double alevel, double ulevel, double cvfactor){
		System.out.println("PARAMETROS DA INSTANCIA");
		System.out.println("Numero de maquinas = "+numMachines);
		System.out.println("Numero de jobs warm up = "+GlobalParameters.MIN_JOBS_STEADY_STATE);
		System.out.println("Numero de jobs total = "+GlobalParameters.MAX_JOBS_STEADY_STATE);
		System.out.println("Numero medio de operacoes por job = "+String.valueOf(getMeanNumberofOperationsperJob()));
		System.out.println("Numero medio de maquinas por operacao perct = "+String.valueOf(getOpFlexibility()));
		System.out.println("Tempo medio de processamento = "+String.valueOf(getMeanOperationProcessingTime()));
		System.out.println("Allowance = "+String.valueOf(alevel));
		System.out.println("Utilisation = "+String.valueOf(ulevel));
		System.out.println("CV = "+String.valueOf(cvfactor));		
	}
	
	public void clearData(){
		machines.clear();
	}
}
