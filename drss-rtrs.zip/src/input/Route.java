package input;

import java.util.ArrayList;
import java.util.List;

public class Route {

	double totalProcessingTime;
	
	/**
	*  Operations order
	*  First element is the sequence order of operations - starting by 1
	*  Second is the operation
	*/
	List<Operation> operations;
	List<Operation> terminalOperations;
	
	private Job job;

	public Route(Job j) {
		super();
		this.job = j;
		totalProcessingTime = 0;
		
		operations = new ArrayList<Operation>();	
		terminalOperations = new ArrayList<Operation>();
	}
	
	public Job getJob() {
		return job;
	}

	public void setJob(Job job) {
		this.job = job;
	}
	
	public  List<Operation> getOperations(){
		return operations;
	}
	
	public  List<Operation> getTerminalOperations(){
		return terminalOperations;
	}	
	
	public void addOperation(Operation operation){
		operations.add(operation);
		
		if(operation.getPrecedent() == null)
			terminalOperations.add(operation);
	}
	
	public double getTotalProcessingTime(){
		
		return totalProcessingTime;
	}
	
	public void setTotalProcessingTime(double time){
		totalProcessingTime = time;
	}	
	
	public int getNumOperations(){
		return operations.size();
	}	
	
}
