package simulator;

import input.Job;
import input.Operation;
import input.Route;


public class ActualJob extends Job{

	Route route;
	int numOperationsLeft;	
	double remainingProcessingTime;
	double dueDate;
	double arrivalTime;

	public ActualJob(Job j) {		
		super(j.getId());
		
		numOperationsWorstCase 	= j.getNumOperationsWorstCase();
		numOperationsBestCase 	= j.getNumOperationsBestCase();
		dueDate					= j.getDueDate();
		arrivalTime				= j.getArrivalTime();
	
		route = null;
		numOperationsLeft = j.getNumOperationsBestCase();
		remainingProcessingTime = j.getAvgProcessingTime();		
	}

	public int getNumOperationsLeft() {
		return numOperationsLeft;
	}

	public double getRemainingProcessingTime() {
		return remainingProcessingTime;
	}

	public Route getRoute() {
		return route;
	}

	public void initializeRouteExecution(Route route) {
		this.route = route;
		this.numOperationsLeft = route.getNumOperations();
		this.remainingProcessingTime = 0;
		for(Operation operation: route.getOperations()){
			remainingProcessingTime += operation.getAverageExpectedTime();
		}
	}		
		
	public void addActualOperation(Operation operation)
	{			
		numOperationsLeft=numOperationsLeft-1;
				
		remainingProcessingTime = 0;
		for(Operation op: route.getOperations()){
			if(!op.isExecuted())
				remainingProcessingTime += op.getAverageExpectedTime();
		}
	}	
	
	public double getDueDate() {
		return dueDate;
	}

	public double getArrivalTime() {
		return arrivalTime;
	}
	
}
