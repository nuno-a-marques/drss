package simulator;

import java.util.Locale;

import main.GlobalParameters;

import java.io.*;

public class PerformanceMetrics {

	private double meanFlowTime;
	private double maxFlowTime;
	private double varFlowTime;
	private double fullTardiness;
	private double meanTardiness;
	private double maxTardiness;
	private double totalTardiness;
	private double varTardiness;
	private double percentageTardyJobs;
	private double makespan;
	private double relativePerformanceTardiness;
	private double relativePerformanceTardyJobs;
	private double relativePerformanceFlowtime;

	private double utilisationRealCum;
	private double utilisationReal;
	private double totalFinishTime;

	private double processingTimeReal;
	private double processingTimeRealCum;
	private double processingTimeEntries;
	private double overallStartTime;		// deprecated
	private double overallFinishTime;		// deprecated

	private double meanQueueSize;
	private double meanRealQueueSize;
	private double queueSizeEntries;
	private double maxMeanQueue;
	
	private double[] flowtimeJobs;
	private double[] tardinessJobs;
	private double totalTardinessNormalized;
	private double meanFlowTimeNormalized;

	private boolean queueThresholdExceeded;

	// HARD CODED VALUES
	// TREINO
	//public static double[] benchmarkList	=	{	528569, 326706, 879981, 655605, 310318, 152888, 545673, 354509	};			// benchmarks week 25
	//public static double[] benchmarkFTList	=	{	704, 704, 880, 880, 589, 589, 710, 710	};								// benchmarks week 25
	// TESTE
	public static double[] benchmarkList		=	{	1,1,1,1,1, 1,1,1,1,1, 1,1,1,1,1, 1,1,1,1,1, 1,1,1,1,1	};			// benchmarks week 25
	public static double[] benchmarkFTList		=	{	1,1,1,1,1, 1,1,1,1,1, 1,1,1,1,1, 1,1,1,1,1, 1,1,1,1,1	};			// benchmarks week 25
		
	public PerformanceMetrics() {
		super();
		
		meanFlowTime 					= 0.0;
		maxFlowTime 					= 0.0;
		varFlowTime 					= 0.0;
		fullTardiness					= 0.0;
		meanTardiness 					= 0.0;
		maxTardiness 					= 0.0;
		varTardiness 					= 0.0;
		percentageTardyJobs 			= 0.0;
		makespan 						= 0.0;	
		relativePerformanceTardiness	= 0.0;
		relativePerformanceTardyJobs	= 0.0;
		relativePerformanceFlowtime		= 0.0;
		maxMeanQueue					= 0.0;
		
		flowtimeJobs = new double[GlobalParameters.MAX_JOBS_STEADY_STATE - GlobalParameters.MIN_JOBS_STEADY_STATE];
		tardinessJobs = new double[GlobalParameters.MAX_JOBS_STEADY_STATE - GlobalParameters.MIN_JOBS_STEADY_STATE];
		totalTardinessNormalized		= 0.0;
		meanFlowTimeNormalized			= 0.0;

		utilisationRealCum				= 0.0;
		totalFinishTime					= 0.0;
		utilisationReal					= 0.0;
		
		processingTimeRealCum			= 0.0;
		processingTimeEntries			= 0.0;
		processingTimeReal				= 0.0;
		overallStartTime				= Double.MAX_VALUE;
		overallFinishTime				= 0.0;
	
		meanQueueSize					= 0.0;
		meanRealQueueSize				= 0.0;
		queueSizeEntries				= 0.0;
		queueThresholdExceeded			= false;

	}
	
	public void addMetrics(PerformanceMetrics performance){		
		
		meanFlowTime 					+= performance.getMeanFlowTime();						// important
		maxFlowTime 					+= performance.getMaxFlowTime();
		varFlowTime 					+= performance.getVarFlowTime();
		meanTardiness 					+= performance.getMeanTardiness();
		maxTardiness 					+= performance.getMaxTardiness();
		varTardiness 					+= performance.getVarTardiness();
		percentageTardyJobs 			+= performance.getNumberTardyJobs();
		makespan 						+= performance.getMakespan();		
		relativePerformanceTardiness 	+= performance.getRelativePerformanceTardiness();
		relativePerformanceTardyJobs 	+= performance.getRelativePerformanceTardyJobs();
		relativePerformanceFlowtime 	+= performance.getRelativePerformanceFlowtime();
		totalTardiness					+= performance.getTotalTardiness();  					// important
		//totalTardinessNormalized 		*= performance.getTotalTardinessNormalized();
		//meanFlowTimeNormalized 		*= performance.getMeanFlowTimeNormalized();	
		totalTardinessNormalized 		+= performance.getTotalTardinessNormalized();
		meanFlowTimeNormalized 			+= performance.getMeanFlowTimeNormalized();		
		meanQueueSize 					+= performance.getMeanQueueSize();						// important
		meanRealQueueSize 				+= performance.getMeanRealQueueSize();					// important

	}

	public void abortReplication(){
		queueThresholdExceeded=true;
	}

	public boolean getReplicationStatus(){
		return queueThresholdExceeded;
	}

	public void setUtilisationReal(double val){
		utilisationReal=val;
	}

	public void setOverallStartTime(double val){
		overallStartTime=Math.min(val,overallStartTime);
	}

	public void setOverallFinishTime(double val){
		overallFinishTime=Math.max(val,overallFinishTime);
	}

	public double getUtilisationReal(){
		return utilisationReal;
	}

	public void addUtilisationReal(double val, double finishTime){
		utilisationRealCum=utilisationRealCum+val;
	}

	public void updateUtilisationReal(double val, int nMac){
		utilisationReal=utilisationRealCum/(val*(double)nMac);
	}

	public void setProcessingTimeReal(double val){
		processingTimeReal=val;
	}

	public double getProcessingTimeReal(){
		return processingTimeReal;
	}

	public void addProcessingTimeReal(double val){
		processingTimeRealCum=processingTimeRealCum+val;
		processingTimeEntries=processingTimeEntries+1;
		processingTimeReal=processingTimeRealCum/processingTimeEntries;
	}

	public double getTotalTardiness() {
		return totalTardiness;
	}
	
	public double[] getTardiness(){
		return tardinessJobs;
	}

	public double getRelativePerformanceTardiness() {
		return relativePerformanceTardiness;
	}
	
	public double getRelativePerformanceTardyJobs() {
		return relativePerformanceTardyJobs;
	}
	
	public double getRelativePerformanceFlowtime() {
		return relativePerformanceFlowtime;
	}	
	
	public void setRelativePerformanceTardiness(double relPer) {
		this.relativePerformanceTardiness = relPer;
	}
	
	public void setRelativePerformanceTardyJobs(double relPer) {
		this.relativePerformanceTardyJobs = relPer;
	}
	
	public void setRelativePerformanceFlowtime(double relPer) {
		this.relativePerformanceFlowtime = relPer;
	}	
	
	
	public double getMeanRealQueueSize() {
		return meanRealQueueSize;
	}

	public void addMeanRealQueueSize(double q) {
		this.meanRealQueueSize += q;
	}
	
	public double getMeanQueueSize() {
		return meanQueueSize;
	}

	public void addMeanQueueSize(double meanQueueSize) {
		this.meanQueueSize += meanQueueSize;
	}
	
	public void updateQueueSize(double val){
		double previousMeanSize = meanQueueSize*queueSizeEntries;
		queueSizeEntries=queueSizeEntries+1;
		meanQueueSize=(previousMeanSize+val)/queueSizeEntries;
		maxMeanQueue=Math.max(maxMeanQueue,val);
	}

	public double getMaxMeanQueue(){
		return maxMeanQueue;
	}

	public void resetMeanQueueSize(){
		meanQueueSize=0.0;
		queueSizeEntries=0.0;
	}
	
	public double getMeanFlowTime() {
		return meanFlowTime;
	}
	
	public void setMeanFlowTime(double f) {
		this.meanFlowTime = f;
	}
	
	public void addMeanFlowTime(double f) {
		this.meanFlowTime += f;
	}	

	public void addRelativePerformanceTardiness(double relPer) {
		this.relativePerformanceTardiness += relPer;
	}
	
	public void addRelativePerformanceFlowtime(double relPer) {
		this.relativePerformanceFlowtime += relPer;
	}
	
	public void addRelativePerformanceTardyJobs(double relPer) {
		this.relativePerformanceTardyJobs += relPer;
	}	
	
	public double getMaxFlowTime() {
		return maxFlowTime;
	}
	
	public double getVarFlowTime() {
		return varFlowTime;
	}			
	
	public void updateMaxFlowTime(double f){
		if(f > maxFlowTime)
			maxFlowTime = f;
	}

	public double getMeanTardiness() {
		return meanTardiness;
	}
	
	public double getVarTardiness() {
		return varTardiness;
	}	
	
	public void addMeanTardiness(double t) {
		this.meanTardiness += t;
	}
	
	public void addTotalTardiness(double t) {
		this.totalTardiness += t;
	}
	
	public double getMaxTardiness() {
		return maxTardiness;
	}
	
	public void updateMaxTardiness(double t){
		if(t > maxTardiness)
			maxTardiness = t;
	}

	public double getNumberTardyJobs() {
		return percentageTardyJobs;
	}
	
	public void addNumberTardyJobs() {
		this.percentageTardyJobs++;
	}	
	
	public void addNumberTardyJobs(double pTardyJobs) {
		this.percentageTardyJobs += pTardyJobs;
	}		
	
	public double getMakespan() {
		return makespan;
	}	
	
	public void updateMakespan(double m) {
		if(m > makespan)
			this.makespan = m;
	}
	
	public double getEpisodeTotalTardiness(){
		totalTardiness=0;

		for(int i= 0; i < tardinessJobs.length; i++){
			totalTardiness=totalTardiness+tardinessJobs[i];
		}

		return totalTardiness;
	}

	public void updateTotalTardinessNormalized(double tardinessVal,int combination){
		totalTardinessNormalized=tardinessVal/benchmarkList[combination];
	}

	public void updateMeanFlowTimeNormalized(double val,int combination){
		meanFlowTimeNormalized=val/benchmarkFTList[combination];
	}

	public double getMeanFlowTimeNormalized(){
		return meanFlowTimeNormalized;
	}

	public double getTotalTardinessNormalized(){
		return totalTardinessNormalized;
	}

	public void addFullTardiness(double dueDate, double finishTime){
		if (finishTime>dueDate) {
			fullTardiness = fullTardiness + (finishTime-dueDate);
		}
	}

	public double getFullTardiness(){
		return fullTardiness;
	}
	public void updatePerformanceMetrics(int index, double releaseDate, double dueDate, double finishTime){
		
		double flowTime = finishTime - releaseDate;
		double tardiness = 0;
		
		if(dueDate < finishTime){
			addNumberTardyJobs();
			tardiness =  finishTime - dueDate;
		}
		
		flowtimeJobs[index] = flowTime;
		tardinessJobs[index] = tardiness;
		
		addMeanFlowTime(flowTime);
		addMeanTardiness(tardiness);
		addTotalTardiness(tardiness);

		updateMakespan(finishTime);
		updateMaxFlowTime(flowTime);
		updateMaxTardiness(tardiness);				
	}

	public void calculateMetrics(int numJobs){			
		meanFlowTime 		/= numJobs;						// important
		meanTardiness 		/= numJobs;
		percentageTardyJobs /= numJobs;
		
		for(int i= 0; i < flowtimeJobs.length; i++){
			varFlowTime 	+= Math.pow(flowtimeJobs[i] - meanFlowTime,2);
			varTardiness 	+= Math.pow(tardinessJobs[i] - meanTardiness,2);
		}	
		
		varFlowTime 		/= numJobs;
		varTardiness 		/= numJobs;	
	}
	
	public void calculateAverageMetricsByReplication(int numReplications, BenchmarkResult benchmark){
		
		meanFlowTime 	/= numReplications;							// important
		maxFlowTime 	/= numReplications;
		varFlowTime 	/= numReplications;
		meanTardiness 	= Math.round(100.0*meanTardiness/numReplications)/100.0;
		maxTardiness 	/= numReplications;
		varTardiness 	/= numReplications;
		percentageTardyJobs /= numReplications;
		makespan 		/= numReplications;
		meanQueueSize 	/= numReplications;
		meanRealQueueSize /= numReplications;
		totalTardiness=totalTardiness/numReplications;				// important
		//totalTardinessNormalized 	= Math.pow( totalTardinessNormalized, 1/numReplications );				// important
		//meanFlowTimeNormalized 		= Math.pow( meanFlowTimeNormalized  , 1/numReplications );				// important
		totalTardinessNormalized 	/= numReplications;				// important
		meanFlowTimeNormalized 		/= numReplications;				// important
		
		double bestTardiness 		= (benchmark == null)? 1: Math.max(0.001,benchmark.getTardiness());
		double bestFlowtime 		= (benchmark == null)? 1: Math.max(0.001,benchmark.getFlowtime());
		double bestPercTardyJobs 	= (benchmark == null)? 1: Math.max(0.001,benchmark.getPercentageTardyJobs());
				
		relativePerformanceTardiness = Math.max(0.001, meanTardiness)/bestTardiness;		
		relativePerformanceFlowtime  = Math.max(0.001, meanFlowTime)/bestFlowtime;	
		relativePerformanceTardyJobs = Math.max(0.001,percentageTardyJobs)/bestPercTardyJobs;	
	}	
	
	
	public String toString(){		
		
		
//		String output = String.format(Locale.UK, "%.2f; %.1f; %.3f; %.2f; %.1f; %.2f; %.2f;%.2f; %.4f; %f", meanFlowTime, maxFlowTime,
//				 percentageTardyJobs, meanTardiness, maxTardiness, meanQueueSize, meanRealQueueSize,relativePerformanceFlowtime, relativePerformanceTardyJobs, relativePerformanceTardiness);		


		String output = String.format(Locale.UK, "%.2f; %.2f; %.3f; %.2f; %.1f; %.2f; %.3f;", meanFlowTime, maxFlowTime,
				 percentageTardyJobs, meanTardiness, maxTardiness, meanQueueSize, relativePerformanceTardiness);
		
		return output;
	}

	public void dumpPerformance(Integer instanceid, Double flexL, Double utilisationL, Double aL) throws IOException{
        String fileName="performance" + instanceid + " .txt";
        BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true));

		String str = "";
		if (instanceid!=null)	{ str = str + instanceid;	}
		str = str + ";" + GlobalParameters.MAR_RULE;
		str = str + ";" + GlobalParameters.BENCHMARK_RULE;
		if (flexL!=null)		{ str = str + " ;" + String.valueOf(flexL);	}
		if (utilisationL!=null)	{ str = str + " ;" + String.valueOf(utilisationL);	}
		if (aL!=null)			{ str = str + " ;" + String.valueOf(aL) + " ; ";	}
        str = str + String.valueOf(getEpisodeTotalTardiness());
		str = str + " ; " + String.valueOf(getMeanFlowTime()/2000.0);			// HARD CODED, if calculate metrics is used, this is useless
		System.out.println(str);
        writer.append(str);
        writer.newLine();
          
        writer.close();       
    }
}
