package simulator;

public class BenchmarkResult {

		private double tardiness;
		private double percentageTardyJobs;
		private double flowtime;
		
		
		public BenchmarkResult(double tardiness, double percentageTardyJobs,
				double flowtime) {
			super();
			this.tardiness = tardiness;
			this.percentageTardyJobs = percentageTardyJobs;
			this.flowtime = flowtime;
		}
		
		public double getTardiness() {
			return tardiness;
		}
		public void setTardiness(double tardiness) {
			this.tardiness = tardiness;
		}
		public double getPercentageTardyJobs() {
			return percentageTardyJobs;
		}
		public void setPercentageTardyJobs(double percentageTardyJobs) {
			this.percentageTardyJobs = percentageTardyJobs;
		}
		public double getFlowtime() {
			return flowtime;
		}
		public void setFlowtime(double flowtime) {
			this.flowtime = flowtime;
		}
		
		
}
