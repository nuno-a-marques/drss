package simulator;

import java.util.List;

import java.util.Random;

import input.Machine;
import input.Operation;
import main.GlobalParameters;

public class DispatchingRule {

	public static double getHildebrandtRule(SimulationStatus status, Order order){

		double nop = order.getNumOperationsLeft();
		double winQ = getWINQ(status, order);
		double pt = order.getExpectedTime();
		double npt = order.getOperation().getSucessor().getAverageExpectedTime();	

		double tis = status.getTimeInstant() - order.getJob().getArrivalTime();
		double tiq = status.getTimeInstant() - order.getEnteringQueueTime();

		double max1 = Math.max(pt, nop-tiq);
		double max2 = Math.max(pt-npt, pt/(pt+tis));
		double a = (npt-npt/pt)*winQ;
		double b = (max1*(max2+1)+1);

		double z = pt*(a+b);

		//System.out.println("Z = "+z);
		return z;
	}

	public static double getWRIQ(SimulationStatus status, Order order){

		double z = 0;

		Machine machine = order.getMachine();
		List<Order> queue = status.getQueue(machine);

		//Para cada ordem na fila da proxima maquina, verificando sua prioridade
		for(Order nextOrder: queue){		
			z+= nextOrder.getJob().getRemainingProcessingTime();
		}						

		return z;	
	}

	public static double getMaxPTQueue(SimulationStatus status, Order order){

		double z = 0;

		Machine machine = order.getMachine();
		List<Order> queue = status.getQueue(machine);

		//Para cada ordem na fila da proxima maquina, verificando sua prioridade
		for(Order nextOrder: queue){	
			if(z < nextOrder.getExpectedTime())
				z = nextOrder.getExpectedTime();
		}								
		return z;	
	}	

	public static double getMinPTQueue(SimulationStatus status, Order order){

		double z = Double.MAX_VALUE;

		Machine machine = order.getMachine();
		List<Order> queue = status.getQueue(machine);

		//Para cada ordem na fila da proxima maquina, verificando sua prioridade
		for(Order nextOrder: queue){	
			if(z > nextOrder.getExpectedTime())
				z = nextOrder.getExpectedTime();
		}								
		return z;	
	}	

	public static double getMaxDDQueue(SimulationStatus status, Order order){

		double z = 0;

		Machine machine = order.getMachine();
		List<Order> queue = status.getQueue(machine);

		//Para cada ordem na fila da proxima maquina, verificando sua prioridade
		for(Order nextOrder: queue){	
			if(z < nextOrder.getDueDate())
				z = nextOrder.getDueDate();
		}								
		return z;	
	}	

	public static double getMinDDQueue(SimulationStatus status, Order order){

		double z = Double.MAX_VALUE;

		Machine machine = order.getMachine();
		List<Order> queue = status.getQueue(machine);

		//Para cada ordem na fila da proxima maquina, verificando sua prioridade
		for(Order nextOrder: queue){	
			if(z > nextOrder.getDueDate())
				z = nextOrder.getDueDate();
		}								
		return z;	
	}		

	public static double getWIQ(SimulationStatus status, Order order){

		double z = 0;

		Machine machine = order.getMachine();
		List<Order> queue = status.getQueue(machine);

		//Para cada ordem na fila da proxima maquina, verificando sua prioridade
		for(Order nextOrder: queue){		
			z+= nextOrder.getExpectedTime();
		}						

		return z;	
	}	

	public static double getWINQ(SimulationStatus status, Order order){

		double z = 0;

		Operation nextOperation = order.getOperation().getSucessor();
		if(nextOperation == null){
			return 0;
		}
		
		Machine nextMachine = nextOperation.getFirstMachine();
		List<Order> nextQueue = status.getQueue(nextMachine);

		//Para cada ordem na fila da proxima maquina, verificando sua prioridade
		for(Order nextOrder: nextQueue){		
			z+= nextOrder.getExpectedTime();
		}							
		
		return z;	
	}
	
	public static double getWINQF(SimulationStatus status, Order order){

		double z = 0;

		Operation nextOperation = order.getOperation().getSucessor();
		if(nextOperation == null){
			return 0;
		}

		double bestProcessingTime=1000000.0;  // HARD CODED
		Machine candidateMachine=null;

		for (Machine nextMachine: nextOperation.getEligibleMachines()){
			if (nextOperation.getTime(nextMachine)<bestProcessingTime){
				bestProcessingTime=nextOperation.getTime(nextMachine);
				candidateMachine=nextMachine;
			}
		}
		
		List<Order> nextQueue = status.getQueue(candidateMachine);

		//Para cada ordem na fila da proxima maquina, verificando sua prioridade
		for(Order nextOrder: nextQueue){		
			z+= nextOrder.getExpectedTime();
		}							
		
		return z;	
	}

	public static double getJINQ(SimulationStatus status, Order order){

		double z = 0;

		Operation nextOperation = order.getOperation().getSucessor();
		if(nextOperation == null){
			return 0;
		}

		double bestProcessingTime=1000000.0;  // HARD CODED
		Machine candidateMachine=null;

		for (Machine nextMachine: nextOperation.getEligibleMachines()){
			if (nextOperation.getTime(nextMachine)<bestProcessingTime){
				bestProcessingTime=nextOperation.getTime(nextMachine);
				candidateMachine=nextMachine;
			}
		}
		
		z = status.getQueueSize(candidateMachine);						
		
		return z;	
	}

	public static double getWOR(SimulationStatus status, Order order){

		double z = 0;

		for(Operation operation: order.getRoute().getOperations()){
			//Para todas as opera�oes restantes
			if(!operation.isExecuted() && !operation.equals(order.getOperation())){
				double zNextQueue = 0.0;

				Machine machine = operation.getFirstMachine();
				List<Order> queue = status.getQueue(machine);

				//Para cada ordem na fila da proxima maquina, verificando sua prioridade
				for(Order nextOrder: queue){		
					zNextQueue+= nextOrder.getExpectedTime();
				}

				z+= zNextQueue;
			}
		}

		return z;	
	}	

	public static double getAvgPTQueue(SimulationStatus status, Order order){

		double z = 0;
		List<Order> queue = status.getQueue(order.getMachine());

		for(Order o: queue){		
			z+= o.getExpectedTime();

			if(queue.size() > 0)
				z /= queue.size();		
		}

		return z;	
	}		

	public static double getQueueSizeNextMachine(SimulationStatus status, Order order){

		double z = 0;

		Operation nextOperation = order.getOperation().getSucessor();
		if(nextOperation == null){
			return 0;
		}
		
		Machine nextMachine = nextOperation.getFirstMachine();		
		List<Order> nextQueue = status.getQueue(nextMachine);
		z+= nextQueue.size();						
		
		return z;	
	}		
	public static double getMostWorkFollowing(Order order){

		return  order.getRemainingProcessingTime() - order.getExpectedTime();
	}
	
	public static double getPTWinRR(SimulationStatus status,Order order, double utilizationLevel){

		double winRR = getWinRR(status, order.getJob(), order.getOperation(), order.getRemainingProcessingTime(), status.getTimeInstant(),utilizationLevel);
		double pt = order.getExpectedTime();					

		return 	pt + 0.25*winRR;
	}	

	public static double getEvolvedRule(SimulationStatus status,Order order, double allowance, double utilizationLevel){

		double winRR = getWinRR(status, order.getJob(), order.getOperation(), order.getRemainingProcessingTime(), status.getTimeInstant(),utilizationLevel);
		double pt = order.getExpectedTime();					
		double rpt = order.getRemainingProcessingTime();
		double slackRPT = getSlack(status, order);
		if(rpt > 0)
			slackRPT /= rpt;	

		double w1 = (allowance-2.6)*(1.02-utilizationLevel);								

		return pt*(w1*slackRPT + 1) + 0.25*winRR;	
	}

	public static double get2PTWINRR(SimulationStatus status, Order order){

		double pt = order.getExpectedTime();
		double wRR = getRelativeWinQ(status, order.getOperation(), order.getDueDate(), order.getRemainingProcessingTime(), status.getTimeInstant());

		double z = 2*pt + wRR;
		return z;
	}
	
	public static double getMachineWaitingTime(SimulationStatus status, Order order){		
		return	Math.max(  status.getTimeInstant()-status.getCompletionTime(order.getMachine()) , 0 );
	}

	public static double getPAT(SimulationStatus status, Order order, Machine mac){
		return Math.max( status.getCompletionTime(mac) - status.getTimeInstant() ,0);
	}

	public static double getEvolvedRule0(SimulationStatus status,Order order, double allowance, double utilizationLevel){

		double winRR = getWinRR(status, order.getJob(), order.getOperation(), order.getRemainingProcessingTime(), status.getTimeInstant(),utilizationLevel);
		double pt = order.getExpectedTime();					
		double rpt = order.getRemainingProcessingTime();
		double slackRPT = getSlack(status, order);
		if(rpt > 0)
			slackRPT /= rpt;	

		double w1 = (allowance*1.1-2.2)*(0.99-utilizationLevel);								

		return pt*(w1*slackRPT + 1) + 0.25*winRR;	
	}

	public static double getEvolvedRule3(SimulationStatus status,Order order, double allowance, double utilizationLevel){

		double winRR = getWinRR(status, order.getJob(), order.getOperation(), order.getRemainingProcessingTime(), status.getTimeInstant(),utilizationLevel);
		double pt = order.getExpectedTime();					
		double rpt = order.getRemainingProcessingTime();
		double slackRPT = getSlack(status, order);
		if(rpt > 0)
			slackRPT /= rpt;	

		return ((pt*slackRPT*(allowance-2))/allowance)/2 + 2*pt + winRR;
	}
	
	public static double getCOVERT(SimulationStatus status,Order order, double objective, double k){
		//a ordenação é feita pela MAXIMIZACAO ou MINIMIZACAO -> controlar via objective
		double resultado=0.0;

		double b=1.0; // from HUNT   HARD CODED
		double weight=1.0; //nao estamos a utilizar   HARD CODED
		
		double num=getPositiveSlack(status, order);
		double denom=k*b*order.getRemainingProcessingTime();

		resultado=(weight/order.getExpectedTime())*Math.max(0,1-num/denom)*objective;

		return resultado*(-1.0);
	}

	public static double getCOVERTb(SimulationStatus status,Order order, double objective){
		//a ordenação é feita pela MAXIMIZACAO ou MINIMIZACAO -> controlar via objective
		double resultado=0.0;

		double k=4.0; // from Ozturk, HUNT suggestes 2 HARD CODED
		double b=1.0; // from HUNT   HARD CODED
		double weight=1.0; //nao estamos a utilizar   HARD CODED
		
		double num=getPositiveSlack(status, order);
		double denom=k*b*order.getRoute().getTotalProcessingTime();

		resultado=(weight/order.getExpectedTime())*Math.max(0,1-num/denom)*objective;

		return resultado*(-1.0);
	}

	public static double getCOVERTbyOzturk(SimulationStatus status,Order order, double objective){
		//a ordenação é feita pela MAXIMIZACAO ou MINIMIZACAO -> controlar via objective
		double resultado=0.0;

		double k=1.0; // from Ozturk, HUNT suggestes 2 HARD CODED
		double b=2.0; // from HUNT   HARD CODED
		double weight=1.0; //nao estamos a utilizar   HARD CODED
		
		double num=getPositiveSlack(status, order);
		double denom=k*b*order.getRemainingProcessingTime();

		resultado=(weight/order.getExpectedTime())*Math.max(0,1-num/denom)*objective;

		return resultado;
	}

	public static double getATC(SimulationStatus status,Order order, double objective){
		//a ordenação é feita pela MAXIMIZACAO OU MINIMIZACAO
		double resultado=0.0;
		double k1=3.0;  //HARD CODED
		double k2=3.0;  //HARD CODED
		double weight=1.0; // nao estamos a utilizar HARD CODED

		double apt=0.0;
		double z=0.0;
		List<Order> nextQueue = status.getQueue(order.getMachine());
		for(Order nextOrder: nextQueue){		
			z+= nextOrder.getExpectedTime();
		}
		if (status.getQueueSize(order.getMachine())>0){
			apt=z/(double)status.getQueueSize(order.getMachine());
		}
		else{
			apt=1.0;
		}

		double num=order.getJob().getDueDate() - status.getTimeInstant() - order.getExpectedTime() - (k1)*(order.getRemainingProcessingTime()-order.getExpectedTime());
		double denom=k2*apt;
		// is the average processing time at current machine but we only analise one machine at a time   HARD CODED

		resultado=(weight/order.getExpectedTime()) * Math.exp(-Math.max(0,num/denom));
		return resultado*objective;
	}

	public static double getSlack(SimulationStatus status, Order order){
		return order.getJob().getDueDate() - status.getTimeInstant() - order.getRemainingProcessingTime();
	}
	
	public static double getEstimatedLateness(SimulationStatus status, Order order){									// tal como implementado em wei2004
		return status.getTimeInstant() + order.getExpectedTime() - order.getJob().getDueDate();							// pode ser feito com o RPT
	}

	public static double getActualTardiness(SimulationStatus status, Order order){									
		return Math.max( status.getTimeInstant() + order.getExpectedTime() - order.getJob().getDueDate(), 0.0 );							
	}

	public static double getEstimatedTardiness(SimulationStatus status, Order order){									
		return Math.max( status.getTimeInstant() + order.getRemainingProcessingTime() - order.getJob().getDueDate(), 0.0 );							
	}

	public static double getEstimatedEarliness(SimulationStatus status, Order order){									
		return Math.min( status.getTimeInstant() + order.getRemainingProcessingTime() - order.getJob().getDueDate(), 0.0 );							
	}

	public static double getPositiveSlack(SimulationStatus status, Order order){

		return Double.max(0, order.getJob().getDueDate() - status.getTimeInstant() - order.getRemainingProcessingTime());
	}

	public static double getPositiveSlackO(SimulationStatus status, Order order){

		return Double.max(0, order.getOperation().getDueDate() - status.getTimeInstant() - order.getExpectedTime());
	}	

	public static double getSlackO(SimulationStatus status, Order order){

		return order.getOperation().getDueDate() - status.getTimeInstant() - order.getExpectedTime();
	}		

	public static double getFinishTime(SimulationStatus status, Order order){

		return status.getTimeInstant() + order.getExpectedTime();
	}

	public static double getTailRemaining(Order order){

		double K = 2.0;

		int numRemainingOrders = order.getNumOperationsLeft();
		double remainingTime = order.getRemainingProcessingTime();			
		double averageRTime = remainingTime / numRemainingOrders;
		double variance = 0;

		for(Operation operation: order.getRoute().getOperations()){
			if(!operation.isExecuted()){
				variance += Math.pow(operation.getAverageExpectedTime() - averageRTime, 2.0);
			}
		}

		double stDev = Math.sqrt(variance);
		return  (remainingTime + K*stDev);			
	}

	public static double getSucessiveDifference(Order order){

		double diff = -order.getExpectedTime();
		double sucessiveTime = order.getOperation().getSucessor().getAverageExpectedTime();

		diff += sucessiveTime;
		return  diff;		
	}	

	public static double getOperationsRemaining(Order order){

		return order.getNumOperationsLeft();						
	}		

	public static double getCriticalRatioPos(SimulationStatus status, Order order){
		// CR se positivo - HARD CODED
		double allowance = Math.max(0,order.getJob().getDueDate() - status.getTimeInstant());			
		if(order.getRemainingProcessingTime() > 0)
			return allowance/order.getRemainingProcessingTime();
		else
			return 1.0;
	}

	public static double getCriticalRatioStd(SimulationStatus status, Order order){
		// CR se positivo - HARD CODED
		double allowance = order.getJob().getDueDate() - status.getTimeInstant();			
		if(order.getRemainingProcessingTime() != 0)  // won t happen
			return allowance/order.getRemainingProcessingTime();
		else
			return 1;
	}

	public static double getAnderson1(SimulationStatus status, Order order){
		return getSlackByRPT(status, order)+order.getExpectedTime();		
	}

	public static double getAnderson1b(SimulationStatus status, Order order){
		double out = 0.0;
		out = Math.max( (getSlack(status, order) / order.getRemainingProcessingTime()) * order.getExpectedTime()     , order.getExpectedTime() ); 
		return out;		
	}

	public static double getAnderson2(SimulationStatus status, Order order){
		return getCriticalRatioStd(status, order)+order.getExpectedTime();		
	}

	public static double getAnderson2b(SimulationStatus status, Order order){
		// implementacao raghu
		// sera min		
		double out = 0.0;
		out = Math.max(getCriticalRatioStd(status, order)*order.getExpectedTime(), order.getExpectedTime());
		return out;		
	}

	public static double getCristiane1(SimulationStatus status, Order order){
		double resultado=0.0;
		resultado=resultado+2*order.getExpectedTime();
		resultado=resultado+(order.getExpectedTime()*getPositiveSlack(status, order))/order.getRemainingProcessingTime();
		resultado=resultado+getWINQ(status, order);
		
		return resultado;		
	}

	public static double getCristiane2(SimulationStatus status, Order order){
		double resultado=0.0;

		double winq=getWINQ(status, order);

		if(getSlack(status, order)>0){
			resultado=order.getExpectedTime()+order.getExpectedTime()*getCriticalRatioPos(status, order)+winq;
		}
		else{
			resultado=3*order.getExpectedTime()+winq-winq/order.getExpectedTime();
		}
		
		return resultado;		
	}



	public static double getSlackByRPT(SimulationStatus status, Order order){

		double slack = getSlack(status, order);
		double rpt = order.getRemainingProcessingTime();
		double dueDate = slack;
		if(rpt > 0)
			dueDate /= rpt*order.getExpectedTime();		

		return Math.max(dueDate, order.getExpectedTime());		
	}
	
	public static double getSlackRPTPlusPT(SimulationStatus status, Order order){

		double slack = getSlack(status, order);
		double pt = order.getExpectedTime();
		double rpt = order.getRemainingProcessingTime();
		double srpt = pt*slack;
		if(rpt > 0)
			srpt /= rpt;		

		return Math.max(srpt, pt);		
	}

	public static double getRR(SimulationStatus status, Order order, double utilizationLevel){

		double slackRPT = getSlack(status, order);
		if(slackRPT > 0)
			status.addPositiveSlack();
		else
			status.addNegativeSlack();
		
		if(order.getRemainingProcessingTime() > 0)
			slackRPT /= order.getRemainingProcessingTime();		
		double w1 = Math.exp(-utilizationLevel);
		double w2 = Math.exp(utilizationLevel);										
		double w = getWinRR(status, order.getJob(), order.getOperation(), order.getRemainingProcessingTime(), status.getTimeInstant(),utilizationLevel);
		//double w = getWINQF(status, order);										

		return order.getExpectedTime()*(slackRPT*w1 + w2) + w;
	}

	public static double getRRMSO(SimulationStatus status, Order order, double utilizationLevel){

		double slackRPT = getPositiveSlackO(status, order);
		if(order.getRemainingProcessingTime() > 0)
			slackRPT /= order.getRemainingProcessingTime();		
		double w1 = Math.exp(-utilizationLevel);
		double w2 = Math.exp(utilizationLevel);										
		double w = getWinRR(status, order.getJob(), order.getOperation(), order.getRemainingProcessingTime(), status.getTimeInstant(),utilizationLevel);										

		return order.getExpectedTime()*(slackRPT*w1 + w2) + w;
	}

	public static double getRRSO(SimulationStatus status, Order order, double utilizationLevel){

		double slackRPT = getSlackO(status, order);
		if(order.getRemainingProcessingTime() > 0)
			slackRPT /= order.getRemainingProcessingTime();		
		double w1 = Math.exp(-utilizationLevel);
		double w2 = Math.exp(utilizationLevel);										
		double w = getWinRR(status, order.getJob(), order.getOperation(), order.getRemainingProcessingTime(), status.getTimeInstant(),utilizationLevel);										

		return order.getExpectedTime()*(slackRPT*w1 + w2) + w;
	}	

	public static double getRRMS(SimulationStatus status, Order order, double utilizationLevel){

		double slackRPT = getPositiveSlack(status, order);
		if(order.getRemainingProcessingTime() > 0)
			slackRPT /= order.getRemainingProcessingTime();		
		double w1 = Math.exp(-utilizationLevel);
		double w2 = Math.exp(utilizationLevel);										
		double w = getWinRR(status, order.getJob(), order.getOperation(), order.getRemainingProcessingTime(), status.getTimeInstant(),utilizationLevel);										

		return order.getExpectedTime()*(slackRPT*w1 + w2) + w ;
	}	

	public static double getRelativeWinQ(SimulationStatus status, Operation operation, double dueDate, double rpt, double startTime){

		double winQ = 0;
		Operation nextOperation = operation.getSucessor();
		if(nextOperation == null){
			return 0;
		}
		
							
			Machine nextMachine = nextOperation.getFirstMachine();
			double av = status.getAvailability(nextMachine);

			double nextTime = Math.max(av, startTime + operation.getAverageExpectedTime());

			double nextRTP = rpt - operation.getAverageExpectedTime();
			double slack = dueDate - nextTime -rpt;
			double slackRPT = Math.max(0, slack)/nextRTP;

			double pt = nextOperation.getAverageExpectedTime();
			double z = pt*(slackRPT + 1);

			List<Order> nextQueue = status.getQueue(nextMachine);			

			//Para cada ordem na fila da proxima maquina, verificando sua prioridade
			for(Order nextOrder: nextQueue){
				if(nextOrder.getMinExecutionTime() <= nextTime){					

					pt = nextOrder.getExpectedTime();
					nextRTP = nextOrder.getRemainingProcessingTime();
					slack = nextOrder.getJob().getDueDate() - nextTime -rpt; 
					slackRPT = Math.max(0, slack)/nextRTP;

					double zOrder = pt*(slackRPT + 1);
					if(zOrder < z){
						winQ += pt;
					}
				}
			}			
		
		return winQ;		
	}
	
	public static double getRelativeWisQ(SimulationStatus status, Operation operation, double dueDate, double rpt, double startTime){
	
		if(operation.getSucessor() == null)
			return 0;

		double wisQ = 0;

		Operation nextOperation = operation.getSucessor();		
		if(nextOperation == null){
			return 0;
		}
		
		Machine nextMachine = nextOperation.getFirstMachine();
		double av = status.getAvailability(nextMachine);

		double nextTime = Math.max(av, startTime + operation.getAverageExpectedTime());

		double nextRTP = rpt - operation.getAverageExpectedTime();
		double slack = dueDate - nextTime -rpt;
		double slackRPT = Math.max(0, slack)/nextRTP;

		double pt = nextOperation.getAverageExpectedTime();
		double z = pt*(slackRPT + 1);

		List<Order> nextQueue = status.getQueue(nextMachine);			

		//Para cada ordem na fila da proxima maquina, verificando sua prioridade
		for(Order nextOrder: nextQueue){
			if(nextOrder.getMinExecutionTime() <= nextTime){					

				pt = nextOrder.getExpectedTime();
				nextRTP = nextOrder.getRemainingProcessingTime();
				slack = nextOrder.getJob().getDueDate() - nextTime -rpt; 
				slackRPT = Math.max(0, slack)/nextRTP;

				double zOrder = pt*(slackRPT + 1);
				if(zOrder < z){
					wisQ += pt;
				}
			}
		}		
		
		wisQ += getRelativeWisQ(status, nextOperation, dueDate, nextRTP, nextTime);
				
		return wisQ;		
	}
	
	public static double getWinRR(SimulationStatus status, ActualJob job, Operation operation, double rpt, double startTime, double utilizationLevel){

		double winQ = 0;
		Operation nextOperation =  operation.getSucessor();
		if(nextOperation == null){
			return 0;
		}
					
		Machine nextMachine = nextOperation.getFirstMachine();
		double av = status.getAvailability(nextMachine);

		double w1 = Math.exp(-utilizationLevel);
		double w2 = Math.exp(utilizationLevel);	

		double nextTime = Math.max(av, startTime + operation.getAverageExpectedTime());

		double nextRTP = rpt - operation.getAverageExpectedTime();
		double slack = job.getDueDate() - nextTime - nextRTP;
		double slackRPT = slack;
		if(nextRTP > 0)
			slackRPT /= nextRTP;
		double pt = nextOperation.getAverageExpectedTime();
		double z = pt*(slackRPT*w1 + w2);

		List<Order> nextQueue = status.getQueue(nextMachine);			

		//Para cada ordem na fila da proxima maquina, verificando sua prioridade
		for(Order nextOrder: nextQueue){
			if(nextOrder.getMinExecutionTime() <= nextTime){					

				pt = nextOrder.getExpectedTime();
				nextRTP = nextOrder.getRemainingProcessingTime();
				slack = nextOrder.getJob().getDueDate() - nextTime - nextRTP;
				if(nextRTP > 0)
					slackRPT = slack/nextRTP;
				else
					slackRPT = slack;
				double zOrder = pt*(slackRPT*w1 + w2);

				if(zOrder < z){
					winQ += pt;
				}
			}
		}	

		return winQ;
	}	

	public static double getWinRR2(SimulationStatus status, ActualJob job, Operation operation, double rpt, double startTime){

		double winQ = 0;

		Operation nextOperation =  operation.getSucessor();
		if(nextOperation == null){
			return 0;
		}
						
		Machine nextMachine = nextOperation.getFirstMachine();
		double av = status.getAvailability(nextMachine);

		double nextTime = Math.max(av, startTime + operation.getAverageExpectedTime());

		double nextRTP = rpt - operation.getAverageExpectedTime();
		double slack = Math.max(0, job.getDueDate() - nextTime - nextRTP);
		double slackRPT = slack;
		if(nextRTP > 0)
			slackRPT /= nextRTP;
		double pt = nextOperation.getAverageExpectedTime();
		double z = pt*(slackRPT + 1);

		List<Order> nextQueue = status.getQueue(nextMachine);			

		//Para cada ordem na fila da proxima maquina, verificando sua prioridade
		for(Order nextOrder: nextQueue){
			if(nextOrder.getMinExecutionTime() <= nextTime){					

				pt = nextOrder.getExpectedTime();
				nextRTP = nextOrder.getRemainingProcessingTime();
				slack = nextOrder.getJob().getDueDate() - nextTime - nextRTP;
				if(nextRTP > 0)
					slackRPT = slack/nextRTP;
				else
					slackRPT = slack;
				double zOrder = pt*(slackRPT + 1);

				if(zOrder < z)
					winQ += pt;
			}
		}	

		return winQ;
	}	
	public static double getPTWINQ(SimulationStatus status,Order order){

		double z = order.getExpectedTime();

		Operation nextOperation =  order.getOperation().getSucessor();
		if(nextOperation == null){
			return z;
		}
		
		Machine nextMachine = nextOperation.getFirstMachine();
		List<Order> nextQueue = status.getQueue(nextMachine);

		//Para cada ordem na fila da proxima maquina, verificando sua prioridade
		for(Order nextOrder: nextQueue){
			z += nextOrder.getExpectedTime();					
		}		

		return z;				
	}

	public static double get2PTWINQNPT(SimulationStatus status,Order order){

		double z = 2*order.getExpectedTime();

		Operation nextOperation =  order.getOperation().getSucessor();
		if(nextOperation == null){
			return z;
		}
		
		z += nextOperation.getAverageExpectedTime();

		z += getWINQF(status, order);		
	
		return z;		
	}

	public static double getNPT(SimulationStatus status,Order order){
		Operation nextOperation =  order.getOperation().getSucessor();
		if(nextOperation == null){
			return 0;
		}
		else{
			return order.getOperation().getSucessor().getAverageExpectedTime();
		}		
	}


	public static double getRANDPTWINQ(SimulationStatus status,Order order){

		if(Math.random() < 0.5)
			return order.getExpectedTime();
		else
			return getWINQ(status, order);
	}		

	public static double getPTWINQSL(SimulationStatus status,Order order){

		double slack = getSlack(status, order);
		double z = order.getExpectedTime() + Math.min(slack, 0);

		Operation nextOperation = order.getOperation().getSucessor();
		if(nextOperation == null){
			return 0;
		}
						
		Machine nextMachine = nextOperation.getFirstMachine();
		List<Order> nextQueue = status.getQueue(nextMachine);

		//Para cada ordem na fila da proxima maquina, verificando sua prioridade
		for(Order nextOrder: nextQueue){		
			z+= nextOrder.getExpectedTime();									
		}
		
		return z;	
	}

	public static double getPTWINQNPTWSL(SimulationStatus status,Order order){

		double z = order.getExpectedTime();

		Operation nextOperation = order.getOperation().getSucessor();
		if(nextOperation == null){
			double slack = getSlack(status, order);
			return  Math.min(slack, 0);
		}

		Machine nextMachine = nextOperation.getFirstMachine();
		z += nextOperation.getTime(nextMachine);

		List<Order> nextQueue = status.getQueue(nextMachine);

		double winQ = 0;

		//Para cada ordem na fila da proxima maquina, verificando sua prioridade
		for(Order nextOrder: nextQueue){
			winQ += nextOrder.getExpectedTime();
		}

		z += winQ;				
		double wSlack = order.getJob().getDueDate() - status.getTimeInstant() - order.getRemainingProcessingTime() - winQ;				
		z += Math.min(wSlack,  0);							

		return z;
	}

	public static double getPTWINQAT(SimulationStatus status,Order order){

		double z = order.getExpectedTime() + order.getJob().getArrivalTime();

		Operation nextOperation = order.getOperation().getSucessor();
		if(nextOperation == null){
			return 0;
		}
	
		Machine nextMachine =  nextOperation.getFirstMachine();	
		List<Order> nextQueue = status.getQueue(nextMachine);

		//Para cada ordem na fila da proxima maquina, verificando sua prioridade
		for(Order nextOrder: nextQueue){			
			z+= nextOrder.getExpectedTime();
		}																
		return z;	
	}	

	public static double getPTWINQATSL(SimulationStatus status, Order order){

		double slack = getSlack(status, order);
		double z = order.getExpectedTime() + Math.min(slack, 0) + order.getJob().getArrivalTime();

		if(order.getOperation().getSucessor() != null){
					
			Machine nextMachine =  order.getOperation().getSucessor().getFirstMachine();	
			List<Order> nextQueue = status.getQueue(nextMachine);

			//Para cada ordem na fila da proxima maquina, verificando sua prioridade
			for(Order nextOrder: nextQueue){		
				z+= nextOrder.getExpectedTime();
			}													
		}
		return z;	
	}		

	public static double getCriticalRatioPlusSPT(SimulationStatus status, Order order){

		double alllowance = order.getJob().getDueDate() - status.getTimeInstant();
		double criticalRatio = alllowance;
		if(order.getRemainingProcessingTime() > 0)
			criticalRatio /= order.getRemainingProcessingTime();	
		else 
			criticalRatio = 0;
		double dueDate = criticalRatio*order.getExpectedTime();		

		return Math.max(dueDate, order.getExpectedTime());
	}

	public static double customRule1m(SimulationStatus status, Order order,boolean tardExist,double tCur){
		double resultado=0.0;
		//O tCur devia ser melhor definido
		//double tCur=status.getTimeInstant();
		//ignorei a verificação se o job ainda tem operações pendentes, uma vez que ainda está na queue
		if(tardExist){
			if(order.getJob().getDueDate()<tCur){
				resultado=tCur+order.getRemainingProcessingTime()-order.getJob().getDueDate();
				resultado=resultado*(-1);
			}
			else{ 
				resultado=100000000;
			}

		}
		else{
			resultado=(order.getJob().getDueDate()-tCur)/order.getJob().numOperationsLeft;
		}

		return resultado+order.getExpectedTime();
	}

	public static double customRule2m(SimulationStatus status, Order order,boolean tardExist, double tCur){
		double resultado=0.0;
		//O tCur devia ser melhor definido
		//double tCur=status.getTimeInstant();
		//ignorei a verificação se o job ainda tem operações pendentes, uma vez que ainda está na queue
		if(tardExist){
			if(order.getJob().getDueDate()<tCur){
				resultado=tCur+order.getRemainingProcessingTime()-order.getJob().getDueDate();
				resultado=resultado*(-1);
			}
			else{
				resultado=100000000;
			}
		}
		else{
			resultado=getCriticalRatioStd(status, order);
		}

		return resultado+order.getExpectedTime();
	}

	public static double customRule3m(SimulationStatus status, Order order,boolean tardExist, double tCur){
		double resultado=0.0;
		//O tCur devia ser melhor definido
		//double tCur=status.getTimeInstant();
		//ignorei a verificação se o job ainda tem operações pendentes, uma vez que ainda está na queue

		resultado=tCur+order.getRemainingProcessingTime()-order.getJob().getDueDate();
		resultado=resultado*(-1);

		//Não consigo fazer a selecção da máquina!!!		

		return resultado+order.getExpectedTime();
	}

	public static double customRule4m(SimulationStatus status, Order order,boolean tardExist, double tCur){
		Random rand = new Random();
		double resultado=0.0;
		//O tCur devia ser melhor definido
		//double tCur=status.getTimeInstant();
		//ignorei a verificação se o job ainda tem operações pendentes, uma vez que ainda está na queue
		//resultado=tCur+order.getRemainingProcessingTime()-order.getJob().getDueDate();
		resultado=rand.nextDouble()+1.0;

		return resultado+order.getExpectedTime();
	}

	public static double customRule5m(SimulationStatus status, Order order,boolean tardExist, double tCur){
		double resultado=0.0;
		//O tCur devia ser melhor definido
		//double tCur=status.getTimeInstant();
		double completeOperations=order.getRoute().getNumOperations()-order.getJob().getNumOperationsLeft();

		//ignorei a verificação se o job ainda tem operações pendentes, uma vez que ainda está na queue
		if(tardExist){
			if(order.getJob().getDueDate()<tCur){
				resultado=(tCur+order.getRemainingProcessingTime()-order.getJob().getDueDate())*(order.getRoute().getNumOperations()/Math.max(completeOperations,1));
				resultado=resultado*(-1);
			}
			else{
				resultado=100000000;
			}			
		}
		else{
			resultado=(completeOperations/order.getRoute().getNumOperations())*(order.getJob().getDueDate()-tCur);
		}

		return resultado+order.getExpectedTime();
	}

	public static double customRule6m(SimulationStatus status, Order order,boolean tardExist, double tCur){
		double resultado=0.0;
		//O tCur devia ser melhor definido
		//double tCur=status.getTimeInstant();

		//ignorei a verificação se o job ainda tem operações pendentes, uma vez que ainda está na queue
		
		resultado=tCur+order.getRemainingProcessingTime()-order.getJob().getDueDate();
		resultado=resultado*(-1);
		
		return resultado+order.getExpectedTime();
	}

	public static double customRule1(SimulationStatus status, Order order,boolean tardExist,double tCur){
		double resultado=0.0;
		//O tCur devia ser melhor definido
		//double tCur=status.getTimeInstant();
		//ignorei a verificação se o job ainda tem operações pendentes, uma vez que ainda está na queue
		if(tardExist){
			if(order.getJob().getDueDate()<tCur){
				resultado=tCur+order.getRemainingProcessingTime()-order.getJob().getDueDate();
				resultado=resultado*(-1);
			}
			else{ 
				resultado=100000000;
			}

		}
		else{
			resultado=(order.getJob().getDueDate()-tCur)/order.getJob().numOperationsLeft;
		}

		return resultado;
	}

	public static double customRule2(SimulationStatus status, Order order,boolean tardExist, double tCur){
		double resultado=0.0;
		//O tCur devia ser melhor definido
		//double tCur=status.getTimeInstant();
		//ignorei a verificação se o job ainda tem operações pendentes, uma vez que ainda está na queue
		if(tardExist){
			if(order.getJob().getDueDate()<tCur){
				resultado=tCur+order.getRemainingProcessingTime()-order.getJob().getDueDate();
				resultado=resultado*(-1);
			}
			else{
				resultado=100000000;
			}
		}
		else{
			resultado=getCriticalRatioStd(status, order);
		}

		return resultado;
	}

	public static double customRule3(SimulationStatus status, Order order,boolean tardExist, double tCur){
		double resultado=0.0;
		//O tCur devia ser melhor definido
		//double tCur=status.getTimeInstant();
		//ignorei a verificação se o job ainda tem operações pendentes, uma vez que ainda está na queue

		resultado=tCur+order.getRemainingProcessingTime()-order.getJob().getDueDate();
		resultado=resultado*(-1);

		//Não consigo fazer a selecção da máquina!!!		

		return resultado;
	}

	public static double customRule4(SimulationStatus status, Order order,boolean tardExist, double tCur){
		Random rand = new Random();
		double resultado=0.0;
		//O tCur devia ser melhor definido
		//double tCur=status.getTimeInstant();
		//ignorei a verificação se o job ainda tem operações pendentes, uma vez que ainda está na queue
		//resultado=tCur+order.getRemainingProcessingTime()-order.getJob().getDueDate();
		resultado=rand.nextDouble()+1.0;

		return resultado;
	}

	public static double customRule5(SimulationStatus status, Order order,boolean tardExist, double tCur){
		double resultado=0.0;
		//O tCur devia ser melhor definido
		//double tCur=status.getTimeInstant();
		double completeOperations=order.getRoute().getNumOperations()-order.getJob().getNumOperationsLeft();

		//ignorei a verificação se o job ainda tem operações pendentes, uma vez que ainda está na queue
		if(tardExist){
			if(order.getJob().getDueDate()<tCur){
				resultado=(tCur+order.getRemainingProcessingTime()-order.getJob().getDueDate())*(order.getRoute().getNumOperations()/Math.max(completeOperations,1));
				resultado=resultado*(-1);
			}
			else{
				resultado=100000000;
			}			
		}
		else{
			resultado=(completeOperations/order.getRoute().getNumOperations())*(order.getJob().getDueDate()-tCur);
		}

		return resultado;
	}

	public static double customRule6(SimulationStatus status, Order order,boolean tardExist, double tCur){
		double resultado=0.0;
		//O tCur devia ser melhor definido
		//double tCur=status.getTimeInstant();

		//ignorei a verificação se o job ainda tem operações pendentes, uma vez que ainda está na queue
		
		resultado=tCur+order.getRemainingProcessingTime()-order.getJob().getDueDate();
		resultado=resultado*(-1);
		
		return resultado;
	}

	public static double getPtPlusSlack(SimulationStatus status, Order order){
		double slackTemp=getSlack(status, order);		
		return order.getExpectedTime()+slackTemp;
	}

	public static double getSels1(SimulationStatus status, Order order){
		double resultado=0.0;
		resultado=2*order.getExpectedTime()+order.getJob().getRemainingProcessingTime()+getFDD(status,order);
		return resultado;
	}

	public static double getSels2(SimulationStatus status, Order order, int multiplier){
		double resultado=0.0;
		// multiplier pode ser 1 ou 2
		resultado=multiplier*order.getExpectedTime()+order.getJob().getRemainingProcessingTime()+getSlack(status, order);
		return resultado;
	}

	//sels 3 e sels 2 com multiplier diferente

	public static double getSels3(SimulationStatus status, Order order){
		double resultado=0.0;
		resultado=2*order.getExpectedTime()+order.getJob().getRemainingProcessingTime()+order.getDueDate();
		return resultado;
	}

	public static double getSels4(SimulationStatus status, Order order, int multiplier){
		double resultado=0.0;
		// multiplier deve ser 0
		resultado=2*order.getExpectedTime()+order.getJob().getRemainingProcessingTime()+multiplier*order.getDueDate();
		return resultado;
	}

	// sels 5 e sels 4 com diferente multiplier

	public static double getSels6(SimulationStatus status, Order order, double aFactor){
		double resultado=0.0;
		// multiplier deve ser 0
		resultado=order.getJob().getRemainingProcessingTime()+getMOD(status,order,aFactor);
		return resultado;
	}

	public static double getSels7(SimulationStatus status, Order order, int multiplier){
		double resultado=0.0;
		// multiplier deve ser 0
		resultado=order.getJob().getRemainingProcessingTime()+order.getExpectedTime()+multiplier*getAVPRO(status, order);
		return resultado;
	}

	//sels 8 e sels 7 com multiplier igual a 1

	public static double getSels9(SimulationStatus status, Order order){
		double resultado=0.0;
		// multiplier deve ser 0
		resultado=order.getJob().getRemainingProcessingTime()+order.getExpectedTime()+getPW(status, order);
		return resultado;
	}

	public static double getSels16(SimulationStatus status, Order order){
		double resultado=0.0;
		// multiplier deve ser 0
		resultado=order.getExpectedTime()+getPW(status, order);
		return resultado;
	}

	public static double getSels18(SimulationStatus status, Order order){
		double resultado=0.0;
		// multiplier deve ser 0
		resultado=order.getExpectedTime()+getPW(status, order)+getFDD(status, order);
		return resultado;
	}

	public static double getSels19(SimulationStatus status, Order order){
		double resultado=0.0;
		// multiplier deve ser 0
		resultado=order.getExpectedTime()+getSlack(status, order);
		return resultado;
	}

	public static double getSlackbyNumberOfOperations(SimulationStatus status, Order order){
		double resultado=0.0;
		resultado=getSlack(status, order)/order.getJob().getNumOperationsBestCase();
		return resultado;
	}

	public static double getAVPRO(SimulationStatus status, Order order){
		double resultado=0.0;
		resultado=order.getRoute().getTotalProcessingTime()/order.getJob().getNumOperationsWorstCase();
		return resultado;
	}

	public static double getPW(SimulationStatus status, Order order){
		double resultado=0.0;
		resultado = status.getTimeInstant()-order.getEnteringQueueTime();
		//if(status.keyExistsCT(order.getJob())){
		//resultado=status.getTimeInstant()-status.getJobCompletionTime(order.getJob());
		//}
		return resultado;
	}

	public static double getFDD(SimulationStatus status, Order order){
		// work that has already been taken
		double resultado=0.0;
		resultado=order.getJob().getArrivalTime()+order.getRoute().getTotalProcessingTime()-order.getJob().getRemainingProcessingTime()+order.getExpectedTime();
		return resultado;
	}

	public static double getPTplusCT(SimulationStatus status, Order order){
		double resultado=0.0;
		if(status.keyExistsCT(order.getJob())){
			resultado=order.getExpectedTime()+status.getJobCompletionTime(order.getJob());
		}
		else{
			resultado=order.getExpectedTime();
		}		
		return resultado;
	}
	
	public static double getPTplusCTplusLWRK(SimulationStatus status, Order order){
		double resultado=0.0;
		if(status.keyExistsCT(order.getJob())){
			resultado=order.getExpectedTime()+status.getJobCompletionTime(order.getJob())+order.getExpectedTime()+order.getJob().getRemainingProcessingTime();
		}
		else{
			resultado=order.getExpectedTime()+order.getJob().getRemainingProcessingTime();
		}
			
		return resultado;
	}

	public static double getMOD(SimulationStatus status, Order order, double aFactor){
		double resultado=0.0;
		double firstComponent=order.getJob().getArrivalTime()+aFactor*(order.getRoute().getTotalProcessingTime()-order.getJob().getRemainingProcessingTime()+order.getExpectedTime()); // FROM SELS
		// FROM OZTURK double firstComponent = order.getJob().getArrivalTime() + (order.getJob().getDueDate() - order.getJob().getArrivalTime())*(order.getRemainingProcessingTime()/order.getRoute().getTotalProcessingTime());
		resultado=Math.max(firstComponent,status.getTimeInstant()+order.getExpectedTime());
		return resultado;
	}

	public static double getMDD(SimulationStatus status, Order order, double aFactor){
		double resultado=0.0;
		double firstComponent=status.getTimeInstant()+aFactor*(order.getRoute().getTotalProcessingTime()-order.getJob().getRemainingProcessingTime());
		resultado=Math.max(firstComponent,status.getTimeInstant()+order.getExpectedTime());
		return resultado;
	}

	public static double getMDD_bb(SimulationStatus status, Order order, double aFactor){
		double out = 0.0;
		out = Math.max(status.getTimeInstant()+ order.getRemainingProcessingTime(), order.getDueDate());
		return out;
	}

	public static double getSels20(SimulationStatus status, Order order){
		double resultado=0.0;
		double firstComponent=order.getJob().getArrivalTime()+order.getRoute().getTotalProcessingTime()-order.getJob().getRemainingProcessingTime()+order.getExpectedTime();
		resultado=Math.max(status.getTimeInstant()+order.getExpectedTime()-firstComponent,0.0);
		return resultado/order.getExpectedTime()*(-1.0); // pois e maximizacao
	}

	public static double getSels25(SimulationStatus status, Order order){
		double resultado=0.0;
		resultado=getFDD(status, order)/order.getJob().getRemainingProcessingTime();
		return resultado;
	}

	public static double getSels23(SimulationStatus status, Order order){
		double resultado=0.0;
		resultado=order.getExpectedTime()/order.getJob().getRemainingProcessingTime();
		return resultado;
	}

	public static double getOzturk1(SimulationStatus status, Order order){
		double resultado=0.0;
		resultado=getSlack(status, order);
		if (resultado>0) {
			resultado=resultado/order.getNumOperationsLeft();
		}
		else {
			resultado=resultado*order.getNumOperationsLeft();
		}
		return resultado;
	}

	public static double getOzturk2(SimulationStatus status, Order order){
		double resultado=0.0;
		resultado=(1 - (order.getJob().getDueDate()-status.getTimeInstant())/order.getRemainingProcessingTime())/order.getExpectedTime()+order.getExpectedTime();

		return resultado;
	}

	public static double getOzturk3(SimulationStatus status, Order order){
		double resultado=0.0;
		resultado = order.getRemainingProcessingTime()+ order.getJob().getArrivalTime() + (order.getJob().getDueDate() - order.getJob().getArrivalTime()) * (order.getRemainingProcessingTime()/order.getRoute().getTotalProcessingTime());

		return resultado;
	}

	public static double getOzturk4(SimulationStatus status, Order order){
		// Nao implementada, contem CRODD
		
		double resultado=0.0;
		resultado = 0;

		return resultado;
	}

	public static double getOzturk5(SimulationStatus status, Order order){
		double resultado=0.0;
		resultado = order.getRoute().getTotalProcessingTime() / (3 + order.getJob().getNumOperationsWorstCase() - order.getNumOperationsLeft());

		return resultado;
	}

	public static double getOzturk6(SimulationStatus status, Order order){
		double rOps=order.getNumOperationsLeft();
		double tops=order.getJob().getNumOperationsWorstCase();
		double tpt=order.getRoute().getTotalProcessingTime();
		double den=0.0;
		if ((order.getRemainingProcessingTime()-tpt)==0){
			den=1.0;
		}
		else{
			den = order.getRemainingProcessingTime()-tpt;
		}

		double subcomponent = tops*((rOps+tpt)/(den));
		
		double resultado=rOps * (order.getJob().getDueDate()+ subcomponent);

		return resultado;
	}

	public static double getOzturk7(SimulationStatus status, Order order){
		double resultado = order.getJob().getArrivalTime() + order.getExpectedTime() + 2*order.getRoute().getTotalProcessingTime();
		return resultado;
	}

	public static double getOzturk8(SimulationStatus status, Order order){
		double resultado = 7*order.getRoute().getTotalProcessingTime() + 11*order.getExpectedTime() + 12*(order.getJob().getNumOperationsWorstCase()+order.getJob().getArrivalTime());
		return resultado;
	}

	public static double getPTplusCTplusFDD(SimulationStatus status, Order order){
		double resultado=0.0;
		if(status.keyExistsCT(order.getJob())){
			resultado=order.getExpectedTime()+status.getJobCompletionTime(order.getJob())+getFDD(status, order);
		}
		else{
			resultado=order.getExpectedTime()+getFDD(status, order);
		}		
		return resultado;
	}

	public static double getPTplusLWRK(SimulationStatus status, Order order){
		double resultado=0.0;
		resultado=2*order.getExpectedTime()+order.getJob().getRemainingProcessingTime();
		return resultado;
	}

	public static double teymourifar1(SimulationStatus status, Order order){
		double resultado=0.0;
		resultado=order.getExpectedTime()/order.getRoute().getTotalProcessingTime();
		return resultado;
	}

	public static double teymourifar2(SimulationStatus status, Order order){
		//action 58
		double resultado=0.0;
		resultado=order.getNumOperationsLeft()-(order.getJob().getArrivalTime()+order.getExpectedTime())/order.getJob().getNumOperationsBestCase();
		return resultado*(-1.0);
	}

	public static double teymourifar3(SimulationStatus status, Order order){
		double resultado=0.0;
		resultado=2.0*order.getRoute().getTotalProcessingTime()+order.getNumOperationsLeft();
		return resultado;
	}

	public static double teymourifar4(SimulationStatus status, Order order){
		double resultado=0.0;
		resultado=order.getNumOperationsLeft()-order.getExpectedTime();
		return resultado;
	}

	public static double zhang1(SimulationStatus status, Order order){
		double resultado=0.0;
		double wiq=getWIQ(status, order);
		double component1 = wiq+order.getRemainingProcessingTime()+ (order.getExpectedTime()+order.getRemainingProcessingTime())/(wiq-1.0+order.getRemainingProcessingTime());
		resultado=order.getExpectedTime()+order.getRemainingProcessingTime()-(1/order.getExpectedTime())*(2*wiq-1.0)-(1/order.getExpectedTime())*component1;
		return resultado;
	}

	public static double zhang2(SimulationStatus status, Order order){
		double resultado=0.0;
		double wiq=getWIQ(status, order);
		double niq=status.getQueueSize(order.getMachine());
		double component1 = Math.max(order.getExpectedTime(), wiq);
		component1=Math.max(component1,Math.max(wiq, order.getRemainingProcessingTime()));
		resultado=niq * (order.getExpectedTime()-1.0) *(order.getExpectedTime()+order.getRemainingProcessingTime()*component1) + (niq+wiq)*( 1.0 + Math.max(order.getRemainingProcessingTime(),niq-1)) * Math.max(wiq,order.getRemainingProcessingTime());
		return resultado;
	}

	public static double customN1(SimulationStatus status, Order order){
		double resultado=0.0;
		double alpha=10.0;
		resultado=order.getExpectedTime()+(getSlack(status, order)/order.getRemainingProcessingTime())*order.getExpectedTime()+alpha*order.getOperation().getNumEligibleMachines()-order.getEnteringQueueTime();
		return resultado;
	}

	public static double customN2(SimulationStatus status, Order order){
		double resultado=0.0;
		double alpha=10.0;
		double beta=50.0;
		resultado=order.getExpectedTime()+(getSlack(status, order)/order.getRemainingProcessingTime())*beta+alpha*order.getOperation().getNumEligibleMachines()-order.getEnteringQueueTime();
		return resultado;
	}

	public static double customN3(SimulationStatus status, Order order){
		double resultado=0.0;
		double alpha=10.0;
		//double beta=50.0;
		resultado=order.getExpectedTime()+(getCriticalRatioStd(status, order)/order.getRemainingProcessingTime())*order.getExpectedTime()+alpha*order.getOperation().getNumEligibleMachines()-(status.getTimeInstant()-order.getEnteringQueueTime());
		return resultado;
	}

	public static double customN4(SimulationStatus status, Order order){
		double resultado=0.0;
		double alpha=10.0;
		double beta=50.0;
		resultado=order.getExpectedTime()+(getCriticalRatioStd(status, order)/order.getRemainingProcessingTime())*beta+alpha*order.getOperation().getNumEligibleMachines()-(status.getTimeInstant()-order.getEnteringQueueTime());
		return resultado;
	}

	public static double ho1(SimulationStatus status, Order order){
		double resultado=0.0;
		double parcela1=order.getRoute().getTotalProcessingTime()*(status.getTimeInstant()+order.getJob().getArrivalTime()+order.getExpectedTime()-3);
		double parcela2=status.getTimeInstant()*order.getExpectedTime()+order.getJob().getArrivalTime()+order.getJob().getNumOperationsWorstCase();
		double parcela3=order.getJob().getNumOperationsWorstCase()*order.getExpectedTime()+2.0*order.getExpectedTime()+status.getTimeInstant()+1;
		resultado=parcela1+parcela2-parcela3;
		return resultado;
	}

	public static double ho2(SimulationStatus status, Order order){
		double resultado=0.0;
		double parcela1=order.getExpectedTime()+status.getTimeInstant()+order.getJob().getArrivalTime()+2;
		double parcela2=order.getRemainingProcessingTime()+order.getExpectedTime()+order.getRoute().getTotalProcessingTime();
		resultado=parcela1*parcela2;
		return resultado;
	}

	public static double ho3(SimulationStatus status, Order order){
		double resultado=0.0;
		resultado=status.getTimeInstant()*order.getRoute().getTotalProcessingTime()+5*order.getJob().getNumOperationsWorstCase()+3*order.getJob().getArrivalTime();
		return resultado;
	}

	public static double ho4(SimulationStatus status, Order order){
		double resultado=0.0;
		resultado=order.getDueDate()*(order.getJob().getArrivalTime()+order.getRoute().getTotalProcessingTime()+order.getRemainingProcessingTime()+order.getExpectedTime());
		return resultado;
	}

	public static double ho5(SimulationStatus status, Order order){
		double resultado=0.0;
		resultado=(order.getRoute().getTotalProcessingTime()+order.getExpectedTime())*(status.getTimeInstant()+order.getJob().getArrivalTime())+(order.getDueDate()-order.getJob().getArrivalTime());
		return resultado;
	}

	public static double ho6(SimulationStatus status, Order order){
		double resultado=0.0;
		double tpt=order.getRoute().getTotalProcessingTime();
		double at=order.getJob().getArrivalTime();
		resultado=3*tpt+(order.getExpectedTime()/tpt+1)*(at+order.getRemainingProcessingTime());
		return resultado;
	}

	public static double ho7(SimulationStatus status, Order order){
		double resultado=0.0;
		double tpt=order.getRoute().getTotalProcessingTime();
		//double at=order.getJob().getArrivalTime();
		double nops=order.getJob().getNumOperationsWorstCase();
		resultado=6*nops+order.getExpectedTime()+status.getTimeInstant()*(order.getExpectedTime()+tpt);
		return resultado;
	}

	public static double ho8(SimulationStatus status, Order order){
		double resultado=0.0;
		double tpt=order.getRoute().getTotalProcessingTime();
		//double at=order.getJob().getArrivalTime();
		double nops=order.getJob().getNumOperationsWorstCase();
		resultado=nops+9*tpt+4*order.getExpectedTime();
		return resultado;
	}

	public static double ho9(SimulationStatus status, Order order){
		double resultado=0.0;
		double tpt=order.getRoute().getTotalProcessingTime();
		//double at=order.getJob().getArrivalTime();
		double nops=order.getJob().getNumOperationsWorstCase();
		resultado=4*tpt-2*nops+3*order.getDueDate()+2*order.getExpectedTime();
		return resultado;
	}

	public static double ho10(SimulationStatus status, Order order){
		double resultado=0.0;
		double tpt=order.getRoute().getTotalProcessingTime();
		double at=order.getJob().getArrivalTime();
		//double nops=order.getJob().getNumOperationsWorstCase();
		resultado=order.getDueDate()/tpt+2*tpt+order.getExpectedTime()+order.getDueDate()+at;
		return resultado;
	}

	public static double ho11(SimulationStatus status, Order order){
		double resultado=0.0;
		double tpt=order.getRoute().getTotalProcessingTime();
		double at=order.getJob().getArrivalTime();
		double nops=order.getJob().getNumOperationsWorstCase();
		resultado=at+2*order.getExpectedTime()+2*tpt+nops;
		return resultado;
	}

	public static double ho14(SimulationStatus status, Order order){
		double resultado=0.0;
		double tpt=order.getRoute().getTotalProcessingTime();
		double at=order.getJob().getArrivalTime();
		double nops=order.getJob().getNumOperationsWorstCase();
		resultado=(at+order.getDueDate())+2*(at+tpt)+order.getExpectedTime()-nops;
		return resultado;
	}

	public static double ho15(SimulationStatus status, Order order){
		double resultado=0.0;
		double tpt=order.getRoute().getTotalProcessingTime();
		double at=order.getJob().getArrivalTime();
		double nops=order.getJob().getNumOperationsWorstCase();
		resultado=(at+order.getDueDate())+(tpt+order.getExpectedTime())-2*(at/nops);
		return resultado;
	}

	public static double getBraune1(SimulationStatus status, Order order){
		double resultado=0.0;
		
		double z=0.0;
		List<Order> nextQueue = status.getQueue(order.getMachine());
		for(Order nextOrder: nextQueue){		
			z+= nextOrder.getExpectedTime();
		}
		double apt=z/(double)status.getQueueSize(order.getMachine());
		
		double jinq=getJINQ(status, order);
		resultado=jinq+order.getExpectedTime()+2*Math.min(jinq,order.getExpectedTime())+Math.min(jinq+order.getExpectedTime(),apt);
		return resultado;
	}

	public static double getHunt1(SimulationStatus status, Order order){
		double resultado=0.0;
		double nrops=order.getNumOperationsLeft();		
		resultado=(order.getExpectedTime()/order.getRemainingProcessingTime())*(status.getTimeInstant()-order.getDueDate())*((nrops+1)/(nrops*order.getJob().getArrivalTime()));
		
		// the weight was assumed to be 1
		// ready time of machine was replaced by time instant

		return resultado * (-1.0);
	}

	public static double getHunt2(SimulationStatus status, Order order){
		double resultado=0.0;		
		resultado=(order.getExpectedTime()/order.getRemainingProcessingTime())*((status.getTimeInstant()-order.getDueDate())/order.getDueDate());

		// ready time of machine was replaced by time instant

		return resultado * (-1.0);
	}

	public static double getHunt3(SimulationStatus status, Order order){
		double resultado=0.0;		
		resultado=(order.getExpectedTime()*(-1.0))/(order.getDueDate()+(status.getTimeInstant()-order.getEnteringQueueTime()));
		if (getSlack(status,order)>0){
			resultado=resultado*((status.getTimeInstant()*(order.getDueDate()-status.getTimeInstant()+order.getRemainingProcessingTime()))/(order.getDueDate()+order.getRemainingProcessingTime()));
		}
		return resultado * (-1.0);
	}

	public static double getHunt4(SimulationStatus status, Order order){
		double resultado=0.0;
		double firstComponent=Math.max(order.getDueDate(),status.getTimeInstant());
		double secondComponent=Math.min(status.getTimeInstant(),firstComponent-order.getRemainingProcessingTime());		
		resultado=(order.getExpectedTime()*(secondComponent-Math.max(order.getDueDate(),status.getTimeInstant())))/order.getRemainingProcessingTime();
		return resultado*(-1.0);
	}

	public static double getPlaninic1(SimulationStatus status, Order order){
		double resultado=0.0;		
		resultado=3*order.getExpectedTime()+2*getSlack(status, order)+getSlack(status, order)*getSlack(status, order);
		return resultado;
	}

	public static double getPlaninic1b(SimulationStatus status, Order order){
		double resultado=0.0;		
		//resultado=3*order.getExpectedTime()+2*getSlack(status, order)+getSlack(status, order)*getSlack(status, order);
		resultado = 3* order.getOperation().getMinProcessingTime()+order.getOperation().getAverageExpectedTime()-order.getExpectedTime()+2*getPositiveSlack(status, order)+ Math.pow(getPositiveSlack(status, order), 2);
		return resultado;
	}

	public static double getPlaninic1c(SimulationStatus status, Order order){
		double resultado=0.0;		
		//resultado=3*order.getExpectedTime()+2*getSlack(status, order)+getSlack(status, order)*getSlack(status, order);
		//resultado = 3* order.getOperation().getMinProcessingTime()+order.getOperation().getAverageExpectedTime()-order.getExpectedTime()+2*getPositiveSlack(status, order)+ Math.pow(getPositiveSlack(status, order), 2);
		resultado = 2* order.getOperation().getMinProcessingTime() + order.getOperation().getAverageExpectedTime() - order.getExpectedTime() + 2* getPositiveSlack(status, order);
		return resultado;
	}

	public static double getPlaninic1d(SimulationStatus status, Order order){
		double resultado=0.0;		
		resultado=3*order.getExpectedTime()+2*getSlack(status, order)+getSlack(status, order)*getSlack(status, order);
		return resultado;
	}

	public static double getPlaninic1e(SimulationStatus status, Order order){
		double resultado=0.0;		
		resultado=2 * ( getSlack(status, order) + order.getExpectedTime() );
		return resultado;
	}

	public static double getPlaninic2(SimulationStatus status, Order order){
		double resultado=0.0;
		double component1=0.0;
		if ((order.getExpectedTime()-getPositiveSlack(status, order))==0){
			component1=1.0;
		}
		else{
			component1 = (order.getExpectedTime()*getPositiveSlack(status, order))/(order.getExpectedTime()-getPositiveSlack(status, order));
		}
		double component2 = order.getExpectedTime()*(order.getDueDate()/order.getExpectedTime()+order.getExpectedTime()+order.getDueDate());	
		resultado=order.getExpectedTime()*order.getEnteringQueueTime()-Math.pow(order.getExpectedTime(),2)+getPositiveSlack(status, order)*order.getDueDate()+component1+component2+getPositiveSlack(status, order)*(getPositiveSlack(status, order)+order.getExpectedTime())+order.getDueDate();
		return resultado;
	}

	public static double getPlaninic2b(SimulationStatus status, Order order){
		double resultado=0.0;
		double component1=0.0;
		if ((order.getOperation().getAverageExpectedTime()-getPositiveSlack(status, order))==0){
			component1=1.0;
		}
		else{
			component1 = (order.getOperation().getMinProcessingTime()*getPositiveSlack(status, order))/(order.getOperation().getAverageExpectedTime()-getPositiveSlack(status, order));
		}
		double component2 = order.getOperation().getMinProcessingTime()*(order.getDueDate()/order.getExpectedTime()+order.getOperation().getAverageExpectedTime()+order.getDueDate());	
		resultado=order.getOperation().getMinProcessingTime()*order.getJob().getArrivalTime()-order.getExpectedTime()*order.getOperation().getAverageExpectedTime()+getPositiveSlack(status, order)+component1+component2+getPositiveSlack(status, order)*(getPositiveSlack(status, order)+order.getOperation().getAverageExpectedTime())+order.getDueDate();
		return resultado;
	}

	public static double getPlaninic2c(SimulationStatus status, Order order){
		double resultado=0.0;
		double component1=0.0;
		if ((order.getExpectedTime()-getPositiveSlack(status, order))==0){
			component1=1.0;
		}
		else{
			component1 = (order.getExpectedTime()*getPositiveSlack(status, order)) / (order.getExpectedTime()-getPositiveSlack(status, order));
		}
		double component2 = order.getExpectedTime()*(order.getDueDate()/order.getExpectedTime()+order.getExpectedTime()+order.getDueDate());	
		
		resultado=order.getExpectedTime() * (status.getTimeInstant() - order.getEnteringQueueTime()) - Math.pow(order.getExpectedTime(),2)+component1+component2+getPositiveSlack(status, order)*(getSlack(status, order)+order.getExpectedTime())+order.getDueDate();
		return resultado;
	}

	public static double getPlaninic2d(SimulationStatus status, Order order){
		double resultado=0.0;
		double component1=0.0;
		if ((order.getExpectedTime()-getPositiveSlack(status, order))==0){
			component1=1.0;
		}
		else{
			component1 = (order.getExpectedTime()*getPositiveSlack(status, order)) / (order.getExpectedTime()-getPositiveSlack(status, order));
		}
		double component2 = (order.getExpectedTime()-1.0)*(order.getDueDate()/order.getExpectedTime()+order.getExpectedTime()+order.getDueDate());	
		
		resultado=order.getExpectedTime() * (status.getTimeInstant() - order.getEnteringQueueTime()) - Math.pow(order.getExpectedTime(),2)+component1+component2+getPositiveSlack(status, order)*(getSlack(status, order)+order.getExpectedTime())+order.getDueDate();
		return resultado;
	}

	public static double getPlaninic3(SimulationStatus status, Order order, Machine mac){
		double resultado=0.0;		
		resultado=-getPositiveSlack(status, order)*order.getExpectedTime()+Math.max(getPositiveSlack(status, order)-order.getExpectedTime(),0)+order.getExpectedTime();
		return resultado;
	}

	public static double getPlaninic3b(SimulationStatus status, Order order, Machine mac){
		double resultado=0.0;
		double pat=getPAT(status, order, mac);		
		resultado = order.getOperation().getAverageExpectedTime() * (order.getOperation().getMinProcessingTime()+pat+getPositiveSlack(status, order)-order.getExpectedTime()) + order.getOperation().getMinProcessingTime();
		return resultado;
	}

	public static double getPlaninic3c(SimulationStatus status, Order order, Machine mac){
		double resultado=0.0;
		//double pat=getPAT(status, order, mac);		
		resultado = order.getExpectedTime()*getSlack(status, order) + order.getExpectedTime();
		return resultado;
	}

	public static double getPlaninic4(SimulationStatus status, Order order){
		double resultado=0.0;		
		resultado=order.getDueDate()-order.getExpectedTime()+getPositiveSlack(status, order);
		return resultado;
	}

	public static double getPlaninic5(SimulationStatus status, Order order){
		double resultado=0.0;		
		resultado=order.getExpectedTime()+3*order.getDueDate()+getSlack(status, order);
		return resultado;
	}

	public static double getPlaninic5b(SimulationStatus status, Order order, Machine mac){
		double resultado=0.0;
		double div=1.0;
		if (getPAT(status, order, mac)!=0.0){
			div = ( 3*order.getDueDate() + order.getExpectedTime() ) / getPAT(status, order, mac);
		}
		resultado = div + order.getOperation().getMinProcessingTime() + order.getDueDate() - order.getExpectedTime() + getPositiveSlack(status, order);
		return resultado;
	}

	public static double getPlaninic5c(SimulationStatus status, Order order){
		double resultado=0.0;		
		resultado = order.getDueDate() + getSlack(status, order);
		return resultado;
	}

	public static double gpRule(SimulationStatus status, Order order){
		double resultado=0.0;
		resultado=getSlack(status, order)*(getWINQ(status,order)+order.getExpectedTime());
		return resultado;
	}

	public static double getDFJSSPRule1(SimulationStatus status, Order order){
		double resultado=0.0;
		resultado=order.getExpectedTime()+order.getOperation().getNumEligibleMachines()+order.getExpectedTime()*getCriticalRatioPos(status, order);
		return resultado;
	}

	public static double getDFJSSPRule2(SimulationStatus status, Order order, int m1, int m2){
		double resultado=0.0;
		double firstTerm=order.getExpectedTime()*order.getOperation().getNumEligibleMachines();
		double secondTerm=order.getJob().getDueDate() - status.getTimeInstant() - order.getRemainingProcessingTime();
		resultado=m1*firstTerm+m2*secondTerm;
		return resultado;
	}

	public static double getDFJSSPRule3(SimulationStatus status, Order order){
		double resultado=0.0;
		double firstTerm=order.getExpectedTime()*order.getOperation().getNumEligibleMachines();
		double secondTerm=order.getExpectedTime()+order.getJob().getDueDate() - status.getTimeInstant() - order.getRemainingProcessingTime();
		resultado=firstTerm+secondTerm;
		return resultado;
	}

	public static double getDFJSSPRule4(SimulationStatus status, Order order,double utilisation){
		double resultado=0.0;
		double ptFlex= order.getExpectedTime()*order.getOperation().getNumEligibleMachines();
		double tis=status.getTimeInstant() - order.getEnteringQueueTime();
		double term1= order.getOperation().getNumEligibleMachines()/(tis*utilisation);
		if(tis==0){
			term1=1;
		}
		resultado= term1*ptFlex+ptFlex+getCriticalRatioPos(status, order)+order.getExpectedTime()+order.getRemainingProcessingTime();
		return resultado;
	}

	public static double getDFJSSPRule5(SimulationStatus status, Order order,double aFactor){
		double resultado=0.0;
		double ptFlex= order.getExpectedTime()*order.getOperation().getNumEligibleMachines();
		double tis=status.getTimeInstant() - order.getEnteringQueueTime();
		double term1= getCriticalRatioPos(status, order)+aFactor;
		double term2= (order.getRemainingProcessingTime()+order.getExpectedTime())/(tis+order.getOperation().getNumEligibleMachines());
		resultado=ptFlex*ptFlex*order.getExpectedTime()*order.getExpectedTime()*term1*term2;
		//double term1= order.getOperation().getNumEligibleMachines()/(tis*utilisation);
		//resultado= term1*ptFlex+ptFlex+getCriticalRatio(status, order)+order.getExpectedTime()+order.getRemainingProcessingTime();
		return resultado;
	}

	public static double getDFJSSPRule6(SimulationStatus status, Order order,double aFactor){
		double resultado=0.0;
		resultado=(order.getExpectedTime()*order.getOperation().getNumEligibleMachines())+(getSlack(status, order)*aFactor);
		return resultado;
	}

	public static double getDFJSSPRule7(SimulationStatus status, Order order,double mult){
		double resultado=0.0;
		resultado=(order.getExpectedTime()*getCriticalRatioPos(status, order))+mult*order.getExpectedTime();
		return resultado;
	}

	public static double getDFJSSPRule8(SimulationStatus status, Order order,double aFactor){
		double resultado=0.0;
		resultado=(aFactor+getCriticalRatioPos(status, order))*order.getExpectedTime();
		return resultado;
	}

	public static double getDFJSSPRule9(SimulationStatus status, Order order,double aFactor){
		double resultado=0.0;
		resultado=(aFactor+getCriticalRatioPos(status, order))*order.getExpectedTime()*order.getOperation().getNumEligibleMachines();
		return resultado;
	}

	public static double getDFJSSPRule10(SimulationStatus status, Order order,double aFactor){
		double resultado=0.0;
		double term1=(aFactor+getCriticalRatioPos(status, order))*order.getExpectedTime();
		resultado=term1*term1*order.getOperation().getNumEligibleMachines();
		return resultado;
	}

	public static double getDFJSSPRule11(SimulationStatus status, Order order,double aFactor){
		double resultado=0.0;
		resultado=(aFactor+getCriticalRatioPos(status, order))*order.getExpectedTime()*order.getExpectedTime()*order.getOperation().getNumEligibleMachines();
		return resultado;
	}

	public static double getDFJSSPRule12(SimulationStatus status, Order order,double aFactor){
		double resultado=0.0;
		double ptFlex= order.getExpectedTime()*order.getOperation().getNumEligibleMachines();
		double tis=status.getTimeInstant() - order.getEnteringQueueTime();
		double div=order.getRemainingProcessingTime()/(order.getRemainingProcessingTime()+tis);
		if ((order.getRemainingProcessingTime()+tis)==0){
			div=1.0;
		}
		resultado=aFactor+((aFactor+getCriticalRatioPos(status, order))*ptFlex*order.getExpectedTime()*div);
		return resultado;
	}

	public static double getDFJSSPRule13(SimulationStatus status, Order order,double uLevel){
		double resultado=0.0;
		double cPt=order.getExpectedTime();
		double tis=status.getTimeInstant() - order.getEnteringQueueTime();
		double div=uLevel/tis;
		if (tis==0){
			div=1.0;
		}
		resultado=cPt+cPt*cPt*cPt*cPt*(uLevel+cPt)*(div)*order.getRemainingProcessingTime()*order.getOperation().getNumEligibleMachines();
		return resultado;
	}

	public static double getDFJSSPRule14(SimulationStatus status, Order order,double aFactor){
		double resultado=0.0;
		double cPt=order.getExpectedTime();
		double ptFlex= order.getExpectedTime()*order.getOperation().getNumEligibleMachines();
		resultado=(ptFlex+order.getRemainingProcessingTime())*cPt*(getCriticalRatioPos(status, order)+aFactor)+getSlack(status, order);
		return resultado;
	}

	public static double getDFJSSPRule15(SimulationStatus status, Order order){
		double resultado=0.0;
		double flexibility = order.getOperation().getNumEligibleMachines();
		double tis=status.getTimeInstant() - order.getEnteringQueueTime();
		resultado = order.getExpectedTime()*order.getRemainingProcessingTime()*(order.getExpectedTime()/(tis+flexibility));
		return resultado;
	}

	public static double getDFJSSPRule16(SimulationStatus status, Order order, double aFactor){
		double resultado=0.0;
		double flexibility = order.getOperation().getNumEligibleMachines();
		resultado = (aFactor+flexibility)*aFactor+getSlack(status, order)+order.getExpectedTime();
		return resultado;
	}

	public static double getDFJSSPRule17(SimulationStatus status, Order order, double aFactor){
		double resultado=0.0;
		double flexibility = order.getOperation().getNumEligibleMachines();
		resultado = (aFactor+flexibility)*(aFactor+order.getExpectedTime()) + getSlack(status, order);
		return resultado;
	}

	public static double getDFJSSPRule18(SimulationStatus status, Order order, double uLevel){
		double resultado	=	0.0	;
		double flexibility 	= 	order.getOperation().getNumEligibleMachines()/10.0		;	//Hard Coded value
		double tis			=	status.getTimeInstant() - order.getEnteringQueueTime()	;
		double den 			= 	0	;
		if (0+tis==0){	den	=	1	;	}
		else{				den	= 	0 + tis	;	}		

		resultado = Math.pow(order.getExpectedTime(),5)*1*1*order.getRemainingProcessingTime()*(flexibility/den);
		return resultado;
	}

	public static double getDFJSSPRule19(SimulationStatus status, Order order, double aFactor, double uLevel){
		double resultado = 0.0;
		double tis=status.getTimeInstant() - order.getEnteringQueueTime();
		double flexibility = order.getOperation().getNumEligibleMachines();
		double factor1 = getCriticalRatioPos(status, order)+ 2 * aFactor;
		double denominator = order.getRemainingProcessingTime()+tis;
		double numerator=0.0;
		if(denominator==0){
			resultado=factor1;
		}
		else{
			numerator = uLevel + (order.getRemainingProcessingTime()*order.getExpectedTime())/aFactor + flexibility * (order.getRemainingProcessingTime()+tis);
			resultado=factor1*(numerator/denominator);
		}
		return resultado;
	}

	public static double getDFJSSPRule20(SimulationStatus status, Order order, double aFactor){
		double resultado = 0.0;
		double flexibility = order.getOperation().getNumEligibleMachines();
		double tis=status.getTimeInstant() - order.getEnteringQueueTime();
		double div = 0.0;
		if (tis==0)		{div = 1.0;}
		else			{div = (aFactor*aFactor)/tis;}
		resultado=Math.pow(order.getExpectedTime(),5)*order.getRemainingProcessingTime()*flexibility*div+flexibility;
		return resultado;
	}

	public static double getDFJSSPRule21(SimulationStatus status, Order order){
		double resultado=0.0;
		double flexibility = order.getOperation().getNumEligibleMachines();
		double tis=status.getTimeInstant() - order.getEnteringQueueTime();
		if (tis==0)	{tis=1.0;}
		else 		{tis=1.0;}

		resultado = Math.pow(order.getExpectedTime(),4)*order.getRemainingProcessingTime()*flexibility/tis;
		return resultado;
	}

	public static double getDFJSSPRule22(SimulationStatus status, Order order){
		double resultado=0.0;
		double tis=status.getTimeInstant() - order.getEnteringQueueTime();
		resultado = Math.pow(order.getExpectedTime(),2)/(order.getExpectedTime()+tis);
		return resultado;
	}

	public static double getDFJSSPRule23(SimulationStatus status, Order order){
		double resultado=0.0;
		double flexibility = order.getOperation().getNumEligibleMachines();
		double tis=status.getTimeInstant() - order.getEnteringQueueTime();

		resultado = (flexibility+2*order.getExpectedTime())*(2*order.getExpectedTime()+order.getRemainingProcessingTime()+flexibility)/(order.getExpectedTime()+tis);
		return resultado;
	}

	public static double getDFJSSPRule24(SimulationStatus status, Order order){
		double resultado=0.0;
		double flexibility = order.getOperation().getNumEligibleMachines();
		double tis=status.getTimeInstant() - order.getEnteringQueueTime();

		resultado = Math.pow(order.getExpectedTime(),2)*flexibility*((2*flexibility+order.getRemainingProcessingTime())/(order.getExpectedTime()+tis));

		return resultado;
	}

	public static double getDFJSSPRule25(SimulationStatus status, Order order){
		double resultado=0.0;
		double flexibility = order.getOperation().getNumEligibleMachines();
		double tis=status.getTimeInstant() - order.getEnteringQueueTime();

		resultado = Math.pow(order.getExpectedTime(),4)*(order.getRemainingProcessingTime()/(flexibility+tis));

		return resultado;
	}

	public static double getDFJSSPRule26(SimulationStatus status, Order order){
		double resultado=0.0;
		double flexibility = order.getOperation().getNumEligibleMachines();
		double tis=status.getTimeInstant() - order.getEnteringQueueTime();

		resultado = Math.pow(order.getExpectedTime(),4)*(order.getRemainingProcessingTime()/(flexibility+tis));

		return resultado;
	}

	public static double getDFJSSPRule27(SimulationStatus status, Order order, double uLevel){
		double resultado=0.0;

		resultado = order.getExpectedTime()*(getCriticalRatioPos(status, order)+uLevel);

		return resultado;
	}

	public static double getDFJSSPRule28(SimulationStatus status, Order order, double uLevel){
		double resultado=0.0;
		double flexibility = order.getOperation().getNumEligibleMachines();

		resultado = order.getExpectedTime()*flexibility*uLevel*(getCriticalRatioPos(status, order)+uLevel)*Math.max(order.getExpectedTime(), (uLevel+order.getExpectedTime())*getCriticalRatioPos(status, order));

		return resultado;
	}

	public static double getDFJSSPRule29(SimulationStatus status, Order order){
		double resultado=0.0;

		resultado = order.getExpectedTime()*getCriticalRatioPos(status, order)*getCriticalRatioPos(status, order)+order.getExpectedTime();

		return resultado;
	}

	public static double getDFJSSPRule30(SimulationStatus status, Order order){
		double resultado=0.0;

		resultado = 2.0*getCriticalRatioPos(status, order)*order.getExpectedTime()+order.getExpectedTime();

		return resultado;
	}

	public static double getDFJSSPRule31(SimulationStatus status, Order order){
		double resultado=0.0;
		double tis=status.getTimeInstant() - order.getEnteringQueueTime();
		double ptFlex= order.getExpectedTime()*order.getOperation().getNumEligibleMachines();
		double flexibility = order.getOperation().getNumEligibleMachines(); 

		resultado = (ptFlex+(order.getExpectedTime()*order.getRemainingProcessingTime())*ptFlex*ptFlex)/(2*tis+flexibility+order.getExpectedTime());

		return resultado;
	}

	public static double getDFJSSPRule32(SimulationStatus status, Order order){
		double resultado=0.0;
		double tis=status.getTimeInstant() - order.getEnteringQueueTime();
		//double ptFlex= order.getExpectedTime()*order.getOperation().getNumEligibleMachines();
		double flexibility = order.getOperation().getNumEligibleMachines(); 

		resultado = ((Math.pow(order.getExpectedTime(), 2)+order.getExpectedTime()*order.getRemainingProcessingTime())*Math.pow(order.getExpectedTime(), 3)*Math.pow(order.getOperation().getNumEligibleMachines(), 3))/(tis+flexibility);

		return resultado;
	}

	public static double getDFJSSPRule33(SimulationStatus status, Order order, double utilisation){
		double resultado=0.0;

		resultado = 2*order.getExpectedTime()*(utilisation*getCriticalRatioPos(status, order))+2*utilisation+order.getExpectedTime()+1;

		return resultado;
	}

	public static double getDFJSSPRule34(SimulationStatus status, Order order, double utilisation, double allowance){
		double resultado=0.0;
		double flexibility = order.getOperation().getNumEligibleMachines();
		double tis=status.getTimeInstant() - order.getEnteringQueueTime(); 

		resultado = (utilisation*2*Math.pow(order.getExpectedTime(),2)*order.getRemainingProcessingTime()*flexibility)/((flexibility+tis)/(order.getExpectedTime()*allowance));

		return resultado;
	}

	public static double getDFJSSPRule35(SimulationStatus status, Order order){
		double resultado=0.0;
		double flexibility = order.getOperation().getNumEligibleMachines();
		double tis=status.getTimeInstant() - order.getEnteringQueueTime(); 

		resultado = (2*Math.pow(order.getExpectedTime(),3)*order.getRemainingProcessingTime()*flexibility)/(2*flexibility+tis)+order.getExpectedTime();

		return resultado;
	}

	public static double getDFJSSPRule36(SimulationStatus status, Order order, double allowance){
		double resultado=0.0;
		double flexibility = order.getOperation().getNumEligibleMachines();
		double tis=status.getTimeInstant() - order.getEnteringQueueTime();
		if (tis == 0) {
			tis=1.0;
		} 

		resultado = (order.getExpectedTime()*flexibility/tis+getCriticalRatioPos(status, order))*Math.pow(order.getExpectedTime(),2)*order.getRemainingProcessingTime()*allowance;

		return resultado;
	}

	public static double getDFJSSPRule37(SimulationStatus status, Order order, double utilisation){
		double resultado=0.0;
		double flexibility = order.getOperation().getNumEligibleMachines();
		double tis=status.getTimeInstant() - order.getEnteringQueueTime();
		
		if (tis == 0) {
			tis=1.0;
		}

		resultado = Math.pow(order.getExpectedTime(),4)*order.getRemainingProcessingTime()*flexibility*utilisation/tis+utilisation;

		return resultado;
	}

	public static double getDFJSSPRule38(SimulationStatus status, Order order){
		double resultado=0.0;
		double flexibility = order.getOperation().getNumEligibleMachines();
		double tis=status.getTimeInstant() - order.getEnteringQueueTime();
		
		resultado = (Math.pow(order.getExpectedTime(),3)*order.getRemainingProcessingTime()*flexibility)/(tis+flexibility);

		return resultado;
	}

	public static double getDFJSSPRule39(SimulationStatus status, Order order){
		double resultado=0.0;
		double flexibility = order.getOperation().getNumEligibleMachines();
		double tis=status.getTimeInstant() - order.getEnteringQueueTime();
		
		resultado = (Math.pow(order.getExpectedTime(),2)* Math.pow(order.getRemainingProcessingTime(),2)/(flexibility+tis)+flexibility+order.getRemainingProcessingTime())*Math.pow(order.getExpectedTime(),2)*flexibility/order.getRemainingProcessingTime();

		return resultado;
	}

	public static double getDFJSSPRule41(SimulationStatus status, Order order){
		double resultado=0.0;
		double flexibility = order.getOperation().getNumEligibleMachines();
		double tis=status.getTimeInstant() - order.getEnteringQueueTime();
		
		resultado = (Math.pow(order.getExpectedTime(),4)*order.getRemainingProcessingTime()+flexibility)/tis;

		return resultado;
	}

	public static double getDFJSSPRule42(SimulationStatus status, Order order){
		double resultado=0.0;
		double flexibility = order.getOperation().getNumEligibleMachines();
		double tis=status.getTimeInstant() - order.getEnteringQueueTime();
		
		double parcela1=(order.getExpectedTime()+flexibility)*order.getExpectedTime();
		double parcela2=tis+order.getRemainingProcessingTime()+order.getExpectedTime()*order.getRemainingProcessingTime();
		resultado=(parcela1*parcela2*flexibility)/(flexibility+tis);

		return resultado;
	}

	public static double getDFJSSPRule43(SimulationStatus status, Order order){
		double resultado=0.0;
		double flexibility = order.getOperation().getNumEligibleMachines();
		double tis=status.getTimeInstant() - order.getEnteringQueueTime();
		
		resultado = Math.pow(order.getExpectedTime(),5)*order.getRemainingProcessingTime()*flexibility/tis+tis;

		return resultado;
	}

	public static double getDFJSSPRule44(SimulationStatus status, Order order, double utilisation,int nMac){
		double resultado=0.0;
		//int nMac = order.getRoute().g
		double flexibility = order.getOperation().getNumEligibleMachines()/(double)nMac;
		double tis=status.getTimeInstant() - order.getEnteringQueueTime();

		if (tis == 0) {
			tis=1.0;
		}

		resultado = (Math.pow(order.getExpectedTime(),4)*order.getRemainingProcessingTime()*flexibility*utilisation)/tis;

		return resultado;
	}

	public static double getDFJSSPRule45(SimulationStatus status, Order order, int nMac){
		double resultado=0.0;
		double flexibility = order.getOperation().getNumEligibleMachines()/(double)nMac;

		resultado = ((getCriticalRatioPos(status, order)+flexibility)*order.getExpectedTime()+flexibility)*order.getExpectedTime();

		return resultado;
	}

	public static double getDFJSSPRule46(SimulationStatus status, Order order, int nMac){
		double resultado=0.0;
		double flexibility = order.getOperation().getNumEligibleMachines()/(double)nMac;

		resultado = (getCriticalRatioPos(status, order)+flexibility)*order.getExpectedTime()+flexibility;

		return resultado;
	}

	public static double getDFJSSPRule47(SimulationStatus status, Order order){
		double resultado=0.0;

		resultado = order.getExpectedTime()+2*order.getExpectedTime()*getCriticalRatioPos(status, order);

		return resultado;
	}

	public static double getDFJSSPRule48(SimulationStatus status, Order order, double utilisation, int a, double mult1, double mult2, double mult3,int nMac){
		double resultado= 0.0;
		double b = 0.0;
		double c = 0.0;
		double tis=status.getTimeInstant() - order.getEnteringQueueTime();
		double flexibility = order.getOperation().getNumEligibleMachines()/(double)nMac;

		if		(mult1==1.0)	{b=flexibility;}
		else					{b=1.0;}

		if		(mult2==1.0)	{c=utilisation;}
		else					{c=1.0;}

		double numerator=Math.pow(order.getExpectedTime(),a)*order.getRemainingProcessingTime()*b*c;
		double denominator=tis + mult3*flexibility;

		if (denominator == 0) {
			denominator=1.0;
		}

		resultado=numerator/denominator;
		return resultado;
	}

	public static double gpRuleInt3(SimulationStatus status, Order order, int nMac){
		return order.getExpectedTime()*order.getRemainingProcessingTime()*((double)order.getOperation().getNumEligibleMachines())/((double)nMac);
	}

	public static double getPTWIQ(SimulationStatus status, Order order){
		return order.getExpectedTime()+getWIQ(status, order);
	}

	public static double alvaro1(SimulationStatus status, Order order){
		double resultado	=	0.0;
		resultado			=	getCriticalRatioPos(status, order);
		return resultado;
	}

	public static double alvaro2(SimulationStatus status, Order order){
		double resultado	=	0.0;
		resultado			=	getWINQ(status, order);
		return resultado;
	}

	public static double alvaro3(SimulationStatus status, Order order){
		double resultado	=	0.0;
		resultado			=	getCriticalRatioPos(status, order)*order.getExpectedTime();
		return resultado;
	}

	public static double alvaro4(SimulationStatus status, Order order){
		double resultado	=	0.0;
		resultado			=	getPTWINQ(status, order);
		return resultado;
	}

	public static double alvaro5(SimulationStatus status, Order order){
		double resultado	=	0.0;
		resultado			=	getCriticalRatioPos(status, order)*order.getExpectedTime()+getWINQ(status, order);
		return resultado;
	}

	public static double alvaro6(SimulationStatus status, Order order){
		double resultado	=	0.0;
		resultado			=	getCriticalRatioPos(status, order)*order.getExpectedTime()+getWINQ(status, order)+order.getExpectedTime();
		return resultado;
	}

	public static double alvaro7(SimulationStatus status, Order order){
		double resultado	=	0.0;
		resultado			=	( getPositiveSlack(status, order) + order.getRemainingProcessingTime() ) * (getWINQ(status, order) + order.getExpectedTime()) / (order.getRemainingProcessingTime());
		return resultado;
	}

	public static double alvaro8(SimulationStatus status, Order order){
		double resultado	=	0.0;
		resultado			=	getCriticalRatioPos(status, order)*order.getExpectedTime()+getWINQ(status, order)+2*order.getExpectedTime();
		return resultado;
	}

	public static double alvaro9(SimulationStatus status, Order order){
		double resultado	=	0.0;
		resultado			=	(getPositiveSlack(status, order) + order.getRemainingProcessingTime()) * (getWINQ(status, order)+order.getExpectedTime()) / (order.getRemainingProcessingTime()+getWINQ(status, order)) ;
		return resultado;
	}

	public static double alvaro10(SimulationStatus status, Order order){
		double resultado	=	0.0;
		resultado			=	getWINQ(status, order) + order.getExpectedTime() + (getPositiveSlack(status, order)*order.getExpectedTime()) / (2*order.getRemainingProcessingTime());
		return resultado;
	}

	// Rules for machine allocation

	public static int mar1(Operation op, double[] timesArr, SimulationStatus sts){
		// first available machine
		int result=0;
		int macIDX=-1;
		double score=Double.MAX_VALUE;
		List<Machine> eligibleMachineList	= op.getEligibleMachines();
		for (Machine mac :eligibleMachineList){
			macIDX=mac.getId()-1;
			double readyTime=0.0;
			if (timesArr[macIDX]==Double.MAX_VALUE){
				readyTime=sts.getTimeInstant();
			}
			else{
				readyTime=timesArr[macIDX];
			}
			if (readyTime<score){
				score=readyTime;
				result=macIDX;
			}
		}
		return result;
	}

	public static int mar2(Operation op, double[] timesArr, SimulationStatus sts){
		// least WINQ
		int result=0;
		double machineScore= Double.MAX_VALUE;
		double score=Double.MAX_VALUE;
		List<Machine> eligibleMachineList	= op.getEligibleMachines();
		for (Machine mac :eligibleMachineList){
			machineScore=sts.getMachineWorkInQueue(mac);
			if (machineScore<score){
				score=machineScore;
				result=mac.getId()-1;
			}
		}
		return result;
	}

	public static int mar3(Operation op, double[] timesArr, SimulationStatus sts){
		// shorter PT
		int result=0;
		double machineScore= Double.MAX_VALUE;
		double score=Double.MAX_VALUE;
		List<Machine> eligibleMachineList	= op.getEligibleMachines();
		for (Machine mac :eligibleMachineList){
			machineScore=op.getTime(mac);
			if (machineScore<score){
				score=machineScore;
				result=mac.getId()-1;
			}
		}
		return result;
	}

	public static double getGS46(SimulationStatus status, Order order,int nMac, double mfq){
		double resultado = 0.0;
		double pt 		 = order.getExpectedTime();
		double ptr 		 = order.getExpectedTime() / order.getOperation().getAverageExpectedTime();
		double flex 	 = (double)order.getOperation().getNumEligibleMachines() / (double)nMac;
		double rpt 		 = order.getRemainingProcessingTime();

		if  (mfq<=0.2){
			// regra 79
			resultado = Math.pow(pt,1.5)*Math.pow(ptr,7.5)*Math.pow(flex,3)*Math.pow(rpt,0.67);
		}
		else if (mfq<=0.4){
			// regra 49
			resultado = pt*Math.pow(ptr,7.5)*Math.pow(flex,2)*Math.pow(rpt,0.67);
		}
		else{
			// regra 46
			resultado = pt*Math.pow(ptr,7.5)*Math.pow(flex,1.33)*Math.pow(rpt,0.67);
		}
		return resultado;
	}

	public static double getBestRule(SimulationStatus status, Order order, double queueData, double uLevel){
		double resultado = 0.0;

		if		  (queueData<= 0) {	resultado = alvaro9(status, order);				}
		else if   (queueData<= 10000)	{	resultado = getRR(status, order, uLevel);		}
		else						{	resultado = alvaro3(status, order);				}
		return resultado;
	}

	public static double newThresholdRule(SimulationStatus status, Order order, double queueData, double uLevel){
		double resultado = 0.0;

		if		  (  queueData >  -  4 ) 							{	resultado = alvaro9(status, order);				}
		else if   ( (queueData >  - 11 ) && (queueData <= -4 ) ) 	{	resultado = getRR(status, order, uLevel);		}
		else						   								{	resultado = getHunt4(status, order);			}
		return resultado;
	}

	public static double thresholdRuleEvo(SimulationStatus status, Order order, double var1, double var2, double uLevel){
		double resultado = 0.0;

		if		  (  var1 >  -  2 ) 							{	resultado = alvaro9(status, order);				}
		else if   (  var2 >    20 ) 							{	resultado = getRR(status, order, uLevel);		}
		else						   							{	resultado = getHunt4(status, order);			}
		
		return resultado;
	}

	public static double shady1(SimulationStatus status, Order order){
		// regra para tardiness
		double out = 0.0;
		out = Math.max( order.getNumOperationsLeft() + Math.max(order.getNumOperationsLeft(), order.getExpectedTime()) , order.getExpectedTime() + getWINQ(status, order));
		if (order.getNumOperationsLeft() == 0){
			out = out + Math.max(  Math.max( 1.0 + order.getExpectedTime() , order.getExpectedTime() ) , order.getNumOperationsLeft() - getSlack(status, order) + getWINQ(status, order) );
		}
		else{
			out = out + Math.max(  Math.max( getSlack(status, order) / order.getNumOperationsLeft() + order.getExpectedTime() , order.getExpectedTime() ) , order.getNumOperationsLeft() - getSlack(status, order) + getWINQ(status, order) );
		}	
		
		return out ;
 
	}

	public static double shady2(SimulationStatus status, Order order){
		// regra para mean tardiness
		double out = 0.0;
		if ( order.getNumOperationsLeft() == 0 ) {
			out = Math.min(    (getWINQ(status,order) + getSlack(status, order) / order.getNumOperationsLeft()) / order.getExpectedTime() ,  Math.max( status.getTimeInstant(), order.getExpectedTime() * getNPT(status, order) )     );
		}
		else{
			out = Math.min(    ( getWINQ(status,order) + 1.0 ) / order.getExpectedTime() ,  Math.max( status.getTimeInstant(), order.getExpectedTime() * getNPT(status, order) )     );
		}
		
		return out* (-1.0);
	}

	public static double shady3(SimulationStatus status, Order order){
		// regra para mean flowtime
		double out = 0.0;
		double comp1 = Math.min(  getNPT(status, order) ,  getWINQ(status, order) + order.getExpectedTime() ) + getWINQ(status, order);
		double comp2 = Math.max(  comp1, order.getExpectedTime()  );
		double comp3 = Math.max(  comp2, getWINQ(status, order) - Math.max( getWINQ(status, order), order.getExpectedTime() ) ) * order.getExpectedTime()  ;
		return comp3* (-1.0);		
	}

}
