package simulator;


import org.json.simple.JsonObject;

import input.Instance;
import input.Job;
import main.InstanceGenerator;

import utils.Utils;

public class JobFactory {

	private  int jobId;
	private  int operationId;
	private  double nextArrivalTime;
	private  double lastArrivalTime;
	Instance instance;
	double allowance;

	public JobFactory(Instance i, double a) {
		super();
		
		jobId = 0;
		operationId = 0;
		nextArrivalTime = 0;
		lastArrivalTime = 0;
		instance = i;
		allowance = a;
	}

	public int getCurrentJobID(){
		return jobId;
	}

	public Job getNextJob(){

		Job job = InstanceGenerator.createJob(instance, jobId, operationId);
		job.setArrivalTime(nextArrivalTime);
		job.setDueDate(allowance);		
		
		jobId++;
		operationId += job.getTotalNumOperations();		
		nextArrivalTime =0;
		
		return job;
	}

	public void setAllowanceDisruption(double val){
		allowance = val;
	}

	public Job getNextJobFromRecord(JsonObject obj,double NextArrivalTimeFromRecord){

		Job job = InstanceGenerator.createJobFromRecord(instance, jobId, operationId,obj);
		job.setArrivalTime(NextArrivalTimeFromRecord);
		job.setDueDate(allowance);		
		
		jobId++;
		operationId += job.getTotalNumOperations();		
		nextArrivalTime =0;
		
		return job;
	}

	public Job getNextJobFromRecordAlt(String str,double NextArrivalTimeFromRecord){

		Job job = InstanceGenerator.createJobFromRecordAlt(instance, jobId, operationId,str);
		job.setArrivalTime(NextArrivalTimeFromRecord);
		job.setDueDate(allowance);		
		
		jobId++;
		operationId += job.getTotalNumOperations();		
		nextArrivalTime =0;
		
		return job;
	}

	public double getNextArrivalTime(){

		//Se o ultimo instante sorteado ja foi utilizado, sortea-se novamente
		if(nextArrivalTime == 0){
			nextArrivalTime = lastArrivalTime + Utils.getArrivalTimeSample() ;
			lastArrivalTime = nextArrivalTime ;
			//double temp4 =Utils.getArrivalTimeSample();
			//int temp = Utils.getRandomInt(1, 100);
			//double temp2 = Utils.getRandomNumber(1, 100);
			//double temp3 = Utils.getRandomNumber(1, 100);
			//double temp5 =0.0;
		}
		return nextArrivalTime;	
	}
	
	public double getLastArrivalTime(){
		return lastArrivalTime;
	}

}
