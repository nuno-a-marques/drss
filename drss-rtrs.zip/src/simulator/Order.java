package simulator;

import input.Machine;
import input.Operation;
import input.Route;


public class Order implements Comparable<Order>{
	
	ActualJob job;
	double minExecutionTime;
	Operation operation;
	double dueDate;	
	Simulator simulator;
	double enteringQueueTime;
	int sequence;
	Machine machine;


	public Order(Simulator sim, ActualJob j, Machine machine, Operation op, double min){
		this.simulator = sim;
		this.job = j;
		this.machine = machine;
		this.operation = op;
		this.minExecutionTime = min;
		
		this.dueDate = j.getDueDate();
		this.enteringQueueTime = 0;
	}	
	
	public double getEnteringQueueTime() {
		return enteringQueueTime;
	}

	public void setEnteringQueueTime(double t) {
		this.enteringQueueTime = t;
	}

	public double getDueDate() {
		return dueDate;
	}

	public void setDueDate(double dueDate) {
		this.dueDate = dueDate;
	}		
	
	public ActualJob getJob() {
		return job;
	}

	public Machine getMachine() {
		return machine;
	}

	public double getMinExecutionTime() {
		return minExecutionTime;
	}

	public Operation getOperation() {
		return operation;
	}
	
	public Route getRoute(){
		return operation.getRoute();
	}
	
	public int getSequence() {
		return sequence;
	}

	public void setSequence(int sequence) {
		this.sequence = sequence;
	}
	
	public void setMinExecutionTime(double minTime){
		minExecutionTime = minTime;
	}
	
	 public int compareTo(Order order) {
		   			
		 double minTimeL = minExecutionTime;
		 double minTimeR = order.getMinExecutionTime();
		
		if(minTimeL < minTimeR)
			return -1;
		else if(minTimeL > minTimeR)
			return 1;
		else
			return 0;
   }		
	
	public double getExpectedTime(){
		return operation.getTime(machine);
	}
	
	public int getNumOperationsLeft(){

		return job.getNumOperationsLeft();
	}
	
	public double getRemainingProcessingTime(){
		
		return job.getRemainingProcessingTime();
	}
}
