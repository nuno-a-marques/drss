package simulator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

import GP.Data;
import GP.MyGPEvaluator;
import GP.MyGPIndividual;
import GP.MyGPEvolutionState;
import GP.operators.AndNode;
import GP.operators.DivisionNode;
import GP.operators.GreaterThanNode;
import GP.operators.IfNode;
import GP.operators.IfSlackNode;
import GP.operators.LessThanNode;
import GP.operators.MaxNode;
import GP.operators.MinNode;
import GP.operators.MultiplyNode;
import GP.operators.NegativeNode;
import GP.operators.NotNode;
import GP.operators.OrNode;
import GP.operators.PowNode;
import GP.operators.SubtractNode;
import GP.operators.SumNode;
import GP.operators.SqrtNode;
import GP.terminals.AllowanceFactorNode;
import GP.terminals.AllowanceNode;
import GP.terminals.ArrivalTimeNode;
import GP.terminals.Const1Node;
import GP.terminals.CRNode;
import GP.terminals.CRPTNode;
import GP.terminals.DueDateNode;
import GP.terminals.FalseNode;
import GP.terminals.JobQueuingTimeNode;
import GP.terminals.LateJobNode;
import GP.terminals.MaxDDQueueNode;
import GP.terminals.MaxPTQueueNode;
import GP.terminals.MinDDQueueNode;
import GP.terminals.MinPTQueueNode;
import GP.terminals.NextPTimeNode;
import GP.terminals.NJobsNode;
import GP.terminals.NMachinesNode;
import GP.terminals.OCRNode;
import GP.terminals.OCRPTNode;
import GP.terminals.OPCompletionTimeNode;
import GP.terminals.OperationDueDateNode;
import GP.terminals.OpLeftNode;
import GP.terminals.OPReadyTimeNode;
import GP.terminals.PositiveAllowanceNode;
import GP.terminals.PositiveSlackNode;
import GP.terminals.PositiveSlackPT;
import GP.terminals.PositiveSlackRPT;
import GP.terminals.PTDividedByRPTNode;
import GP.terminals.PTimeNode;
import GP.terminals.PTQueueNode;
import GP.terminals.PTWinRRNode;
import GP.terminals.QSizeNextNode;
import GP.terminals.QueueSizeNode;
import GP.terminals.RemainingPTimeNode;
import GP.terminals.RemainingSucTimesNode;
import GP.terminals.SequenceNode;
import GP.terminals.SlackNode;
import GP.terminals.SlackONode;
import GP.terminals.SlackOPTNode;
import GP.terminals.SlackPT;
import GP.terminals.SucessiveDiffNode;
import GP.terminals.TailPTimeNode;
import GP.terminals.TimeInSystemNode;
import GP.terminals.TrueNode;
import GP.terminals.TwicePTNode;
import GP.terminals.UtilizationNode;
import GP.terminals.UtilizationSlackNode;
import GP.terminals.WinQNode;
import GP.terminals.WinRRNode;
import GP.terminals.WIQNode;
import GP.terminals.WisqNode;
import QTable.QTable;
import GP.terminals.WORNode;
import GP.terminals.WRIQNode;
import GP.terminals.Flex;
import GP.terminals.FlexAdimensionalNode;
import GP.terminals.CRNodeStd;
import GP.terminals.WinQF;
import GP.terminals.WinQFAdimensional;
import GP.terminals.PTimeNodeAdimensional;
import GP.terminals.NextPTimeNodeAdimensional;
import GP.terminals.RemainingPTimeNodeAdimensional;
import GP.terminals.SlackNodeAdimensional;
import GP.terminals.TimeInSystemNodeAdimensional;
import GP.terminals.ProcessingTimePenaltyRel;
import GP.terminals.ProcessingTimePenalty;
import ec.EvolutionState;
import ec.Individual;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.koza.KozaFitness;
import ec.simple.SimpleProblemForm;
import ec.util.Parameter;
import input.Instance;
import input.Job;
import input.Machine;
import input.Operation;
import input.Route;
import main.DataLoader;
import main.GlobalParameters;
import main.InstanceGenerator;
import nn.NeuralNet;
import nn.NeuralNet4v;
import nn.NeuralNet4v6r;
import nn.NeuralNetClassFlex;
import nn.NeuralNetClassifier;
import nn.NeuralNetClassifier71;
import nn.NeuralNetLarge;
import nn.NeuralNetLarger;
import nn.NeuralNetRegressor;
//import smile.classification.SVM;
import utils.Utils;
import utils.Utils.EvaluationType;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;

import org.apache.commons.io.FileUtils;

//import org.deeplearning4j.nn.api.OptimizationAlgorithm;
//import org.deeplearning4j.nn.conf.graph.MergeVertex;
/* import org.deeplearning4j.nn.conf.layers.DenseLayer;
import org.deeplearning4j.nn.conf.layers.OutputLayer;
import org.deeplearning4j.nn.conf.NeuralNetConfiguration; */
//import org.deeplearning4j.nn.conf.ComputationGraphConfiguration;
// import org.deeplearning4j.nn.conf.MultiLayerConfiguration;
//import org.deeplearning4j.nn.conf.Updater;
//import org.deeplearning4j.nn.graph.ComputationGraph;
/* import org.deeplearning4j.nn.multilayer.MultiLayerNetwork;
import org.deeplearning4j.nn.weights.WeightInit;
import org.nd4j.linalg.activations.Activation;
import org.nd4j.linalg.learning.config.AdaGrad;
import org.nd4j.linalg.lossfunctions.LossFunctions; */

//import org.json.simple.JsonArray;
//import org.json.simple.JsonObject;

//import java.io.FileWriter;
import java.io.IOException;
import java.io.LineNumberReader;
import java.io.PrintWriter;
import java.io.Writer;

import RL.RLagent;
import RL.RLagentCustom;
import SVM.SvmClassifier;
import SVM.SvmRegressor;
import RL.Observation;
import RL.ObservationCustom;
import DQN.Dqn;

import org.json.simple.JsonObject;
import org.json.simple.Jsoner;
import org.json.simple.parser.JSONParser;
//import org.h2.store.fs.FileUtils;
import org.json.simple.DeserializationException;
import org.json.simple.JsonArray;
import org.neuroph.nnet.MultiLayerPerceptron;
//import org.neuroph.util.TransferFunctionType;


/**
 * Simulador de chegadas din�micas de jobs. 
 * Gera os jobs e simula sua execu��o de acordo com a prioriza��o feita por uma regra de despacho.
 * 
 * Inputs: 
 * - Inst�ncia (n�mero de m�quinas e par�metros para HRTs) 
 * - Utiliza��o m�dia das m�quinas; 
 * - Tolerancia para due dates; 
 * - N�vel de incerteza nos tempos de processamento
 * 
 * Outputs: 
 * - Makespan;
 * - Mean Flowtime;
 * - Maximum flowtime;
 * -  % of tardy jobs;
 * - Mean Tardiness;
 * - Maximum tardiness
 * 
 * Par�metros
 * - Regras de despacho a serem simuladas; 
 * - N�mero de jobs simulados
 * - N�mero de replica��es
 * - N�mero m�ximo de precedentes por opera��o (se n�o for shop)
 */
public class Simulator extends Problem implements SimpleProblemForm{


	private static final long serialVersionUID = 1L;

	public static final String P_DATA = "data";		
	public Individual individual;
	public ADFStack stack;
	public GPData input;	
	public EvolutionState state;
	public int threadnum;	
	private Instance instance;
	private String dispRule;
	private double utilizationLevel;
	private double allowanceFactor;
	private int maxJobsSimulation;
	private double CV = 0;
	private int combination=0;	
	
	double positiveSlack;
	double bestTardiness;
	//double currentTardiness;
	
	public static HashMap<MyGPIndividual, Double> performanceNormal;
	public static HashMap<MyGPIndividual, Double> performanceSimplified;
	public static HashMap<MyGPIndividual, Double> performanceSmall;
	public ArrayList<JsonObject> replicationData= new ArrayList<JsonObject>();
	public ArrayList<String> replicationDataAlt= new ArrayList<String>();

	public Simulator(){
		this.input = new Data();
		dispRule = "";
		bestTardiness=Double.MAX_VALUE;
		//currentTardiness=Double.MAX_VALUE;

	}

	public Simulator(EvolutionState state){
		this.input = new Data();
		this.state = state;
		dispRule = "";		
	}	

	/**
	 * Executa o simulador para uma lista de inst�ncias
	 * @param instances Lista de Instancias
	 * @param ind Regra de despacho (se null, executa todas as regras especificadas em parametros) 
	 * @throws IOException
	 * @throws DeserializationException
	 */
	public double simulate(List<Instance> instances, Individual ind) throws IOException, DeserializationException{
		
		this.input = new Data();
		double fitness = (GlobalParameters.GEO_MEAN)? 1.0: 0.0;
		double[] utilizationArray;
		double[] cvsArray;		
		double[] allowanceArray;
		int nReplications;
		individual = ind;			

		if(MyGPEvaluator.LEVEL_OF_EVALUATION==EvaluationType.SIMPLIFIED){
			utilizationArray = GlobalParameters.SIMPLIFIED_TRAINING_UTILIZATION;
			cvsArray = GlobalParameters.SIMPLIFIED_TRAINING_CVS;		
			allowanceArray = GlobalParameters.SIMPLIFIED_TRAINING_ALLOWANCE_FACTOR;
			maxJobsSimulation = GlobalParameters.SIMPLIFIED_MAX_JOBS_TRAINING_SIMULATION;
			nReplications = GlobalParameters.SIMPLIFIED_TRAINING_REPLICATIONS;

		}else{
			utilizationArray = GlobalParameters.TRAINING_UTILIZATION;
			cvsArray = GlobalParameters.TRAINING_CVS;		
			allowanceArray = GlobalParameters.TRAINING_ALLOWANCE_FACTOR;
			maxJobsSimulation = GlobalParameters.MAX_JOBS_TRAINING_SIMULATION;

			nReplications = (MyGPEvaluator.LEVEL_OF_EVALUATION==EvaluationType.SMALL)?
					GlobalParameters.SMALL_TRAINING_REPLICATIONS: GlobalParameters.FULL_TRAINING_REPLICATIONS;
		}				
		
		if(GlobalParameters.VERBOSE){
			ind.printIndividualForHumans(state, 0);
		}

		//Para cada instancia de treino
		for(Instance instance: instances){

			//Para cada nivel de utiliza��o do shop
			for(int uIndex = 0; uIndex < utilizationArray.length; uIndex++){
				double utilization = utilizationArray[uIndex];		
				Utils.initializeExpDistributions(instance, utilization);

				//Para cada n�vel de due date
				for(int dIndex = 0; dIndex < allowanceArray.length; dIndex++){
					double allowance = allowanceArray[dIndex];

					//Para cada cv de treino
					for(int cvIndex = 0; cvIndex < cvsArray.length; cvIndex++){
						double cv = cvsArray[cvIndex];						
						PerformanceMetrics performance = runTrainingInstance(ind, instance, cv , nReplications, utilization, allowance);

						if(GlobalParameters.GEO_MEAN){
							fitness *= performance.getRelativePerformanceTardiness();							
						}
						else
						{
							fitness += performance.getRelativePerformanceTardiness();							
						}

					}					
				}
			}
		}	
		if(instances.size() > 0){
			if(GlobalParameters.GEO_MEAN){
				fitness  = Math.pow(fitness, 1.0/(double)(instances.size()* 
						utilizationArray.length* allowanceArray.length* cvsArray.length));				
			}else{
				fitness  /= (double)(instances.size()* 
						utilizationArray.length* allowanceArray.length* cvsArray.length);					
			}
		}			
		return fitness;
	}	

	public PerformanceMetrics runTrainingInstance(Individual ind, Instance instance, double cv, int nReplications, double uLevel, double aFactor) throws IOException, DeserializationException{		

		CV = cv;
		utilizationLevel = uLevel;
		allowanceFactor = aFactor;
		this.instance = instance;	

		BenchmarkResult benchmark = Utils.getBenchmarkResult(instance, allowanceFactor, utilizationLevel, cv);

		PerformanceMetrics totalPerformance = new PerformanceMetrics();
		PerformanceMetrics performance;

		Utils.setDistributionsSeed(1, CV);

		for(int n = 0; n < nReplications; n++){

			performance = new PerformanceMetrics();			
			runReplicationGP(instance, performance,0,0);			
			totalPerformance.addMetrics(performance);
		}						
		totalPerformance.calculateAverageMetricsByReplication(nReplications, benchmark);

		//String output = String.format(Locale.UK, "%s; %d; %.2f; %.2f; %.4f; %.4f; %.4f", dispRule, allowanceFactor, utilizationLevel, cv,
		//		totalPerformance.getMeanFlowTime(), totalPerformance.getNumberTardyJobs(), totalPerformance.getMeanTardiness());		
		//	System.out.println(output);

		return totalPerformance;
	}
	
	/**
	 * Executa o simulador para uma inst�ncia espec�fica e todas as regras de despacho especificadas nos parametros
	 * ou a regra 'ind' resultante do GP
	 * @param ind - Individuo resultante do GP (regra de despacho a ser usada)
	 * @param instances - Instancias a correr
	 * @param cv - N�vel de incerteza nos tempos de processamento
	 * @param uLevel - N�vel de utiliza��o do shop
	 * @param aFactor - Toler�ncia para c�lculo dos due dates
	 * @param nReplications - N�mero de replica��es a correr, para cada regra de despacho
	 * @return
	 * @throws IOException
	 * @throws DeserializationException
	 */
	public void testInstances(Individual ind, List<Instance> instances, double cv, int nReplications, double uLevel, double aFactor) throws IOException, DeserializationException{		

		CV = cv;
		utilizationLevel = uLevel;
		allowanceFactor = aFactor;

		//System.out.println("Instancia "+instance.getName()+" Allowance "+allowanceFactor+" U:"+uLevel+" cv: "+cv);
		maxJobsSimulation = GlobalParameters.MAX_JOBS_STEADY_STATE - GlobalParameters.MIN_JOBS_STEADY_STATE;	
		individual = ind;	
		PerformanceMetrics performance;

		//keeps the best tardiness found by each of the benchmark rules
		double[] meanTardiness = new double[GlobalParameters.BENCHMARK_RULES.length];
		double[] stdTardiness = new double[GlobalParameters.BENCHMARK_RULES.length];

		for(int r = 0; r < GlobalParameters.BENCHMARK_RULES.length; r++){

			dispRule = GlobalParameters.BENCHMARK_RULES[r];			
			
			double[] tardiness = new double[nReplications*instances.size()*maxJobsSimulation];
			
			for(int i = 0; i < instances.size(); i++){
				Instance instance = instances.get(i);
				this.instance = instance;
				Utils.initializeExpDistributions(instance, uLevel);	
				BenchmarkResult benchmark = Utils.getBenchmarkResult(instance, aFactor, uLevel, cv);
				
				//Alterando o seed das distribui��es
				Utils.setDistributionsSeed(GlobalParameters.SEED, CV);
				
				for(int n = 0; n < nReplications; n++){

					performance = new PerformanceMetrics();			
					runReplication(instance,performance,null,null,null,0);
					double[] t = performance.getTardiness();
					for(int j = 0; j < maxJobsSimulation; j++){
						double relPer = (benchmark.getTardiness() == 0)?  t[j]/0.0001: t[j]/benchmark.getTardiness();
						if(t[j] == 0 && benchmark.getTardiness() == 0)
							relPer = 1;
						tardiness[i*n*maxJobsSimulation + j] = relPer;
						meanTardiness[r] += relPer;						
					}
				}
			}

			
			meanTardiness[r] /= (double)(nReplications*instances.size()*maxJobsSimulation);
			for(int n = 0; n < nReplications*instances.size()*maxJobsSimulation; n++){
				stdTardiness[r] += Math.pow(tardiness[n]-meanTardiness[r],2);
			}
			//todo em vez de meanTardiness[r] tem que ser mean tardiness global
			stdTardiness[r] = Math.sqrt(stdTardiness[r]/((double)nReplications*instances.size()*maxJobsSimulation));
		}

		dispRule = "";			
		double meanRelTardiness = 0;
		
		for(int i = 0; i < instances.size(); i++){
			Instance instance = instances.get(i);
			this.instance = instance;
			Utils.initializeExpDistributions(instance, uLevel);
			
			//Alterando o seed das distribui��es
			Utils.setDistributionsSeed(GlobalParameters.SEED, CV);
			
			BenchmarkResult benchmark = Utils.getBenchmarkResult(instance, aFactor, uLevel, cv);
			PerformanceMetrics totalPerformance = new PerformanceMetrics();
			
			for(int n = 0; n < nReplications; n++){

				performance = new PerformanceMetrics();			
				runReplication(instance,performance,null,null,null,0);			
				totalPerformance.addMetrics(performance);	
			}		
			totalPerformance.calculateAverageMetricsByReplication(nReplications, benchmark);
			meanRelTardiness += totalPerformance.getRelativePerformanceTardiness();
		}
		
		meanRelTardiness /= (double)instances.size();
		
		double bestMeanTardiness = Double.MAX_VALUE;
		double bestStdTardiness = Double.MAX_VALUE;
		for(int r2 = 0; r2 < GlobalParameters.BENCHMARK_RULES.length; r2++){
			if(meanTardiness[r2] < bestMeanTardiness){
				bestMeanTardiness = meanTardiness[r2];
				bestStdTardiness = stdTardiness[r2];
			}
		}
		
		double z = (bestMeanTardiness-meanRelTardiness)/(bestStdTardiness/Math.sqrt(nReplications*instances.size()*maxJobsSimulation));

		String output = String.format(Locale.UK, "%.2f; %.2f; %.2f; %f", allowanceFactor, utilizationLevel, cv, z);		
		System.out.println(output);	
	}
	
	public void testInstances2(Individual ind, List<Instance> instances, double cv, int nReplications, double uLevel, double aFactor) throws IOException, DeserializationException{		

		CV = cv;
		utilizationLevel = uLevel;
		allowanceFactor = aFactor;

		maxJobsSimulation = GlobalParameters.MAX_JOBS_STEADY_STATE - GlobalParameters.MIN_JOBS_STEADY_STATE;	
		individual = ind;	
		PerformanceMetrics performance;

		//keeps the best tardiness found by each of the benchmark rules
		double[] meanTardiness = new double[GlobalParameters.BENCHMARK_RULES.length];
		double[] stdTardiness = new double[GlobalParameters.BENCHMARK_RULES.length];

		for(int r = 0; r < GlobalParameters.BENCHMARK_RULES.length; r++){

			dispRule = GlobalParameters.BENCHMARK_RULES[r];			
			
			double[] tardiness = new double[nReplications*instances.size()];
			
			for(int i = 0; i < instances.size(); i++){
				Instance instance = instances.get(i);
				this.instance = instance;
				Utils.initializeExpDistributions(instance, uLevel);	
				BenchmarkResult benchmark = Utils.getBenchmarkResult(instance, aFactor, uLevel, cv);
				
				//Alterando o seed das distribui��es
				Utils.setDistributionsSeed(GlobalParameters.SEED, CV);
				
				for(int n = 0; n < nReplications; n++){

					performance = new PerformanceMetrics();			
					runReplication(instance,performance,null,null,null,0);
					double tardinessRule = performance.getMeanTardiness();
					double relPer = (benchmark.getTardiness() == 0)?  tardinessRule/0.0001: tardinessRule/benchmark.getTardiness();
					if(tardinessRule == 0 && benchmark.getTardiness() == 0)
						relPer = 1;
					tardiness[i*nReplications + n] = relPer;
					meanTardiness[r] += relPer;						
				}
			}

			meanTardiness[r] /= (double)(nReplications*instances.size());
			for(int n = 0; n < nReplications*instances.size(); n++){
				stdTardiness[r] += Math.pow(tardiness[n]-meanTardiness[r],2);
			}
			stdTardiness[r] = Math.sqrt(stdTardiness[r]/((double)nReplications*instances.size()));
		}

		dispRule = "";			
		double meanRelTardiness = 0;
		
		for(int i = 0; i < instances.size(); i++){
			Instance instance = instances.get(i);
			this.instance = instance;
			Utils.initializeExpDistributions(instance, uLevel);
			
			//Alterando o seed das distribui��es
			Utils.setDistributionsSeed(GlobalParameters.SEED, CV);
			
			BenchmarkResult benchmark = Utils.getBenchmarkResult(instance, aFactor, uLevel, cv);
			PerformanceMetrics totalPerformance = new PerformanceMetrics();
			
			for(int n = 0; n < nReplications; n++){

				performance = new PerformanceMetrics();			
				runReplication(instance,performance,null,null,null,0);			
				totalPerformance.addMetrics(performance);	
			}		
			totalPerformance.calculateAverageMetricsByReplication(nReplications, benchmark);
			meanRelTardiness += totalPerformance.getRelativePerformanceTardiness();
		}
		
		meanRelTardiness /= (double)instances.size();
		
		double bestMeanTardiness = Double.MAX_VALUE;
		double bestStdTardiness = Double.MAX_VALUE;
		for(int r2 = 0; r2 < GlobalParameters.BENCHMARK_RULES.length; r2++){
			if(meanTardiness[r2] < bestMeanTardiness){
				bestMeanTardiness = meanTardiness[r2];
				bestStdTardiness = stdTardiness[r2];
			}
		}
		
		double z = (bestMeanTardiness-meanRelTardiness)/(bestStdTardiness/Math.sqrt(nReplications*instances.size()));

		String output = String.format(Locale.UK, "%.2f; %.2f; %.2f; %f", allowanceFactor, utilizationLevel, cv, z);		
		System.out.println(output);	
	}
	
	/**
	 * Executa o simulador para uma inst�ncia espec�fica e todas as regras de despacho especificadas nos parametros
	 * ou a regra 'ind' resultante do GP
	 * @param ind - Individuo resultante do GP (regra de despacho a ser usada)
	 * @param instance - Instancia a correr
	 * @param cv - N�vel de incerteza nos tempos de processamento
	 * @param uLevel - N�vel de utiliza��o do shop
	 * @param aFactor - Toler�ncia para c�lculo dos due dates
	 * @param nReplications - N�mero de replica��es a correr, para cada regra de despacho
	 * @return
	 * @throws IOException
	 * @throws DeserializationException
	 */

	public void runInstanceRL(Individual ind, Instance instance, double cv, int nReplications, double uLevel, double aFactor) throws IOException, DeserializationException{
		CV = cv;
		utilizationLevel = uLevel;
		allowanceFactor = aFactor;
		maxJobsSimulation = GlobalParameters.MAX_JOBS_STEADY_STATE - GlobalParameters.MIN_JOBS_STEADY_STATE;
		individual = ind;	
		this.instance = instance;
		PerformanceMetrics performance;
		RLagent agent =new RLagent();
		MultiLayerPerceptron neuralNet=agent.initializeNetwork("online");
		MultiLayerPerceptron targetNet=agent.initializeNetwork("target");
		if	(!GlobalParameters.LOAD_WEIGHTS)	{agent.synchronizeWeights(neuralNet, targetNet);}
		if	(GlobalParameters.LOAD_DATASET)		{agent.loadDataset();}
		if 	(GlobalParameters.LOAD_QTABLE) 		{agent.loadQTable();}

		for(int n = 0; n < nReplications; n++){
			performance = new PerformanceMetrics();

			if(!GlobalParameters.ONLINE_MODE){							
				runReplication(instance,performance,agent,neuralNet,targetNet,n);
				System.out.println("Terminou a iteracao:" +n);			
				agent.clearEpisodeDataset();
			}
			else{
				for(int j=0; j<100;j++){
					runReplication(instance,performance,agent,neuralNet,targetNet,j);
					System.out.println("Terminou a iteracao de teste:" +j);
					agent.clearEpisodeDataset();
				}
				GlobalParameters.ONLINE_MODE=false;
			}
		}		
	}

	public void trainOrTest(int n){
		if(n%10==0 && n>9){
			GlobalParameters.ONLINE_MODE=true;
			System.out.println("Online mode activated");
		}
	}

	public void runBenchmark(Individual ind, Instance instance, double cv, int nReplications, double uLevel, double aFactor) throws IOException, DeserializationException{
		CV = cv;
		utilizationLevel = uLevel;
		allowanceFactor = aFactor;
		maxJobsSimulation = GlobalParameters.MAX_JOBS_STEADY_STATE - GlobalParameters.MIN_JOBS_STEADY_STATE;
		individual = ind;	
		this.instance = instance;
		PerformanceMetrics performance;

		
		//RLagent agent =new RLagent();
		//MultiLayerPerceptron neuralNet= agent.initializeNetwork("online");
		//MultiLayerPerceptron targetNet=agent.initializeNetwork("target");
		//if	(!GlobalParameters.LOAD_WEIGHTS)	{agent.synchronizeWeights(neuralNet, targetNet);}

		for(int n = 0; n < nReplications; n++){

			performance = new PerformanceMetrics();
			//hierarchicalSim(instance, performance);		 for debugging
			//if (!(performance.getReplicationStatus())) {performance.dumpPerformance(GlobalParameters.INSTANCETOTEST, instance.getOpFlexibility(), utilizationLevel, allowanceFactor); }

			// BENCHMARK NORMAL
			//long startTime = System.nanoTime();
			//Utils.setDistributionsSeed(n+1, 0);
			//n = 27 ;     
			runReplicationBenchmark(instance,performance,null, null,null,n);
			//long estimatedTime = System.nanoTime() - startTime;
			//System.out.println("TIMING - The iteration took:  " + String.valueOf(estimatedTime));
			//FileUtils.writeStringToFile(new File("runningTimes instance" + GlobalParameters.INSTANCETOTEST+".txt"), GlobalParameters.INSTANCETOTEST+"; "+GlobalParameters.BENCHMARK_RULE+"; "+String.valueOf(instance.getOpFlexibility())+"; "+String.valueOf(uLevel)+"; "+String.valueOf(aFactor)+"; "+n+"; "+estimatedTime+"\n",true);			

		}

	}

	public void runCustom(Individual ind, Instance instance, double cv, int nReplications, double uLevel, double aFactor) throws IOException{
		CV = cv;
		utilizationLevel = uLevel;
		allowanceFactor = aFactor;
		maxJobsSimulation = GlobalParameters.MAX_JOBS_STEADY_STATE - GlobalParameters.MIN_JOBS_STEADY_STATE;
		individual = ind;	
		this.instance = instance;
		PerformanceMetrics performance;
		RLagentCustom agent =new RLagentCustom();
		MultiLayerPerceptron neuralNet=agent.initializeNetwork("online");
		MultiLayerPerceptron targetNet=agent.initializeNetwork("target");
		if	(!GlobalParameters.LOAD_WEIGHTS)	{agent.synchronizeWeights(neuralNet, targetNet);}
		if 	(GlobalParameters.LOAD_DATASET)		{agent.loadDataset();}
		for(int n = 0; n < nReplications; n++){

			performance = new PerformanceMetrics();			
			runReplicationCustom(instance,performance,agent, neuralNet,targetNet,n);			
			//totalPerformance.addMetrics(performance);
			// if(n<nReplications-1){
			// 	agent.updatePolicy(neuralNet,n);
			// }
			//agent.clearDataset();
			agent.dumpWeights(neuralNet, "online");
			agent.dumpWeights(targetNet, "target");
			agent.clearEpisodeDataset();
			System.out.println("Terminou a iteracao :" +n);
		}		
	}
	
	public PerformanceMetrics[] runInstance(Individual ind, Instance instance, double cv, int nReplications, double uLevel, double aFactor) throws IOException, DeserializationException{		

		CV = cv;
		PerformanceMetrics[] metrics = new PerformanceMetrics[GlobalParameters.RULES.length];
		utilizationLevel = uLevel;
		allowanceFactor = aFactor;

		//System.out.println("Instancia "+instance.getName()+" Allowance "+allowanceFactor+" U:"+uLevel+" cv: "+cv);
		maxJobsSimulation = GlobalParameters.MAX_JOBS_STEADY_STATE - GlobalParameters.MIN_JOBS_STEADY_STATE;
		BenchmarkResult benchmark = Utils.getBenchmarkResult(instance, allowanceFactor, utilizationLevel, cv);		
		individual = ind;	
		this.instance = instance;
		PerformanceMetrics performance;
		
		int	rulesCount = (individual != null)? 1: GlobalParameters.RULES.length;
		for(int r = 0; r < rulesCount; r++){

			dispRule = (ind == null)? GlobalParameters.RULES[r] : "";			
			PerformanceMetrics totalPerformance = new PerformanceMetrics();
			//Alterando o seed das distribui��es
			Utils.setDistributionsSeed(GlobalParameters.SEED, CV);
			positiveSlack = 0;
			
			for(int n = 0; n < nReplications; n++){

				performance = new PerformanceMetrics();			
				runReplicationGP(instance,performance,0,0);			
				totalPerformance.addMetrics(performance);	
			}						
			
			totalPerformance.calculateAverageMetricsByReplication(nReplications, benchmark);
			
			metrics[r] = totalPerformance;
			positiveSlack /= nReplications;

			String output = String.format(Locale.UK, "%s; %d; %s; %.2f; %.2f; %.2f; %.3f; %.3f;  %.3f; %.3f; %.3f", instance.getName(), instance.getMaxProcessingTime(), dispRule, allowanceFactor, utilizationLevel, cv,
					totalPerformance.getMeanTardiness(), positiveSlack, totalPerformance.getMeanQueueSize(), totalPerformance.getMeanRealQueueSize(), totalPerformance.getRelativePerformanceTardiness());		
			System.out.println(output);
		}		

		return metrics;
	}

	private void dumpDebugDataJobs(int jid, int nOp, double arrivalTime, double dueDate){
		// TOIMPROVE  nao esta robusto a varias corridas

		String output="";

		output=jid + ";" + nOp + ";" + String.valueOf(arrivalTime) + " ; " + String.valueOf(dueDate);


		FileWriter fw;
		try {
			fw = new FileWriter("debugDataJobs.txt", true);
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(output);
			bw.newLine();
			bw.close();
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public double[] getNextReadyTime(double[] timesArray, SimulationStatus sts){
		double result[]= {Double.MAX_VALUE,-1};			//  Max Value and -1 are reset values

		
		for (int i = 0; i < timesArray.length; i++){
			if (timesArray[i]<result[0]){
				result[0]=timesArray[i];
				result[1]=i;
			}
		}
		return result;
	}

	public int runMachineAllocationRule(Operation op, double[] timesArr, SimulationStatus sts){
		int result=-1;
		switch(GlobalParameters.MAR_RULE){
			case 1:
				result=DispatchingRule.mar1(op, timesArr, sts);
				break;
			case 2:
				result=DispatchingRule.mar2(op, timesArr, sts);
				break;
			case 3:
				result=DispatchingRule.mar3(op, timesArr, sts);
				break;
			default:
				System.out.println("INVALID MAR RULE:  " + GlobalParameters.MAR_RULE);
				result=0;
		}
		return result;
	}

	public boolean isMachineFree(int macIDX, double[] timesArr,SimulationStatus sts){
		if (timesArr[macIDX]==Double.MAX_VALUE || timesArr[macIDX]<=sts.getTimeInstant()){
			return true;
		}
		else{
			return false;
		}
	}

	public void hierarchicalSim(Instance instance, PerformanceMetrics performance){
		boolean dbgVerbose=false;
		boolean dbgData=false;
		this.instance = instance;
		maxJobsSimulation = GlobalParameters.MAX_JOBS_STEADY_STATE - GlobalParameters.MIN_JOBS_STEADY_STATE;
		int numberOfFreeMachines=instance.getNumMachines();
		
		InstanceGenerator.initMachinePerformance(numberOfFreeMachines);
		double[] 	machineReadyTime;			// goes to simulation status
		Order[] 	orderInProcessing;
		orderInProcessing	= 	new Order[instance.getNumMachines()];
		machineReadyTime 	= 	new double[instance.getNumMachines()];

		for(Machine machine: instance.getMachines()){					
			machineReadyTime[machine.getId()-1] = Double.MAX_VALUE;			//max value is the reset value
		}		

		boolean	jobArrivalMode=false;
		
		SimulationStatus status 	= new SimulationStatus(instance);		
		JobFactory factory 			= new JobFactory(instance, allowanceFactor);

		long startTime = System.nanoTime();
		boolean queueThresholdExceeded = false;

		do{
			long heapFreeSize = Runtime.getRuntime().freeMemory();
			if (dbgVerbose)	{	System.out.println("--------------------EVENT STARTED -> " + "Finished Jobs: " + status.getFinishedJobs() +  "  current queues:  " + status.getCurrentQueue(instance)  + "  memory:  " + String.valueOf(heapFreeSize) + "-----------------------");	}
			double nextEventExecutionTime	=	0.0;
			double nextArrivalTime	=	factory.getNextArrivalTime();

			double[] nextMachineTermination	=	getNextReadyTime(machineReadyTime,status);
			double nextReadyTime			=	nextMachineTermination[0];
			int nextMachineIDX				=	(int)nextMachineTermination[1];
			

			if (nextArrivalTime<nextReadyTime) {	// DBG   what if it is the same, if there is a tie
				jobArrivalMode=true;
				nextEventExecutionTime=nextArrivalTime;
			}
			else{
				nextEventExecutionTime=nextReadyTime;
				jobArrivalMode=false;
			}

			status.setTimeInstant(nextEventExecutionTime);

			if (jobArrivalMode) {
				if (dbgVerbose)	{	System.out.println("Next event: Job arrival. Time " + nextArrivalTime);	}
								
				Job job = factory.getNextJob();
				if (dbgData) { 	dumpDebugDataJobs(job.getId(), job.getNumOperationsWorstCase(), status.getTimeInstant(), job.getDueDate());	}
				status.setNumJobs(status.getNumJobs()+1);

				if(job != null){
					ActualJob actualJob = new ActualJob(job);		
					Route route = job.getRoute();
					if(actualJob.getRoute() == null){
						actualJob.initializeRouteExecution(route);			
					}
					
					status.addNumOperations(route.getNumOperations());
					status.setJobCompletionRate(actualJob, actualJob.getNumOperationsLeft());
					//dumpDebugDataJobs(actualJob.getId(), actualJob.getNumOperationsLeft(), actualJob.getArrivalTime(), actualJob.getDueDate());
					if (dbgVerbose)	{ System.out.format("* Job %d ArrivalTime: %.1f Due Date: %.1f M%d \n",actualJob.getId(), actualJob.getArrivalTime(), actualJob.getDueDate(), route.getOperations().get(0).getFirstMachine().getId());	}					
						
					// MACHINE ASSIGNMENT FOR NEW OPERATION 	
					for(Operation operation: route.getTerminalOperations()){
						// use dispatching rule to define machine
						int selectedMachineIDX = runMachineAllocationRule(operation, machineReadyTime,status);
						if (dbgVerbose)	{	System.out.println("Selected machine was:  " + selectedMachineIDX + "  for JOB:  " + actualJob.getId() + "  for Operation:  "+ operation.getId());	}
						Order order = new Order(this, actualJob, instance.getMachine(selectedMachineIDX+1), operation, job.getArrivalTime());

						if (isMachineFree(selectedMachineIDX,machineReadyTime, status)){
							// start processing right away
							double actualOperationTime = order.getOperation().getTimebyMachineIDX(selectedMachineIDX);
							operation.setActualOperationTime(actualOperationTime);
							actualJob.addActualOperation(operation);							

							if (dbgVerbose)	{	System.out.println("Processing started right away,  timeInstant:  " + String.valueOf(status.getTimeInstant()) + "  duration:  "+ String.valueOf(order.getOperation().getTimebyMachineIDX(selectedMachineIDX)));	}
							if (dbgData)	{ 	dumpDebugDataEvents(job.getId(), operation.getId(), selectedMachineIDX+1, status.getTimeInstant(), order.getOperation().getTimebyMachineIDX(selectedMachineIDX), operation.getPrecedent()); 	}
							machineReadyTime[selectedMachineIDX]=status.getTimeInstant()+operation.getTimebyMachineIDX(selectedMachineIDX);
							orderInProcessing[selectedMachineIDX]=order;
						}
						else{
							status.pushOrderInMachineQueue(order);
							status.incrementMachineWorkInQueue(order.getMachine(), order.getExpectedTime());
							if (dbgVerbose)	{	System.out.println("Machine was busy, machine queue");	}
						}				
					}
				}
			}
			else{
				if (dbgVerbose)	{	System.out.println("Next event: Operation Finished");	}
				//it is necessary to know the job that finish and allocate a machine to next operation
				// STEP 1, find next machine to successor operation
				if (dbgVerbose)	{	System.out.println("STEP 1, find next machine to successor operation");	}
				Order currentOrder = orderInProcessing[nextMachineIDX];
				/* if (currentOrder.getJob().getId()==281) {	
					System.out.println("alto");		} */				
				ActualJob actualJob = currentOrder.getJob();				
				Operation nextOperation = currentOrder.getOperation().getSucessor();
				if(nextOperation != null){
					int selectedMachineIDX = runMachineAllocationRule(nextOperation, machineReadyTime,status);		// este vetor pode interagir com o array de times
					if (dbgVerbose)	{	System.out.println("Selected machine was:  " + selectedMachineIDX+ "   for JOB:  "+ actualJob.getId()+ "   for Operation:  "+ nextOperation.getId());	}
					Order order = new Order(this, actualJob, instance.getMachine(selectedMachineIDX+1), nextOperation, actualJob.getArrivalTime());

					if (isMachineFree(selectedMachineIDX,machineReadyTime,status) & (selectedMachineIDX!=(currentOrder.getMachine().getId()-1))){
						// start processing right away if the selected machine has no queue, excludes the current machine because it will be assigne next
						double actualOperationTime = order.getOperation().getTimebyMachineIDX(selectedMachineIDX);
						nextOperation.setActualOperationTime(actualOperationTime);
						actualJob.addActualOperation(nextOperation);

						if (dbgVerbose)	{	System.out.println("Processing started right away,  timeInstant:  " + String.valueOf(status.getTimeInstant()) + "  duration:  "+ String.valueOf(nextOperation.getTimebyMachineIDX(selectedMachineIDX)));	}
						if (dbgData)	{ 	dumpDebugDataEvents(actualJob.getId(), nextOperation.getId(), selectedMachineIDX+1, status.getTimeInstant(), order.getOperation().getTimebyMachineIDX(selectedMachineIDX), nextOperation.getPrecedent()); 	}
						//dumpDebugDataEvents(actualJob.getId(), nextOperation.getId(), selectedMachineIDX+1, status.getTimeInstant(), order.getOperation().getTimebyMachineIDX(selectedMachineIDX), nextOperation.getPrecedent());
						machineReadyTime[selectedMachineIDX]=status.getTimeInstant()+nextOperation.getTimebyMachineIDX(selectedMachineIDX);
						orderInProcessing[selectedMachineIDX]=order;
					}
					else{
						status.pushOrderInMachineQueue(order);
						status.incrementMachineWorkInQueue(order.getMachine(), order.getExpectedTime());
						if (dbgVerbose)	{	System.out.println("Machine was busy, machine queue (or was the same)");	}
					}		
				}
				else{
					if(actualJob.getNumOperationsLeft() == 0){
						status.setNumJobs(status.getNumJobs()-1);
						
						if((actualJob.getId() > GlobalParameters.MIN_JOBS_STEADY_STATE) && (actualJob.getId() <= GlobalParameters.MIN_JOBS_STEADY_STATE + maxJobsSimulation)){
							// only events in the stable zone are considered for metrics
							performance.updatePerformanceMetrics(status.getFinishedJobs(),actualJob.getArrivalTime(), actualJob.getDueDate(), status.getTimeInstant());
							status.addFinishedJobs();
							//System.out.println("Mais um job terminou   " + status.getFinishedJobs() + "  current queues:  " + status.getCurrentQueue(instance) + "  memory:  " + String.valueOf(heapFreeSize));		
						}				
					}
				}

				//machine is idle
				machineReadyTime[currentOrder.getMachine().getId()-1]=Double.MAX_VALUE;
				orderInProcessing[currentOrder.getMachine().getId()-1]=null;

				// STEP 2, find a operation for the idle machine
				if (dbgVerbose)	{	System.out.println("STEP 2, find a operation for the idle machine");	}
				List<Order> queue = status.getQueue(currentOrder.getMachine());

				Order nextOrder = null;
				double bestScore = Double.MAX_VALUE;

				if(queue.size()==0){
					if (dbgVerbose)	{	System.out.println("Machine queue is empty");	}
				}
				else{
					for(Order order: queue){
						double score=getDispatchingRuleValueRL(status, order,14);	// HARD CODED				
						if((score < bestScore) || (score == bestScore && order.getEnteringQueueTime() < nextOrder.getEnteringQueueTime())) {
							bestScore = score;
							nextOrder = order;
						}
					}

					if(nextOrder == null){System.out.println("Time instant = "+status.getTimeInstant()+" Ordem nula, Queue: "+queue.size());}
					else{ 
						if(dbgVerbose){	System.out.println("Decision: Job "+nextOrder.getJob().getId()+"  Op "+nextOrder.getOperation().getId()+" time: "+String.valueOf(status.getTimeInstant())+ " Proc. Time:"+nextOrder.getExpectedTime()); }
						if (dbgData)	{ 	dumpDebugDataEvents(nextOrder.getJob().getId(), nextOrder.getOperation().getId(), nextOrder.getMachine().getId(), status.getTimeInstant(), nextOrder.getExpectedTime(), nextOrder.getOperation().getPrecedent()); 	}
						//dumpDebugDataEvents(nextOrder.getJob().getId(), nextOrder.getOperation().getId(), nextOrder.getMachine().getId(), status.getTimeInstant(), nextOrder.getExpectedTime(), nextOrder.getOperation().getPrecedent());				
						//Execute order
						//Remover as ordens para a mesma operacao que foram disparadas para fila de outras maquinas
						double actualOperationTime = nextOrder.getOperation().getTimebyMachineIDX(currentOrder.getMachine().getId()-1);
						nextOrder.getOperation().setActualOperationTime(actualOperationTime);
						nextOrder.getJob().addActualOperation(nextOrder.getOperation());
						machineReadyTime[nextOrder.getMachine().getId()-1]=status.getTimeInstant()+nextOrder.getOperation().getTimebyMachineIDX(nextOrder.getMachine().getId()-1);
						orderInProcessing[nextOrder.getMachine().getId()-1]=nextOrder;

						status.removeOrder(nextOrder,nextOrder.getMachine());				// DBG   don t know if it is going to work
						status.decrementMachineWorkInQueue(nextOrder.getMachine(), nextOrder.getExpectedTime());
						//executeOrderGP(status, nextOrder, performance);		// must adapt, not necessary	
					}
				}
			}

			long estimatedTime = System.nanoTime() - startTime;
			if (estimatedTime>15000000000.0) {
				queueThresholdExceeded=true;
				performance.abortReplication();
			}

		}while ((status.getFinishedJobs() < maxJobsSimulation) && (!queueThresholdExceeded));
		System.out.println("Terminou");

	}

	public void operationFocusediSim(Instance instance, PerformanceMetrics performance){
		boolean dbgVerbose=false;
		boolean dbgData=false;
		this.instance = instance;
		maxJobsSimulation = GlobalParameters.MAX_JOBS_STEADY_STATE - GlobalParameters.MIN_JOBS_STEADY_STATE;
		int numberOfFreeMachines=instance.getNumMachines();
		
		InstanceGenerator.initMachinePerformance(numberOfFreeMachines);
		double[] 	machineReadyTime;			// goes to simulation status
		Order[] 	orderInProcessing;
		orderInProcessing	= 	new Order[instance.getNumMachines()];
		machineReadyTime 	= 	new double[instance.getNumMachines()];
		Map<Machine, List<Order>> machinesFinalQueue;
		machinesFinalQueue 		= new HashMap<Machine, List<Order>>();

		for(Machine machine: instance.getMachines()){					
			machineReadyTime[machine.getId()-1] = Double.MAX_VALUE;			//max value is the reset value
			machinesFinalQueue.put(machine, new ArrayList<Order>());
		}		

		boolean	jobArrivalMode=false;
		
		SimulationStatus status 	= new SimulationStatus(instance);		
		JobFactory factory 			= new JobFactory(instance, allowanceFactor);

		long startTime = System.nanoTime();
		boolean queueThresholdExceeded = false;

		do{
			long heapFreeSize = Runtime.getRuntime().freeMemory();
			if (dbgVerbose)	{	System.out.println("--------------------EVENT STARTED -> " + "Finished Jobs: " + status.getFinishedJobs() +  "  current queues:  " + status.getCurrentQueue(instance)  + "  memory:  " + String.valueOf(heapFreeSize) + "-----------------------");	}
			double nextEventExecutionTime	=	0.0;
			double nextArrivalTime	=	factory.getNextArrivalTime();

			double[] nextMachineTermination	=	getNextReadyTime(machineReadyTime,status);
			double nextReadyTime			=	nextMachineTermination[0];
			int nextMachineIDX				=	(int)nextMachineTermination[1];
			

			if (nextArrivalTime<nextReadyTime) {	// DBG   what if it is the same, if there is a tie
				jobArrivalMode=true;
				nextEventExecutionTime=nextArrivalTime;
			}
			else{
				nextEventExecutionTime=nextReadyTime;
				jobArrivalMode=false;
			}

			status.setTimeInstant(nextEventExecutionTime);

			if (jobArrivalMode) {
				if (dbgVerbose)	{	System.out.println("Next event: Job arrival. Time " + nextArrivalTime);	}
								
				Job job = factory.getNextJob();
				if (dbgData) { 	dumpDebugDataJobs(job.getId(), job.getNumOperationsWorstCase(), status.getTimeInstant(), job.getDueDate());	}
				status.setNumJobs(status.getNumJobs()+1);

				if(job != null){
					ActualJob actualJob = new ActualJob(job);		
					Route route = job.getRoute();
					if(actualJob.getRoute() == null){
						actualJob.initializeRouteExecution(route);			
					}
					
					status.addNumOperations(route.getNumOperations());
					status.setJobCompletionRate(actualJob, actualJob.getNumOperationsLeft());
					
					if (dbgVerbose)	{ System.out.format("* Job %d ArrivalTime: %.1f Due Date: %.1f M%d \n",actualJob.getId(), actualJob.getArrivalTime(), actualJob.getDueDate(), route.getOperations().get(0).getFirstMachine().getId());	}					
				
					for(Operation operation: route.getTerminalOperations()){
						if (dbgVerbose)	{ System.out.println("Terminal operations list size:  " + route.getTerminalOperations().size());	}
						boolean processingStarted=false;

						List<Order> potentialOrderList	= 	new ArrayList<Order>();
						
						// check if there is an available machine
						for (Machine mac: operation.getEligibleMachines()){		// DBG se controlarmos o numero de maquinas disponivel, number of free machines, podemos evitar este passo
							Order order = new Order(this, actualJob, instance.getMachine(mac.getId()), operation, job.getArrivalTime());
							potentialOrderList.add(order);
							if (isMachineFree(mac.getId()-1,machineReadyTime, status)){
								int selectedMachineIDX=mac.getId()-1;					
								
								double actualOperationTime = order.getOperation().getTimebyMachineIDX(selectedMachineIDX);
								operation.setActualOperationTime(actualOperationTime);
								actualJob.addActualOperation(operation);							

								if (dbgVerbose)	{	System.out.println("Processing started right away,  timeInstant:  " + String.valueOf(status.getTimeInstant()) + "  duration:  "+ String.valueOf(order.getOperation().getTimebyMachineIDX(selectedMachineIDX)));	}
								if (dbgData)	{ 	dumpDebugDataEvents(job.getId(), operation.getId(), selectedMachineIDX+1, status.getTimeInstant(), order.getOperation().getTimebyMachineIDX(selectedMachineIDX), operation.getPrecedent()); 	}
								machineReadyTime[selectedMachineIDX]=status.getTimeInstant()+operation.getTimebyMachineIDX(selectedMachineIDX);
								orderInProcessing[selectedMachineIDX]=order;
								processingStarted=true;
								potentialOrderList.clear();
								break;
							}
						}
						if (!processingStarted){
							for (Order potentialOrder: potentialOrderList){
								status.pushOrderInMachineQueue(potentialOrder);
								status.incrementMachineWorkInQueue(potentialOrder.getMachine(), potentialOrder.getExpectedTime());		// DBG decrement in the right places
							}							
							if (dbgVerbose)	{	System.out.println("Machines were busy, sent to the queue");	}
							potentialOrderList.clear();
						}						
					}
				}			
			}
			else{
				// JOB FINISHED CODE
				Order currentOrder = orderInProcessing[nextMachineIDX];				
				ActualJob actualJob = currentOrder.getJob();				
				Operation nextOperation = currentOrder.getOperation().getSucessor();
				if(nextOperation != null){
					// check if there is an available machine
					List<Order> potentialOrderList	= 	new ArrayList<Order>();
					boolean processingStarted=false;

					for (Machine mac: nextOperation.getEligibleMachines()){		// DBG se controlarmos o numero de maquinas disponivel, number of free machines, podemos evitar este passo
						Order order = new Order(this, actualJob, instance.getMachine(mac.getId()), nextOperation, actualJob.getArrivalTime());
						potentialOrderList.add(order);
						if ((isMachineFree(mac.getId()-1,machineReadyTime, status)) && ((mac.getId()-1)!=nextMachineIDX)){
							int selectedMachineIDX=mac.getId()-1;					
							
							double actualOperationTime = order.getOperation().getTimebyMachineIDX(selectedMachineIDX);
							nextOperation.setActualOperationTime(actualOperationTime);
							actualJob.addActualOperation(nextOperation);							

							if (dbgVerbose)	{	System.out.println("Processing started right away,  timeInstant:  " + String.valueOf(status.getTimeInstant()) + "  duration:  "+ String.valueOf(order.getOperation().getTimebyMachineIDX(selectedMachineIDX)));	}
							if (dbgData)	{ 	dumpDebugDataEvents(actualJob.getId(), nextOperation.getId(), selectedMachineIDX+1, status.getTimeInstant(), order.getOperation().getTimebyMachineIDX(selectedMachineIDX), nextOperation.getPrecedent()); 	}
							machineReadyTime[selectedMachineIDX]=status.getTimeInstant()+nextOperation.getTimebyMachineIDX(selectedMachineIDX);
							orderInProcessing[selectedMachineIDX]=order;
							processingStarted=true;
							potentialOrderList.clear();
							break;
						}
					}

					if (!processingStarted){
						for (Order potentialOrder: potentialOrderList){
							status.pushOrderInMachineQueue(potentialOrder);
							status.incrementMachineWorkInQueue(potentialOrder.getMachine(), potentialOrder.getExpectedTime());		// DBG decrement in the right places
						}							
						if (dbgVerbose)	{	System.out.println("Machines were busy, sent to the queue");	}
						potentialOrderList.clear();
					}

				}
				else{
					if(actualJob.getNumOperationsLeft() == 0){
						status.setNumJobs(status.getNumJobs()-1);
						
						if((actualJob.getId() > GlobalParameters.MIN_JOBS_STEADY_STATE) && (actualJob.getId() <= GlobalParameters.MIN_JOBS_STEADY_STATE + maxJobsSimulation)){
							// only events in the stable zone are considered for metrics
							performance.updatePerformanceMetrics(status.getFinishedJobs(),actualJob.getArrivalTime(), actualJob.getDueDate(), status.getTimeInstant());
							status.addFinishedJobs();
							//System.out.println("Mais um job terminou   " + status.getFinishedJobs() + "  current queues:  " + status.getCurrentQueue(instance) + "  memory:  " + String.valueOf(heapFreeSize));		
						}				
					}
				}

				//machine is idle
				machineReadyTime[currentOrder.getMachine().getId()-1]=Double.MAX_VALUE;
				orderInProcessing[currentOrder.getMachine().getId()-1]=null;

				// STEP 2, sequence and route movable operations
				if (dbgVerbose)	{	System.out.println("STEP 2, sequence and route movable operations");	}
				List<Order> queue = status.getAvailableOrdersInAllMachines();

				Order nextOrder = null;
				double bestScore = Double.MAX_VALUE;

				if(queue.size()==0){
					if (dbgVerbose)	{	System.out.println("Job Shop queue is empty");	}
				}
				else{
					int queueSize=queue.size();
					while(queueSize!=0){		// DBG this won t work
						for(Order order: queue){	// DBG is it necessary to have a for every time
							double score=getDispatchingRuleValueRL(status, order,14);	// HARD CODED				
							if((score < bestScore) || (score == bestScore && order.getEnteringQueueTime() < nextOrder.getEnteringQueueTime())) {
								bestScore = score;
								nextOrder = order;
							}
						}

						if(nextOrder == null){System.out.println("Time instant = "+status.getTimeInstant()+" Ordem nula, Queue: "+queue.size());}
						else{ 
							if(dbgVerbose){	System.out.println("Decision: Job "+nextOrder.getJob().getId()+"  Op "+nextOrder.getOperation().getId()+" time: "+String.valueOf(status.getTimeInstant())+ " Proc. Time:"+nextOrder.getExpectedTime()); }
							if (dbgData)	{ 	dumpDebugDataEvents(nextOrder.getJob().getId(), nextOrder.getOperation().getId(), nextOrder.getMachine().getId(), status.getTimeInstant(), nextOrder.getExpectedTime(), nextOrder.getOperation().getPrecedent()); 	}
							//dumpDebugDataEvents(nextOrder.getJob().getId(), nextOrder.getOperation().getId(), nextOrder.getMachine().getId(), status.getTimeInstant(), nextOrder.getExpectedTime(), nextOrder.getOperation().getPrecedent());				
							//Execute order
							//Remover as ordens para a mesma operacao que foram disparadas para fila de outras maquinas
							double actualOperationTime = nextOrder.getOperation().getTimebyMachineIDX(currentOrder.getMachine().getId()-1);
							nextOrder.getOperation().setActualOperationTime(actualOperationTime);
							nextOrder.getJob().addActualOperation(nextOrder.getOperation());
							machinesFinalQueue.get(nextOrder.getMachine()).add(nextOrder);

							status.removeOrder(nextOrder);				// DBG   don t know if it is going to work
							queueSize=queueSize-nextOrder.getOperation().getEligibleMachines().size();
							status.decrementMachineWorkInQueue(nextOrder.getMachine(), nextOrder.getExpectedTime());		// DBG decrement in the right places
							//executeOrderGP(status, nextOrder, performance);		// must adapt, not necessary	
						}
					}
				}

				// STEP 3, find a operation for the idle machine
				if (dbgVerbose)	{	System.out.println("STEP 3, find a operation for the idle machine");	}
				
				if(machinesFinalQueue.get(instance.getMachine(nextMachineIDX+1)).size()>0){
					Order nextOrderinMachineFinalQueue=machinesFinalQueue.get(instance.getMachine(nextMachineIDX+1)).get(0);
					machineReadyTime[nextMachineIDX]=status.getTimeInstant()+nextOrderinMachineFinalQueue.getOperation().getTimebyMachineIDX(nextOrderinMachineFinalQueue.getMachine().getId()-1);
					orderInProcessing[nextMachineIDX]=nextOrderinMachineFinalQueue;
				}
				else{
					if (dbgVerbose)	{	System.out.println("Machine queue is empty");	}
				}

			}

		}while ((status.getFinishedJobs() < maxJobsSimulation) && (!queueThresholdExceeded));
	}

	public int runReplicationGP(Instance instance, PerformanceMetrics performance, int numReplication, int currentSeed) throws IOException, DeserializationException{		
		maxJobsSimulation = GlobalParameters.MAX_JOBS_STEADY_STATE - GlobalParameters.MIN_JOBS_STEADY_STATE;
		this.instance = instance;
		Utils.setDistributionsSeed(currentSeed, 0);
		InstanceGenerator.initMachinePerformance(instance.getNumMachines());
		double utilisationAdj=( 1.0-(InstanceGenerator.getMachineMeanPerformance()-1) )*utilizationLevel;
		System.out.println("Performance media das maquinas:" + String.valueOf(InstanceGenerator.getMachineMeanPerformance()));
		Utils.initializeExpDistributions(instance, utilisationAdj);
		Utils.setDistributionsSeed(currentSeed, 0);
					
		SimulationStatus status 	= new SimulationStatus(instance);		
		JobFactory factory 			= new JobFactory(instance, allowanceFactor);

		boolean queueThresholdExceeded=false;

		long startTime = System.nanoTime();
		long estimatedTime = System.nanoTime();

		if(GlobalParameters.VERBOSE){
			instance.describeInstance(allowanceFactor, utilizationLevel, CV);
			System.out.println(" =============== INITIALIZING REPLICATION =============== ");
		}
		
		//Executa as ordens ate que o criterio de parada seja satisfeito
		do{	
			if(GlobalParameters.VERBOSE)
				System.out.println("TIME INSTANT: "+status.getTimeInstant()+" Finished Jobs: "+status.getFinishedJobs());

			// ANTES DO CODIGO TRES CONDICOES DE TERMINO DE UMA REPLICACAO, 1 MEMORIA, 2 MAXMEANQUEU, 3 TIME
			long heapMaxSize = Runtime.getRuntime().maxMemory();
			long heapFreeSize = Runtime.getRuntime().freeMemory();
			double heapFreeSizePerc = ((double) heapFreeSize / heapMaxSize);
			
			if(heapFreeSizePerc<0.000008){  												// HARD CODED
				queueThresholdExceeded=true;
				System.out.println("Replicacao abortada - low memory");
				System.out.println("heap max size: " + String.valueOf(heapMaxSize));
				System.out.println("heap free size: " + String.valueOf(heapFreeSize));
				System.out.println(String.valueOf(heapFreeSizePerc));
				performance.abortReplication();
			}
			if(performance.getMaxMeanQueue()>65){  											// HARD CODED
				queueThresholdExceeded=true;
				System.out.println("Replicacao abortada - high queue");
				performance.abortReplication();
			}

			estimatedTime = System.nanoTime() - startTime;
			if (estimatedTime>3000000000000.0) {
				queueThresholdExceeded=true;
				System.out.println("Replicacao abortada - high running time");
				performance.abortReplication();
			}

			double nextArrivalTime			= factory.getNextArrivalTime();
			double nextEventExecutionTime 	= status.getNextOrderExecutionTime();
			double nextPendingOrderTime 	= status.getNextPedingOrder();

			//Se o proximo evento e uma ordem pronta pra ser executada
			if((nextEventExecutionTime < nextPendingOrderTime) && (nextEventExecutionTime < nextArrivalTime)){
				
				if(GlobalParameters.VERBOSE)
					System.out.println("Next event: Order execution. Time "+nextEventExecutionTime);

				status.setTimeInstant(nextEventExecutionTime);

				//E executa o proximo evento dessa maquina
				executeEventGP(status, performance,numReplication);
			}

			//Se o proximo evento e a chegada de um job, cria as ordens para o job
			else if((nextArrivalTime <= nextPendingOrderTime)){
				
				if(GlobalParameters.VERBOSE)
					System.out.println("Next event: Job arrival. Time "+nextArrivalTime);
								
				Job job = factory.getNextJob();

				status.setNumJobs(status.getNumJobs()+1);

				if(job != null){
					status.setTimeInstant(nextArrivalTime);

					ActualJob actualJob = new ActualJob(job);		
					Route route = job.getRoute();

					for(Operation operation: route.getTerminalOperations()){
						createArrivalOrders(status, actualJob, operation);					
					}
					
					status.addNumOperations(route.getNumOperations());
					status.setJobCompletionRate(actualJob, actualJob.getNumOperationsLeft());
					//dumpDebugDataJobs(actualJob.getId(), actualJob.getNumOperationsLeft(), actualJob.getArrivalTime(), actualJob.getDueDate());
					if(GlobalParameters.VERBOSE)					
						System.out.format("* Job %d ArrivalTime: %.1f Due Date: %.1f M%d \n",actualJob.getId(), actualJob.getArrivalTime(), actualJob.getDueDate(), route.getOperations().get(0).getFirstMachine().getId());
				}
			}
			else{
				
				if(GlobalParameters.VERBOSE)
					System.out.println("Next event: Push order to queue. Time "+nextPendingOrderTime);

				//Se o proximo evento � liberar uma ordem que estava pendente				
				status.setTimeInstant(nextPendingOrderTime);	
				//Inclui todas as ordens pendentes
				status.pushOrdersInMachineQueue();
				
			}

		}while ((status.getFinishedJobs() < maxJobsSimulation) && (!queueThresholdExceeded));
		
		if(status.getFinishedJobs() != maxJobsSimulation){
			System.out.println("ERRO. Simulacao encerrou e nao ha mais jobs ("+status.getFinishedJobs()+
					"). Instancia "+instance.getName()+" U: "+utilizationLevel+" a:"+allowanceFactor+" cv: "+CV);
		}
				
		positiveSlack += status.getNumberPositiveSlack();
		
		status.finishSimulation();			
		
		performance.addMeanRealQueueSize(status.getMeanQueueSize());
		performance.updateQueueSize(status.getCurrentQueue(instance));
		performance.calculateMetrics(status.getFinishedJobs());
		performance.updateUtilisationReal(status.getTimeInstant(),instance.getNumMachines());
		
		return status.getFinishedJobs();
	}	
	
	public int runReplication(Instance instance, PerformanceMetrics performance, RLagent agent, MultiLayerPerceptron neuralNet,MultiLayerPerceptron targetNet,int numReplication) throws IOException, DeserializationException{		
		System.out.println("Inicio de uma nova replicacao: "+numReplication);
		if(GlobalParameters.VERBOSE)
			System.out.println(" =============== INITIALIZING REPLICATION =============== ");

		//System.out.println("Allowance: "+allowanceFactor+" U:"+utilizationLevel+" CV: "+CV+" Rule "+dispRule);
		SimulationStatus status 	= new SimulationStatus(instance);		
		JobFactory factory 			= new JobFactory(instance, allowanceFactor);
		if(GlobalParameters.ONLINE_MODE)	{readReplicationData(numReplication);}
		int currentRecord=0;
		boolean noRecordsExceeded=false;


		//Executa as ordens at� que o crit�rio de parada seja satisfeito
		do{	
			//System.out.println("TIME INSTANT: "+status.getTimeInstant());
			if(GlobalParameters.VERBOSE)
				System.out.println("TIME INSTANT: "+status.getTimeInstant()+" Finished Jobs: "+status.getFinishedJobs());

			// if(status.getFinishedJobs()==500){
			// 	System.out.println("TEMPO DE CORTE");
			// 	System.out.println(String.valueOf(status.getTimeInstant()));
			// }

			//status.dumpQueueTelemetry(instance);

			double nextArrivalTime=0.0;
			if(!GlobalParameters.ONLINE_MODE){
				nextArrivalTime= factory.getNextArrivalTime();
			}
			else{
				try{
					nextArrivalTime=getNextArrivalTimeFromRecord(currentRecord);
				}
				catch(Exception e){
					System.out.println("Não há mais jobs guardados, simulacao TERMINOU");
					noRecordsExceeded=true;
				}
				
			}


			double nextEventExecutionTime = status.getNextOrderExecutionTime();
			double nextPendingOrderTime = status.getNextPedingOrder();

			//Se o proximo evento � uma ordem pronta pra ser executada
			if((nextEventExecutionTime < nextPendingOrderTime) && (nextEventExecutionTime < nextArrivalTime) && (!noRecordsExceeded)){
				
				if(GlobalParameters.VERBOSE)
					System.out.println("Next event: Order execution. Time "+nextEventExecutionTime);

				status.setTimeInstant(nextEventExecutionTime);				

				//E executa o proximo evento dessa maquina
				executeEvent(status, performance,agent,neuralNet,numReplication);
				if(!GlobalParameters.ONLINE_MODE){
					//agent.softPolicyUpdate(neuralNet,targetNet,numReplication);
				}

			}
			//Se o proximo evento � a chegada de um job, cria as ordens para o job
			else if((nextArrivalTime <= nextPendingOrderTime) && (!noRecordsExceeded)){
				
				if(GlobalParameters.VERBOSE)
					System.out.println("Next event: Job arrival. Time "+nextArrivalTime);
				
				Job job;
				if(!GlobalParameters.ONLINE_MODE){
					job = factory.getNextJob();
				}
				else{
					job = factory.getNextJobFromRecord(replicationData.get(currentRecord),nextArrivalTime);
					currentRecord=currentRecord+1;
				}

				status.setNumJobs(status.getNumJobs()+1);
				//dumpReplicationData(job,numReplication);

				// if(job.getId()==500){
				// 	System.out.println("TEMPO DE CORTE");
				// 	System.out.println(String.valueOf(status.getTimeInstant()));
				// }

				if(job != null){
					status.setTimeInstant(nextArrivalTime);

					ActualJob actualJob = new ActualJob(job);		
					Route route = job.getRoute();

					for(Operation operation: route.getTerminalOperations()){
						createArrivalOrders(status, actualJob, operation);					
					}
					
					status.addNumOperations(route.getNumOperations());
					status.setJobCompletionRate(actualJob, actualJob.getNumOperationsLeft());
					if(GlobalParameters.VERBOSE)
						System.out.format("* Job %d ArrivalTime: %.1f Due Date: %.1f M%d \n",actualJob.getId(), actualJob.getArrivalTime(), actualJob.getDueDate(), route.getOperations().get(0).getFirstMachine().getId());
						//log_entries=log_entries+1;
						//log_entry.put(String.valueOf(log_entries),"Next event: Job arrival. Time "+nextArrivalTime);
						//logBook.add(log_entry);
				}
			}
			else{
				
				if(GlobalParameters.VERBOSE)
					System.out.println("Next event: Push order to queue. Time "+nextPendingOrderTime);
				if(!noRecordsExceeded){
					//Se o proximo evento � liberar uma ordem que estava pendente				
					status.setTimeInstant(nextPendingOrderTime);	
					//Inclui todas as ordens pendentes
					status.pushOrdersInMachineQueue();
				}
			}
			//System.out.println(status.getFinishedJobs());
/* 			if(nReplications%2000==0 && nReplications!=0){
				
				System.out.println("Dumping Data");
				try						{agent.dumpData();}
				catch (IOException e) 	{e.printStackTrace();}

				agent.updatePolicy(neuralNet);

			} */
		}while ((status.getFinishedJobs() < maxJobsSimulation) && (!noRecordsExceeded));
		
		if(status.getFinishedJobs() != maxJobsSimulation){
			System.out.println("ERRO. Simulacao encerrou e nao ha mais jobs ("+status.getFinishedJobs()+
					"). Instancia "+instance.getName()+" U: "+utilizationLevel+" a:"+allowanceFactor+" cv: "+CV);
		}
		
		Random random=new Random();
		double rnd2=random.nextDouble();

		if(rnd2<0.001||numReplication==0){
			try						{agent.dumpEpisodeData();}
			catch (IOException e) 	{e.printStackTrace();}
		}

		double episodeTardinessTemp=0.0;
		if(noRecordsExceeded)	{episodeTardinessTemp=100000000;}
		else					{episodeTardinessTemp=status.getEpisodeTotalTardinessStable();}		
		try						{status.dumpPerformance(episodeTardinessTemp);}
		catch (IOException e) 	{e.printStackTrace();}

		if(false){
			agent.dumpWeights(neuralNet, "online");
			agent.dumpWeights(targetNet, "target");
			bestTardiness=episodeTardinessTemp;
		}

		try						{agent.dumpActionFrequencies();}
		catch (IOException e) 	{e.printStackTrace();}

		if((episodeTardinessTemp<bestTardiness && numReplication>0)||(episodeTardinessTemp<65000)){
			try						{agent.dumpQTable(numReplication);
									bestTardiness=episodeTardinessTemp;}
			catch (IOException e) 	{e.printStackTrace();}
		}

		if(!GlobalParameters.ONLINE_MODE){
			checkTestConditions(numReplication,episodeTardinessTemp);
		}

		double[] utilisationTemp=status.getMachineUtilisation();
		System.out.println("UTILIZACAO:   "+String.valueOf(utilisationTemp[0]));
		
		
		positiveSlack += status.getNumberPositiveSlack();
		
		status.finishSimulation();			
		performance.addMeanQueueSize(status.getMeanQueueSize());
		performance.addMeanRealQueueSize(status.getMeanRealQueueSize());
		
		performance.calculateMetrics(status.getFinishedJobs());
		return status.getFinishedJobs();
	}
	
	public void checkTestConditions(int n,double tardinessTemp) throws IOException{
		//boolean resultado=false;
		if(n>20){
			if(tardinessTemp<65000 && n-GlobalParameters.lastCheckPoint>=100){
				GlobalParameters.ONLINE_MODE=true;
				GlobalParameters.lastCheckPoint=n;
				
				try{
					Writer output = new FileWriter("testCycles.txt");
					output.write(n);
					output.close();
				}
				catch(Exception e) {
					e.getStackTrace();
				}
			}
		}
	}

	private void dumpDebugDataEvents(int jid, int oid, int macid, double stime, double dtime, Operation parentOp){
		// TOIMPROVE  nao esta robusto a varias corridas
/* 		if (jid==281 && oid ==2198) {
			System.out.println("alto");
		} */
		double ftime= stime+dtime;
		String output="";
		if (parentOp!=null) {
			output=jid + ";" + oid + ";" + macid + ";" + String.valueOf(stime) + ";" + String.valueOf(dtime) + ";" + String.valueOf(ftime) + ";" + parentOp.getId();
		}
		else{
			output=jid + ";" + oid + ";" + macid + ";" + String.valueOf(stime) + ";" + String.valueOf(dtime) + ";" + String.valueOf(ftime) + ";" + "null";
		}

		FileWriter fw;
		try {
			fw = new FileWriter("debugDataEvents.txt", true);
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(output);
			bw.newLine();
			bw.close();
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void dumpDebugDataQueue(SimulationStatus status, Order order){
		double ptr = order.getExpectedTime()/order.getOperation().getAverageExpectedTime();
		double flexadimensional = (double)order.getOperation().getNumEligibleMachines()/(double)instance.getNumMachines();
		String output = String.valueOf(status.getTimeInstant()) + ", " + String.valueOf(order.getExpectedTime()) + ", " + String.valueOf(ptr) + ", " + String.valueOf(flexadimensional) + ", " + String.valueOf(order.getRemainingProcessingTime()) + ", " + String.valueOf(order.getJob().getDueDate());
		
		FileWriter fw;
		try {
			fw = new FileWriter("debugDataQueues.txt", true);
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(output);
			bw.newLine();
			bw.close();
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void dumpDebugDataStateTelemetry(String outputLine){		
		FileWriter fw;
		try {
			fw = new FileWriter("debugDataStateTelemetry_" + GlobalParameters.INSTANCETOTEST + ".txt", true);
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(outputLine);
			bw.newLine();
			bw.close();
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void executeEventGP(SimulationStatus status, PerformanceMetrics performance, int numReplication){

		List<Order> queue = status.getAvailableOrders();

		Order nextOrder = null;
		double bestScore = Double.MAX_VALUE;
		
		for(Order order: queue){
			//dumpDebugDataQueue(status, order);

			double score=getDispatchingRuleValue(status, order);					
			if((score < bestScore) || (score == bestScore && order.getEnteringQueueTime() < nextOrder.getEnteringQueueTime())) {
				bestScore = score;
				nextOrder = order;
			}
		}			

		if(nextOrder == null){
			System.out.println("Time instant = "+status.getTimeInstant()+" Ordem nula, Queue: "+queue.size());
		}
		else{
			if(GlobalParameters.VERBOSE)
				System.out.println("⚠⚠ Chosen Order: Job "+nextOrder.getJob().getId()+" "+nextOrder.getOperation().getId()+" Score: "+bestScore+ " Proc. Time:"+nextOrder.getExpectedTime());
			//dumpDebugDataEvents(nextOrder.getJob().getId(), nextOrder.getOperation().getId(), nextOrder.getMachine().getId(), status.getTimeInstant(), nextOrder.getExpectedTime(), nextOrder.getOperation().getPrecedent());				
			//Execute order
			//Remover as ordens para a mesma operacao que foram disparadas para fila de outras maquinas
			status.removeOrder(nextOrder);
			executeOrderGP(status, nextOrder, performance);			
		}			
	}

	private void executeEvent(SimulationStatus status, PerformanceMetrics performance, RLagent agent, MultiLayerPerceptron neuralNet, int numReplication){
		Random rand = new Random();
		List<Order> queue = status.getAvailableOrders();

		Order nextOrder = null;
		double bestScore = Double.MAX_VALUE;

		int action=0;

		boolean rlActionNeededEval=rlActionNeeded(queue);

		if(rlActionNeededEval){
			//Observa o estado
			Observation obs=observedState(status,agent);
			obs.setIteration(numReplication);

			int[] index=agent.idx(obs);

			boolean takeRandomAction=takeRandomAction(numReplication);
			if(takeRandomAction){
				action=rand.nextInt(6)+1;
				agent.setAction(action);
				obs.setRandomStatus(1.0);
			}
			else{
				//action=agent.makePrediction(neuralNet, obs);
				action=agent.makePredictionQTable(index);
				if(!GlobalParameters.ONLINE_MODE){
					agent.setAction(action);
				}
			}	
					
			agent.computeReward();

			for(Order order: queue){
								

				//if(!evaluatedOrders.contains(order)){
					//double score = getDispatchingRuleValue(status, order);
					//double score = rand.nextDouble()+1.0;
					double score=getDispatchingRuleValueRL(status, order, action);
					//System.out.println("O score obtido foi:   "+score);
					//System.out.println("Job "+order.getJob().getId()+" "+order.getOperation().getId()+" Score: "+score+ " Proc. Time:"+order.getExpectedTime());	
					
					if((score < bestScore) || (score == bestScore && order.getEnteringQueueTime() < nextOrder.getEnteringQueueTime())) {
						bestScore = score;
						nextOrder = order;
					}	
										
					//evaluatedOrders.add(order);
				//}

			}

			//double[] rlScores=rlOrderScores(status, nextOrder);
			//double[] votes=benchmarkVotes(status, queue);
			//double rewardVoting =computeRewardVoting(rlScores,votes,queue);
			//nextOrder=votingSystemSA(status,queue,votes,nextOrder);

			//obs.setReward(rewardVoting);
			if(!GlobalParameters.ONLINE_MODE){
				agent.updateQtableLA(index);
			}

		}
		else{
				for(Order order: queue){				

					//if(!evaluatedOrders.contains(order)){
						//double score = getDispatchingRuleValue(status, order);
						//double score = rand.nextDouble()+1.0;
						//double rand_dub2 = rand.nextDouble();
						double score=getDispatchingRuleValueRL(status, order, 4);
						//System.out.println("O score obtido foi:   "+score);
						//System.out.println("Job "+order.getJob().getId()+" "+order.getOperation().getId()+" Score: "+score+ " Proc. Time:"+order.getExpectedTime());	
						
						if((score < bestScore) || (score == bestScore && order.getEnteringQueueTime() < nextOrder.getEnteringQueueTime())) {
							bestScore = score;
							nextOrder = order;
						}	
											
						//evaluatedOrders.add(order);
					//}
				}

		}		

		if(nextOrder == null){
			System.out.println("Time instant = "+status.getTimeInstant()+" Ordem nula, Queue: "+queue.size());
			System.out.println(action);
		}
		else{

			if(GlobalParameters.VERBOSE)
				System.out.println("⚠⚠ Chosen Order: Job "+nextOrder.getJob().getId()+" "+nextOrder.getOperation().getId()+" Score: "+bestScore+ " Proc. Time:"+nextOrder.getExpectedTime());
							
			//Execute order
			//Remover as ordens para a mesma opera��o que foram disparadas para fila de outras maquinas
			status.removeOrder(nextOrder);
			executeOrder(status, nextOrder, null, performance,agent);			
		}			
	}

	public boolean takeRandomAction(int numReplication){
		Random rand=new Random();
		double threshold=rand.nextDouble();
		
		boolean resultado=false;
		
		if	(GlobalParameters.ONLINE_MODE)	{resultado=false;}
		else{
			if(GlobalParameters.LOAD_WEIGHTS||GlobalParameters.LOAD_QTABLE){
				if	(threshold<0.10)	{resultado=true;}
				else				{resultado=false;}
			}
			else{
				if	(threshold<Math.max(0.10,0.5-numReplication*0.02))	{resultado=true;}
				else													{resultado=false;}
			}
		}
		return resultado;
	}

	public boolean rlActionNeeded(List<Order> queue){
		boolean resultado=false;
		
		if(queue.size()==1)	{resultado=false;}
		else{
			int opId=queue.get(0).getOperation().getId();
			for(int i=1;i<queue.size();i++){			
				if(queue.get(i).getOperation().getId()!=opId){
					resultado=true;
					break;
				}
			}
		}

		return resultado;

	}

	

	private void executeOrder(SimulationStatus status, Order order, Window window, PerformanceMetrics performance, RLagent agent){

		ActualJob actualJob = order.getJob();
		Route route = order.getRoute();		
		Operation operation = order.getOperation();
		double startTime = status.getTimeInstant();

		double actualOperationTime = order.getExpectedTime();		
		if(CV > 0){
			actualOperationTime = Utils.getOperationTimeSample(actualOperationTime, CV);
		}		
		double finishTime = startTime + actualOperationTime;

		if(GlobalParameters.VERBOSE){
			//			System.out.format("\n JOB %d (op %d) Time [Exp: %d - Act: %d] Mode: %s (%d - %d) MinTime: %d DueDate: %d", 
			//					actualJob.getId(), operation.getId(),
			//					(int) order.getExpectedTime(), (int)actualOperationTime, mode.toString(), 
			//					(int)startTime, (int)finishTime,
			//					(int) order.getMinExecutionTime(), 
			//					(int) order.getJob().getDueDate());	
			System.out.format("\n-- JOB%d (op %d) Time: %.1f (%.1f - %.1f),  NumOpLeft %d M%d", 
					actualJob.getId(), operation.getId(),
					order.getExpectedTime(), startTime, finishTime, actualJob.getNumOperationsLeft(), order.getMachine().getId());				
			System.out.println();
		}

		status.setJobCompletionRate(actualJob, actualJob.getNumOperationsLeft()-1);
		status.setJobCompletionTime(actualJob, finishTime);

		//actualJob.initializeRouteExecution(route);
		//Se é a primeira operação da rota,
		//Definindo a rota do job e corrigindo o tempo de processamento faltante
		//Tambem remove-se as ordens referentes a outras rotas para o job,
		//Uma vez a rota "route" foi escolhida
		if(actualJob.getRoute() == null){
			actualJob.initializeRouteExecution(route);
			//if(actualJob.getRoutes().size() > 1){
				//status.removeOrdersFromDifferentRoutes(route);
			//}				
		}			

		operation.setActualOperationTime(actualOperationTime);

		//É na instrução seguinte que o número de operações left é descontado
		actualJob.addActualOperation(operation);

		//Atualizando informa��es para a execu��o da pr�xima ordem nesta maquina
		Machine machine = order.getMachine();
		status.setAvailability(machine, finishTime);
		
		status.setUtilisation(machine, actualOperationTime);
		status.setCompletionTime(machine, finishTime);

		Operation nextOperation = operation.getSucessor();
		if(nextOperation != null){
			createOrders(status, actualJob, nextOperation, finishTime);			
		}

		if(actualJob.getNumOperationsLeft() == 0){
			status.setNumJobs(status.getNumJobs()-1);
			//status.addFinishedJobs();
			
			//Se o simulador est� considerando chegadas dinamicas, a performance s� � contabilizada a partir de 
			//um certo numero de jobs
			if((actualJob.getId() > GlobalParameters.MIN_JOBS_STEADY_STATE) &&
					(actualJob.getId() <= GlobalParameters.MIN_JOBS_STEADY_STATE + maxJobsSimulation)){
				performance.updatePerformanceMetrics(status.getFinishedJobs(),actualJob.getArrivalTime(), actualJob.getDueDate(), finishTime);
				status.addFinishedJobs();
				performance.updateQueueSize(status.getCurrentQueue(instance));		
			}
			performance.addFullTardiness(actualJob.getDueDate(), finishTime);
			window.updateIntraWindowTardiness( Math.max(finishTime - actualJob.getDueDate(), 0.0) - Math.max(window.getInitialTimestep() - actualJob.getDueDate(), 0.0) );
		}
	}

	private void executeOrderGP(SimulationStatus status, Order order, PerformanceMetrics performance){

		ActualJob actualJob = order.getJob();
		Route route = order.getRoute();		
		Operation operation = order.getOperation();
		double startTime = status.getTimeInstant();

		double actualOperationTime = order.getExpectedTime();		
		if(CV > 0){
			actualOperationTime = Utils.getOperationTimeSample(actualOperationTime, CV);
		}		
		double finishTime = startTime + actualOperationTime;

		if(GlobalParameters.VERBOSE){
			//			System.out.format("\n JOB %d (op %d) Time [Exp: %d - Act: %d] Mode: %s (%d - %d) MinTime: %d DueDate: %d", 
			//					actualJob.getId(), operation.getId(),
			//					(int) order.getExpectedTime(), (int)actualOperationTime, mode.toString(), 
			//					(int)startTime, (int)finishTime,
			//					(int) order.getMinExecutionTime(), 
			//					(int) order.getJob().getDueDate());	
			System.out.format("\n-- JOB%d (op %d) Time: %.1f (%.1f - %.1f),  NumOpLeft %d M%d", 
					actualJob.getId(), operation.getId(),
					order.getExpectedTime(), startTime, finishTime, actualJob.getNumOperationsLeft(), order.getMachine().getId());				
			System.out.println();
		}

		status.setJobCompletionRate(actualJob, actualJob.getNumOperationsLeft()-1);
		status.setJobCompletionTime(actualJob, finishTime);

		//actualJob.initializeRouteExecution(route);
		//Se é a primeira operação da rota,
		//Definindo a rota do job e corrigindo o tempo de processamento faltante
		//Tambem remove-se as ordens referentes a outras rotas para o job,
		//Uma vez a rota "route" foi escolhida
		if(actualJob.getRoute() == null){
			actualJob.initializeRouteExecution(route);
			//if(actualJob.getRoutes().size() > 1){
				//status.removeOrdersFromDifferentRoutes(route);
			//}				
		}			

		operation.setActualOperationTime(actualOperationTime);

		//É na instrução seguinte que o número de operações left é descontado
		actualJob.addActualOperation(operation);

		//Atualizando informa��es para a execu��o da pr�xima ordem nesta maquina
		Machine machine = order.getMachine();
		status.setAvailability(machine, finishTime);
		
		status.setUtilisation(machine, actualOperationTime);
		status.setCompletionTime(machine, finishTime);

		Operation nextOperation = operation.getSucessor();
		if(nextOperation != null){
			createOrders(status, actualJob, nextOperation, finishTime);			
		}

		performance.addUtilisationReal(order.getExpectedTime(), finishTime);
		performance.addProcessingTimeReal(order.getExpectedTime());

		if(actualJob.getNumOperationsLeft() == 0){
			status.setNumJobs(status.getNumJobs()-1);
			performance.updateQueueSize(status.getCurrentQueue(instance));
			//status.addFinishedJobs();
			
			//Se o simulador est� considerando chegadas dinamicas, a performance s� � contabilizada a partir de 
			//um certo numero de jobs
			if((actualJob.getId() > GlobalParameters.MIN_JOBS_STEADY_STATE) &&
					(actualJob.getId() <= GlobalParameters.MIN_JOBS_STEADY_STATE + maxJobsSimulation)){
				performance.updatePerformanceMetrics(status.getFinishedJobs(),actualJob.getArrivalTime(), actualJob.getDueDate(), finishTime);
				status.addFinishedJobs();
				//performance.setOverallStartTime(startTime);
				//performance.setOverallFinishTime(finishTime);
			}				
		}
	}

	private Observation observedState(SimulationStatus status, RLagent agent){
		double[] machinesUtilisationTemp=status.getMachineUtilisation();
		double[] operationsStatus=status.operationsStatus();
		double[] tardinessKPI=status.tardinessKPI();

		Observation obs=new Observation(status.getTimeInstant());
		obs.setMachineUtilisation(machinesUtilisationTemp[0], machinesUtilisationTemp[1]);
		obs.setOperationsRate(operationsStatus[0]);
		obs.setJobsRate(operationsStatus[1], operationsStatus[2]);
		obs.setTardiness(tardinessKPI[0], tardinessKPI[1]);
		//obs.setAction(action);
		if(!GlobalParameters.ONLINE_MODE){
			agent.addObservation(obs);
			agent.setPreviousObservation(obs);
		}
		agent.addObservationEpisodeSet(obs);
		return obs;
	}

	private void createOrders(SimulationStatus status, ActualJob job, Operation operation, double minStartTime){

		for(Machine machine: operation.getEligibleMachines())
		{				
			if(GlobalParameters.VERBOSE)
				System.out.println("Creating order Op "+operation.getId()+" Time "+operation.getAverageExpectedTime());
			Order order = new Order(this, job, machine, operation, minStartTime);														
			status.addPendingOrderToQueue(order);
			status.incrementMachineWorkInQueue( machine, order.getExpectedTime() );	
		}
	}
	private void createArrivalOrders(SimulationStatus status, ActualJob job, Operation operation){

		for(Machine machine: operation.getEligibleMachines())
		{					
			Order order = new Order(this, job, machine, operation, job.getArrivalTime());														
			status.pushOrderInMachineQueue(order);
			status.incrementMachineWorkInQueue( machine, order.getExpectedTime() );	
			//System.out.println("\nAdding job "+job.getId()+" ArrivalTime: "+job.getArrivalTime()+" Ops: "+job.getRoutes().get(0).getNumOperations()+" Machine: "+mode.getMachines().get(0).getId()+" Queue: "+status.getQueueSize(mode)+" Finished Jobs: "+status.getFinishedJobs());
		}
	}

	public void testLoop(final EvolutionState state,Instance instance){
		LineNumberReader lineNumberReader;
		try {
			lineNumberReader = new LineNumberReader(new FileReader("Rules"));
			state.population.readPopulation(state, lineNumberReader);
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		double[] flexibilityArray		=	{0.5  };
		double[] utilisationArray		= 	{0.90 };
		double[] allowanceArray			=	{1.3  };

		int nReplications=150;
		int individualidx=0;
		int[] rulesIDArray				=	{1};
		
		for (int r=0; r<rulesIDArray.length; r++){
			//Utils.setDistributionsSeed(200, CV);
			individualidx=rulesIDArray[r];
			Individual individualToTest=state.population.subpops.get(0).individuals.get(individualidx);
			
			Individual ind=individualToTest;
			individual=individualToTest;

			System.out.println("SIZE OF IND:   " + String.valueOf(individual.size()));

			for(int i = 0; i < flexibilityArray.length; i++){
				double flexibility=flexibilityArray[i];
				instance.setOpFlexibility(flexibility);
				for(int j = 0; j < utilisationArray.length; j++){
					utilizationLevel=utilisationArray[j];
					//Utils.initializeExpDistributions(instance, utilizationLevel);
					//Utils.setExpDistributionsSeed(1, CV);
					for(int k = 0; k < allowanceArray.length; k++){
						allowanceFactor=allowanceArray[k];
						combination=9*i+3*j+1*k;
						for(int n = 0; n < nReplications; n++){
							//Utils.setDistributionsSeed(n+1, CV);
							try {			
								PerformanceMetrics performance = new PerformanceMetrics();	
								runReplicationGP(instance,performance,nReplications,n+1);
								//DEBUG
								double episodeTotalTardinessTemp=performance.getEpisodeTotalTardiness();
								performance.updateTotalTardinessNormalized(episodeTotalTardinessTemp, combination);
								String output = String.valueOf(state.generation) + ";"+String.valueOf(ind.hashCode()) + ";" + String.valueOf(flexibility) + ";" + String.valueOf(utilizationLevel)+";"+ String.valueOf(allowanceFactor) + ";"+ n + ";" + String.valueOf(episodeTotalTardinessTemp) + ";" + String.valueOf(performance.getTotalTardinessNormalized()) + " ; " + String.valueOf(performance.getMeanFlowTime()) + ";" + String.valueOf(performance.getUtilisationReal()) +";"+ String.valueOf(performance.getProcessingTimeReal()) +";"+ String.valueOf(performance.getMeanQueueSize()) + "; 1.0";	
								//System.out.println(output);
								if(performance.getMaxMeanQueue()<65){  // HARD CODED VALUE
									FileWriter fw;
									try {
										fw = new FileWriter("testLoopResults instance" + GlobalParameters.INSTANCETOTEST + ".txt", true);
										BufferedWriter bw = new BufferedWriter(fw);
										bw.write(output);
										bw.newLine();
										bw.close();
										fw.close();
									} catch (IOException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
								}
								else{
									performance.updateTotalTardinessNormalized(10000000.0, combination);
									// SO ESTAMOS A ATUALIZAR A TARDINESS NORMALIZADA
									output = String.valueOf(state.generation) + ";"+String.valueOf(ind.hashCode()) + ";" + String.valueOf(flexibility) + ";" + String.valueOf(utilizationLevel)+";"+ String.valueOf(allowanceFactor) + ";"+ n + ";" + String.valueOf(episodeTotalTardinessTemp) + ";" + String.valueOf(performance.getTotalTardinessNormalized()) + " ; " + String.valueOf(performance.getMeanFlowTime()) + ";" + "10.0" +";"+ "99.9" +";"+ String.valueOf(performance.getMeanQueueSize()) + "; 0.0";
									FileWriter fw;
									try {
										fw = new FileWriter("testLoopResults instance" + GlobalParameters.INSTANCETOTEST + ".txt", true);
										BufferedWriter bw = new BufferedWriter(fw);
										bw.write(output);
										bw.newLine();
										bw.close();
										fw.close();
									} catch (IOException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
								}
							} catch (IOException | DeserializationException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					}
				}
			}
		}
		
		//java.awt.Toolkit.getDefaultToolkit().beep();
		int tempvar=1/0;
	}

	public int checkIndPos(final EvolutionState state, int code)	{
		int resultado = 0;
		for(int i=0;i<state.population.subpops.get(0).initialSize;i++){
			Individual individualToTest=state.population.subpops.get(0).individuals.get(i);
			if(code==individualToTest.hashCode()){
				resultado=i;
				break;
			}			
		}
		return resultado;
	}

	public void outputReplicationData(PerformanceMetrics performance, int comb, Individual ind, double flexibility, int n, int indIDX){
		String output = "" ;
		performance.updateTotalTardinessNormalized	(	performance.getTotalTardiness()	, 	comb	);
		performance.updateMeanFlowTimeNormalized	(	performance.getMeanFlowTime()	, 	comb	);

		if ( performance.getReplicationStatus() ) {
			performance.updateTotalTardinessNormalized(10000000.0, combination);
			performance.updateMeanFlowTimeNormalized(10000000.0, combination);
			output = String.valueOf(state.generation) + ";"+String.valueOf(ind.hashCode()) + ";" + String.valueOf(flexibility) + ";" + String.valueOf(utilizationLevel)+";"+ String.valueOf(allowanceFactor) + ";"+ n + ";" + String.valueOf(performance.getTotalTardiness()) + ";" + String.valueOf(performance.getTotalTardinessNormalized()) + " ; " + String.valueOf(performance.getMeanFlowTime()) + " ; " + String.valueOf(performance.getMeanFlowTimeNormalized()) + ";" + "10.0" +";"+ "99.9" +";"+ String.valueOf(performance.getMeanQueueSize()) + "; 0;" + String.valueOf(ind.size())+ ";"+ String.valueOf(indIDX);
		}
		else{
			output = String.valueOf(state.generation) + ";"+String.valueOf(ind.hashCode()) + ";" + String.valueOf(flexibility) + ";" + String.valueOf(utilizationLevel)+";"+ String.valueOf(allowanceFactor) + ";"+ n + ";" + String.valueOf(performance.getTotalTardiness()) + ";" + String.valueOf(performance.getTotalTardinessNormalized()) + " ; " + String.valueOf(performance.getMeanFlowTime()) + " ; " + String.valueOf(performance.getMeanFlowTimeNormalized()) + ";" + String.valueOf(performance.getUtilisationReal()) +";"+ String.valueOf(performance.getProcessingTimeReal()) +";"+ String.valueOf(performance.getMeanQueueSize()) + "; 1 ;" + String.valueOf(ind.size()) + ";"+ String.valueOf(indIDX);	
		}		

		FileWriter fw;
			try {
				fw = new FileWriter(GlobalParameters.OUTPUT_DIR +  "generationMetrics.txt", true);
				BufferedWriter bw = new BufferedWriter(fw);
				bw.write(output);
				bw.newLine();
				bw.close();
				fw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//n=n-1;		
	}

	public int getSeedNumber(int gen, int comb, int nReps, int rep){
		int seedNumber = 0;
		seedNumber = seedNumber + (gen+1)*1000000;									// afetar pelo numero de geracao
		if 		(nReps>2) 	{ seedNumber = seedNumber + 20000		; }				// afetar fase de avaliacao
		else				{ seedNumber = seedNumber + 10000		; }				// afetar fase de avaliacao
		//seedNumber = seedNumber + comb * 100 ;										// afetar pelo cenario
		seedNumber = seedNumber + rep;												// afetar pelo numero de replicacao
		return seedNumber;
	}

	public void evaluate(final EvolutionState state,final Individual ind,final int subpopulation,final int threadnum)	{

		// Instance reading
		List<Instance> instances = DataLoader.readInstanceSetList("ValidationInstances.csv");		
		Instance instance=instances.get(GlobalParameters.INSTANCETOTEST);
		
		// Benchmark Reading  -  not in use
		BenchmarkResult benchmark = Utils.getBenchmarkResult(instance, allowanceFactor, utilizationLevel, CV);

		if (GlobalParameters.VERBOSE){			System.out.println("A iniciar a geracao: " + state.generation);		}
		
		this.state = state;
		this.threadnum = threadnum;		
		this.input = new Data();
		individual = ind;
		boolean ignoreInd  = false;
		int indIDX=checkIndPos(state, ind.hashCode());
		double nRepEffective=0.0;

		int nReplications=0;
		if		( MyGPEvaluator.LEVEL_OF_EVALUATION==EvaluationType.SIMPLIFIED )	{	
			nReplications = GlobalParameters.SIMPLIFIED_TRAINING_REPLICATIONS;		
		}
		else																		{	
			nReplications = (MyGPEvaluator.LEVEL_OF_EVALUATION==EvaluationType.SMALL)	?	GlobalParameters.SMALL_TRAINING_REPLICATIONS	:	GlobalParameters.FULL_TRAINING_REPLICATIONS;		
		}

		double[] flexibilityArray		=	{0.25, 0.50, 1.00};
		double[] utilisationArray		= 	{0.85, 0.90, 0.95};
		double[] allowanceArray			=	{1.00, 1.30, 1.50};
		CV=0;

		Utils.initializeExpDistributions(instance, 0.85);  				// object initialization only, values replaced ahead
		PerformanceMetrics totalPerformance = new PerformanceMetrics();
		
		//	dumping the rule being analised
		System.out.println(ind.hashCode());
		ind.printIndividualForHumans(state, 0);

		// Activated if run is to test a given rule
		testLoop(state,instance);

		//double indSize=individual.size();
		for(int i = 0; i < flexibilityArray.length; i++){
			double flexibility=flexibilityArray[i];
			instance.setOpFlexibility(flexibility);
			for(int j = 0; j < utilisationArray.length; j++){
				utilizationLevel=utilisationArray[j];
				//Utils.initializeExpDistributions(instance, utilizationLevel);
				for(int k = 0; k < allowanceArray.length; k++){
					allowanceFactor=allowanceArray[k];
					combination=i*4+j*2+k*1;										// important to compute  normalised values
					for(int n = 0; n < nReplications; n++){
						//Utils.setExpDistributionsSeed(getSeedNumber(state.generation, combination, nReplications, n), CV);
						if (!ignoreInd){
							try {
								PerformanceMetrics performance = new PerformanceMetrics();
								runReplicationGP(instance, performance, nReplications, getSeedNumber(state.generation, combination, nReplications, n));
								outputReplicationData(performance, combination, ind, flexibility, n, indIDX);
								totalPerformance.addMetrics(performance);
								nRepEffective=nRepEffective+1;
								if (performance.getReplicationStatus()){
									ignoreInd=true;									//ignorar regra se for desinteressante
								}	
							} catch (IOException | DeserializationException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					}
				}
			}
		}

		totalPerformance.calculateAverageMetricsByReplication((int) nRepEffective, benchmark);

		KozaFitness f = ((KozaFitness)ind.fitness);
		double sizePenalty= ind.size()*Utils.getIndividualSizePenalty(state.parameters.getInt(new Parameter("generations"),null ,0), state.generation+1);
		f.setStandardizedFitness(state, totalPerformance.getTotalTardinessNormalized()+sizePenalty);	// set for tardiness
		f.hits = 0;
		ind.evaluated = true;

		if(GlobalParameters.VERBOSE){
			String output = String.format(Locale.UK, "%s; %d; %s; %.2f; %.2f; %.2f; %.3f; %.3f;  %.3f; %.3f; %.3f", instance.getName(), instance.getMaxProcessingTime(), dispRule, allowanceFactor, utilizationLevel, CV,
			totalPerformance.getMeanTardiness(), positiveSlack, totalPerformance.getMeanQueueSize(), totalPerformance.getMeanRealQueueSize(), totalPerformance.getRelativePerformanceTardiness());		
			System.out.println(output);
		}

		
		// OUTPUT updates Rules_<i> file
		if(MyGPEvaluator.LEVEL_OF_EVALUATION==EvaluationType.SMALL){
			String fileName= GlobalParameters.OUTPUT_DIR +  "Rules_" + String.valueOf(state.generation+1);
			File rulesFile = new File(fileName);
			// Rules_<gen i>.txt;
			try{
				PrintWriter writer = new PrintWriter(rulesFile);		
				state.population.printPopulation(state, writer);
				writer.close();
			}catch(FileNotFoundException fnfe){
				fnfe.printStackTrace();
			}
		}
	}
	
	
	public void evaluateDepre(final EvolutionState state,
			final Individual ind,
			final int subpopulation,
			final int threadnum)
	{
		//ind.printIndividual(state, 0);
		//Maximo de gera��es
		int maxGen = state.parameters.getInt(new Parameter("generations"),null ,0);

		//Adicionando uma penaliza��o pelo numero de n�s do individuo
		//Fica maior com o passar das gera��es
		
		double fitness = ((GPIndividual)ind).trees[0].child.atDepth()*Utils.getIndividualSizePenalty(maxGen, state.generation+1);

		if(GlobalParameters.CO_EVOLVE){
			fitness += (1 + ((GPIndividual)ind).trees[1].child.atDepth())*Utils.getIndividualSizePenalty(maxGen, state.generation+1);
		}
		//System.out.println("Generation: "+state.generation+", LastFitness: "+lastFitness+", Penalty: "+penalty+", New Fitness: "+fitness);
		this.state = state;
		this.threadnum = threadnum;   
		double performance = 0;

		if (MyGPEvaluator.LEVEL_OF_EVALUATION==EvaluationType.SMALL){

			if(performanceSmall.containsKey((MyGPIndividual)ind)){
				performance = performanceSmall.get(ind);
			}
			else{
				try {
					performance = simulate(DataLoader.instancesTS, ind);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (DeserializationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 		
				performanceSmall.put((MyGPIndividual)ind, performance);
			}
				
		}else if(MyGPEvaluator.LEVEL_OF_EVALUATION==EvaluationType.NORMAL){

			if(performanceNormal.containsKey((MyGPIndividual)ind)){
				performance = performanceNormal.get(ind);
			}
			else{
				try {
					performance = simulate(DataLoader.instancesTS, ind);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (DeserializationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 		
				performanceNormal.put((MyGPIndividual)ind, performance);
			}
		}else{

			if(performanceSimplified.containsKey((MyGPIndividual)ind)){
				performance = performanceSimplified.get(ind);
			}
			else{
				try {
					performance = simulate(DataLoader.instancesSimplifiedTS, ind);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (DeserializationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 		
				performanceSimplified.put((MyGPIndividual)ind, performance);
			}							
		}

		fitness += performance;	
		((KozaFitness)(ind.fitness)).setStandardizedFitness(state, fitness); 		
	}	

	public void setup(EvolutionState state, Parameter base) {
		super.setup(state, base);

		//this.input = new Data();

		// verify that our GPData is of the right class (or subclasses from it)
		//if (!(input instanceof Data))
		//state.output.fatal("GPData class must subclass from " + Data.class, base.push(P_DATA), null);
	}

	public void dumpReplicationData(Job job,int id){
		JsonObject obj = new JsonObject();
		obj.put("arrivalTime",Double.toString(job.getArrivalTime()));
		obj.put("nOperations",job.getRoute().getNumOperations());

		for(int i=0;i<job.getRoute().getNumOperations();i++){
			JsonArray opMachines = new JsonArray();
			JsonArray opTimes = new JsonArray();
			for(Machine m:job.getRoute().getOperations().get(i).getEligibleMachines()){
				opMachines.add(m.getId());
				opTimes.add(String.valueOf(job.getRoute().getOperations().get(i).getTime(m)));
			}
			obj.put("opMachines"+i,opMachines);
			obj.put("opTimes"+i,opTimes);
		}

		try (FileWriter file = new FileWriter("replicationData"+GlobalParameters.EPISODE_CODE+id+".json",true)) {
			file.write(obj.toJson());
			file.write("/");
		} catch (IOException e) {
			System.out.println("Nao foi possivel guardar dados da replicacao");
			e.printStackTrace();
		}
	}

	public void dumpReplicationDataAlt(Job job,int id){
		String output="";

		double arrivalTime=job.getArrivalTime();
		output=String.valueOf(arrivalTime)+";";
		int nOperations=job.getRoute().getNumOperations();
		output=output+nOperations+";";

		for(int i=0;i<job.getRoute().getNumOperations();i++){
			List<Machine> machineList=job.getRoute().getOperations().get(i).getEligibleMachines();
			int nMachines=machineList.size();
			output=output+nMachines+";";

			for(Machine m:job.getRoute().getOperations().get(i).getEligibleMachines()){
				int machineID=m.getId();
				double processingTime=job.getRoute().getOperations().get(i).getTime(m);
				output=output+machineID+";"+String.format("%.2f",processingTime)+";";
			}
		}

		FileWriter fw;
		try {
			fw = new FileWriter("replicationData"+GlobalParameters.EPISODE_CODE+id+".txt", true);
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(output);
			bw.newLine();
			bw.close();
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void readReplicationData(int n) throws FileNotFoundException, DeserializationException{
		Scanner read = new Scanner (new File("replicationData"+GlobalParameters.EPISODE_CODE+n+".json"));

		int controlo=0;
		//JSONParser parser = new JSONParser();
		replicationData.clear();

		while(read.hasNextLine()){
            String str=read.nextLine();
			//System.out.println(str);
            Scanner sc = new Scanner(str);
            sc.useDelimiter("/");
            while (sc.hasNext()){
				//controlo=controlo+1;
				//System.out.println(controlo);
				//System.out.println(sc.next());
				JsonObject json = (JsonObject) Jsoner.deserialize(sc.next());
				//json.get("nOperations");
				replicationData.add(json);
				//System.out.println(json.get("nOperations"));
			}
			sc.close();
		}

		read.close();

	}

	public void readReplicationDataAlt(int n) throws FileNotFoundException, DeserializationException{
		Scanner read = new Scanner (new File("replicationData"+GlobalParameters.EPISODE_CODE+n+".txt"));

		int controlo=0;
		//JSONParser parser = new JSONParser();
		replicationData.clear();

		while(read.hasNextLine()){
            String str=read.nextLine();
			//System.out.println(str);
			replicationDataAlt.add(str);
            
		}
		read.close();
	}
	
	public double getNextArrivalTimeFromRecord(int currentRecord){
		//System.out.println(currentRecord);
		JsonObject obj = replicationData.get(currentRecord);
		double arrivalTime=Double.valueOf((String) obj.get("arrivalTime"));
		return arrivalTime;
	}

	public double getNextArrivalTimeFromRecordAlt(int currentRecord){
		//System.out.println(currentRecord);
		String str = replicationDataAlt.get(currentRecord);
		Scanner sc = new Scanner(str);
        sc.useDelimiter(";");
        double arrivalTime= Double.valueOf(sc.next());
		//System.out.println(String.valueOf(arrivalTime));
		sc.close();
		return arrivalTime;
	}

	public double getDispatchingRuleValue(SimulationStatus status, Order order){

		if(!dispRule.equals("")){ //se corre o GP ele tem um inidivido, uma arvore
			if(dispRule.equals("Hild"))
				return DispatchingRule.getHildebrandtRule(status, order);
			if(dispRule.equals("MWF"))
				return -DispatchingRule.getMostWorkFollowing(order);
			else if(dispRule.equals("SPT"))
				return order.getExpectedTime();					
			else if(dispRule.equals("LPT"))
				return -order.getExpectedTime();
			else if(dispRule.equals("FCFS"))
				return order.getEnteringQueueTime();
			else if(dispRule.equals("LTR"))
				return 	-DispatchingRule.getTailRemaining(order);
			else if(dispRule.equals("MOR"))
				return 	-DispatchingRule.getOperationsRemaining(order);	
			else if(dispRule.equals("LSD"))
				return -DispatchingRule.getSucessiveDifference(order);
			else if(dispRule.equals("Finish"))
				return DispatchingRule.getFinishTime(status, order);
			else if(dispRule.equals("DD"))
				return order.getJob().getDueDate();		
			else if(dispRule.equals("Slack"))
				return DispatchingRule.getSlack(status, order);		
			else if(dispRule.equals("Slack+"))
				return DispatchingRule.getPositiveSlack(status, order);	
			else if(dispRule.equals("SlackO"))
				return DispatchingRule.getSlackO(status, order);	
			else if(dispRule.equals("SlackO+"))
				return DispatchingRule.getPositiveSlackO(status, order);
			else if(dispRule.equals("CR"))
				return DispatchingRule.getCriticalRatioPos(status, order);		
			else if(dispRule.equals("CRSPT"))
				return DispatchingRule.getCriticalRatioPlusSPT(status, order);		
			else if(dispRule.equals("SRPT"))
				return DispatchingRule.getSlackByRPT(status, order);		
			else if(dispRule.equals("RR"))
				return DispatchingRule.getRR(status, order,utilizationLevel);					
			else if(dispRule.equals("WINQ"))
				return DispatchingRule.getWINQ(status, order);	
			else if(dispRule.equals("RANDPTWINQ"))
				return DispatchingRule.getRANDPTWINQ(status, order);			
			else if(dispRule.equals("PTWINQ"))
				return DispatchingRule.getPTWINQ(status, order);			
			else if(dispRule.equals("2PTWINQNPT"))
				return DispatchingRule.get2PTWINQNPT(status, order);		
			else if(dispRule.equals("PTWINQSL"))
				return DispatchingRule.getPTWINQSL(status, order);
			else if(dispRule.equals("PTWINQAT"))
				return DispatchingRule.getPTWINQAT(status, order);			
			else if(dispRule.equals("PTWINQATSL"))
				return DispatchingRule.getPTWINQATSL(status, order);				
			else if(dispRule.equals("PTWINQNPTWSL"))
				return DispatchingRule.getPTWINQNPTWSL(status, order);	
			else if(dispRule.equals("PTWINRR"))
				return DispatchingRule.getPTWinRR(status, order,utilizationLevel);				
			else if(dispRule.equals("2PTWINRR"))
				return DispatchingRule.get2PTWINRR(status, order);		
			else if(dispRule.equals("rpt"))
				return order.getRemainingProcessingTime();	
			else{

				return DispatchingRule.getEvolvedRule(status, order, allowanceFactor, utilizationLevel);
			}
		}else{

			initializeDataInput(status, order);
			
			double slack = DispatchingRule.getSlack(status, order);
			if(slack > 0)
				status.addPositiveSlack();
			else
				status.addNegativeSlack();
					
			if(GlobalParameters.CO_EVOLVE){
				if(slack > 0){
					((GPIndividual)individual).trees[0].child.eval(
							state, threadnum, input, stack, ((GPIndividual)individual),this);						
				}else{
					((GPIndividual)individual).trees[1].child.eval(
							state, threadnum, input, stack, ((GPIndividual)individual),this);		
				}			
			} else{
				((GPIndividual)individual).trees[0].child.eval(
						state, threadnum, input, stack, ((GPIndividual)individual),this);				
			}
	
			return ((Data)input).value;
		}
	}

	public double[] rlOrderScores(SimulationStatus status, Order order){
		double[] resultado= new double[6];
		resultado[0]=DispatchingRule.get2PTWINQNPT(status, order);
		resultado[1]=DispatchingRule.getRR(status, order, utilizationLevel);
		resultado[2]=DispatchingRule.getAnderson1(status, order);
		resultado[3]=DispatchingRule.getAnderson2(status, order);
		resultado[4]=DispatchingRule.getCristiane1(status, order);
		resultado[5]=DispatchingRule.getCristiane2(status, order);
		return resultado;
	}

	public double[] benchmarkVotes(SimulationStatus status,List<Order> queue){
		double[] resultado=new double[6];

		//System.out.println("O tamanho da lista é: " + queue.size());

		for(int i=17;i<=22;i++){
			int action=i-16;
			//int action=i;
			Order nextOrder=null;
			double bestScore=Double.MAX_VALUE;

			for(Order order: queue){				

				//if(!evaluatedOrders.contains(order)){
					//double score = getDispatchingRuleValue(status, order);
					//double score = rand.nextDouble()+1.0;
					double score=getDispatchingRuleValueRL(status, order, action);
					//System.out.println("O score obtido foi:   "+score);
					//System.out.println("Job "+order.getJob().getId()+" "+order.getOperation().getId()+" Score: "+score+ " Proc. Time:"+order.getExpectedTime());	
					
					if((score < bestScore) || (score == bestScore && order.getEnteringQueueTime() < nextOrder.getEnteringQueueTime())) {
						bestScore = score;
						nextOrder = order;
						resultado[i-17]=score;
					}	
										
					//evaluatedOrders.add(order);
				//}
			}
		}

		return resultado;
		
	}

	public Order votingSystemSA(SimulationStatus status,List<Order> queue,double[] votes,Order nextOrder){
		double bestScore=Double.MAX_VALUE;
		//Order nexOrder=null;
		double[] resultado= new double[6];
		double score;
		double[] delta=new double[6];
		
		for(Order order: queue){
			score=0.0;				
			resultado[0]=DispatchingRule.get2PTWINQNPT(status, order);
			resultado[1]=DispatchingRule.getRR(status, order, utilizationLevel);
			resultado[2]=DispatchingRule.getAnderson1(status, order);
			resultado[3]=DispatchingRule.getAnderson2(status, order);
			resultado[4]=DispatchingRule.getCristiane1(status, order);
			resultado[5]=DispatchingRule.getCristiane2(status, order);

			for(int i=0;i<=5;i++){
				if(votes[i]<=0){
					votes[i]=votes[i]+Math.abs(votes[i])+Math.abs(resultado[i]);
					resultado[i]=resultado[i]+Math.abs(votes[i])+Math.abs(resultado[i]);
				}
				delta[i]=Math.min(1.0,(resultado[i]-votes[i])/votes[i]);
				score=score+delta[i];
			}
			
			if((score < bestScore) || (score == bestScore && order.getEnteringQueueTime() < nextOrder.getEnteringQueueTime())) {
				bestScore = score;
				nextOrder = order;
			}	
		}
		return nextOrder;
	}

	public double computeRewardVoting(double[] rlScores, double[] votes,List<Order> queue){
		double resultado=0;
		double[] delta=new double[6];
		
		for(int i=0;i<=5;i++){
			if(votes[i]<=0){
				votes[i]=votes[i]+Math.abs(votes[i])+Math.abs(rlScores[i]);
				rlScores[i]=rlScores[i]+Math.abs(votes[i])+Math.abs(rlScores[i]);
			}
			delta[i]=Math.min(1.0,(rlScores[i]-votes[i])/votes[i]);
			resultado=resultado+delta[i];
		}

		if(GlobalParameters.VERBOSE){
			System.out.println(rlScores[0]+" ; " + rlScores[1]+" ; " + rlScores[2]+" ; "+rlScores[3]+" ; "+rlScores[4]+" ; "+rlScores[5]);
			System.out.println(votes[0]+" ; " + votes[1]+" ; " + votes[2]+" ; "+votes[3]+" ; "+votes[4]+" ; "+votes[5]);
			System.out.println(delta[0]+" ; " + delta[1]+" ; " + delta[2]+" ; "+delta[3]+" ; "+delta[4]+" ; "+delta[5]);
			System.out.println(resultado);

			System.out.println(resultado/(-3)+1);
		}

		resultado=resultado/(-3)+1;

		return resultado;
	}

	
	public double getDispatchingRuleValueGS(SimulationStatus status, Order order, int action, double meanFlexinQueue){
		double resultado = 0.0;
		
		switch(action){
			case 300:				
				resultado=DispatchingRule.getGS46(status, order, instance.getNumMachines(), meanFlexinQueue);
				break;
			default:
				System.out.println("INVALID ACTION, GS dispatching rule is being used");
				resultado=order.getExpectedTime();
		}

		return resultado;
	}
			
	public double getDispatchingRuleValueDyn(SimulationStatus status, Order order, int action, double var1, double var2){
		double resultado = 0.0;
		//18 214  508 507  22    216
		// 14 13 16 42    12 9997
		switch(action){
			case 12:
				resultado = DispatchingRule.getWINQ(status, order);
				break;
			case 13:
				resultado=order.getJob().getDueDate();	
				break;
			case 14:
				resultado=order.getExpectedTime();
				break;
			case 16:
				resultado=DispatchingRule.getCriticalRatioStd(status, order);
				break;
			case 17:
				resultado=DispatchingRule.get2PTWINQNPT(status, order);
				break;
			case 18:
				resultado=DispatchingRule.getRR(status, order, utilizationLevel);
				break;
			case 19:
				resultado=DispatchingRule.getAnderson1(status, order);
				break;
			case 20:
				resultado=DispatchingRule.getAnderson2(status, order);
				break;
			case 21:
				resultado=DispatchingRule.getCristiane1(status, order);
				break;
			case 22:
				resultado=DispatchingRule.getCristiane2(status, order);
				break;
			case 23:
				resultado=DispatchingRule.getATC(status, order,-1.0);
				break;
			case 24:
				resultado=DispatchingRule.getCOVERTb(status, order,-1.0);
				break;
			case 28:
				resultado=DispatchingRule.getSels1(status, order);
				break;
			case 31:
				resultado=DispatchingRule.getSels4(status, order, 0);
				break;
			case 33:
				resultado=DispatchingRule.getSels6(status, order, allowanceFactor);
				break;
			case 42:
				resultado=DispatchingRule.getMOD(status, order, allowanceFactor);
				break;
			case 46:
				resultado=DispatchingRule.getSels19(status,order);
				break;	
			case 47:
				resultado=DispatchingRule.getSels20(status,order);
				break;
			case 213:
				resultado=DispatchingRule.getHunt1(status, order);
				break;
			case 214:
				resultado=DispatchingRule.getHunt2(status, order);
				break;
			case 215:
				resultado=DispatchingRule.getHunt3(status, order);
				break;
			case 216:
				resultado=DispatchingRule.getHunt4(status, order);
				break;
			case 500:
				resultado= DispatchingRule.alvaro1(status, order);
				break;
			case 501:
				resultado= DispatchingRule.alvaro2(status, order);
				break;
			case 502:
				resultado= DispatchingRule.alvaro3(status, order);
				break;
			case 503:
				resultado= DispatchingRule.alvaro4(status, order);
				break;
			case 504:
				resultado= DispatchingRule.alvaro5(status, order);
				break;
			case 505:
				resultado= DispatchingRule.alvaro6(status, order);
				break;
			case 506:
				resultado= DispatchingRule.alvaro7(status, order);
				break;
			case 507:
				resultado= DispatchingRule.alvaro8(status, order);
				break;
			case 508:
				resultado= DispatchingRule.alvaro9(status, order);
				break;
			case 509:
				resultado= DispatchingRule.alvaro10(status, order);
				break;
			case 600:
				resultado = DispatchingRule.shady1(status, order);
				break;
			case 601:
				resultado = DispatchingRule.shady2(status, order);
				break;
			case 602:
				resultado = DispatchingRule.shady3(status, order);
				break;
			case 1000:
				resultado=DispatchingRule.getBestRule(status, order, var1, utilizationLevel);
				break;
			case 1001:
				resultado=DispatchingRule.newThresholdRule(status, order, var1, utilizationLevel);
				break;
			case 1002:
				resultado=DispatchingRule.thresholdRuleEvo(status, order, var1, var2, utilizationLevel);
				break;
			case 9996:
				resultado = - DispatchingRule.getEstimatedTardiness(status, order);
				break;
			case 9997:
				resultado = DispatchingRule.getSlack(status, order);						// NOTA o menor e selecionado
				break;
			case 9998:
				resultado = (status.getTimeInstant() - order.getEnteringQueueTime()) * (-1.0);						// NOTA o menor e selecionado
				break;
			case 9999:
				resultado = order.getJob().getArrivalTime();
				break;		
			
			default:
				System.out.println("INVALID DR CODE" + action + ", base dr in use -> SPT");
				resultado=order.getExpectedTime();
		}

		return resultado;
	}

	public double getDispatchingRuleValueRL(SimulationStatus status, Order order, int action){
		double resultado=0.0;
		double tCur=0.0;
		boolean tardExist=false;

		//action=action+16;

/* 		switch(action){
			case 1:
				action=31;
				break;
			case 2:
				action=18;
				break;
			case 3:
				action=34;
				break;
			case 4:
				action=20;
				break;
			case 5:
				action=33;
				break;
			case 6:
				action=14;
				break;
			default:
				System.out.println("Ação INVALIDA");
				action=31;
		} */


		switch(action){
			case 1:
				tCur=status.getMeanMachineCompletionTime();
				tardExist=status.existTardyJobs(tCur);
				resultado=DispatchingRule.customRule1m(status,order,tardExist,tCur);
				break;
			case 2:
				tCur=status.getMeanMachineCompletionTime();
				tardExist=status.existTardyJobs(tCur);
				resultado=DispatchingRule.customRule2m(status,order,tardExist,tCur);
				break;
			case 3:
				tCur=status.getMeanMachineCompletionTime();
				tardExist=status.existTardyJobs(tCur);
				resultado=DispatchingRule.customRule3m(status,order,tardExist,tCur);
				break;
			case 4:
				tCur=status.getMeanMachineCompletionTime();
				tardExist=status.existTardyJobs(tCur);
				resultado=DispatchingRule.customRule4m(status,order,tardExist,tCur);
				break;
			case 5:
				tCur=status.getMeanMachineCompletionTime();
				tardExist=status.existTardyJobs(tCur);
				resultado=DispatchingRule.customRule5m(status,order,tardExist,tCur);
				break;
			case 6:
				tCur=status.getMeanMachineCompletionTime();
				tardExist=status.existTardyJobs(tCur);
				resultado=DispatchingRule.customRule6m(status,order,tardExist,tCur);
				break;
			case 11:
				//FIFO
				resultado=order.getEnteringQueueTime();
				break;
			case 12:
				//number of operations left
				resultado=order.getJob().getNumOperationsLeft();
				break;
			case 13:
				//earliest due date
				resultado=order.getJob().getDueDate();	
				break;
			case 14:
				//spt
				resultado=order.getExpectedTime();
				break;
			case 15:
				//lpt
				resultado=-order.getExpectedTime();
				break;
			case 16:
				//random
				Random rand = new Random();
				resultado=rand.nextDouble()+1.0;
				break;
			case 17:
				resultado=DispatchingRule.get2PTWINQNPT(status, order);
				break;
			case 18:
				resultado=DispatchingRule.getRR(status, order, utilizationLevel);
				break;
			case 19:
				resultado=DispatchingRule.getAnderson1(status, order);
				break;
			case 20:
				resultado=DispatchingRule.getAnderson2(status, order);
				break;
			case 21:
				resultado=DispatchingRule.getCristiane1(status, order);
				break;
			case 22:
				resultado=DispatchingRule.getCristiane2(status, order);
				break;
			case 23:
				resultado=DispatchingRule.getATC(status, order,-1.0);
				break;
			case 24:
				resultado=DispatchingRule.getCOVERT(status, order, 1.0, 4.0);
				break;
			case 25:
				resultado=DispatchingRule.getFDD(status, order);
				break;
			case 26:
				resultado=DispatchingRule.getPtPlusSlack(status, order);
				break;
			case 27:
				resultado=DispatchingRule.getSlackbyNumberOfOperations(status, order);
				break;
			case 28:
				resultado=DispatchingRule.getSels1(status, order);
				break;
			case 29:
				resultado=DispatchingRule.getSels2(status, order,2);
				break;
			case 30:
				resultado=DispatchingRule.getSels2(status, order,1);
				break;
			case 31:
				resultado=DispatchingRule.getSels4(status,order,0);
				break;
			case 32:
				resultado=DispatchingRule.getSels4(status, order, 1);
				break;
			case 33:
				resultado=DispatchingRule.getSels6(status,order,allowanceFactor);
				break;
			case 34:
				resultado=DispatchingRule.getSels7(status, order, 0);
				break;
			case 35:
				resultado=DispatchingRule.getSels7(status, order, 1);
				break;
			case 36:
				resultado=DispatchingRule.getSels9(status, order);
				break;
			case 37:
				resultado=DispatchingRule.getAVPRO(status, order);
				break;
			case 38:
				resultado=order.getRemainingProcessingTime();
				break;
			case 39:
				resultado=0.0; //sem efeito EDD 13
				break;
			case 40:
				resultado=0.0; //sem efeito Anderson1 19
				break;
			case 41:
				resultado=0.0; //sem efeito SPT 14
				break;
			case 42:
				resultado=DispatchingRule.getMOD(status, order,allowanceFactor);
				break;
			case 43:
				resultado=DispatchingRule.getSels16(status, order);
				break;
			case 44:
				resultado=0.0;  //sem efeito anderson2
				break;
			case 45:
				resultado=DispatchingRule.getSels18(status, order);
				break;
			case 46:
				resultado=DispatchingRule.getSels19(status, order);
				break;
			case 47:
				resultado=DispatchingRule.getSels20(status, order);
				break;
			case 90:
				resultado=DispatchingRule.getSels23(status, order);
				break;
			case 91:
				resultado=DispatchingRule.getSlack(status, order);
				break;
			case 92:
				resultado=DispatchingRule.getSels25(status, order);
				break;
			case 93:
				resultado=DispatchingRule.getOzturk1(status, order);
				break;
			case 94:
				resultado=DispatchingRule.getOzturk2(status, order);
				break;
			case 95:
				resultado=DispatchingRule.getOzturk3(status, order);
				break;
			case 96:
				resultado=DispatchingRule.getOzturk4(status, order);  // NOT IMPLEMENTED  CRODD
				break;
			case 97:
				resultado=DispatchingRule.getOzturk5(status, order);
				break;
			case 98:
				resultado=DispatchingRule.getOzturk6(status, order);
				break;
			case 99:
				resultado=DispatchingRule.getOzturk7(status, order);
				break;
			case 200:
				resultado=DispatchingRule.getOzturk8(status, order);
				break;
			case 50:
				tCur=status.getMeanMachineCompletionTime();
				tardExist=status.existTardyJobs(tCur);
				resultado=DispatchingRule.customRule1(status,order,tardExist,tCur);
				break;
			case 51:
				tCur=status.getMeanMachineCompletionTime();
				tardExist=status.existTardyJobs(tCur);
				resultado=DispatchingRule.customRule2(status,order,tardExist,tCur);
				break;
			case 52:
				tCur=status.getMeanMachineCompletionTime();
				tardExist=status.existTardyJobs(tCur);
				resultado=DispatchingRule.customRule3(status,order,tardExist,tCur);
				break;
			case 53:
				tCur=status.getMeanMachineCompletionTime();
				tardExist=status.existTardyJobs(tCur);
				resultado=DispatchingRule.customRule4(status,order,tardExist,tCur);
				break;
			case 54:
				tCur=status.getMeanMachineCompletionTime();
				tardExist=status.existTardyJobs(tCur);
				resultado=DispatchingRule.customRule5(status,order,tardExist,tCur);
				break;
			case 55:
				tCur=status.getMeanMachineCompletionTime();
				tardExist=status.existTardyJobs(tCur);
				resultado=DispatchingRule.customRule6(status,order,tardExist,tCur);
				break;
			case 56:
				resultado=((double)order.getNumOperationsLeft())*(-1.0);
				break;
			case 57:
				resultado=DispatchingRule.teymourifar1(status, order);
				break;
			case 58:
				resultado=DispatchingRule.teymourifar2(status, order);
				break;
			case 59:
				resultado=DispatchingRule.teymourifar3(status, order);
				break;
			case 60:
				resultado=DispatchingRule.teymourifar4(status, order)*(-1.0);
				break;
			case 62:
				resultado=DispatchingRule.customN1(status, order);
				break;
			case 63:
				resultado=DispatchingRule.customN2(status, order);
				break;
			case 64:
				resultado=DispatchingRule.customN3(status, order);
				break;
			case 65:
				resultado=DispatchingRule.customN4(status, order);
				break;
			case 66:
				resultado=DispatchingRule.ho1(status, order);
				break;
			case 67:
				resultado=DispatchingRule.ho2(status, order);
				break;
			case 68:
				resultado=DispatchingRule.ho3(status, order);
				break;
			case 69:
				resultado=DispatchingRule.ho4(status, order);
				break;
			case 70:
				resultado=DispatchingRule.ho5(status, order);
				break;
			case 80:
				resultado=DispatchingRule.gpRule(status, order);
				break;
			case 100:
				resultado=DispatchingRule.getDFJSSPRule1(status, order);
				break;
			case 101:
				resultado=DispatchingRule.getDFJSSPRule2(status, order,1,1);
				break;	
			case 102:
				resultado=DispatchingRule.getDFJSSPRule2(status, order,1,2);
				break;
			case 103:
				resultado=DispatchingRule.getDFJSSPRule2(status, order,2,2);
				break;
			case 104:
				resultado=DispatchingRule.getDFJSSPRule3(status, order);
				break;
			case 105:
				resultado=DispatchingRule.getDFJSSPRule4(status, order,utilizationLevel);
				break;
			case 106:
				resultado=DispatchingRule.getDFJSSPRule5(status, order,allowanceFactor);
				break;
			case 107:
				resultado=DispatchingRule.getDFJSSPRule6(status, order,allowanceFactor);
				break;
			case 108:
				resultado=DispatchingRule.getDFJSSPRule7(status, order,1.0);
				break;
			case 109:
				resultado=DispatchingRule.getDFJSSPRule7(status, order,2.0);
				break;
			case 110:
				resultado=DispatchingRule.getDFJSSPRule2(status, order,1,3);
				break;
			case 111:
				resultado=DispatchingRule.getDFJSSPRule8(status, order,allowanceFactor);
				break;
			case 112:
				resultado=DispatchingRule.getDFJSSPRule9(status, order,allowanceFactor);
				break;
			case 113:
				resultado=DispatchingRule.getDFJSSPRule10(status, order,allowanceFactor);
				break;
			case 114:
				resultado=DispatchingRule.getDFJSSPRule11(status, order,allowanceFactor);
				break;
			case 115:
				resultado=DispatchingRule.getDFJSSPRule12(status, order, allowanceFactor);
				break;
			case 116:
				resultado=DispatchingRule.getDFJSSPRule13(status, order, utilizationLevel);
				break;
			case 117:
				resultado=DispatchingRule.getDFJSSPRule14(status, order, allowanceFactor);
				break;
			case 118:
				resultado=DispatchingRule.getDFJSSPRule15(status, order);
				break;
			case 119:
				resultado=DispatchingRule.getDFJSSPRule16(status, order, allowanceFactor);
				break;
			case 120:
				resultado=DispatchingRule.getDFJSSPRule17(status, order, allowanceFactor);
				break;
			case 121:
				resultado=DispatchingRule.getDFJSSPRule18(status, order, utilizationLevel);
				break;
			case 122:
				resultado=DispatchingRule.getDFJSSPRule19(status, order, allowanceFactor,utilizationLevel);
				break;
			case 123:
				resultado=DispatchingRule.getDFJSSPRule20(status, order, allowanceFactor);
				break;
			case 124:
				resultado=DispatchingRule.getDFJSSPRule21(status, order);
				break;
			case 125:
				resultado=DispatchingRule.getDFJSSPRule22(status, order);
				break;
			case 126:
				resultado=DispatchingRule.getDFJSSPRule23(status, order);
				break;
			case 127:
				resultado=DispatchingRule.getDFJSSPRule24(status, order);
				break;
			case 128:
				resultado=DispatchingRule.getDFJSSPRule25(status, order);
				break;
			case 129:
				resultado=DispatchingRule.getDFJSSPRule27(status, order, utilizationLevel);
				break;
			case 130:
				resultado=DispatchingRule.getDFJSSPRule28(status, order, utilizationLevel);
				break;
			case 131:
				resultado=DispatchingRule.getDFJSSPRule29(status, order);
				break;
			case 132:
				resultado=DispatchingRule.getDFJSSPRule30(status, order);
				break;
			case 133:
				resultado=DispatchingRule.getDFJSSPRule31(status, order);
				break;
			case 134:
				resultado=DispatchingRule.getDFJSSPRule32(status, order);
				break;
			case 135:
				resultado=DispatchingRule.getDFJSSPRule33(status, order, utilizationLevel);
				break;
			case 136:
				resultado=DispatchingRule.getCOVERT(status, order, -1.0, 4.0);
				break;
			case 137:
				resultado=DispatchingRule.getATC(status, order, 1.0);
				break;
			case 138:
				resultado=DispatchingRule.getDFJSSPRule34(status, order, utilizationLevel,allowanceFactor);
				break;
			case 139:
				resultado=DispatchingRule.getDFJSSPRule35(status, order);
				break;
			case 140:
				resultado=DispatchingRule.getDFJSSPRule36(status, order,allowanceFactor);
				break;
			case 141:
				resultado=DispatchingRule.getDFJSSPRule37(status, order, utilizationLevel);
				break;
			case 142:
				resultado=DispatchingRule.getDFJSSPRule38(status, order);
				break;
			case 143:
				resultado=DispatchingRule.getDFJSSPRule39(status, order);
				break;
			case 144:
				resultado=DispatchingRule.getDFJSSPRule41(status, order);
				break;
			case 145:
				resultado=DispatchingRule.getDFJSSPRule42(status, order);
				break;
			case 146:
				resultado=DispatchingRule.getDFJSSPRule43(status, order);
				break;
			case 147:
				resultado=DispatchingRule.getDFJSSPRule44(status, order,utilizationLevel, instance.getNumMachines());
				break;
			case 148:
				resultado=DispatchingRule.getDFJSSPRule45(status, order, instance.getNumMachines());
				break;
			case 149:
				resultado=DispatchingRule.getDFJSSPRule46(status, order, instance.getNumMachines());
				break;
			case 150:
				resultado=DispatchingRule.getDFJSSPRule47(status, order);
				break;
			case 151:
				resultado=DispatchingRule.getDFJSSPRule48(status,order,utilizationLevel,2,0,0,0,instance.getNumMachines());
				break;
			case 201:
				resultado=DispatchingRule.ho6(status, order);
				break;
			case 202:
				resultado=DispatchingRule.ho7(status, order);
				break;
			case 203:
				resultado=DispatchingRule.ho8(status, order);
				break;
			case 204:
				resultado=DispatchingRule.ho9(status, order);
				break;
			case 205:
				resultado=DispatchingRule.ho10(status, order);
				break;
			case 206:
				resultado=DispatchingRule.ho11(status, order);
				break;
			case 209:
				resultado=DispatchingRule.ho14(status, order);
				break;
			case 210:
				resultado=DispatchingRule.ho15(status, order);
				break;
			case 211:
				resultado=DispatchingRule.getBraune1(status, order);
				break;
			case 212:
				resultado=DispatchingRule.getCOVERTbyOzturk(status, order, 1.0);
				break;
			case 213:
				resultado=DispatchingRule.getHunt1(status, order);
				break;
			case 214:
				resultado=DispatchingRule.getHunt2(status, order);
				break;
			case 215:
				resultado=DispatchingRule.getHunt3(status, order);
				break;
			case 216:
				resultado=DispatchingRule.getHunt4(status, order);
				break;
			case 217:
				resultado=DispatchingRule.getPlaninic1(status, order);
				break;
			case 218:
				resultado=DispatchingRule.getPlaninic2(status, order);
				break;
			case 219:
				resultado=DispatchingRule.getPlaninic3b(status, order, instance.getMachine(order.getOperation().getBestMachine()));
				break;
			case 220:
				resultado=DispatchingRule.getPlaninic4(status, order);
				break;
			case 221:
				resultado=DispatchingRule.getPlaninic5b(status, order, instance.getMachine(order.getOperation().getBestMachine()));
				break;
			case 222:
				resultado=DispatchingRule.zhang1(status, order);
				break;
			case 223:
				resultado=DispatchingRule.zhang2(status, order);
				break;
			case 249:
				resultado=DispatchingRule.getPTWIQ(status, order);
				break;
			case 250:
				resultado = DispatchingRule.gpRuleInt3(status, order,instance.getNumMachines());
				break;
			case 251:
				resultado=DispatchingRule.getPlaninic2b(status, order);
				break;
			case 252:
				resultado=DispatchingRule.getPlaninic1b(status, order);
				break;
			default:
				System.out.println("INVALID ACTION:  " + action);
				resultado=order.getExpectedTime();
		}
		return resultado;
	}



	public String getDispRule() {
		return dispRule;
	}

	public void setDispRule(String dispRule) {
		this.dispRule = dispRule;
	}	

	public void initializeDataInput(SimulationStatus status, Order order){

		((Data)input).setOrder(order);
		((Data)input).status = status;
		((Data)input).instance = this.instance;
		((Data)input).timeInstant = status.getTimeInstant();
		((Data)input).value = 0;
		((Data)input).booleanValue = false;
		((Data)input).utilizationLevel = utilizationLevel;
		((Data)input).allowanceFactor = allowanceFactor;
					
		((Data)input).winQ	 		= 0;
		((Data)input).ptWinRR	 	= 0;
		((Data)input).winRR	 		= 0;
		((Data)input).qs	 		= 0;
		((Data)input).maxPTiQ	 	= 0;
		((Data)input).minPTiQ	 	= 0;
		((Data)input).maxDDiQ	 	= 0;
		((Data)input).minDDiQ	 	= 0;	
		((Data)input).wriQ	 		= 0;
		((Data)input).wor	 		= 0;
		((Data)input).wiQ	 		= 0;
		((Data)input).nqs	 		= 0;
		((Data)input).qpt	 		= 0;
		((Data)input).sRPT	 		= -1;		
		((Data)input).soRPT	 		= -1;	
		((Data)input).crPT	 		= -1;
	}


	public int runReplicationBenchmark(Instance instance, PerformanceMetrics performance, RLagent agent, MultiLayerPerceptron neuralNet,MultiLayerPerceptron targetNet,int numReplication) throws FileNotFoundException, DeserializationException{		
		//System.out.println("A INICIAR REPLICATION");
		int nReplications=0;
		if(GlobalParameters.VERBOSE)
			System.out.println(" =============== INITIALIZING REPLICATION =============== ");

		//System.out.println("Allowance: "+allowanceFactor+" U:"+utilizationLevel+" CV: "+CV+" Rule "+dispRule);

		//readReplicationData(numReplication);
		boolean print_log = false;
		int seedBias = 0;
		switch(GlobalParameters.TESTMODE){
			
			case "train":
				if (print_log) { System.out.println("TRAIN instances will be used"); }
				seedBias = 1000;
				break;
			case "test":
				if (print_log) { System.out.println("TEST instances will be used"); }
				seedBias = 0;
				break;
			case "validation":
				if (print_log) { System.out.println("VALIDATION instances will be used"); }
				seedBias = 100;
				break;
			default :
				//code
				if (print_log) { System.out.println("No test mode was found"); }
				int a = 1000/0;
		}

		int currentRecord=0;
		boolean noRecordsexceeded=false;
		Utils.setDistributionsSeed(numReplication+1+seedBias, 0);
		//InstanceGenerator.initMachinePerformance(instance.getNumMachines());
		//System.out.println("Performance media das maquinas: " + String.valueOf(InstanceGenerator.getMachineMeanPerformance()));	 // DBG	
		//double utilisationAdj=( 1.0-(InstanceGenerator.getMachineMeanPerformance()-1) )*utilizationLevel;
		//System.out.println("Utilizacao ajustada: " + String.valueOf(utilisationAdj));	// DBG
		Utils.initializeExpDistributions(instance, utilizationLevel);
		//Utils.setExpDistributionsSeed(numReplication+1, 0);
		Utils.setDistributionsSeed(numReplication+1+seedBias, 0);

		SimulationStatus status 	= new SimulationStatus(instance);		
		JobFactory factory 			= new JobFactory(instance, allowanceFactor);
		Window window 				= new Window();
		Dqn dqn						= new Dqn();
		
		dqn.setWeights();
		
		NeuralNetClassFlex	nnClass			    = new NeuralNetClassFlex(0);
		NeuralNetRegressor  nnReg				= new NeuralNetRegressor(0);
		
		SvmClassifier svm           			= new SvmClassifier(0);
		SvmRegressor  svmReg 					= new SvmRegressor( 0 );

		QTable        qtable                    = null;
		NeuralNet	  nn                        = null;

		if (GlobalParameters.rtrsTYPE.equals("ql")) {
			qtable                      = new QTable();
			nn			    			= new NeuralNet( 0 );
		}
		else if(GlobalParameters.rtrsTYPE.equals("dql")){
			qtable                      = new QTable(0);
			nn			    			= new NeuralNet(  );
		}		
		
		long startTime = System.nanoTime();
		long estimatedTime = System.nanoTime();

		//Executa as ordens at� que o crit�rio de parada seja satisfeito
		do{	
			if(GlobalParameters.VERBOSE)
				System.out.println("TIME INSTANT: "+status.getTimeInstant()+" Finished Jobs: "+status.getFinishedJobs());
			
			nReplications=nReplications+1;

			long heapMaxSize = Runtime.getRuntime().maxMemory();
			long heapFreeSize = Runtime.getRuntime().freeMemory();
			//System.out.println("heap size: " + formatSize(heapSize));
			double heapFreeSizePerc = ((double) heapFreeSize / heapMaxSize);

			estimatedTime = System.nanoTime() - startTime;

			if(heapFreeSizePerc<0.000008){
				noRecordsexceeded=true;
				System.out.println("Replicacao abortada - low memory");
				System.out.println(String.valueOf(performance.getMaxMeanQueue()));
				System.out.println("heap max size: " + String.valueOf(heapMaxSize));
				System.out.println("heap free size: " + String.valueOf(heapFreeSize));
				System.out.println(String.valueOf(heapFreeSizePerc));
			}

			if(performance.getMaxMeanQueue()>65){
				noRecordsexceeded=true;
				System.out.println("Replicacao abortada - high queue");
			}

			if(estimatedTime>55000000000.0){
				noRecordsexceeded=true;
				System.out.println("Replicacao abortada - high running time");
			}

			//status.dumpQueueTelemetry(instance,numReplication);
			double nextArrivalTime = factory.getNextArrivalTime();
			/* double nextArrivalTime=0.0;
			try{nextArrivalTime=getNextArrivalTimeFromRecord(currentRecord);}
			catch(Exception e){
				System.out.println("Não há mais jobs neste episódio");
				noRecordsexceeded=true;
			} */

			double nextEventExecutionTime = status.getNextOrderExecutionTime();
			double nextPendingOrderTime = status.getNextPedingOrder();

			double sampleU = 0.0;
			double sampleA = 0.0;
			if ( false ) {										// status.ifDisruption()
				sampleU = Utils.getUtilisationDisruption();
				/* if ( status.getNumJobsCumulative() == 1000 ) {					// hard coded, HC
					sampleU = 0.80;												// hard coded, HC
				}
				else{
					sampleU = 0.85;												// hard coded, HC
				} */
				utilizationLevel = sampleU;
				Utils.initializeExpDistributions(instance, sampleU);
				sampleA = Utils.getAllowanceDisruption()  ;
				/* if ( status.getNumJobsCumulative() == 1000 ) {					// hard coded, HC
					sampleA = 3;												// hard coded, HC
				}
				else{
					sampleA = 4;												// hard coded, HC
				} */
				allowanceFactor    = sampleA;
				factory.setAllowanceDisruption(sampleA);
				status.setNextDisruptionTimestep();								// hard coded, HC
				if (GlobalParameters.VERBOSE){
					System.out.println(status.getNumJobsCumulative() + ", " + String.valueOf(sampleU)+ ", " + String.valueOf(sampleA) + ", " + status.getDisruptionTimestep());
				}				
			}

			status.windowLenghtCorrection();

			if (status.ruleUpdateNecessary() == 1) {					// se interval termina, ele atualiza a regra
				
				//window.normalizeWindowMetrics();						// normalizar as metricas
				window.setFinalTardiness(status.getFutureTardinessEstimation(window.getInitialTimestep()) + window.getIntraWindowTardiness());		// jobs que terminaram durante a window
				window.setFinalTimestep(status.getTimeInstant());	
				if ( window.getIDX()==GlobalParameters.WINDOWLIMIT ){		// so vale apena guardar da window em foco window.getIDX()==GlobalParameters.WINDOWLIMIT
					//window.computeRuleEffectivess();						
					window.dumpWindowData(utilizationLevel, allowanceFactor, numReplication+1+1000, status.getNumJobsCumulative(), performance.getFullTardiness());							// WIP dump dos dados da window atual, exceto se for window vazia (-1)
				}
				
				double windowState [] = window.getWindowState();
				double iTiq = window.getMaxTiQ();
				double previousWindowArrivalRate = window.getWindowArrivalRate();			
				window.resetWindow();									// os dados sao apagados

				window.setInitialTardiness(status.getFutureTardinessEstimation(window.getInitialTimestep()));		// o get initial timestep nao esta a fazer nada porque a window foi reset
				window.setInitialTimestep(status.getTimeInstant());
				window.setInitialStates(windowState);
				window.setArrivalRateReference(utilizationLevel, instance.getNumMachines(), instance.getMeanNumberofOperationsperJob() , instance.getMeanOperationProcessingTime() - 0.5);
				window.setPreviousArrivalRate( previousWindowArrivalRate);
				window.setEpisodeArrivalRate( status.getInterArrivalTime());
				double [] utilAllowFeat = status.getUtilisationAllowanceFeatures();
				//window.setWindowInitialRPT(status.getJobShopRPT());						// esta func ja era
				window.windowSetUtilAlloFeatures(utilAllowFeat);
				double [] bottleneckInfo = status.getBottleneckFeatures();
				window.setBootleneckLoad( 	bottleneckInfo[0] );
				window.setBootleneckSlack( 	bottleneckInfo[1] );
				window.setAvgOrderPT( 		bottleneckInfo[3] );
				window.setPosSlack( 		bottleneckInfo[4] );
				window.setCoefVar (         bottleneckInfo[5] );
				window.setMaxTiQ(iTiq);
				
				status.updateRuleForNextWindow(window, nnClass, nnReg, svm, svmReg, windowState, instance.getMaxProcessingTime(), utilAllowFeat);					// se windowLimit ativado, será regra PRESET, otherwise RANDOM ou CLASSIFIER
				//status.readRuleSequence(window, utilizationLevel, allowanceFactor, numReplication);
				
				// System.out.println(Double.valueOf(performance.getFullTardiness()));				
				
				if (status.windowlimitreached()==1){					// para o treino, só interessa analisar até certo ponto
					noRecordsexceeded=true;
				}
			};					

			//Se o proximo evento � uma ordem pronta pra ser executada
			if((nextEventExecutionTime < nextPendingOrderTime) && (nextEventExecutionTime < nextArrivalTime) && (!noRecordsexceeded)){
				
				if(GlobalParameters.VERBOSE)
					System.out.println("Next event: Order execution. Time "+nextEventExecutionTime);

				status.setTimeInstant(nextEventExecutionTime);
				
				//status.dumpQueueTelemetry(instance, numReplication);							// get evolution of the queues over time

				//E executa o proximo evento dessa maquina
				Boolean criticalError = executeEventBenchmark(status, performance, window, qtable, dqn,neuralNet,numReplication, instance.getMaxProcessingTime(), nn);
				if (criticalError){
					noRecordsexceeded=true;
					System.out.println("Replicacao abortada - null order");
				}
				//agent.softPolicyUpdate(neuralNet,targetNet,numReplication);

			}
			//Se o proximo evento � a chegada de um job, cria as ordens para o job
			else if((nextArrivalTime <= nextPendingOrderTime) && (!noRecordsexceeded)){
				
				if(GlobalParameters.VERBOSE)
					System.out.println("Next event: Job arrival. Time "+nextArrivalTime);
				
				window.updateWindowArrivalRate( nextArrivalTime - status.getPreviousJobArrivalTime()  );
				status.updateInterArrivalTime ( nextArrivalTime - status.getPreviousJobArrivalTime()  );
				Job job = factory.getNextJob();
 				//Job job = factory.getNextJobFromRecord(replicationData.get(currentRecord),nextArrivalTime);
				currentRecord=currentRecord+1;

				//dumpReplicationDataAlt(job,numReplication);
				status.setNumJobs(status.getNumJobs()+1);

				if(job != null){
					status.setTimeInstant(nextArrivalTime);
					status.setPreviousJobArrivalTime(nextArrivalTime);

					ActualJob actualJob = new ActualJob(job);		
					Route route = job.getRoute();

					for(Operation operation: route.getTerminalOperations()){
						createArrivalOrders(status, actualJob, operation);					
					}
					
					status.addNumOperations(route.getNumOperations());
					status.setJobCompletionRate(actualJob, actualJob.getNumOperationsLeft());
					
					//dumpDebugDataJobs(actualJob.getId(), actualJob.getNumOperationsLeft(), actualJob.getArrivalTime(), actualJob.getDueDate());
					if(GlobalParameters.VERBOSE)
						System.out.format("* Job %d ArrivalTime: %.1f Due Date: %.1f M%d \n",actualJob.getId(), actualJob.getArrivalTime(), actualJob.getDueDate(), route.getOperations().get(0).getFirstMachine().getId());
						//log_entries=log_entries+1;
						//log_entry.put(String.valueOf(log_entries),"Next event: Job arrival. Time "+nextArrivalTime);
						//logBook.add(log_entry);
				}
			}
			else{
				
				if(GlobalParameters.VERBOSE)
					System.out.println("Next event: Push order to queue. Time "+nextPendingOrderTime);
				if(!noRecordsexceeded){
					//Se o proximo evento � liberar uma ordem que estava pendente				
					status.setTimeInstant(nextPendingOrderTime);	
					//Inclui todas as ordens pendentes
					status.pushOrdersInMachineQueue();
				}
			}
			//System.out.println(status.getFinishedJobs());
			/* 			if(nReplications%2000==0 && nReplications!=0){
				
				System.out.println("Dumping Data");
				try						{agent.dumpData();}
				catch (IOException e) 	{e.printStackTrace();}

				agent.updatePolicy(neuralNet);

			} */

		}while ((status.getFinishedJobs() < maxJobsSimulation) && (!noRecordsexceeded));
		
		if(status.getFinishedJobs() != maxJobsSimulation){
			System.out.println("ERRO. Simulacao encerrou e nao ha mais jobs ("+status.getFinishedJobs()+
					"). Instancia "+instance.getName()+" U: "+utilizationLevel+" a:"+allowanceFactor+" cv: "+CV);
		}

		performance.updateQueueSize(status.getCurrentQueue(instance));

		// try						{agent.dumpData();}
		// catch (IOException e) 	{e.printStackTrace();}

		Random random=new Random();
		double rnd2=random.nextDouble();

		if(false){
			try						{agent.dumpEpisodeData();}
			catch (IOException e) 	{e.printStackTrace();}
		}

		double episodeTardinessTemp=0.0;
		if(noRecordsexceeded)	{episodeTardinessTemp=100000000;}
		else{
			episodeTardinessTemp=status.getEpisodeTotalTardinessStable();
		}
		double utilisationTemp=status.getMachineUtilisationAlt();
		//System.out.println("UTILIZACAO:   "+String.valueOf(utilisationTemp));
		
		positiveSlack += status.getNumberPositiveSlack();
		
		status.finishSimulation();			
		performance.addMeanQueueSize(status.getMeanQueueSize());
		performance.addMeanRealQueueSize(status.getMeanRealQueueSize());
		
		
		performance.calculateMetrics(status.getFinishedJobs());

		dumpEpisodeTelemetry(status, episodeTardinessTemp,utilisationTemp,performance, numReplication, noRecordsexceeded, estimatedTime);
		try						{status.dumpPerformance(episodeTardinessTemp);}
		catch (IOException e) 	{e.printStackTrace();}

		performance.resetMeanQueueSize();
		return status.getFinishedJobs();
	}

	public void dumpEpisodeTelemetry(SimulationStatus status,double tard,double util,PerformanceMetrics performance, int nRep, boolean aborted, long runtime){
		//String episodeTotalTimeStr=String.valueOf(status.getTimeInstant());
		//int totalNumJobs = status.getNumJobsCumulative();
		//System.out.println("Tempo total do episódio:       "+ episodeTotalTimeStr);
		//System.out.println("No total de jobs do episodio:  "+ totalNumJobs);
		//int nOpLiquid=status.episodeJobTelemetry();
		//double[] machUtil=status.getMachineUtilisationAlt2(nOpLiquid);

		String output=GlobalParameters.INSTANCETOTEST + ";" + GlobalParameters.BENCHMARK_RULE + ";" + String.valueOf(instance.getOpFlexibility()) + ";" + String.valueOf(utilizationLevel)+ ";"+ String.valueOf(allowanceFactor) + ";"+ nRep + ";" + String.valueOf(tard) + ";" + String.valueOf(performance.getMeanFlowTime()) + ";" + String.valueOf(performance.getMaxMeanQueue()) + ";" + String.valueOf(runtime) + ";"+ String.valueOf(aborted);
		if (	GlobalParameters.VERBOSE	) 	{	System.out.println(output)			;	}
	
		FileWriter fw;
		try {
			fw = new FileWriter("detailedPerformance " + GlobalParameters.TESTMODE + " i" + GlobalParameters.INSTANCETOTEST + ".txt", true);
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(output);
			bw.newLine();
			bw.close();
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void dumpStateRecord(double util, double allow, double var1, double var2) throws IOException{
		try {
			PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("stateData.txt", true))); //the true will append the new data
			out.println(String.valueOf(util) + ", " + String.valueOf(allow) + ", " + String.valueOf(var1) + ", " + String.valueOf(var2));
			out.close();
		} catch (IOException e) {
			System.out.println(e);
		}

    }

	private int jobShopUnderControlAlt(int maxPT, double maxTiQ, double minSlack, double maxTard){
		int action = GlobalParameters.BENCHMARK_RULE;
		
		if ( (GlobalParameters.BENCHMARK_RULE == 508) ) {

			if        (maxPT < 51) {
				// instance 6
				if (maxTiQ >  7500) {								// HC, hard coded
					action = 9999;
					//System.out.println("control system triggered");
				}
			}
			else if (maxPT < 101) {
				// instance 7
				if (maxTiQ > 14000) {									// HC, hard coded
					action = 9999;
				}
			}
			else if (maxPT < 201) {
				// instance 8
				if (maxTiQ > 28000) {									// HC, hard coded
					action = 9999;
				}
			}
			else{
				// other instances
				if (maxTiQ > 75000) {									// HC, hard coded
					action = 9999;
				}
			}
		}

		//action = 18 ;				// forcar o uso da regra
		
		return action;
	}

	private Boolean executeEventBenchmark(SimulationStatus status, PerformanceMetrics performance, Window window, QTable qtable, Dqn dqn, MultiLayerPerceptron neuralNet, int numReplication, int maxPT, NeuralNet nn){
		List<Order> queue = status.getAvailableOrders();

		Order nextOrder = null;
		double bestScore = Double.MAX_VALUE;
		Boolean criticalError=false;

		// QUEUE ANALYSIS
		String  line = String.valueOf(GlobalParameters.BENCHMARK_RULE) + ", " + String.valueOf(GlobalParameters.INSTANCETOTEST) + ", " + String.valueOf(instance.getNumMachines());
		line = line + ", " + String.valueOf(instance.getMaxProcessingTime()) + ", " + String.valueOf(utilizationLevel) + ", " + String.valueOf(allowanceFactor) + ", " + String.valueOf(numReplication);
				
		// 		queue size
		double wip 					 = 0.0;
		double winq                  = 0.0;
		double meanSlackinQueue 	 = 0.0;
		double meanEstimatedLateness = 0.0;
		double queueRPT				 = 0.0;
		double jobType				 = 0.0;																						// job type, as defined by subramaniam2000
		double meanActualTard		 = 0.0;																						
		double meanEstimatedTard	 = 0.0;
		double meanEstimatedEarliness= 0.0;
		double machinePoolUtil		 = 0.0;
		double orderTimeInQueue		 = 0.0;
		double maxTiQ				 = 0.0;
		double minSlack				 = 0.0;
		double maxEstTard            = 0.0;
		//double meanQueueAllowance  = 0.0;

		for(Order order: queue){
			//wip 	 				= wip 					+ order.getExpectedTime();
			queueRPT 				= queueRPT 				+ order.getRemainingProcessingTime();
			//winq                  = winq                  + DispatchingRule.getWINQ(status, order);
			meanSlackinQueue 		= meanSlackinQueue 		+ DispatchingRule.getSlack(status,order);							// slack (positive or negative)
			meanEstimatedLateness 	= meanEstimatedLateness + DispatchingRule.getEstimatedLateness(status, order);
			//jobType				= jobType 				+ ( order.getNumOperationsLeft() / order.getRemainingProcessingTime() );
			//meanActualTard  		= meanActualTard 		+ DispatchingRule.getActualTardiness(status, order);
			meanEstimatedTard		= meanEstimatedTard		+ DispatchingRule.getEstimatedTardiness(status, order);
			orderTimeInQueue		= status.getTimeInstant() - order.getJob().getArrivalTime();
			maxTiQ                  = Math.max(maxTiQ, orderTimeInQueue);
			window.updateMaxTiQ(orderTimeInQueue);
			minSlack                = Math.min( minSlack, DispatchingRule.getSlack(status,order) ) ;
			maxEstTard              = Math.max( DispatchingRule.getEstimatedTardiness(status, order), maxEstTard ) ;
			//meanEstimatedEarliness  = meanEstimatedEarliness+ DispatchingRule.getEstimatedEarliness(status, order);

			//meanQueueAllowance = meanQueueAllowance + ( order.getJob().getDueDate()-status.getTimeInstant() );

		}
		//meanQueueAllowance = meanQueueAllowance / queue.size() ;
		winq                    = winq                  / (double)queue.size();
		//meanSlackinQueue 		= meanSlackinQueue 		/ (double)queue.size();
		meanEstimatedLateness   = (meanEstimatedLateness/(double)queue.size()) / (queueRPT/(double)queue.size()) ;				// pressure, avg da lateness sobre a avg do RPT
		jobType					= jobType				/(double)queue.size();
		meanActualTard			= meanActualTard		/(double)queue.size();
		meanEstimatedTard		= meanEstimatedTard		/(double)queue.size();
		meanEstimatedEarliness	= meanEstimatedEarliness/(double)queue.size();
		machinePoolUtil			= status.computeMachinePoolUtilisation()/(double)instance.getNumMachines();

		window.accumulateWindowMetricsWithES(meanSlackinQueue, meanEstimatedLateness, (double)queue.size(), meanEstimatedTard, (double)status.getNumAvailableMachines() / (double)instance.getNumMachines(), machinePoolUtil);
		
		if (GlobalParameters.VERBOSE) {
			line = line + ", " + String.valueOf(status.getTimeInstant()) + ", " + String.valueOf( queue.size() )			+ ", " + String.valueOf(wip); 
			line = line + ", " + String.valueOf(meanSlackinQueue) 		 + ", " + String.valueOf(meanEstimatedLateness);
			line = line + ", " + String.valueOf(jobType) 				 + ", " + String.valueOf(meanActualTard) 			+ ", " + String.valueOf(meanEstimatedTard);
			line = line + ", " + String.valueOf(meanEstimatedEarliness)  + ", " + String.valueOf( (double)status.getNumAvailableMachines() / (double)instance.getNumMachines() );
			line = line + ", " + String.valueOf(winq) 					 + ", " + String.valueOf(machinePoolUtil);
			
			dumpDebugDataStateTelemetry(line);
		}

		//GlobalParameters.BENCHMARK_RULE = Dqn.preQf3LR(meanSlackinQueue, meanEstimatedLateness, (double)queue.size(), meanEstimatedTard, machinePoolUtil);
		//GlobalParameters.BENCHMARK_RULE = Dqn.preNN(dqn.getNetwork(), meanSlackinQueue, meanEstimatedLateness, (double)queue.size(), meanEstimatedTard, machinePoolUtil);

		double[] jsState = status.getAgentStatus();
		// state 0  rpt
		// state 1  iTard
		// state 2  posSlack
		// state 3  coefVar machine queues

		// NEURAL NET INPUTS
		// var 0 rpt / pt_avg             state 0 modificado
		// var 1 iTard                    state 1 
		// var 2 coefVar queue load       state 3
		// var 3 avgPosSlack              state 2
		// var 4 earliness                state 4

		// CONFIGURADO PARA EARLINESS
		
		double x3 = (double)status.getNumAvailableMachines() / (double)instance.getNumMachines();
		double x6 = jsState[0] / ( (double)maxPT/2.0  )  ;

		// modo RL
		int action = 508;
		
		if ( GlobalParameters.rtrsTYPE.equals("ql") ){
			action = qtable.getAgentSuggestion(jsState[0], jsState[1], jsState[4], status);
		}
		else if ( GlobalParameters.rtrsTYPE.equals("dql")){
			action = nn.getNNSugestion(jsState[0], jsState[1], jsState[4]);
		}

		// int action = nn.getNNSugestion(jsState[0], jsState[1]);
		GlobalParameters.BENCHMARK_RULE = action;
		action = jobShopUnderControlAlt(maxPT, maxTiQ, minSlack, maxEstTard);
		//int action = GlobalParameters.WINDOWRULE ;

		//action = 508;

		for(Order order: queue){		
				double score = getDispatchingRuleValueDyn(status, order, action, meanEstimatedLateness, meanEstimatedTard);		// queueData is for threshold tests
								
				if((score < bestScore) || (score == bestScore && order.getEnteringQueueTime() < nextOrder.getEnteringQueueTime())) {
					bestScore = score;
					nextOrder = order;
				}										
		}

		if(nextOrder == null){
			System.out.println("Time instant = "+status.getTimeInstant()+" Ordem nula, Queue: "+queue.size());
			criticalError=true;
		}
		else{
			//dumpDebugDataEvents(nextOrder.getJob().getId(), nextOrder.getOperation().getId(), nextOrder.getMachine().getId(), status.getTimeInstant(), nextOrder.getExpectedTime(), nextOrder.getOperation().getPrecedent());
			if(GlobalParameters.VERBOSE)
				System.out.println("⚠⚠ Chosen Order: Job "+nextOrder.getJob().getId()+" "+nextOrder.getOperation().getId()+" Score: "+bestScore+ " Proc. Time:"+nextOrder.getExpectedTime());
			
			//Dumping telemetria dos jobs
			//String output=String.valueOf(status.getTimeInstant()+";"+nextOrder.getJob().getId()+";"+nextOrder.getOperation().getId()+";"+nextOrder.getMachine().getId()+";"+String.valueOf(nextOrder.getExpectedTime()));
						
			/* try {
				FileWriter fw;
				fw = new FileWriter("jobTelemetryData.txt", true);
				BufferedWriter bw = new BufferedWriter(fw);
				bw.write(output);
				bw.newLine();
				bw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} */

			//Execute order
			//Remover as ordens para a mesma opera��o que foram disparadas para fila de outras maquinas
			window.incrementPreviousWindowsWorks(nextOrder);
			status.decrementMachineWorkInQueue( nextOrder.getMachine(), nextOrder.getExpectedTime() );
			status.removeOrder(nextOrder);
			executeOrder(status, nextOrder, window, performance,null);			
		}
		
		return criticalError;
	}

	public int runReplicationCustom(Instance instance, PerformanceMetrics performance, RLagentCustom agent, MultiLayerPerceptron neuralNet,MultiLayerPerceptron targetNet,int numReplication) throws IOException{		
		System.out.println("A INICIAR REPLICATION");
		int nReplications=0;
		if(GlobalParameters.VERBOSE)
			System.out.println(" =============== INITIALIZING REPLICATION =============== ");

		//System.out.println("Allowance: "+allowanceFactor+" U:"+utilizationLevel+" CV: "+CV+" Rule "+dispRule);
		SimulationStatus status 	= new SimulationStatus(instance);		
		JobFactory factory 			= new JobFactory(instance, allowanceFactor);
		

		//Executa as ordens at� que o crit�rio de parada seja satisfeito
		do{	
			if(GlobalParameters.VERBOSE)
				System.out.println("TIME INSTANT: "+status.getTimeInstant()+" Finished Jobs: "+status.getFinishedJobs());
			
				nReplications=nReplications+1;

			double nextArrivalTime = factory.getNextArrivalTime();
			double nextEventExecutionTime = status.getNextOrderExecutionTime();
			double nextPendingOrderTime = status.getNextPedingOrder();

			//Se o proximo evento � uma ordem pronta pra ser executada
			if((nextEventExecutionTime < nextPendingOrderTime) && (nextEventExecutionTime < nextArrivalTime)){
				
				if(GlobalParameters.VERBOSE)
					System.out.println("Next event: Order execution. Time "+nextEventExecutionTime);

				status.setTimeInstant(nextEventExecutionTime);				

				//E executa o proximo evento dessa maquina
				executeEventCustom(status, performance,agent,neuralNet,numReplication);
				
				agent.softPolicyUpdate(neuralNet,targetNet,numReplication);

			}
			//Se o proximo evento � a chegada de um job, cria as ordens para o job
			else if(nextArrivalTime <= nextPendingOrderTime){
				
				if(GlobalParameters.VERBOSE)
					System.out.println("Next event: Job arrival. Time "+nextArrivalTime);
				
				Job job = factory.getNextJob();
				status.setNumJobs(status.getNumJobs()+1);

				if(job != null){
					status.setTimeInstant(nextArrivalTime);

					ActualJob actualJob = new ActualJob(job);		
					Route route = job.getRoute();

					for(Operation operation: route.getTerminalOperations()){
						createArrivalOrders(status, actualJob, operation);					
					}
					
					status.addNumOperations(route.getNumOperations());
					status.setJobCompletionRate(actualJob, actualJob.getNumOperationsLeft());
					if(GlobalParameters.VERBOSE)
						System.out.format("* Job %d ArrivalTime: %.1f Due Date: %.1f M%d \n",actualJob.getId(), actualJob.getArrivalTime(), actualJob.getDueDate(), route.getOperations().get(0).getFirstMachine().getId());
						//log_entries=log_entries+1;
						//log_entry.put(String.valueOf(log_entries),"Next event: Job arrival. Time "+nextArrivalTime);
						//logBook.add(log_entry);
				}
			}
			else{
				
				if(GlobalParameters.VERBOSE)
					System.out.println("Next event: Push order to queue. Time "+nextPendingOrderTime);
				
				//Se o proximo evento � liberar uma ordem que estava pendente				
				status.setTimeInstant(nextPendingOrderTime);	
				//Inclui todas as ordens pendentes
				status.pushOrdersInMachineQueue();
			}
/* 			if(nReplications%2000==0 && nReplications!=0){
				
				System.out.println("Dumping Data");
				try						{agent.dumpData();}
				catch (IOException e) 	{e.printStackTrace();}

				agent.updatePolicy(neuralNet);

			} */
		}while (status.getFinishedJobs() < maxJobsSimulation);
		
		if(status.getFinishedJobs() != maxJobsSimulation){
			System.out.println("ERRO. Simulacao encerrou e nao ha mais jobs ("+status.getFinishedJobs()+
					"). Instancia "+instance.getName()+" U: "+utilizationLevel+" a:"+allowanceFactor+" cv: "+CV);
		}

		Random random=new Random();
		double rnd2=random.nextDouble();

		if(rnd2<0.001){
			try						{agent.dumpEpisodeData(neuralNet);}
			catch (IOException e) 	{e.printStackTrace();}
		}

		double episodeTardinessTemp=status.getEpisodeTotalTardinessStable();

		try						{status.dumpPerformance(episodeTardinessTemp);}
		catch (IOException e) 	{e.printStackTrace();}

		if(episodeTardinessTemp<=bestTardiness){
			agent.dumpWeights(neuralNet, "online");
			agent.dumpWeights(targetNet, "target");
			bestTardiness=episodeTardinessTemp;
		}
		
		positiveSlack += status.getNumberPositiveSlack();
		
		status.finishSimulation();			
		performance.addMeanQueueSize(status.getMeanQueueSize());
		performance.addMeanRealQueueSize(status.getMeanRealQueueSize());
		
		performance.calculateMetrics(status.getFinishedJobs());
		return status.getFinishedJobs();


	}

	private void executeEventCustom(SimulationStatus status, PerformanceMetrics performance, RLagentCustom agent, MultiLayerPerceptron neuralNet, int numReplication){
		Random rand = new Random();
		List<Order> queue = status.getAvailableOrders();

		Order nextOrder = null;
		double bestScore = Double.MAX_VALUE;
		//List<Order> evaluatedOrders = new ArrayList<Order>();
		//select the next order according to the dispatching rule

		//Descrição do estado
		ObservationCustom obs=new ObservationCustom(status.getTimeInstant());		
		double[] statetemp=status.getStatusCustom();
		double remainingWorkperMachine=statetemp[0]/instance.getNumMachines();
		double slackperMachine=statetemp[1]/instance.getNumMachines();
		obs.setWorkInfo(remainingWorkperMachine);
		obs.setAllowanceInfo(slackperMachine);
		agent.addObservation(obs);
		agent.setPreviousObservation(obs);
		obs.setIteration(numReplication);
		
		//Definir a ação
		boolean takeRandomAction=takeRandomAction(numReplication);

		agent.computeReward();
		double[] actionFeatures={0.0,0.0,0.0,0.0,0.0,0.0};

		for(Order order: queue){				

			//if(!evaluatedOrders.contains(order)){
				//double score = getDispatchingRuleValue(status, order);
				//double score = rand.nextDouble()+1.0;
				double score=0.0;
				if(!takeRandomAction){
					actionFeatures=discretizeAction(status, order);
					score=getDispatchingRuleValueCustom(status, order, neuralNet,remainingWorkperMachine,slackperMachine,actionFeatures)*(-1);
				}
				else{
					actionFeatures=discretizeAction(status, order);
					score=rand.nextDouble();
				}
				//System.out.println("O score obtido foi:   "+score);
				//System.out.println("Job "+order.getJob().getId()+" "+order.getOperation().getId()+" Score: "+score+ " Proc. Time:"+order.getExpectedTime());	
				
				if((score < bestScore) || (score == bestScore && order.getEnteringQueueTime() < nextOrder.getEnteringQueueTime())) {
					bestScore = score;
					nextOrder = order;
					obs.setAction(actionFeatures[0],actionFeatures[1], actionFeatures[2], actionFeatures[3], actionFeatures[4], actionFeatures[5]);
				}	

				//evaluatedOrders.add(order);
			//}
		}

		if(nextOrder == null){
			System.out.println("Time instant = "+status.getTimeInstant()+" Ordem nula, Queue: "+queue.size());
		}
		else{

			if(GlobalParameters.VERBOSE)
				System.out.println("⚠⚠ Chosen Order: Job "+nextOrder.getJob().getId()+" "+nextOrder.getOperation().getId()+" Score: "+bestScore+ " Proc. Time:"+nextOrder.getExpectedTime());
							
			//Execute order
			//Remover as ordens para a mesma opera��o que foram disparadas para fila de outras maquinas
			status.removeOrder(nextOrder);
			executeOrderCustom(status, nextOrder, performance,agent);			
		}			
	}

	private void executeOrderCustom(SimulationStatus status, Order order, PerformanceMetrics performance, RLagentCustom agent){

		ActualJob actualJob = order.getJob();
		Route route = order.getRoute();		
		Operation operation = order.getOperation();
		double startTime = status.getTimeInstant();

		double actualOperationTime = order.getExpectedTime();		
		if(CV > 0){
			actualOperationTime = Utils.getOperationTimeSample(actualOperationTime, CV);
		}		
		double finishTime = startTime + actualOperationTime;

		if(GlobalParameters.VERBOSE){
			//			System.out.format("\n JOB %d (op %d) Time [Exp: %d - Act: %d] Mode: %s (%d - %d) MinTime: %d DueDate: %d", 
			//					actualJob.getId(), operation.getId(),
			//					(int) order.getExpectedTime(), (int)actualOperationTime, mode.toString(), 
			//					(int)startTime, (int)finishTime,
			//					(int) order.getMinExecutionTime(), 
			//					(int) order.getJob().getDueDate());	
			System.out.format("\n-- JOB%d (op %d) Time: %.1f (%.1f - %.1f),  NumOpLeft %d M%d", 
					actualJob.getId(), operation.getId(),
					order.getExpectedTime(), startTime, finishTime, actualJob.getNumOperationsLeft(), order.getMachine().getId());				
			System.out.println();
		}

		status.setJobCompletionRate(actualJob, actualJob.getNumOperationsLeft()-1);
		status.setJobCompletionTime(actualJob, finishTime);

		//actualJob.initializeRouteExecution(route);
		//Se é a primeira operação da rota,
		//Definindo a rota do job e corrigindo o tempo de processamento faltante
		//Tambem remove-se as ordens referentes a outras rotas para o job,
		//Uma vez a rota "route" foi escolhida
		if(actualJob.getRoute() == null){
			actualJob.initializeRouteExecution(route);
			//if(actualJob.getRoutes().size() > 1){
				//status.removeOrdersFromDifferentRoutes(route);
			//}				
		}			

		operation.setActualOperationTime(actualOperationTime);

		//É na instrução seguinte que o número de operações left é descontado
		actualJob.addActualOperation(operation);

		//Atualizando informa��es para a execu��o da pr�xima ordem nesta maquina
		Machine machine = order.getMachine();
		status.setAvailability(machine, finishTime);
		
		status.setUtilisation(machine, actualOperationTime);
		status.setCompletionTime(machine, finishTime);

		Operation nextOperation = operation.getSucessor();
		if(nextOperation != null){
			createOrders(status, actualJob, nextOperation, finishTime);			
		}

		if(actualJob.getNumOperationsLeft() == 0){
			status.setNumJobs(status.getNumJobs()-1);
			//status.addFinishedJobs();
			
			//Se o simulador est� considerando chegadas dinamicas, a performance s� � contabilizada a partir de 
			//um certo numero de jobs
			if((actualJob.getId() > GlobalParameters.MIN_JOBS_STEADY_STATE) &&
					(actualJob.getId() <= GlobalParameters.MIN_JOBS_STEADY_STATE + maxJobsSimulation)){
				performance.updatePerformanceMetrics(status.getFinishedJobs(),actualJob.getArrivalTime(), actualJob.getDueDate(), finishTime);
				status.addFinishedJobs();		
			}				
		}
	}

	public double getDispatchingRuleValueCustom(SimulationStatus status, Order order, MultiLayerPerceptron neuralNet, double workInfo, double slackInfo, double[] actionFeatures){
				
		//Cálculo do Q value
		neuralNet.setInput(workInfo,slackInfo,actionFeatures[0],actionFeatures[1],actionFeatures[2],actionFeatures[3],actionFeatures[4],actionFeatures[5]);
        neuralNet.calculate();
        double[] networkOutputOne = new double[]{neuralNet.getOutput()[0]};
            
		double resultado=networkOutputOne[0];

		//System.out.println(String.valueOf(workInfo)+"; "+String.valueOf(slackInfo)+"; "+String.valueOf(actionFeatures[0])+"; "+String.valueOf(actionFeatures[1])+"; "+String.valueOf(actionFeatures[2])+"; "+String.valueOf(actionFeatures[3])+"; "+String.valueOf(actionFeatures[4])+"; "+String.valueOf(actionFeatures[5])+"; "+String.valueOf(resultado));

		return resultado;

	}

	public double[] discretizeAction(SimulationStatus status,Order order){
		//As actions são as diferentes operacoes
		// - caracteristicas relacionadas com processing time
		double processingTime=order.getExpectedTime();
		double nextProcessingTime=0.0;
		if(order.getOperation().getSucessor()!=null){
			nextProcessingTime=order.getOperation().getSucessor().getAverageExpectedTime();
		}
		double remainingProcessingTime=order.getRemainingProcessingTime();

		// - caracteristicas relacionadas com due date
		double allowance =order.getJob().getDueDate() - status.getTimeInstant();
		double slack=DispatchingRule.getSlack(status, order);

		// - caracteristicas relacionadas com queue
		double winq=DispatchingRule.getWINQ(status, order);

		double[] resultado={processingTime,nextProcessingTime,remainingProcessingTime,allowance,slack,winq};

		return resultado;
	}

}


