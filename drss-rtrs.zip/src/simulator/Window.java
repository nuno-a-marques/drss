package simulator;

// IMPORT LIST
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import main.GlobalParameters;

public class Window {
    
    // CLASS VARIABLES
    private int windowIDX;
    private int numUpdates;
    private int rule;
    private double var1;            // var          meanSlackinQueue
    private double var2;            // var          meanestLateness
    private double var3;            // var          queueSize
    private double var4;            // var          meanEstTardiness
    private double var5;            // var          machineUtilization
    private double var6;            // var          machineUtilisation
    private double var10;           // var          rpt
    private double var11;           // var          bottleneckLoad
    private double var12;           // var          bottleneckSlack
    private double var13;
    private double initialTiQ;
    private double initialTardiness;    //var9      expectedTardiness
    private double finalTardiness;
    private double initialTimestep;
    private double finalTimestep;
    private double intraWindowTardiness;
    private double [] previousState;
    private double exponentialSmoothingFactor;
    private double arrivalRateReference;
    private double previousArrivalRate;
    private double windowArrivalRate;   //var7      windowArrivalRate
    private double episodeArrivalRate;  //var8      cumulativeArrivalRate
    private double previousWindowsWorks;
    private double avgOrderPT;
    private double posSlack;
    private double coefVar;
    private double nJobs_i;
    private double wip_i;
    private double rpt_i;
    private double tpt_i;
    private double allo_i;
    private double slk_i;
    private double etard_i;
    private double earl_i;
    private double lat_i;

    public Window(){
        
        // ASSIGN VALUES TO VARIABLES
        windowIDX   = -1;
        numUpdates  =  0;
        rule        = -1;
        var1 = 0.0;
        var2 = 0.0;
        var3 = 0.0;
        var4 = 0.0;
        var5 = 0.0;
        var6 = 0.0;
        var10 = 0.0;
        var11 = 0.0;
        var12 = 0.0;
        var13 = 0.0;
        initialTardiness = -1.0;
        avgOrderPT       = -1.0;
        finalTardiness   = -1.0;
        initialTimestep  = -1.0;
        finalTimestep    = -1.0;
        intraWindowTardiness    = 0.0;
        previousState           = new double[6];
        exponentialSmoothingFactor = 0.80;
        arrivalRateReference    = -1.0;
        windowArrivalRate       = 0.0;
        episodeArrivalRate      = 0.0;
        previousWindowsWorks    = 0.0;
        posSlack                = -1.0;
        coefVar                 = 0.0;

        nJobs_i         = 0.0 ;
        wip_i           = 0.0 ;
        rpt_i           = 0.0 ;
        tpt_i           = 0.0 ;

        allo_i          = 0.0 ;
        slk_i           = 0.0 ;
        etard_i         = 0.0 ;
        earl_i          = 0.0 ;
        lat_i           = 0.0 ;
    }

    // method to accumulate values
    public void accumulateWindowMetrics(double nVar1, double nVar2, double nVar3, double nVar4, double nVar5, double nVar6){
        numUpdates=numUpdates+1;
        var1 = var1 + nVar1;
        var2 = var2 + nVar2;
        var3 = var3 + nVar3;
        var4 = var4 + nVar4;
        var5 = var5 + nVar5;
        var6 = var6 + nVar6;
    }

    public void accumulateWindowMetricsWithES(double nVar1, double nVar2, double nVar3, double nVar4, double nVar5, double nVar6){
        if (numUpdates==0) {
            var1 = nVar1;
            var2 = nVar2;
            var3 = nVar3;
            var4 = nVar4;
            var5 = nVar5;
            var6 = nVar6;
        }
        else {            
            var1 = var1 * exponentialSmoothingFactor + (1-exponentialSmoothingFactor) * nVar1;
            var2 = var2 * exponentialSmoothingFactor + (1-exponentialSmoothingFactor) * nVar2;
            var3 = var3 * exponentialSmoothingFactor + (1-exponentialSmoothingFactor) * nVar3;
            var4 = var4 * exponentialSmoothingFactor + (1-exponentialSmoothingFactor) * nVar4;
            var5 = var5 * exponentialSmoothingFactor + (1-exponentialSmoothingFactor) * nVar5;
            var6 = var6 * exponentialSmoothingFactor + (1-exponentialSmoothingFactor) * nVar6;
        }

        numUpdates=numUpdates+1;
    }

    // method to normalize values
    public void normalizeWindowMetrics(){
        if (numUpdates!= 0) {
            var1 = var1 / numUpdates;
            var2 = var2 / numUpdates;
            var3 = var3 / numUpdates;
            var4 = var4 / numUpdates;
            var5 = var5 / numUpdates;
            var6 = var6 / numUpdates;
        }
    }

    public double[] getWindowState(){
        double out [] = {var1, var2, var3, var4, var5, var6};
        return out;
    }

    // method to dump values
    public void dumpWindowData(double utilData, double allowData, int seedNumber, int jid, double ftard){
        // os dados tem de estar normalizados antes
        if (windowIDX >= 0){

            String out = rule + ", " + GlobalParameters.INSTANCETOTEST + ", " + String.valueOf(utilData) + ", "+ String.valueOf(allowData) + ", " + seedNumber + ", " + windowIDX;
            out = out + ", " + String.valueOf(initialTimestep) + ", " + String.valueOf(finalTimestep);
            out = out + ", " + String.valueOf(initialTardiness) + ", " + String.valueOf(finalTardiness);
            out = out + ", " + String.valueOf(previousState[0]) + ", " + String.valueOf(previousState[1]) + ", " + String.valueOf(previousState[2]) + ", " + String.valueOf(previousState[3]) + ", " + String.valueOf(previousState[4]) + ", " + String.valueOf(previousState[5]);
            out = out + ", " + String.valueOf(previousArrivalRate) + ", " + String.valueOf(episodeArrivalRate) + " , " + String.valueOf(initialTardiness) + " , " + String.valueOf( var10 ) + " , " + String.valueOf( var11 ) + " , " + String.valueOf( var12 );
            out = out + ", " + String.valueOf(initialTiQ)  + ", " + String.valueOf(avgOrderPT) + ", " + String.valueOf(posSlack) + ", " + String.valueOf(coefVar) + ", " + String.valueOf(ftard) ;
            out = out + ", " + (int) nJobs_i  + ", " + String.valueOf(wip_i) + ", " + String.valueOf(rpt_i) + ", " + String.valueOf(tpt_i);
            out = out + ", " + String.valueOf(allo_i) + ", " + String.valueOf(slk_i)  + ", " + String.valueOf(etard_i) + ", " + String.valueOf(earl_i)  + ", " + String.valueOf(lat_i);
            
            FileWriter fw;
            try {
                fw = new FileWriter("window  " + GlobalParameters.WINDOWINTERVAL + " instance  " + GlobalParameters.INSTANCETOTEST + ".txt", true);
                BufferedWriter bw = new BufferedWriter(fw);
                bw.write(out);
                bw.newLine();
                bw.close();
                fw.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        
    }

    // method to reset values
    public void resetWindow(){
        windowIDX   = -1;
        numUpdates  =  0;
        rule        = -1;
        var1 = 0.0;
        var2 = 0.0;
        var3 = 0.0;
        var4 = 0.0;
        var5 = 0.0;
        var6 = 0.0;
        var10 = 0.0;
        var11 = 0.0;
        var12 = 0.0;
        var13 = 0.0;
        initialTiQ = 0.0;
        initialTardiness = -1.0;
        finalTardiness   = -1.0;
        initialTimestep  = -1.0;
        finalTimestep    = -1.0;
        intraWindowTardiness = 0.0;
        arrivalRateReference = -1.0;
        windowArrivalRate    = 0.0;
        previousWindowsWorks = 0.0;
    }
    
    // get and set

    public int getIDX(){
        return windowIDX;
    }

    public void setIDX(int index){
        windowIDX = index;
    }

    public void setRule(int code){
        rule = code;
    }

    public int getRule(){
        return rule;
    }

    public void setInitialTardiness(double val){
        initialTardiness = val;
    }

    public double getInitialTardiness(){
        return initialTardiness;
    }

    public void setFinalTardiness(double val){
        finalTardiness = val;
    }

    public void setFinalTimestep(double val){
        finalTimestep = val;
    }

    public void setInitialTimestep(double val){
        initialTimestep = val;
    }

    public double getFinalTimestep(){
        return finalTimestep;
    }

    public double getInitialTimestep(){
        return initialTimestep;
    }

    public void setInitialStates(double[] val){
        previousState[0]=val[0];
        previousState[1]=val[1];
        previousState[2]=val[2];
        previousState[3]=val[3];
        previousState[4]=val[4];
        previousState[5]=val[5];
    }

    public void windowSetUtilAlloFeatures( double [] val){
        nJobs_i         = val[0] ;
        wip_i           = val[1] ;
        rpt_i           = val[2] ;
        tpt_i           = val[3] ;

        allo_i          = val[4] ;
        slk_i           = val[5] ;
        etard_i         = val[6] ;
        earl_i          = val[8] ;
        lat_i           = val[7] ;
    }

    public void updateIntraWindowTardiness(double val){
        intraWindowTardiness = intraWindowTardiness + val;
    }

    public double getIntraWindowTardiness(){
        return intraWindowTardiness;
    }

    public void setArrivalRateReference( double util, int nmacs, double avgNumOps, double avgPT){
        // utilisation, nmacs, avg number of ops, avg pt
        arrivalRateReference = (util * (double)nmacs) / ( avgNumOps * avgPT);
    }

    public double getArrivalRateReference(){
        return arrivalRateReference;
    }

    public void setPreviousArrivalRate(double val){
        previousArrivalRate = val;
    }

    public double getPreviousArrivalRate(){
        return previousArrivalRate;
    }

    public void updateWindowArrivalRate(double val){
        windowArrivalRate = windowArrivalRate + val;
        //System.out.println( "ARRIVAL : " + String.valueOf(val) );
    }

    public double getWindowArrivalRate(){
        return windowArrivalRate / (double)GlobalParameters.WINDOWINTERVAL;
    }

    public void setEpisodeArrivalRate(double val){
        episodeArrivalRate = val;
    }

    public double getEpisodeArrivalRate(){
        return episodeArrivalRate;
    }

    public void setWindowInitialRPT(double val){
        var10 = val;
    }

    public double getWindowInitialRPT(){
        return var10;
    }

    public void setBootleneckLoad(double val){
        var11 = val;
    }

    public void setBootleneckSlack(double val){
        var12 = val;
    }

    public void setMaxTiQ(double val){
        initialTiQ = val;
    }

    public double getInitialTiQ(){
        return initialTiQ;
    }

    public double getBootleneckSlack(){
        return var12;
    }

    public double getBottleneckLoad(){
        return var11;
    }

    public double getMaxTiQ(){
        return var13;
    }

    public void updateMaxTiQ(double val){
        var13 = Math.max(var13, val);
    }

    public void setAvgOrderPT ( double val) {
        avgOrderPT = val;
    }

    public double getAvgOrderPT ( ) {
        return avgOrderPT;
    }

    public void setPosSlack(double val){
        posSlack = val;
    }

    public void setCoefVar(double val){
        coefVar  = val;
    }

    public double getPosSlack(double val){
        return posSlack;
    }

    public void incrementPreviousWindowsWorks(Order order){
        if (order.getJob().getArrivalTime() < initialTimestep){
            previousWindowsWorks = previousWindowsWorks + order.getExpectedTime();
        }
    }

    public void computeRuleEffectivess(){
        double effectiveness = -1.0;
        if (var10 != 0){
            effectiveness = previousWindowsWorks/var10;
        }
        else{
            effectiveness   =  1.0;
        }

        System.out.println(windowIDX + ", " + String.valueOf(effectiveness));
    }



}
