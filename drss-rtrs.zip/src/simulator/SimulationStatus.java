package simulator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.lang.model.util.ElementScanner6;

//import org.jdesktop.swingx.plaf.windows.WindowsTaskPaneUI;

import DT.DecisionTree;
import RF.RandomForest;
import RFregressor.RandomForestRegressor;
import SVM.SvmClassifier;
import SVM.SvmRegressor;
import input.Instance;
import input.Machine;
import input.Operation;
//import input.Route;
//import input.Job;
import main.GlobalParameters;
import nn.NeuralNetClassFlex;
import nn.NeuralNetClassifier;
import nn.NeuralNetClassifier71;
import nn.NeuralNetRegressor;
//import smile.math.Math;
import utils.Utils;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import java.io.*;

public class SimulationStatus {
	
	private double timeInstant;
	private int finishedJobs;
	private int numJobs;
	private int numJobsCumulative;
	private int numOperations;
	private int finishedOperations;

	int lastWindowUpdate;
	int disruptionTimeStep;

	double meanQueueSize;
	double meanRealQueueSize;
	double machinePoolUtilisation;
	double machinePoolOpTime;
	double jsWIP;
	double avgInterArrivalTime;
	double previousJobArrivalTime;
	
	private int positiveSlack;
	private int negativeSlack;	

	/**
	* Order queue list for each machine
 	*/
	Map<Machine, List<Order>> machinesQueue;
	Map<Machine, Double> machinesUtilisation;
	Map<Machine, Double> machinesWorkInQueue;
	Map<Machine, Double> machinesCompletionTime;
	Map<Machine, Double> machineEfficiency;
	Map<ActualJob, Integer> jobCompletionRate;
	Map<ActualJob, Double> jobCompletionTime;

	/*
	* Next time each machine will be available for other events
	*/
	double[] machinesAvailability;
	int numAvailableMachines;
	/*
	* Keeps the current number of orders scheduled to machine
	*/
	int[] machineSequence;	
	List<Order> pendingOrders;		
	
	public SimulationStatus(Instance instance){
		
		timeInstant = 0.0;
		finishedJobs = 0;
		numJobs = 0;
		numJobsCumulative=0;
		pendingOrders 		= new ArrayList<Order>();
		positiveSlack   = 0;
		negativeSlack	= 0;
		
		machinesQueue 				= new HashMap<Machine, List<Order>>();
		machinesUtilisation 		= new HashMap<Machine, Double>();
		machinesWorkInQueue 		= new HashMap<Machine, Double>();
		machinesCompletionTime		= new HashMap<Machine, Double>();
		machineEfficiency			= new HashMap<Machine, Double>();
		machineSequence 			= new int[instance.getNumMachines()];
		machinesAvailability 		= new double[instance.getNumMachines()];
		numAvailableMachines		= 0;

		machinePoolUtilisation		= 0.0 ;
		machinePoolOpTime			= 0.0 ;
		jsWIP						= 0.0 ;
		avgInterArrivalTime			= 0.0 ;
		
		jobCompletionRate 		= new HashMap<ActualJob, Integer>();
		jobCompletionTime 		= new HashMap<ActualJob, Double>();

		lastWindowUpdate   = -1;
		disruptionTimeStep = -1;
		previousJobArrivalTime = 0 ;
		
		for(Machine machine: instance.getMachines())
		{					
			machinesQueue.put(machine, new ArrayList<Order>());
			machinesUtilisation.put(machine, 0.0);
			machinesCompletionTime.put(machine, 0.0);
			machinesWorkInQueue.put(machine, 0.0);
			machinesAvailability[machine.getId()-1] = 0.0;
			machineSequence[machine.getId()-1] = 0;
			machineEfficiency.put(machine,Utils.getRandomNumber(0.0, 1.5));
		}					
		
		meanQueueSize = 0.0;
		meanRealQueueSize = 0.0;
	}
	
	public int getFinishedJobs() {
		return finishedJobs;
	}

	public void setFinishedJobs(int finishedJobs) {
		this.finishedJobs = finishedJobs;
	}
	
	public void addFinishedJobs() {
		this.finishedJobs++;
		//System.out.println(this.finishedJobs);
	}	
	
	public void addPositiveSlack() {
		this.positiveSlack++;
	}
	
	public void addNegativeSlack() {
		this.negativeSlack++;
	}
	
	public double getNumberPositiveSlack() {
		return ((double)positiveSlack)/(double)(positiveSlack + negativeSlack);
	}
	
	public double getNumberNegativeSlack() {
		return ((double)negativeSlack)/(double)(positiveSlack + negativeSlack);
	}	
	
	public double getTimeInstant() {
		return timeInstant;
	}

	public int getNumJobs() {
		return numJobs;
	}

	public void setNumJobs(int numJobs) {
		if(numJobs>this.numJobs){
			this.numJobsCumulative=this.numJobsCumulative+1;
			//System.out.println(this.numJobsCumulative);
		}	
		this.numJobs = numJobs;	
	}

	public int getNumJobsCumulative(){
		return numJobsCumulative;
	}

	public int getNumOperations() {
		return numOperations;
	}

	public void addNumOperations(int numOperations) {
		this.numOperations = this.numOperations+numOperations;
	}

	public int getFinishedOperations() {
		return finishedOperations;
	}

	public void addFinishedOperation() {
		this.finishedOperations = this.finishedOperations+1;
	}
	
	public void setTimeInstant(double timeInstant) {
		//System.out.println("Set time instant: "+timeInstant);
		this.timeInstant = timeInstant;
	}		
	
	public int getNumPendingOrders() {
		return pendingOrders.size();
	}
	
	public void setPreviousJobArrivalTime( double val) {
		previousJobArrivalTime = val;
	}

	public double getPreviousJobArrivalTime () {
		return previousJobArrivalTime;
	}

	public List<Order> getQueue(Machine machine) {
		return machinesQueue.get(machine);
	}
	public void setQueue(Machine machine, List<Order> orders){
		machinesQueue.put(machine, orders); 
	}

	public double getMachineEfficiency(Machine machine){
		return machineEfficiency.get(machine);
	}

	public Double getUtilisation(Machine machine) {
		return machinesUtilisation.get(machine);
	}

	public Double getMachinePoolUtilisation() {
		return machinePoolUtilisation;
	}

	public Double computeMachinePoolUtilisation() {
		if (machinePoolOpTime==0){
			return 0.0;
		}
		else{
			return machinePoolUtilisation/machinePoolOpTime;				// falta dividir pelo numero de maquinas
		}
	}

	public void setUtilisation(Machine machine, Double utilisation){
		machinePoolUtilisation = machinePoolUtilisation + utilisation;
		machinesUtilisation.put(machine, getUtilisation(machine)+utilisation); 
	}

	public void incrementMachineWorkInQueue(Machine machine, double processTime){
		double temp = machinesWorkInQueue.get(machine);
		machinesWorkInQueue.put(machine, temp+processTime);
		jsWIP = jsWIP + processTime;
	}

	public void decrementMachineWorkInQueue(Machine machine, double processTime){
		double temp = machinesWorkInQueue.get(machine);
		machinesWorkInQueue.put(machine, temp-processTime);
		jsWIP = jsWIP - processTime;
	}

	public double getMachineWorkInQueue(Machine machine){
		return machinesWorkInQueue.get(machine);
	}

	public double getJsWIP(){
		return jsWIP;
	}

	public Double getCompletionTime(Machine machine) {
		return machinesCompletionTime.get(machine);
	}

	public Double getMachinePoolOpTime(Machine machine) {
		return machinePoolOpTime;
	}

	public void setCompletionTime(Machine machine, Double CompletionTime){
		machinePoolOpTime = Math.max(CompletionTime, machinePoolOpTime);
		machinesCompletionTime.put(machine, CompletionTime); 
	}
	
	public double getAvailability(Machine machine){
		
		return  machinesAvailability[machine.getId()-1];
	}
	
	public int getNumAvailableMachines(){
		return numAvailableMachines;
	}
	
	public int getQueueSize(Machine machine){
		
		return getQueue(machine).size();
	}
	
	public void setJobCompletionRate(ActualJob job,int numOperationsTemp){
		jobCompletionRate.put(job,numOperationsTemp); 
	}
	
	public int getJobCompletionRate(ActualJob job){
		return  jobCompletionRate.get(job);
	}

	public void setJobCompletionTime(ActualJob job,Double time){
		jobCompletionTime.put(job,time); 
	}
	
	public double getJobCompletionTime(ActualJob job){
		return  jobCompletionTime.get(job);
	}

	public boolean keyExistsCT(ActualJob job){
		return jobCompletionTime.containsKey(job);
	}
	
	public int getSequence(Machine machine) {
		
		return machineSequence[machine.getId()-1];
	}	
	
	public void setAvailability(Machine machine, double time)
	{
		machinesAvailability[machine.getId()-1] = time;
	}

	public void updateInterArrivalTime(double val) {
		avgInterArrivalTime = avgInterArrivalTime + val;
	}

	public double getInterArrivalTime() {
		if (numJobsCumulative==0){ return 0.0;                                            }
		else 					 { return avgInterArrivalTime/ (double)numJobsCumulative; }
	}
	
	public void pushOrdersInMachineQueue()
	{			
		List<Order> pendingOrdersAux = new ArrayList<Order>();
		pendingOrdersAux.addAll(pendingOrders);
		
		for(Order order: pendingOrdersAux){
			
			if(order.getMinExecutionTime() <= timeInstant){		// se o job ja acabou de ser processado entretanto

				pushOrderInMachineQueue(order);
				pendingOrders.remove(order);
			}
		}
	}	
	
	public void pushOrderInMachineQueue(Order order){
		
		Machine machine = order.getMachine();
			
		machinesQueue.get(machine).add(order);
		order.setEnteringQueueTime(timeInstant);
							
		order.setSequence(machineSequence[machine.getId()-1]);
		machineSequence[machine.getId()-1]++;		
		
		if(GlobalParameters.VERBOSE)
			System.out.println("Adding op "+order.getOperation().getId()+" to machine "+machine.getId()+". Queue "+getQueue(machine).size());			
	}
	
	public void addPendingOrderToQueue(Order order){
		pendingOrders.add(order);
	}
	
	public void removeOrder(Order order){
						
		Operation operation = order.getOperation();
			
		for(Machine machine: operation.getEligibleMachines())
		{
			List<Order> machineQueue = new ArrayList<Order>();
			machineQueue.addAll(getQueue(machine));
			for(Order orderToRemove: machineQueue){
				if(orderToRemove.getOperation().equals(operation)){
					machinesQueue.get(machine).remove(orderToRemove);	
				}
			}
			machineQueue.clear();
		}				
	}
	
	public void removeOrder(Order order,Machine mac){
		machinesQueue.get(mac).remove(order);			
	}
	
	public double getNextMachineAvailableTime()
	{	
		double nextInstant = Double.MAX_VALUE;		
		for(Machine machine: machinesQueue.keySet()){
					
			double	time =  machinesAvailability[machine.getId()-1];				
			if(time < nextInstant){	
				nextInstant = time;
			}			
		}	
		return nextInstant;
	}

	public Machine getNextMachineAvailableMachine(int currentMachineID, double currentOperationTime)
	{	
		Machine nextMachine=null;
		double nextInstant = Double.MAX_VALUE;		
		for(Machine machine: machinesQueue.keySet()){
					
			double	time =  0.0;
			if (machine.getId()==currentMachineID){
				time = machinesAvailability[machine.getId()-1]+currentOperationTime;
			}
			else{
				time =  machinesAvailability[machine.getId()-1];
			}				
			if(time < nextInstant){
				nextInstant=time;
				nextMachine=machine;	
			}			
		}	
		return nextMachine;
	}
	
	public double getNextPedingOrder()
	{	
		double nextOrderInstant = Double.MAX_VALUE;		
		for(Order order: pendingOrders){
					
			double	time =  order.getMinExecutionTime();				
			if(time < nextOrderInstant){	
				nextOrderInstant = time;
			}			
		}	
		return nextOrderInstant;
	}	
	

	public List<Order> getAvailableOrders(){
		int contador = 0;
		List<Order> queueList = new ArrayList<Order>();
		
		for(Machine machine: machinesQueue.keySet()){
			
			double av = machinesAvailability[machine.getId()-1];
			if(av <= timeInstant){
				contador = contador + 1;
				List<Order> machineQueue = getQueue(machine);
				for(Order order: machineQueue){											
					queueList.add(order);						
				}
			}
		}		
		
		numAvailableMachines = contador;
		return queueList;		
	}

	public double getFutureTardinessEstimation(double ti){
		double estTard = 0.0;		
		
		for(Machine machine: machinesQueue.keySet()){					// tardiness de jobs que estao nas queues			
			List<Order> machineQueue = getQueue(machine);
			for(Order order: machineQueue){
				estTard = estTard + ( Math.max( timeInstant + order.getRemainingProcessingTime() - order.getJob().getDueDate(), 0.0 ) - Math.max( ti + order.getRemainingProcessingTime() - order.getJob().getDueDate(), 0.0 ) );													
			}
		}
		
		for (Order order2: pendingOrders){								// tardiness dos jobs que estao em processamento
			estTard = estTard + ( Math.max( timeInstant + order2.getRemainingProcessingTime() - order2.getJob().getDueDate(), 0.0 ) - Math.max( ti + order2.getRemainingProcessingTime() - order2.getJob().getDueDate(), 0.0 ) );
		}

		return estTard;
	}

	public double getJobShopRPT(){
		double jsWip = 0.0;
		int    nJobs = 0  ;
		double jsRpt = 0.0;
			
		for(Machine machine: machinesQueue.keySet()){					// metricas dos jobs nas queues			
			List<Order> machineQueue = getQueue(machine);
			for(Order order: machineQueue){
				jsWip = jsWip + order.getExpectedTime()         	;
				jsRpt = jsRpt + order.getRemainingProcessingTime()	;
				nJobs = nJobs + 1;																
			}
		}
		
		for (Order order2: pendingOrders){								// metricas dos jobs em processamento
			jsWip = jsWip + order2.getExpectedTime()	         ;
			jsRpt = jsRpt + order2.getRemainingProcessingTime()	 ;
			nJobs = nJobs + 1;
		}

		return jsWip;
	}

	public double [] getUtilisationAllowanceFeatures(){
		double [] outputFeatureArray = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 } ;

		double jsWip     = 0.0;
		int    nJobs     = 0  ;
		double jsRpt     = 0.0;
		//double workNQ    = 0.0;
		double totalPTs  = 0.0;
		double estTard   = 0.0;
		double slk       = 0.0;
		double allo      = 0.0;
		double lat       = 0.0;
		double earl      = 0.0;
			
		for(Machine machine: machinesQueue.keySet()){					// metricas dos jobs nas queues			
			List<Order> machineQueue = getQueue(machine);
			for(Order order: machineQueue){
				jsWip    = jsWip + order.getExpectedTime()         	;
				jsRpt    = jsRpt + order.getRemainingProcessingTime()	;
				nJobs    = nJobs + 1;
				totalPTs = totalPTs + order.getJob().getAvgProcessingTime();

				estTard  = estTard + ( Math.max( timeInstant + order.getRemainingProcessingTime() - order.getJob().getDueDate(), 0.0 ) );
				slk      = slk	   + ( order.getJob().getDueDate() - (timeInstant + order.getRemainingProcessingTime()) );
				allo     = allo    + ( order.getJob().getDueDate() - timeInstant);
				lat      = lat     + ( timeInstant + order.getRemainingProcessingTime() - order.getJob().getDueDate() );
				earl     = earl    + Math.max( order.getJob().getDueDate() - (timeInstant + order.getRemainingProcessingTime()), 0.0 );
			}
		}
		
		for (Order order2: pendingOrders){								// metricas dos jobs em processamento
			jsWip = jsWip + order2.getExpectedTime()	         ;
			jsRpt = jsRpt + order2.getRemainingProcessingTime()	 ;
			nJobs = nJobs + 1;
			totalPTs = totalPTs + order2.getJob().getAvgProcessingTime();

			estTard = estTard + ( Math.max( timeInstant + order2.getRemainingProcessingTime() - order2.getJob().getDueDate(), 0.0 ) );
			slk     = slk	  + ( order2.getJob().getDueDate() - (timeInstant + order2.getRemainingProcessingTime()) );
			allo    = allo    + ( order2.getJob().getDueDate() - timeInstant);
			lat     = lat     + ( timeInstant + order2.getRemainingProcessingTime() - order2.getJob().getDueDate() );
			earl    = earl    + Math.max( order2.getJob().getDueDate() - (timeInstant + order2.getRemainingProcessingTime()), 0.0 );
		}

		// output
		// wip, nJobs, rpt  ;  allowance, slack, estTard, estLateness, estEarliness
		outputFeatureArray[0] =    (double) nJobs;
		outputFeatureArray[1] =    jsWip;
		outputFeatureArray[2] =    jsRpt;
		outputFeatureArray[3] =    totalPTs;
		outputFeatureArray[4] =    allo;
		outputFeatureArray[5] =    slk;
		outputFeatureArray[6] =    estTard;
		outputFeatureArray[7] =    lat;
		outputFeatureArray[8] =    earl;
		return outputFeatureArray;
	}

	public double[] getAgentStatus(){
		double jsrpt 	= 0.0;
		double estTard 	= 0.0;
		double temp4    = 0.0;
		int contador    = 0;
		double loadbyMachine[] = {0.0, 0.0, 0.0, 0.0, 0.0,   0.0, 0.0, 0.0, 0.0, 0.0 ,   0.0, 0.0, 0.0, 0.0, 0.0,  0.0, 0.0, 0.0, 0.0, 0.0  ,   0.0, 0.0, 0.0, 0.0, 0.0,  0.0, 0.0, 0.0, 0.0, 0.0};			// HC Hard Coded
		double tempLoad = 0.0;
		int nMac 		= 0 ;
		double covVal 	= 0.0;
		double earl      = 0.0;
		
		double out [] 	= {0.0, 0.0, 0.0, 0.0, 0.0};
		// 0 rpt
		// 1 iTard
		// 2 pos_slk
		// 3 coefVar queueLoad
		// 4 earliness

		// CONFIGURADO PARA EARLINESS
		
		for(Machine machine: machinesQueue.keySet()){					// rpt dos jobs nas queues			
			List<Order> machineQueue = getQueue(machine);
			tempLoad 	= 0.0;
			nMac 		= nMac + 1;
			for(Order order: machineQueue){
				contador = contador + 1 ;

				jsrpt   = jsrpt + order.getExpectedTime()	;
				estTard = estTard + ( Math.max( timeInstant + order.getRemainingProcessingTime() - order.getJob().getDueDate(), 0.0 ) );
				//slk     = slk + ( order.getJob().getDueDate() - timeInstant - order.getRemainingProcessingTime() );
				temp4   = temp4 + Math.max( order.getJob().getDueDate() - (timeInstant + order.getRemainingProcessingTime()), 0.0 );															
				tempLoad = tempLoad + order.getExpectedTime()	;
				earl     = earl    + Math.max( order.getJob().getDueDate() - (timeInstant + order.getRemainingProcessingTime()), 0.0 );
			}
			loadbyMachine[machine.getId() - 1 ] = tempLoad;
		}

		covVal	= computeCV(loadbyMachine, jsrpt / (double)nMac, nMac);
		
		for (Order order2: pendingOrders){								// rpt nos jobs em processamento
			contador = contador + 1 ;

			jsrpt    = jsrpt + order2.getExpectedTime()	     ;
			estTard  = estTard + ( Math.max( timeInstant + order2.getRemainingProcessingTime() - order2.getJob().getDueDate(), 0.0 ) );
			//slk     = slk + ( order2.getJob().getDueDate() - timeInstant - order2.getRemainingProcessingTime() );
			temp4    = temp4 + Math.max( order2.getJob().getDueDate() - (timeInstant + order2.getRemainingProcessingTime()), 0.0 );
			earl     = earl    + Math.max( order2.getJob().getDueDate() - (timeInstant + order2.getRemainingProcessingTime()), 0.0 );		
		}
		if (contador > 0) {
			temp4 = temp4/(double)contador;
		}
		out[0] = jsrpt;
		out[1] = estTard;
		out[2] = temp4;
		out[3] = covVal;
		out[4] = earl;	

		return out;
	}

	public double computeCV(double[] loadValues, double avg_load_val, int nMac){
		double out 	= 0.0;
		double temp = 0.0;
		
		for (int i = 0; i < nMac; i++) {
			temp = temp + (loadValues[i] - avg_load_val) * (loadValues[i] - avg_load_val) ;
		}
		temp = temp / (double)nMac;
		temp = Math.sqrt(temp);					// stdev

		if (avg_load_val > 0) {
			out = temp / avg_load_val;
		}
		else {
			out = 0.0;
		}
		
		//cv = sdev / avg
		// sdev = sqrt [  SUM (obs - avg) / nObs ]
		return out;
	}

	public double[] getBottleneckFeatures() {
		double maxWorkload = 0.0;
		double minSlack	   = Double.MAX_VALUE;
		double maxTiQ = 0.0;	// 2 tiq
		double temp   = 0.0;	// 0 rpt
		double temp2  = 0.0;	// 1 slack
		double temp3  = 0.0;	// 3 avg_rpt
		double temp4  = 0.0;	// 4 slack if possible
		double covVal = 0.0;	// 5 coef de var		
		double out [] =  {0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
		double loadbyMachine[] = {0.0, 0.0, 0.0, 0.0, 0.0,   0.0, 0.0, 0.0, 0.0, 0.0 ,   0.0, 0.0, 0.0, 0.0, 0.0,  0.0, 0.0, 0.0, 0.0, 0.0  ,   0.0, 0.0, 0.0, 0.0, 0.0,  0.0, 0.0, 0.0, 0.0, 0.0};			// HC Hard Coded
		int contador           = 0;
		double loadTotal       = 0.0;
		
		int nMac = 0;	
		
		for(Machine machine: machinesQueue.keySet()){					// jobs nas queues das maquinas
			temp  = 0.0;
			temp2 = 0.0;
			nMac = nMac +1;

			List<Order> machineQueue = getQueue(machine);
			for(Order order: machineQueue){
				temp  = temp + order.getExpectedTime()	;
				contador = contador + 1;
				temp2 = temp2 + ( order.getJob().getDueDate() - (timeInstant + order.getRemainingProcessingTime()) );
				temp4 = temp4 + Math.max( order.getJob().getDueDate() - (timeInstant + order.getRemainingProcessingTime()), 0.0 );
				maxTiQ = Math.max( maxTiQ , timeInstant - order.getEnteringQueueTime() );
			}

			loadbyMachine[machine.getId() - 1]  = temp ;
			loadTotal                       = loadTotal + temp;
			

			if (temp  > maxWorkload               ) {maxWorkload = temp ;   }
			if (temp2 < minSlack   && temp2 != 0.0) {minSlack    = temp2;   }
			temp3 = temp3 + temp;
		}

		covVal	= computeCV(loadbyMachine, loadTotal / (double)nMac, nMac);

		out[0] = maxWorkload ;
		if (minSlack != Double.MAX_VALUE) {
			out[1] = minSlack    ;
		}
		else 	{ out[1] = 0.0; }
		out[2] = maxTiQ;
		
		if (contador > 0) {
			out[3] = temp3 / (double)contador;
			out[4] = temp4 / (double)contador; 
		}
		else{
			out[3] = 0.0;
			out[4] = 0.0;
		}
		
		out[5] = covVal;
		
		return out ;
	}
	
	public List<Order> getAvailableOrdersInAllMachines(){
		
		List<Order> queueList = new ArrayList<Order>();
		
		for(Machine machine: machinesQueue.keySet()){
			List<Order> machineQueue = getQueue(machine);
			for(Order order: machineQueue){											
				queueList.add(order);
			}						
		}		
		
		//queueSizes.add(queueList.size());
		
		return queueList;		
	}
	
	public double getNextOrderExecutionTime(){
		double nextInstant = Double.MAX_VALUE;		
		for(Machine machine: machinesQueue.keySet()){
			
			List<Order> machineQueue = machinesQueue.get(machine);
			if(machineQueue.size() > 0){
				
				double minOrderAvailability =  machinesAvailability[machine.getId()-1];
				double	time =  Math.max(timeInstant, minOrderAvailability);	
				
				if(time < nextInstant){	
					nextInstant = time;
				}							
			}
		}	
		return nextInstant;
	}

	
	
	public boolean ordersToBeProcessed(){
		
		for(Machine machine: machinesQueue.keySet()){
			if(machinesQueue.get(machine).size() > 0)
				return true;
		}		
		return false;
	}
	
	public void finishSimulation(){

		machinesQueue.clear();
		pendingOrders.clear();	
	}
	
	public double getMeanQueueSize(){
		return meanQueueSize;
	}	
	
	public double getMeanRealQueueSize(){
		return meanRealQueueSize;
	}

	public int episodeJobTelemetry(){
		double jobTotalProcessingTime=0.0;
		double numOperationsCum=0.0;
		//int episodeTotalNumberofLeftOperations=0;
		double episodeRemainingProcessingTime=0.0;
		double remainingNumOpTemp=0.0;
		for(ActualJob job: jobCompletionRate.keySet()){
			try{
				//System.out.println("Pára aí");
				jobTotalProcessingTime=jobTotalProcessingTime+job.getRoute().getTotalProcessingTime();
				//episodeTotalNumberofLeftOperations=episodeTotalNumberofLeftOperations+Job.getNumOperationsLeft();
				episodeRemainingProcessingTime=episodeRemainingProcessingTime+job.getRemainingProcessingTime();
				numOperationsCum=numOperationsCum+job.getNumOperationsBestCase();
				remainingNumOpTemp=remainingNumOpTemp+job.getNumOperationsLeft();
			}
			catch(Exception e){
				//System.out.println("Informação do job não disponível");
			}
			
		}
		/* System.out.println("Tempo de processamento total:            "+ String.valueOf(jobTotalProcessingTime));
		System.out.println("Processamento em falta (seg):"+episodeRemainingProcessingTime);
		System.out.println("Número total de operacoes por processar:"+remainingNumOpTemp);
		System.out.println("Número total de operacoes:"+numOperationsCum); */

		return (int) ((int) numOperationsCum-(int)remainingNumOpTemp);
	}

	public void dumpQueueTelemetry(Instance instance, int idxRep){
		double[] resultado= new double[]{0,0,0,0,0,0,0,0,0,0};								// HC HARD CODED
		int idx=0;
		for(Machine machine: machinesQueue.keySet()){
			idx=machine.getId();
			List<Order> machineQueue = machinesQueue.get(machine);
			//if(machineQueue.size() > 0){}
			resultado[idx-1]=machineQueue.size();
		}

		FileWriter fw;
		try {
			fw = new FileWriter("queueTelemetry_"+idxRep+".txt", true);
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(String.valueOf(timeInstant)+";"+resultado[0]+";"+resultado[1]+";"+resultado[2]+";"+resultado[3]+";"+resultado[4]+";"+resultado[5]+";"+resultado[6]+";"+resultado[7]+";"+resultado[8]+";"+resultado[9]);
			bw.newLine();
			bw.close();
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
	}

	public double getCurrentQueue(Instance instance){
		double[] resultado= new double[instance.getNumMachines()];
		int idx=0;
		double sum=0.0;
		for(Machine machine: machinesQueue.keySet()){
			idx=machine.getId();
			List<Order> machineQueue = machinesQueue.get(machine);
			//if(machineQueue.size() > 0){}
			resultado[idx-1]=machineQueue.size();
			sum=sum+resultado[idx-1];
		}
		
		return sum/(double)instance.getNumMachines();   //HARD CODED
	}
	
	public double getMeanMachineCompletionTime(){
		double resultado=0.0;
		int contador=0;
		
		for(Machine machine: machinesCompletionTime.keySet()){					
			if(getCompletionTime(machine)!=null){
				resultado=resultado+getCompletionTime(machine);
				contador=contador+1;
			}		
		}

		if(contador!=0){resultado=resultado/contador;}

		return resultado;
	}
	
	public double[] getMachineUtilisation(){
		double machineUtilisationTemp;
		double machinesCompletionTimeTemp;

		double[] aux=new double[100];

		double sum = 0.0, standardDeviation = 0.0;
        int length = 0;

		for (Machine key : machinesUtilisation.keySet()) {
			machineUtilisationTemp=machinesUtilisation.get(key);
			machinesCompletionTimeTemp=machinesCompletionTime.get(key);
			if(machinesCompletionTimeTemp!=0){
				sum = sum+machineUtilisationTemp/machinesCompletionTimeTemp;
				aux[length]=machineUtilisationTemp/machinesCompletionTimeTemp;
			}
			else{aux[length]=0;}
			
			length=length+1;
		}

		double mean = sum/length;

		int i;
		for(i = 0; i < length; i++){
			standardDeviation += Math.pow(aux[i] - mean, 2);
        }
		
		standardDeviation=standardDeviation/length;
		standardDeviation=Math.sqrt(standardDeviation);
		double[] resultado = new double[] {mean, standardDeviation};
        return resultado;
	}

	public double getMachineUtilisationAlt(){
		double machineUtilisationTemp;
		double machinesCompletionTimeTemp;

		double sum = 0.0;
		double resultado=0.0;

		for (Machine key : machinesUtilisation.keySet()) {
			machineUtilisationTemp=machinesUtilisation.get(key);
			machinesCompletionTimeTemp=machinesCompletionTime.get(key);
			if(machinesCompletionTimeTemp>timeInstant){
				sum = sum+machineUtilisationTemp-(machinesCompletionTimeTemp-timeInstant);
			}
			else{
				sum = sum+machineUtilisationTemp;
			}
		}

		resultado=sum/(timeInstant*((double) machinesUtilisation.size()));
		return resultado;
	}

	public double[] getMachineUtilisationAlt2(int nOpLiquid){
		double machineUtilisationTemp;
		double machinesCompletionTimeTemp;

		double sum = 0.0;
		double[] resultado= new double[]{0,0};

		for (Machine key : machinesUtilisation.keySet()) {
			machineUtilisationTemp=machinesUtilisation.get(key);
			machinesCompletionTimeTemp=machinesCompletionTime.get(key);
			if(machinesCompletionTimeTemp>timeInstant){
				sum = sum+machineUtilisationTemp-(machinesCompletionTimeTemp-timeInstant);
			}
			else{
				sum = sum+machineUtilisationTemp;
			}
		}

		resultado[0]=sum;
		resultado[1]=resultado[0]/nOpLiquid;
		//System.out.println("Tempo de processamento das Máquinas:       "+String.valueOf(resultado[0]));
		//System.out.println("Tempo de processamento medio real:       "+String.valueOf(resultado[1]));
		return resultado;
	}

	public boolean existTardyJobs(double tCur){
		boolean resultado=false;

		for (ActualJob key : jobCompletionRate.keySet()) {
			if(key.getDueDate()<tCur){
				resultado=true;
				break;
			}
		}

		return resultado;
	}

	public double[] operationsStatus(){
		double uncompleteOperations=0.0;
		int length=0;
		double crj=0.0;
		double aux[]=new double[100000];

		for (ActualJob key : jobCompletionRate.keySet()) {
			
			length=length+1;
			double crji=0.0;

			//Route routeTemp=key.getRoute();
			double jobTotalNumberOperations=key.getNumOperationsWorstCase();
			
			double numOperationsLeftTemp=jobCompletionRate.get(key);
			Double completionOfLastOperation=jobCompletionTime.get(key);

			if(completionOfLastOperation==null){
				uncompleteOperations=uncompleteOperations+numOperationsLeftTemp;
				crji=0.0;
				aux[length]=0.0;
				crj=crj+crji;
			}
			else if(timeInstant>=completionOfLastOperation){
				uncompleteOperations=uncompleteOperations+numOperationsLeftTemp;
				crji=1.0-(numOperationsLeftTemp/jobTotalNumberOperations);
				aux[length]=crji;
				crj=crj+crji;
			}
			else{
				uncompleteOperations=uncompleteOperations+numOperationsLeftTemp+1;
				crji=1.0-((numOperationsLeftTemp+1)/jobTotalNumberOperations);
				aux[length]=crji;
				crj=crj+crji;
			}
		}

		double standardDeviation=0.0;
		double cro=(numOperations-uncompleteOperations)/numOperations;
		double crjMean=crj/length;

		int i;
		for(i = 1; i <= length; i++){
			standardDeviation += Math.pow(aux[i] - crjMean, 2);
		}		

		double crjSD=standardDeviation/length;
		crjSD=Math.sqrt(crjSD);
		double[] resultado = {cro,crjMean,crjSD};
        return resultado;
	}

	public double[] tardinessKPI(){
		double nLeft=0.0;
		double nTard=0.0;
		double nTardEstimated=0.0;
		for (ActualJob key : jobCompletionRate.keySet()) {
			double numOperationsLeftTemp=jobCompletionRate.get(key);
			double completionOfLastOperationTemp=0.0;
			double remainingProcessingTimeTemp=key.remainingProcessingTime;
			try 				{completionOfLastOperationTemp=jobCompletionTime.get(key);}
			catch(Exception e)	{completionOfLastOperationTemp=0.0;}
			if(timeInstant<completionOfLastOperationTemp){
				numOperationsLeftTemp=numOperationsLeftTemp+1;
				remainingProcessingTimeTemp=remainingProcessingTimeTemp+completionOfLastOperationTemp-timeInstant;
			}
			if(numOperationsLeftTemp!=0){
				nLeft=nLeft+numOperationsLeftTemp;
				if(completionOfLastOperationTemp>key.dueDate){
					nTard=nTard+numOperationsLeftTemp;
				}
			
				if(timeInstant+remainingProcessingTimeTemp>key.dueDate){
					double fraction=0.0;
					if(remainingProcessingTimeTemp==0){
						if(timeInstant>=key.dueDate){
							fraction=0.0;
						}
						else{
							fraction=(key.dueDate-timeInstant)/(completionOfLastOperationTemp-timeInstant);
						}
					}
					else{
						if(timeInstant>=key.dueDate){
							fraction=0.0;
						}
						else{
							fraction=(key.dueDate-timeInstant)/remainingProcessingTimeTemp;
						}
						
					}
					double nIncompleteOps=(1-fraction)*numOperationsLeftTemp;
					nIncompleteOps=Math.ceil(nIncompleteOps);
					nTardEstimated=nTardEstimated+nIncompleteOps;
				}
			}
		}

		double estimatedTard=nTardEstimated/nLeft;
		// if(estimatedTard>1.1){
		// 	estimatedTard=1000;
		// }
		double actualTard=nTard/nLeft;
		double[] resultado={estimatedTard,actualTard};
		if(actualTard>estimatedTard){
			System.out.println("algo está mal");
		}
		return resultado;
	}

	public double getEpisodeTotalTardiness(){
		//o metodo getEpisodeTotalTardiness difere do metodo homonimo do PerformanceMetrics pois considera os 20 jobs iniciais

		double totalTardiness=0;

		for (ActualJob key : jobCompletionRate.keySet()) {
			if(key.getId() <= GlobalParameters.MAX_JOBS_STEADY_STATE){
				double dueDate=key.getDueDate();
				double finishTime=0.0;
				try					{finishTime=jobCompletionTime.get(key);}
				catch(Exception e)	{finishTime=0.0;}

				if(dueDate < finishTime){
					totalTardiness =  totalTardiness + finishTime - dueDate;
				}
			}
			//System.out.println(key.getId()+" - "+String.valueOf(key.arrivalTime)+" - "+String.valueOf(finishTime)+" - "+String.valueOf(dueDate));
		}

		return totalTardiness;
	}

	public double getEpisodeTotalTardinessStable(){
		//o metodo getEpisodeTotalTardiness difere do metodo homonimo do PerformanceMetrics pois considera os 20 jobs iniciais

		double totalTardiness=0;

		for (ActualJob key : jobCompletionRate.keySet()) {
			if((key.getId() > GlobalParameters.MIN_JOBS_STEADY_STATE) && (key.getId() <= GlobalParameters.MAX_JOBS_STEADY_STATE)){
				double dueDate=key.getDueDate();
				double finishTime=jobCompletionTime.get(key);

				if(dueDate < finishTime){
					totalTardiness =  totalTardiness + finishTime - dueDate;
				}
				//System.out.println(key.getId()+" - "+String.valueOf(key.arrivalTime)+" - "+String.valueOf(finishTime)+" - "+String.valueOf(dueDate) +" - "+String.valueOf(finishTime - dueDate));
			}
		}

		return totalTardiness;
	}

	public double[] getStatusCustom(){
		double remainingWork=0.0;
		double totalSlack=0.0;
		

		for(ActualJob key : jobCompletionTime.keySet()){
			double numOperationsLeftTemp=jobCompletionRate.get(key);
			double completionOfLastOperationTemp=jobCompletionTime.get(key);

			if(timeInstant<completionOfLastOperationTemp){
				numOperationsLeftTemp=numOperationsLeftTemp+1;
			}
			if(numOperationsLeftTemp>0.0){
				remainingWork=remainingWork+key.getRemainingProcessingTime();
				totalSlack=totalSlack+(key.getDueDate() - timeInstant - key.getRemainingProcessingTime());
			}
			
		}

		double[] resultado={remainingWork,totalSlack};
		return resultado;
	}

	// LOGIC FOR DISRUPTION MANAGEMENT

	public void setNextDisruptionTimestep(){
		disruptionTimeStep = disruptionTimeStep + (int) Utils.getDisruptionTimestepSample(400, 600);			// Hard Coded
		disruptionTimeStep = 1600;
	}

	public int getDisruptionTimestep(){
		return disruptionTimeStep;
	}

	public boolean ifDisruption(){
		boolean out = false;
		if (numJobsCumulative == disruptionTimeStep){
			out=true;
		}
		if (disruptionTimeStep < 0){						// obter update inicial
			disruptionTimeStep = (int) Utils.getDisruptionTimestepSample(400, 600);					// manter as instancias intactas
			disruptionTimeStep = 800;																		   // HARD CODED, primeira mudanca aos 1000 jobs
		}
		return out; 
	}

	// LOGIC FOR WINDOW MANAGEMENT
	public int ruleUpdateNecessary(){
		int out = 0;
		if (numJobsCumulative>lastWindowUpdate){										// numero de jobs que chegam
			if (numJobsCumulative % GlobalParameters.WINDOWINTERVAL == 0){				// window chegou ao fim
				out = 1;																// e necessario update
				lastWindowUpdate = numJobsCumulative;									// atualiza o momento do ultimo update
			}
		}
		return out; 
	}

	public void windowLenghtCorrection(){
		// manter as instancias coerentes mesmo com windows maiores
		if (numJobsCumulative>lastWindowUpdate){
			if (numJobsCumulative % 50 == 0){											// HC HARD CODED
				if (numJobsCumulative % GlobalParameters.WINDOWINTERVAL != 0){																				
					double rdNum = Utils.getRandomNumber(0,1);
					lastWindowUpdate = numJobsCumulative;										
				}
			}
		}
	}

	public int randomForestRegressorPredictionAlt(double var1, double var2, double var3, double var4, double var5, double var6, double var7, double var8, double var9){
		int[] 		ruleCodeList     =   { 18  , 214  , 508  };
		double[]	outputs			 =   {  0.0,   0.0,   0.0};
		// get rules prediction
		for (int r = 0; r < RandomForestRegressor.numRules; r++){
			int    ruleID     = ruleCodeList[r];
			double out        = -1.0;
			int    controlo   = 0;		
			for (int p = 0; p < RandomForestRegressor.nPaths[r]; p++){
				try {
					Method method = RandomForestRegressor.class.getDeclaredMethod("checkDT"+ruleID+"Tree0Path"+p, double.class, double.class, double.class, double.class, double.class, double.class, double.class, double.class, double.class);
					out = (double) method.invoke(null, var1, var2, var3, var4, var5, var6, var7, var8, var9 ) ;
					if (out != -1.0) {
						outputs[r] = out;
						p = RandomForestRegressor.nPaths[r]; // sai da tree
						controlo = 1;
					}			
				} catch (NoSuchMethodException e) {		e.printStackTrace();
				} catch (SecurityException e) {			e.printStackTrace();
				} catch (IllegalAccessException e) {	e.printStackTrace();
				} catch (IllegalArgumentException e) {	e.printStackTrace();
				} catch (InvocationTargetException e) {	e.printStackTrace();
				}
			}

			if (controlo==0){
				System.out.println("A observacao nao encontrou um path!!!");
			}
		}
		int		ruleCode	=	0;
		double min = Math.min(outputs[0], Math.min(outputs[1], outputs[2]) );
		if 		(outputs[2] == min){
			ruleCode = 508;
		}
		else if (outputs[1] == min) {
			ruleCode = 214;
		}
		else {
			ruleCode =  18;
		}

		return ruleCode;
	}

	public int randomForestRegressorPrediction(double var1, double var2, double var3, double var4, double var5, double var6){
		int ruleID = -1;
		int nPaths[];
		
		double contador_508 = 0;
		double contador_214 = 0;
		double contador_18  = 0;

		double out;

		int controlo = 0;
		
		for (int r = 0; r < RandomForestRegressor.numRules; r++){
			if 			(r==0) 	{
				ruleID =  18;
				nPaths = RandomForestRegressor.nPaths_18; 
			}
			else if 	(r==1) 	{
				ruleID = 214;
				nPaths = RandomForestRegressor.nPaths_214;  
			}
			else 				{
				nPaths = RandomForestRegressor.nPaths_508; 
				ruleID = 508; 
			}

			for (int t = 0; t < RandomForestRegressor.nTrees; t++){
				controlo = 0;
				for (int p = 0; p < nPaths[t]; p++){
					try {
						//Class myClass = Class.forName("DecisionTree");
						Method method = RandomForestRegressor.class.getDeclaredMethod("checkDT"+ruleID+"Tree"+t+"Path"+p, double.class, double.class, double.class, double.class, double.class, double.class);
						out = (double) method.invoke(null, var1, var2, var3, var4, var5, var6) ;
						if (out != -1.0) {
							if        			(ruleID==508){contador_508 = contador_508 + out ;}
							else if             (ruleID==214){contador_214 = contador_214 + out ;}
							else                             {contador_18  = contador_18  + out ;}
							p = nPaths[t]; // sai da tree
							controlo = 1;
						}			
					} catch (NoSuchMethodException e) {		e.printStackTrace();
					} catch (SecurityException e) {			e.printStackTrace();
					} catch (IllegalAccessException e) {	e.printStackTrace();
					} catch (IllegalArgumentException e) {	e.printStackTrace();
					} catch (InvocationTargetException e) {	e.printStackTrace();
					}
				}

				if (controlo == 0) {
					System.out.println("problema a encontrar a prediction");
				}
			}
		}

		double min = Math.min(contador_508, Math.min(contador_214, contador_18) );
		// nao e necessario dividir por 10, numTrees

		if 				(contador_508 == min){
			ruleID = 508;
		}
		else if 		(contador_214 == min) {
			ruleID = 214;
		}
		else {
			ruleID =  18;
		}

		return ruleID;
	}

	public int randomForestPrediction(double var1, double var2, double var3, double var4, double var5, double var6, double var7, double var8, double var9){

		// # 18    n jobs js                  17	var1
		// # 19    wip js                     18	var2
		// # 20    rpt js                     19	var3
		// # 21    rpt js                     20 			esta repetido !!
		// # --    tpt js                     -- 	var4	e sempre zero
		// # 22    allowance js               21	var5
		// # 23    slack js                   22	var6
		// # 24    e tard js                  23	var7
		// # 25    earliness js               24	var8
		// # 26    lateness js                25	var9

		int out = -2;
		int contador_508 = 0;
		int contador_214 = 0;
		int contador_18  = 0;

		for (int t = 0; t < RandomForest.nTrees; t++){
			for (int p = 0; p < RandomForest.nPaths[t]; p++){
				try {
					//Class myClass = Class.forName("DecisionTree");
					Method method = RandomForest.class.getDeclaredMethod("checkDTTree"+t+"Path"+p, double.class, double.class, double.class, double.class, double.class, double.class, double.class, double.class, double.class);
					out = (int) method.invoke(null, var1, var2, var3, var4, var5, var6, var7, var8, var9) ;
					if (out != -1) {
						if        			(out==508){contador_508=contador_508+1;}
						else if             (out==216){contador_214=contador_214+1;}				// HC rule codes
						else                          {contador_18=contador_18+1;}
						p = RandomForest.nPaths[t]; // sai da tree
					}			
				} catch (NoSuchMethodException e) {		e.printStackTrace();
				} catch (SecurityException e) {			e.printStackTrace();
				} catch (IllegalAccessException e) {	e.printStackTrace();
				} catch (IllegalArgumentException e) {	e.printStackTrace();
				} catch (InvocationTargetException e) {	e.printStackTrace();
				}
			}
		}

		if (contador_508 + contador_214 + contador_18 != RandomForest.nTrees){
			System.out.println("Problema no Voting");
		}

		int max = Math.max(contador_508, Math.max(contador_214, contador_18) );

		if 				(contador_508 == max){
			out = 508;
		}
		else if 		(contador_214 == max) {
			out = 216;
		}
		else {
			out=18;
		}

		return out;
	}

	public int decisionTreePrediction(double var1, double var2, double var3, double var4, double var5, double var6, double var7, double var8, double var9, double var10, double var11, double var12){
		int out = -2;
		for (int i = 0; i < DecisionTree.nPaths; i++){
			try {
				//Class myClass = Class.forName("DecisionTree");
				Method method = DecisionTree.class.getDeclaredMethod("checkDTPath"+i, double.class, double.class, double.class, double.class, double.class, double.class , double.class , double.class, double.class, double.class, double.class, double.class);
				out = (int) method.invoke(null, var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12) ;
				if (out != -1) { i = DecisionTree.nPaths; }
			} catch (NoSuchMethodException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SecurityException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return out;
	}

	public int isSequenceOver(Window window, double u, double a, int n){
		int out = 1;
		// code to read the window data
		// i  u  a  s
		// choose the seed properly

		//System.out.println ("sequenceFiles\\"+ GlobalParameters.INSTANCETOTEST + " " + u + " " + (int)a + " "+ (n+1001) +".txt");

		File file = new File("sequenceFiles\\"+ GlobalParameters.INSTANCETOTEST + " " + u + " " + (int)a + " "+ (n+1001) +".txt");
	
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(file));
			String st;
			while ((st = br.readLine()) != null){
				System.out.println(st);
				String[] tokens = st.split(", ");
				int[] token = {0,0};
				token[0] = Integer.parseInt(tokens[0]) ;
				token[1] = Integer.parseInt(tokens[1]) ;

				if (token[1]==9999) {											// hard code
					out = 0;
					break;
				}
			}
		}
		catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println ("nao encontrou ficheiro");
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return out;
	}

	public void readRuleSequence(Window window, double u, double a, int n){
		int windowCode = (int) numJobsCumulative/GlobalParameters.WINDOWINTERVAL;
		if (windowCode < GlobalParameters.WINDOWLIMIT){
			// code to read the window data
			// i  u  a  s
			// choose the seed properly

			System.out.println ("sequenceFiles\\"+ GlobalParameters.INSTANCETOTEST + " " + u + " " + (int)a + " "+ (n+1001) +".txt");

			File file = new File("sequenceFiles\\"+ GlobalParameters.INSTANCETOTEST + " " + u + " " + (int)a + " "+ (n+1001) +".txt");
	 
			BufferedReader br;
			try {
				br = new BufferedReader(new FileReader(file));
				String st;
				while ((st = br.readLine()) != null){
					System.out.println(st);
					String[] tokens = st.split(", ");
					int[] token = {0,0};
					token[0] = Integer.parseInt(tokens[0]) ;
					token[1] = Integer.parseInt(tokens[1]) ;

					if (token[0]==windowCode) {
						GlobalParameters.BENCHMARK_RULE = token[1];
						window.setRule(GlobalParameters.BENCHMARK_RULE);
						break;
					}
				}
			}
			catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println ("nao encontrou ficheiro");
			}
			catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
			
	}

	public Boolean jobShopUnderControl( double windowArrivalRateTemp, double maxTimeInQueueTemp, double maxPT){
		// if operations are getting stuck then apply an emergy rule
		// emergency rule is longer time in queue

		Boolean out = false;
		double x = windowArrivalRateTemp;

		// for instance type 6
		if ( maxPT <51 ){																	// HC, HARD CODED
			// double upperLimit = ( (-460.31) * x * x ) + ( 9280.6 * x ) - 31435;
			//double upperLimit = ( (-483.86 * x * x ) + (10020 * x) - 37151 );
			double upperLimit = 7500;
			if ( (maxTimeInQueueTemp > upperLimit) && (windowArrivalRateTemp>0.0) ) {
				out = true;
			}
		}
		else{
			//double upperLimit = ( (-32.509) * x * x ) + ( 1107 * x ) + 4821.5;
			double upperLimit = 14000;
			if ( (maxTimeInQueueTemp > upperLimit) && (windowArrivalRateTemp>0.0) ) {
				out = true;
			}
		}

		/* if ( GlobalParameters.VERBOSE ) {											// GlobalParameters.VERBOSE
			System.out.println( "XX " + String.valueOf(windowArrivalRateTemp) + ", " + String.valueOf(upperLimit) + ", " + String.valueOf( maxTimeInQueueTemp ) );
		} */

		return out;
	}

	public void updateRuleForNextWindow(Window window, NeuralNetClassFlex nn, NeuralNetRegressor nnReg,  SvmClassifier svm,    SvmRegressor svmReg, double [] windowState, int instanceInfo, double [] utilAllowArray){
		int ruleCode = 0;
		
		// get window metric	(stand by)
		// get classifier decision or a rand decision (for training)		
		if (numJobsCumulative % 50 == 0){								// HC HARD CODED
			double rdNum = Utils.getRandomNumber(0,1);

			if  (rdNum < 0.33){
				ruleCode = 18;											// rr
			}
			else if(rdNum< 0.66){
				ruleCode = 214;											// hunt2
			}
			else{
				ruleCode = 508;											// alvaro9
			}
		}

		GlobalParameters.BENCHMARK_RULE = ruleCode;

		// STATE COMPUTATION		
		//int dtPrediction = 0;
		double iatEffective = window.getPreviousArrivalRate();																// o arriaval rate efetivo TEM de estar atualizado
		double numOfArrivals= numJobsCumulative;
		double expArrivals  = 1.0;
		if (timeInstant>0){	expArrivals  = window.getArrivalRateReference() * timeInstant; }								// o arriaval rate de referencia TEM de estar atualizado										
		
		// MODEL PREDICTION, available models
			// randomForestRegressorPredictionAlt() (windowState[0], windowState[1], windowState[2], windowState[3], windowState[4], windowState[5], window.getWindowArrivalRate(), window.getEpisodeArrivalRate() , window.getInitialTardiness() , window.getWindowInitialRPT(), window.getBottleneckLoad(), window.getBootleneckSlack(), window.getInitialTiQ(), window.getAvgOrderPT());
			// decisionTreePrediction()
			// randomForestPrediction( tenho de enviar as 9 vars )	

			/* outputFeatureArray[0] =    (double) nJobs;
			   outputFeatureArray[1] =    jsWip;
			   outputFeatureArray[2] =    jsRpt;
			   outputFeatureArray[3] =    totalPTs;
			   outputFeatureArray[4] =    allo;
			   outputFeatureArray[5] =    slk;
			   outputFeatureArray[6] =    estTard;
			   outputFeatureArray[7] =    lat;
			   outputFeatureArray[8] =    earl; */

			//            0         1        2        3        4         5          6            8          7
			//   #[    'nJobs', 'wipJS' , 'rptJS', 'tptJS', 'allowJS', 'slkJS' , 'eTardJS',  'eEarlJS',  'eLatJS'   ]

		int dtPrediction   = GlobalParameters.WINDOWRULE;		// modo RL
		//int dtPrediction = randomForestPrediction(utilAllowArray[0], utilAllowArray[1], utilAllowArray[2], utilAllowArray[3]  ,  utilAllowArray[4] ,  utilAllowArray[5], utilAllowArray[6],  utilAllowArray[8] ,  utilAllowArray[7]);
		//int dtPrediction = randomForestRegressorPredictionAlt( utilAllowArray[0], utilAllowArray[1], utilAllowArray[2], utilAllowArray[3]  ,  utilAllowArray[4] ,  utilAllowArray[5], utilAllowArray[6],  utilAllowArray[8] ,  utilAllowArray[7]);
		//int dtPrediction = nn.getNNSugestion(utilAllowArray[1], utilAllowArray[6],utilAllowArray[8] , utilAllowArray[7]);
		//int dtPrediction = svm.getSvmSuggestion(utilAllowArray[1], utilAllowArray[6],utilAllowArray[8] , utilAllowArray[7]);
		//int dtPrediction   = nnReg.getSuggestion(utilAllowArray[1], utilAllowArray[6],utilAllowArray[8] , utilAllowArray[7]);
		//int dtPrediction   = svmReg.getSvmSuggestion(utilAllowArray[1], utilAllowArray[6],utilAllowArray[8] , utilAllowArray[7]);

		if (dtPrediction<0) {
			System.out.println("Decision Tree Bug");
			//System.out.println(String.valueOf(windowState[0]) + ", "+ String.valueOf(windowState[1]) + ", " + String.valueOf(windowState[2]) + ", " + String.valueOf(windowState[3]) + ", " + String.valueOf(windowState[4]) + ", " + String.valueOf(windowState[5]));
			GlobalParameters.BENCHMARK_RULE = 508;					// sera a regra neutra	
		}
		else{
			GlobalParameters.BENCHMARK_RULE = dtPrediction;	
		}

		/* if ( (window.getWindowInitialRPT()>4000) && (dtPrediction == 214)){
			GlobalParameters.BENCHMARK_RULE = 18;	
		} */
		
		//System.out.println( dtPrediction );		

		/* if ( jobShopUnderControl( window.getEpisodeArrivalRate(), window.getInitialTiQ(), instanceInfo ) ){						// it is true if it is not under control
			GlobalParameters.BENCHMARK_RULE = 9999;
			// System.out.println("Rule override");
		} */

		int windowCode = (int) numJobsCumulative/GlobalParameters.WINDOWINTERVAL;
		if (windowCode==GlobalParameters.WINDOWLIMIT){
			GlobalParameters.BENCHMARK_RULE= GlobalParameters.WINDOWRULE;
		}

		//GlobalParameters.BENCHMARK_RULE= GlobalParameters.WINDOWRULE;						// forçar o singlepass

		// code to read the window data

		window.setIDX(windowCode);
		window.setRule(GlobalParameters.BENCHMARK_RULE);

		//System.out.println( GlobalParameters.BENCHMARK_RULE );

		if (GlobalParameters.VERBOSE){
			System.out.println(windowCode + " , " + numJobsCumulative + " , " + GlobalParameters.BENCHMARK_RULE);
		}
	}

	public int windowlimitreached(){
		int out = 0;
		
		int windowCode = (int) numJobsCumulative/GlobalParameters.WINDOWINTERVAL;
		if (windowCode>GlobalParameters.WINDOWLIMIT){
			out = 1;
		}

		return out;
	}


	// ----------------------------------------------------------------------

	public void dumpPerformance(double eptard) throws IOException{
        String fileName="";
		if(!GlobalParameters.ONLINE_MODE){
			fileName="performance.txt";
		}
		else{
			fileName="./test/performance.txt";
		}
        BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true));

        String str= String.valueOf(eptard);
		//System.out.println("Tardiness Total da replicacao: "+ str);
        writer.append(str);
        writer.newLine();
          
        writer.close();       
    }
}
